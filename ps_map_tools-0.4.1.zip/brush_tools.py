"""Brush tools, as Hammer has them: make a room of a box, cut a door or a window into a wall, cut a brush with a plane,
build stairs (steps seen, a clip ramp to walk on), a cylinder and an arch. Every piece made is a brush of its own."""
import math
import time

import bmesh
import bpy
from bpy_extras import view3d_utils
from mathutils import Matrix, Vector

from . import UNIT, apply_grid, object_mode, deselect_all, child_collection, ensure_materials, make_brush, material, snapped_cursor, is_brush, TOOLS


def world_box(obj):
    # From the mesh's own corners and the object's own place (location, turn, scale), not obj.bound_box and matrix_world:
    # those are worked out with the scene's update, and an operator run again from its panel (a slider dragged: undone,
    # then done again) sees them from before the undo — the wall taken for one somewhere else.
    mw = obj.matrix_basis if obj.parent is None else obj.matrix_world
    corners = [mw @ v.co for v in obj.data.vertices] if obj.type == "MESH" and obj.data.vertices else \
        [mw @ Vector(c) for c in obj.bound_box]
    lo = Vector((min(c.x for c in corners), min(c.y for c in corners), min(c.z for c in corners)))
    hi = Vector((max(c.x for c in corners), max(c.y for c in corners), max(c.z for c in corners)))
    return lo, hi


def low_corner(points):
    return Vector([min(p[k] for p in points) for k in range(3)])


def origin_to_corner(obj):
    """The brush's origin at the low corner of its box (as Hammer snaps a brush by its corner): moved with the grid snap
    (which moves the origin onto the grid), its corners stay on the grid."""
    mw = obj.matrix_world
    corner = low_corner([mw @ v.co for v in obj.data.vertices])
    offset = mw.inverted() @ corner
    if offset.length < 1e-7:
        return
    for v in obj.data.vertices:
        v.co -= offset
    obj.data.update()
    obj.matrix_world = Matrix.Translation(corner - mw.translation) @ mw


def bake_transform(obj):
    """The object's scale and turn into its mesh: a brush is its corners (as in Hammer), its object only placed (scale 1,
    no turn), so the grid means the same on it as everywhere. A mesh shared with another object (Alt+D) is left alone."""
    mw = obj.matrix_world.copy()
    location = mw.translation.copy()
    m3 = mw.to_3x3()
    plain = all(abs(m3[i][j] - (1.0 if i == j else 0.0)) < 1e-6 for i in range(3) for j in range(3))
    # Something parented to it (a lamp on a brush) would be moved: the brush is left placed as it is.
    if plain or obj.data.users > 1 or obj.children:
        return False
    for v in obj.data.vertices:
        v.co = (mw @ v.co) - location
    if mw.to_3x3().determinant() < 0:
        obj.data.flip_normals()  # mirrored: the faces turned outward again
    obj.data.update()
    obj.matrix_world = Matrix.Translation(location)
    return True


def box_like(obj):
    """Every face square to the axes (a box, a wall, steps): its corners belong on the grid."""
    rot = obj.matrix_world.to_3x3()
    for f in obj.data.polygons:
        n = (rot @ f.normal).normalized()
        if max(abs(n.x), abs(n.y), abs(n.z)) < 0.9999:
            return False
    return True


def corners_onto_grid(obj, step):
    """The corners onto the grid: of this step, or a finer one when this one would flatten the brush (a wall thinner
    than the grid). True when anything moved."""
    mw = obj.matrix_world
    inv = mw.inverted()
    points = [mw @ v.co for v in obj.data.vertices]
    distinct = len({tuple(round(c, 6) for c in p) for p in points})
    s = step
    while s >= UNIT - 1e-9:
        snapped = [Vector([round(c / s) * s for c in p]) for p in points]
        lo, hi = low_corner(snapped), Vector([max(p[k] for p in snapped) for k in range(3)])
        if min(hi - lo) > 1e-6 and len({tuple(round(c, 6) for c in p) for p in snapped}) == distinct:
            if all((a - b).length < 1e-6 for a, b in zip(points, snapped)):
                return False
            for v, p in zip(obj.data.vertices, snapped):
                v.co = inv @ p
            obj.data.update()
            return True
        s /= 2
    return False


def tidy(obj, step):
    """After a move, a resize or a turn: the transform into the mesh, a box's corners onto the grid, the origin at its
    corner. Round and slanted brushes (arches, cuts, turned off the axes) keep their shape."""
    if obj.children:
        return False  # something parented to it (a lamp on a brush) would move with its origin
    if obj.ps_maker.kind:
        from . import makers
        if makers.kept_turn(obj) and not makers.edited(obj):
            return False  # built from its settings where it stands: placed (moved, turned about the vertical), not reshaped
        makers.plain(obj, "edited by hand")  # reshaped (Edit Mode, scaled): a plain brush of what it is now
    changed = bake_transform(obj)
    if box_like(obj) and not obj.get("ps_round") and not obj.get("ps_cut") and not obj.get("ps_parts"):
        changed = corners_onto_grid(obj, step) or changed
    if changed:
        origin_to_corner(obj)
    return changed


def mesh_brush(name, verts, faces, materials, collection, indices=None):
    """A brush from corner points (world space) and faces; its origin at its low corner (see origin_to_corner)."""
    centre = low_corner([Vector(v) for v in verts])
    mesh = bpy.data.meshes.new(name)
    mesh.from_pydata([Vector(v) - centre for v in verts], [], faces)
    if indices is not None and len(indices) == len(mesh.polygons):
        mesh.polygons.foreach_set("material_index", indices)
    mesh.validate()
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(mesh)
    bm.free()
    obj = bpy.data.objects.new(name, mesh)
    obj.location = centre
    collection.objects.link(obj)
    for m in materials:
        mesh.materials.append(m)
    make_brush(obj)
    return obj


def box_corners(lo, hi):
    """A box's corners and faces (the order box_brush and set_box keep)."""
    verts = [Vector((x, y, z)) for x in (lo[0], hi[0]) for y in (lo[1], hi[1]) for z in (lo[2], hi[2])]
    faces = [(0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1), (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)]
    return verts, faces


def box_brush(name, lo, hi, materials, collection):
    if min(hi[i] - lo[i] for i in range(3)) <= 1e-4:
        return None
    verts = [(x, y, z) for x in (lo[0], hi[0]) for y in (lo[1], hi[1]) for z in (lo[2], hi[2])]
    faces = [(0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1), (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)]
    return mesh_brush(name, verts, faces, materials, collection)


def selected_brushes(context):
    return [o for o in context.selected_objects if is_brush(o)]


def materials_of(obj):
    return [m for m in obj.data.materials if m] or [material("Dev Grey", (0.55, 0.55, 0.55))]


KEPT = ("ps_entity", "ps_surface", "ps_nocollide")  # a brush's own settings: what it is (detail...), its surface


def placed(obj):
    """The object's place (see world_box: matrix_world is stale on a panel redo)."""
    return obj.matrix_basis if obj.parent is None else obj.matrix_world


class Likeness:
    """What a brush cut into pieces (a room, an opening, a cut) passes on to them: its settings (Detail, No collision, its
    surface) and each face's material, by the way the face looks (a wall's concrete side stays concrete)."""

    def __init__(self, obj):
        self.settings = {k: obj[k] for k in KEPT if k in obj}
        rot = placed(obj).to_3x3()
        self.faces = [((rot @ f.normal).normalized(), f.material_index) for f in obj.data.polygons]

    def give(self, piece):
        if piece is None:
            return None
        for k, v in self.settings.items():
            piece[k] = v
        if len(piece.data.materials) > 1 and self.faces:
            for f in piece.data.polygons:
                f.material_index = max(self.faces, key=lambda t: t[0].dot(f.normal))[1]
        return piece


def stairs_left_alone(op, objs):
    """Stairs (steps and their clip ramp in one object) are not cut: cut, the ramp would turn into a seen brush."""
    kept = [o for o in objs if not o.get("ps_parts") or o.ps_maker.kind == "slab"]
    if len(kept) < len(objs):
        op.report({"WARNING"}, "Stairs left as they are (Stairs makes them again with other settings)")
    return kept


def select_only(context, objs):
    deselect_all(context)
    for o in objs:
        o.select_set(True)
    if objs:
        context.view_layer.objects.active = objs[-1]


def set_box(obj, lo, hi):
    """Reshapes a box brush made by box_brush (its corners in the same order) to span lo..hi."""
    centre = lo.copy()
    corners = [Vector((x, y, z)) - centre for x in (lo.x, hi.x) for y in (lo.y, hi.y) for z in (lo.z, hi.z)]
    for v, co in zip(obj.data.vertices, corners):
        v.co = co
    obj.location = centre
    obj.data.update()


def flat_view_at(context, event):
    """The 3D view region under the mouse and, for a flat view (top, front, side, orthographic), the axis it looks along."""
    for area in context.window.screen.areas:
        if area.type != "VIEW_3D":
            continue
        def under(region):
            return region.x <= event.mouse_x < region.x + region.width and region.y <= event.mouse_y < region.y + region.height
        # The sidebar, the toolbar, the headers lie over the view (region overlap): a click on them is not in the view.
        if any(r.type != "WINDOW" and r.width > 1 and r.height > 1 and under(r) for r in area.regions):
            continue
        for region in area.regions:
            if region.type == "WINDOW" and region.x <= event.mouse_x < region.x + region.width \
                    and region.y <= event.mouse_y < region.y + region.height:
                rv3d = region.data
                look = rv3d.view_rotation @ Vector((0, 0, -1))
                axis = max(range(3), key=lambda k: abs(look[k]))
                flat = rv3d.view_perspective == "ORTHO" and abs(look[axis]) > 0.999
                return region, rv3d, axis if flat else None
    return None, None, None


def box_under(region, rv3d, view_axis, lo, hi, mouse, pick=8):
    """Where the mouse is on a box seen in a flat view: (the sides under it [(axis, 0 low / 1 high)], inside it). Sides
    within `pick` pixels of the mouse; inside: within the box and on no side. (None, False): off it."""
    px = view3d_utils.location_3d_to_region_2d
    m = Vector(mouse)
    sides, inside = [], True
    for k in (k for k in range(3) if k != view_axis):
        q = lo.copy()
        q[k] = hi[k]
        s0, s1 = px(region, rv3d, lo), px(region, rv3d, q)
        if s0 is None or s1 is None:
            return None, False
        d = s1 - s0
        n = d.length
        if n < 1e-6:
            return None, False
        t = (m - s0).dot(d / n)
        if t < -pick or t > n + pick:
            return None, False
        if abs(t) <= pick:
            sides.append((k, 0))
        elif abs(t - n) <= pick:
            sides.append((k, 1))
        if not 0 <= t <= n:
            inside = False
    return sides, inside and not sides


def draw_box_handles(region, rv3d, view_axis, lo, hi, hot, colour=(1.0, 0.85, 0.2, 1.0)):
    """Hammer's handles on a box in a flat view: a square at each side's middle and each corner, `hot` ones filled."""
    import gpu
    from gpu_extras.batch import batch_for_shader
    a, b = [k for k in range(3) if k != view_axis]
    px = view3d_utils.location_3d_to_region_2d
    empty, full = [], []
    for ea in (0, 0.5, 1):
        for eb in (0, 0.5, 1):
            if ea == 0.5 and eb == 0.5:
                continue
            p = lo.copy()
            p[a] = lo[a] + (hi[a] - lo[a]) * ea
            p[b] = lo[b] + (hi[b] - lo[b]) * eb
            s = px(region, rv3d, p)
            if s is None:
                continue
            mine = set()
            if ea != 0.5:
                mine.add((a, int(ea)))
            if eb != 0.5:
                mine.add((b, int(eb)))
            quad = [(s.x - 4, s.y - 4), (s.x + 4, s.y - 4), (s.x + 4, s.y + 4), (s.x - 4, s.y + 4)]
            (full if hot and mine == set(hot) else empty).append(quad)
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    shader.uniform_float("color", colour)
    for quad in empty:
        batch_for_shader(shader, "LINE_LOOP", {"pos": quad}).draw(shader)
    for quad in full:
        batch_for_shader(shader, "TRI_FAN", {"pos": quad}).draw(shader)


def finish_rects(area, region):
    """Where a modal tool's Apply and Cancel buttons are in a 3D view (its own coordinates): at the bottom left, right of
    the toolbar, where the tool's panel (F9) comes once it is done."""
    s = bpy.context.preferences.system.ui_scale
    left = 8 * s
    for r in area.regions:
        if r.type == "TOOLS" and r.width > 1:
            left += r.width
    w, h, gap, y = 96 * s, 26 * s, 6 * s, 12 * s
    return {"apply": (left, y, left + w, y + h), "cancel": (left + w + gap, y, left + 2 * w + gap, y + h)}


def draw_finish_buttons(area, region, under=None):
    """The Apply and Cancel buttons drawn (`under`: the one the mouse is on, lighter)."""
    import blf
    import gpu
    from gpu_extras.batch import batch_for_shader
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    gpu.state.blend_set("ALPHA")
    s = bpy.context.preferences.system.ui_scale
    for name, (x0, y0, x1, y1) in finish_rects(area, region).items():
        quad = [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]
        shader.uniform_float("color", (0.33, 0.33, 0.33, 0.95) if name == under else (0.16, 0.16, 0.16, 0.92))
        batch_for_shader(shader, "TRI_FAN", {"pos": quad}).draw(shader)
        shader.uniform_float("color", (0.45, 0.62, 0.95, 1.0) if name == "apply" else (0.5, 0.5, 0.5, 1.0))
        batch_for_shader(shader, "LINE_LOOP", {"pos": quad}).draw(shader)
        text = "Apply (Enter)" if name == "apply" else "Cancel (Esc)"
        blf.size(0, 12 * s)
        tw, th = blf.dimensions(0, text)
        blf.color(0, 1.0, 1.0, 1.0, 1.0)
        blf.position(0, (x0 + x1 - tw) / 2, (y0 + y1 - th) / 2 + 1, 0)
        blf.draw(0, text)
    gpu.state.blend_set("NONE")


def finish_button_at(context, event):
    """The Apply or Cancel button under the mouse in any 3D view, or None."""
    for area in context.window.screen.areas:
        if area.type != "VIEW_3D":
            continue
        for region in area.regions:
            if region.type != "WINDOW":
                continue
            x, y = event.mouse_x - region.x, event.mouse_y - region.y
            if not (0 <= x < region.width and 0 <= y < region.height):
                continue
            for name, (x0, y0, x1, y1) in finish_rects(area, region).items():
                if x0 <= x <= x1 and y0 <= y <= y1:
                    return name
    return None


def view_axis_of(rv3d):
    """The axis a flat view looks along, or None (the perspective view, a turned one)."""
    if rv3d is None or rv3d.view_perspective != "ORTHO":
        return None
    look = rv3d.view_rotation @ Vector((0, 0, -1))
    axis = max(range(3), key=lambda k: abs(look[k]))
    return axis if abs(look[axis]) > 0.999 else None


ZONES = ("bombsite", "buyzone", "killzone", "ladder", "radarlayer", "ambient")  # volume entities: boxes, as brushes are
# Keys that end the drawing and the resizing tools first (then do what they do): menus, Blender's own transforms.
DONE_KEYS = {"Q", "F", "TAB", "G", "S", "R", "X", "DEL", "W", "E", "A", "D", "M", "H"}


class MAP_OT_draw_brush(bpy.types.Operator):
    bl_idname = "psmap.draw_brush"
    bl_label = "Draw brush"
    bl_description = ("Hammer's block tool. Drag a rectangle in a flat view (top, front or side), then drag in another flat "
                      "view for its height. Then: drag its yellow handles (a side, a corner) to resize it, inside it to "
                      "move it, outside it to draw it again; Ctrl+Z takes back the last of these. Enter, Esc or right "
                      "click: done (or its Apply / Cancel at the bottom left of the views, while drawing)")
    # No panel (F9) after it: its Apply and Cancel are in the views while it draws (no execute: nothing to run again).
    bl_options = {"REGISTER", "UNDO"}
    _last = {}  # axis -> (lo, hi) of the last box drawn: a new box takes its depth from it, as in Hammer
    _running = []  # the one drawing now: started again (Q, the button) while it draws, it ends first (its box kept)

    def invoke(self, context, event):
        if context.object is not None and context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        ensure_materials()
        apply_grid(context)
        # Names, not the objects: an undo while drawing rebuilds every data-block, a kept reference would point at freed memory.
        self.box_name, self.lo, self.hi, self.axis, self.drag, self.made = None, None, None, None, None, 0
        self.tall = False   # its height drawn in a second view: from then on, handles there too
        self.hover = None   # (region pointer, sides) under the mouse, for the handles drawn filled
        self.hover_button = None  # its Apply / Cancel under the mouse
        self.history = []   # the box before each drag (had a box, lo, hi, first view, its height drawn): Ctrl+Z
        # The box being drawn is known by a mark of its own, not by its name alone: removed meanwhile (a tool, X), the
        # name may be another brush's ("Brush" is common), and that one would be reshaped.
        self.token = int(time.time() * 1000) % 2_000_000_000
        self._stop = False
        for old in MAP_OT_draw_brush._running:
            try:
                old.keep(context)
                old.finish(context)
                old._stop = True  # it ends on its next event (its handles gone already)
            except ReferenceError:
                pass
        MAP_OT_draw_brush._running[:] = [self]
        self._draw = bpy.types.SpaceView3D.draw_handler_add(self.draw_handles, (), "WINDOW", "POST_PIXEL")
        context.window_manager.modal_handler_add(self)
        self.status(context)
        return {"RUNNING_MODAL"}

    @property
    def box(self):
        obj = bpy.data.objects.get(self.box_name) if self.box_name else None
        return obj if obj is not None and obj.get("ps_drawing") == self.token else None

    def status(self, context, text=None):
        if text is None:
            if self.box is None:
                text = "Draw brush: drag a rectangle in a flat view (top, front, side)   |   Esc / right click: done"
            elif not self.tall:
                text = ("Draw brush: drag in another flat view for the height; handles: resize, inside: move, outside: "
                        "draw again   |   Enter: next brush   |   Esc / right click: done")
            else:
                text = ("Draw brush: handles: resize, inside: move, outside: draw again (another view: the height)   |   "
                        "Enter: next brush   |   Esc / right click: done")
        context.workspace.status_text_set(text)

    def finish(self, context):
        try:
            bpy.types.SpaceView3D.draw_handler_remove(self._draw, "WINDOW")
        except (ValueError, AttributeError):
            pass
        if self in MAP_OT_draw_brush._running:
            MAP_OT_draw_brush._running.remove(self)
        context.workspace.status_text_set(None)
        for area in context.screen.areas:
            area.tag_redraw()

    def point(self, context, region, rv3d, event):
        step = context.scene.ps_grid_units * UNIT
        p = view3d_utils.region_2d_to_location_3d(region, rv3d, (event.mouse_x - region.x, event.mouse_y - region.y),
                                                  context.scene.cursor.location)
        return Vector([round(v / step) * step for v in p])

    def update(self, context, event):
        mode, region, rv3d, axis, start, was = self.drag
        p = self.point(context, region, rv3d, event)
        step = context.scene.ps_grid_units * UNIT
        if mode == "rect":
            # A rectangle in this view: its two directions; the depth from the box drawn, or the last one, or the cursor up.
            if self.box is None:
                self.axis = axis
                lo, hi = Vector(), Vector()
                if axis in MAP_OT_draw_brush._last:
                    lo[axis], hi[axis] = MAP_OT_draw_brush._last[axis]
                else:
                    c = snapped_cursor(context)[axis]
                    lo[axis], hi[axis] = c, c + 128 * UNIT
            else:
                lo, hi = self.lo.copy(), self.hi.copy()
            for k in range(3):
                if k != axis:
                    lo[k], hi[k] = min(start[k], p[k]), max(start[k], p[k])
        elif mode == "height":
            # Another view: only the depth the first view left open.
            k = self.axis
            lo, hi = self.lo.copy(), self.hi.copy()
            lo[k], hi[k] = min(start[k], p[k]), max(start[k], p[k])
        elif mode == "sides":
            # Handles: each side grabbed to the mouse, not through the other side (at least a step, or its own size).
            lo, hi = was[0].copy(), was[1].copy()
            for k, end in was[2]:
                least = min(step, was[1][k] - was[0][k])
                if end == 1:
                    hi[k] = max(p[k], was[0][k] + least)
                else:
                    lo[k] = min(p[k], was[1][k] - least)
        else:  # "move": the whole box along this view's two directions, by whole grid steps
            lo, hi = was[0].copy(), was[1].copy()
            for k in range(3):
                if k != axis:
                    lo[k] += p[k] - start[k]
                    hi[k] += p[k] - start[k]
        self.lo, self.hi = lo, hi
        box = self.box
        if box is None:
            if min(hi[k] - lo[k] for k in range(3) if k != axis) <= 1e-6:
                return
            box = box_brush("Brush", lo, hi, [material("Dev Grey", (0.55, 0.55, 0.55))],
                            child_collection(context.scene, "Seen"))
            self.box_name = box.name
            box["ps_drawing"] = self.token
            select_only(context, [box])
            self.made += 1
        else:
            set_box(box, lo, hi)
        size = " x ".join(str(round(v / UNIT)) for v in hi - lo)
        self.status(context, f"Draw brush: {size} units")

    def undo_step(self, context):
        """The box back as it was before the last drag (none: as before the tool, no box)."""
        box = self.box
        if not self.history:
            if box is not None:
                bpy.data.objects.remove(box, do_unlink=True)
                self.made -= 1
            self.box_name, self.lo, self.hi, self.axis, self.tall = None, None, None, None, False
            self.status(context)
            return
        had, lo, hi, axis, tall = self.history.pop()
        if had:
            if box is None:
                box = box_brush("Brush", lo, hi, [material("Dev Grey", (0.55, 0.55, 0.55))],
                                child_collection(context.scene, "Seen"))
                self.box_name = box.name
                box["ps_drawing"] = self.token
                self.made += 1
            else:
                set_box(box, lo, hi)
            select_only(context, [box])
            self.lo, self.hi, self.axis, self.tall = lo, hi, axis, tall
        elif box is not None:
            bpy.data.objects.remove(box, do_unlink=True)
            self.made -= 1
            self.box_name, self.lo, self.hi, self.axis, self.tall = None, None, None, None, False
        self.status(context, "Draw brush: the last step taken back (Ctrl+Z)")

    def keep(self, context):
        box = self.box
        if box is not None:
            if min(self.hi - self.lo) <= 1e-6:
                bpy.data.objects.remove(box, do_unlink=True)
                self.made -= 1
            else:
                del box["ps_drawing"]
                for k in range(3):
                    MAP_OT_draw_brush._last[k] = (self.lo[k], self.hi[k])
        self.box_name, self.axis, self.tall = None, None, False
        self.status(context)

    def modal(self, context, event):
        if self._stop:
            return {"FINISHED"} if self.made else {"CANCELLED"}
        if (context.mode != "OBJECT" or event.type in DONE_KEYS and event.value == "PRESS") and not self.drag:
            # Into Edit Mode (Tab), a menu (Q: its pie, whose click the tool took for one in the view), Blender's own
            # move, scale, delete...: done first, as Enter (its box kept, its handles gone); the key goes on.
            self.keep(context)
            self.finish(context)
            return {"FINISHED", "PASS_THROUGH"} if self.made else {"CANCELLED", "PASS_THROUGH"}
        for area in context.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()
        if event.type in {"Z", "Y"} and (event.ctrl or event.oskey) and event.value == "PRESS":
            # Blender's undo is not run while drawing (it would pull the data from under the tool): Ctrl+Z takes back the
            # tool's own last step — a redraw by a click outside, a resize, a move, the height — the box as it was.
            if not self.drag:
                self.undo_step(context)
            return {"RUNNING_MODAL"}
        if event.type in {"RET", "NUMPAD_ENTER", "ESC", "RIGHTMOUSE"} and event.value == "PRESS" and not self.drag:
            self.keep(context)
            self.finish(context)
            return {"FINISHED"} if self.made else {"CANCELLED"}
        region, rv3d, axis = flat_view_at(context, event)
        if event.type == "MOUSEMOVE":
            if self.drag:
                self.update(context, event)
                return {"RUNNING_MODAL"}
            box = self.box
            self.hover_button = finish_button_at(context, event) if box is not None else None
            self.hover = None
            if box is not None and axis is not None:
                sides, _ = box_under(region, rv3d, axis, self.lo, self.hi,
                                     (event.mouse_x - region.x, event.mouse_y - region.y))
                if sides:
                    self.hover = (region.as_pointer(), sides)
            return {"PASS_THROUGH"}
        if event.type == "LEFTMOUSE" and event.value == "PRESS" and not self.drag and self.box is not None:
            # Its own Apply / Cancel at the bottom left of the views (the panel F9 shows them only once it is done).
            button = finish_button_at(context, event)
            if button == "apply":
                self.keep(context)
                self.finish(context)
                return {"FINISHED"} if self.made else {"CANCELLED"}
            if button == "cancel":
                bpy.data.objects.remove(self.box, do_unlink=True)
                self.made -= 1
                self.box_name = None
                self.finish(context)
                return {"FINISHED"} if self.made > 0 else {"CANCELLED"}
        if event.type == "LEFTMOUSE":
            if event.value == "PRESS":
                if region is None:
                    # A button (the map tools' panel, a header, another editor): done first, as Esc, and the click
                    # goes on to the button. Make a room, Door, a material: on the box just drawn, an undo step after it.
                    self.keep(context)
                    self.finish(context)
                    return {"FINISHED", "PASS_THROUGH"} if self.made else {"CANCELLED", "PASS_THROUGH"}
                if axis is None:
                    return {"PASS_THROUGH"}  # the perspective view: as usual
                start = self.point(context, region, rv3d, event)
                mouse = (event.mouse_x - region.x, event.mouse_y - region.y)
                had = self.box is not None
                self.history.append((had, self.lo.copy() if had else None, self.hi.copy() if had else None, self.axis,
                                     self.tall))
                mode, was = "rect", None
                if self.box is not None:
                    # Its handles in every flat view: a handle grabbed resizes, inside moves, outside draws it again (the
                    # view it was drawn in) or its height (another one).
                    sides, inside = box_under(region, rv3d, axis, self.lo, self.hi, mouse)
                    if sides:
                        mode, was = "sides", (self.lo.copy(), self.hi.copy(), sides)
                    elif inside:
                        mode, was = "move", (self.lo.copy(), self.hi.copy())
                    else:
                        mode = "rect" if axis == self.axis else "height"
                self.drag = (mode, region, rv3d, axis, start, was)
                return {"RUNNING_MODAL"}
            if event.value == "RELEASE" and self.drag:
                self.update(context, event)
                if self.drag[0] == "height":
                    self.tall = True
                self.drag = None
                self.status(context)
                return {"RUNNING_MODAL"}
        return {"PASS_THROUGH"}  # moving the views (middle mouse, wheel) as usual

    def draw_handles(self):
        context = bpy.context
        if context.mode != "OBJECT":
            return  # Edit Mode: no handles (the tool ends on its next event)
        region, rv3d = context.region, context.region_data
        axis = view_axis_of(rv3d)
        try:
            box = self.box
        except ReferenceError:
            return
        if box is not None and context.area is not None:
            draw_finish_buttons(context.area, region, self.hover_button)
        if box is None or axis is None or self.lo is None:
            return
        hot = None
        if self.drag and self.drag[0] == "sides" and self.drag[1] == region:
            hot = self.drag[5][2]
        elif self.hover and self.hover[0] == region.as_pointer():
            hot = self.hover[1]
        draw_box_handles(region, rv3d, axis, self.lo, self.hi, hot)


class MAP_OT_resize(bpy.types.Operator):
    bl_idname = "psmap.resize"
    bl_label = "Resize"
    bl_description = ("Hammer's handles: in a flat view (top, front, side), drag a side or a corner of the selected brushes "
                      "and it goes along the grid, the other sides staying where they are; click a brush to select it. "
                      "A room or a wall with openings: its sides move its walls (the doors stay where they are), and its "
                      "doors and windows have frames: drag one to move it, its edges to size it. V: edges (a corner dragged "
                      "moves the edge behind it: slanted sides, wedges). Enter, Esc or right "
                      "click: done")
    bl_options = {"REGISTER", "UNDO"}
    PICK = 8  # pixels from a side that grab it

    def invoke(self, context, event):
        object_mode(context)
        apply_grid(context)
        self.drag, self.hover, self.moved = None, None, 0
        self.odrag, self.ohover = None, None  # an opening's frame dragged / under the mouse
        self.hdrag, self.hhover = None, None  # a floor's (or a ceiling's) hole dragged / under the mouse
        self.edges, self.cdrag, self.chover = False, None, None  # V: the edges mode, its corner dragged / under the mouse
        self._draw = bpy.types.SpaceView3D.draw_handler_add(self.draw_handles, (context,), "WINDOW", "POST_PIXEL")
        context.window_manager.modal_handler_add(self)
        self.status(context)
        return {"RUNNING_MODAL"}

    def status(self, context, text=None):
        if text is None and self.edges:
            text = ("Resize, edges: drag a corner in a flat view: the edge behind it moves (on the grid), a slanted side; "
                    "onto another corner: a wedge   |   V: sides again   |   Enter / Esc / right click: done")
        context.workspace.status_text_set(text or "Resize: drag a side or a corner of the selected brushes in a flat view "
                                                  "(on the grid); a door's or a window's frame: inside moves it, its "
                                                  "edges size it   |   V: edges (slanted sides)   |   Enter / Esc / right "
                                                  "click: done")

    def finish(self, context):
        bpy.types.SpaceView3D.draw_handler_remove(self._draw, "WINDOW")
        context.workspace.status_text_set(None)
        for area in context.screen.areas:
            area.tag_redraw()

    @staticmethod
    def picked(context):
        # Brushes, and the zones (bomb sites, buy zones, kill zones, ladders, radar layers): drawn to size the same way.
        from . import makers
        # Rooms and walls made with the map tools too (their pieces in one mesh): sized by their settings.
        return [o for o in context.selected_objects
                if (is_brush(o) or o.type == "MESH" and o.get("ps_entity") in ZONES)
                and not o.get("ps_round") and not o.get("ps_cut") and (not o.get("ps_parts") or makers.resizable(o))]

    # ---------- Openings (doors, windows) of the selected rooms and walls ----------
    def openings_seen(self, context, axis):
        """Each opening of the selected rooms and walls this flat view shows: (object, index, its wall's frame, along (the
        world axis along the wall), whether its height can be dragged here (a view facing the wall; from above: along only))."""
        from . import makers
        out = []
        for obj in self.picked(context):
            p = obj.ps_maker
            if p.kind not in ("room", "wall"):
                continue
            for i, o in enumerate(p.openings):
                frame = makers.wall_frame(obj, int(o.side) if p.kind == "room" else 0)
                place = frame[2]
                a = place(1.0, 0.0, 0.0) - place(0.0, 0.0, 0.0)
                n = place(0.0, 0.0, 1.0) - place(0.0, 0.0, 0.0)
                ka = max(range(3), key=lambda k: abs(a[k]))
                kn = max(range(3), key=lambda k: abs(n[k]))
                if axis == ka:
                    continue  # seen edge on
                out.append((obj, i, frame, a.normalized(), n.normalized(), axis == kn))
        return out

    def opening_at(self, context, region, rv3d, axis, mouse):
        """The opening frame under the mouse: (object name, index, edges [("along" | "up", 0 low / 1 high)] or "move"),
        or None."""
        if axis is None or mouse is None:
            return None
        p0 = view3d_utils.region_2d_to_location_3d(region, rv3d, mouse, context.scene.cursor.location)
        p1 = view3d_utils.region_2d_to_location_3d(region, rv3d, (mouse[0] + self.PICK, mouse[1]), context.scene.cursor.location)
        tol = (p1 - p0).length
        best = None
        for obj, i, (length, height, place, t), a, n, facing in self.openings_seen(context, axis):
            o = obj.ps_maker.openings[i]
            origin = place(0.0, 0.0, 0.0)
            s = (p0 - origin).dot(a)
            s0, s1 = o.offset * UNIT, (o.offset + o.width) * UNIT
            if not s0 - tol <= s <= s1 + tol:
                continue
            edges = [("along", 0)] if abs(s - s0) <= tol else [("along", 1)] if abs(s - s1) <= tol else []
            if facing:
                u = p0.z - origin.z
                u0, u1 = o.sill * UNIT, (o.sill + o.height) * UNIT
                if not u0 - tol <= u <= u1 + tol:
                    continue
                edges += [("up", 0)] if abs(u - u0) <= tol else [("up", 1)] if abs(u - u1) <= tol else []
            else:
                d = (p0 - origin).dot(n)
                if not -tol <= d <= t + tol:
                    continue
            hit = (obj.name, i, edges or "move")
            if best is None or (edges and best[2] == "move"):
                best = hit
        return best

    # ---------- Holes in the selected floors, ceilings and rooms ----------
    def holes_seen(self, context, axis):
        """Each hole this flat view shows: (object, index, its slab's z span (local, metres), which of its sides can be
        dragged here: {"x", "y"} from above, the one across the view from the side)."""
        out = []
        for obj in self.picked(context):
            p = obj.ps_maker
            if p.kind not in ("slab", "room"):
                continue
            turn = obj.matrix_world.to_3x3()
            kx = max(range(3), key=lambda k: abs(turn[k][0]))
            ky = max(range(3), key=lambda k: abs(turn[k][1]))
            dims = {"x", "y"} if axis == 2 else {"y"} if axis == kx else {"x"} if axis == ky else set()
            if not dims:
                continue
            for i, h in enumerate(p.holes):
                if p.kind == "slab":
                    z = (0.0, p.slab_thickness * UNIT)
                elif h.level == "floor":
                    z = (0.0, p.room_thickness * UNIT)
                elif p.ceiling:
                    z = ((p.room_size[2] - p.room_thickness) * UNIT, p.room_size[2] * UNIT)
                else:
                    continue
                out.append((obj, i, z, dims))
        return out

    def hole_at(self, context, region, rv3d, axis, mouse):
        """The hole under the mouse: (object name, index, edges [("x" | "y", 0 low / 1 high)] or "move"), or None."""
        if axis is None or mouse is None:
            return None
        p0 = view3d_utils.region_2d_to_location_3d(region, rv3d, mouse, context.scene.cursor.location)
        p1 = view3d_utils.region_2d_to_location_3d(region, rv3d, (mouse[0] + self.PICK, mouse[1]), context.scene.cursor.location)
        tol = (p1 - p0).length
        best = None
        for obj, i, (z0, z1), dims in self.holes_seen(context, axis):
            h = obj.ps_maker.holes[i]
            local = obj.matrix_world.inverted() @ p0
            spans = {"x": (local.x, h.x * UNIT, (h.x + h.size_x) * UNIT), "y": (local.y, h.y * UNIT, (h.y + h.size_y) * UNIT)}
            if axis != 2 and not z0 - tol <= local.z <= z1 + tol:
                continue  # from the side: on the slab's edge
            ok, edges = True, []
            for d in dims:
                v, a, b = spans[d]
                if not a - tol <= v <= b + tol:
                    ok = False
                    break
                edges += [(d, 0)] if abs(v - a) <= tol else [(d, 1)] if abs(v - b) <= tol else []
            if not ok:
                continue
            hit = (obj.name, i, edges or "move")
            if best is None or (edges and best[2] == "move"):
                best = hit
        return best

    def drag_hole(self, context, value):
        """The dragged hole moved or sized to the mouse (on the grid), kept within its floor."""
        from . import makers
        name, i, edges, dims, start, at0 = self.hdrag[1:]
        obj = bpy.data.objects.get(name)
        if obj is None or i >= len(obj.ps_maker.holes):
            return
        h = obj.ps_maker.holes[i]
        p = obj.ps_maker
        least = context.scene.ps_grid_units
        local = obj.matrix_world.inverted() @ value
        at = {"x": local.x / UNIT, "y": local.y / UNIT}
        size_of = {"x": "size_x", "y": "size_y"}
        whole = {"x": p.room_size[0] if p.kind == "room" else p.slab_x, "y": p.room_size[1] if p.kind == "room" else p.slab_y}
        makers._building[0] = True
        try:
            for d in dims:
                pos0, size0 = start[d]
                if edges == "move":
                    setattr(h, d, pos0 + (at[d] - at0[d]))
                for e, end in (edges if edges != "move" else []):
                    if e != d:
                        continue
                    if end == 0:
                        setattr(h, d, min(at[d], pos0 + size0 - least))
                        setattr(h, size_of[d], pos0 + size0 - getattr(h, d))
                    else:
                        setattr(h, size_of[d], max(least, at[d] - pos0))
                size = min(getattr(h, size_of[d]), whole[d])
                setattr(h, size_of[d], size)
                setattr(h, d, min(max(getattr(h, d), 0.0), whole[d] - size))
        finally:
            makers._building[0] = False
        makers.rebuild(obj)
        self.status(context, f"Hole: {round(h.size_x)} x {round(h.size_y)} u, at {round(h.x)}, {round(h.y)} u")

    def drag_opening(self, context, value):
        """The dragged opening moved or sized to the mouse (on the grid), kept within its wall."""
        from . import makers
        name, i, edges, start, s_start, u_start, origin, a = self.odrag[2:]
        obj = bpy.data.objects.get(name)
        if obj is None or i >= len(obj.ps_maker.openings):
            return
        o = obj.ps_maker.openings[i]
        least = context.scene.ps_grid_units
        s = (value - origin).dot(a) / UNIT
        u = (value.z - origin.z) / UNIT
        offset, width, sill, height = start
        makers._building[0] = True
        try:
            if edges == "move":
                o.offset = offset + (s - s_start)
                if any(e[0] == "up" for e in self.odrag[1]):
                    o.sill = sill + (u - u_start)
            else:
                for dim, end in edges:
                    if dim == "along" and end == 0:
                        o.offset = min(s, offset + width - least)
                        o.width = offset + width - o.offset
                    elif dim == "along":
                        o.width = max(least, s - offset)
                    elif end == 0:
                        o.sill = min(u, sill + height - least)
                        o.height = sill + height - o.sill
                    else:
                        o.height = max(least, u - sill)
            makers.keep_opening_in(obj, o)
        finally:
            makers._building[0] = False
        makers.rebuild(obj)
        self.status(context, f"{'Window' if o.sill > 0 else 'Door'}: {round(o.width)} x {round(o.height)} u, "
                             f"{round(o.offset)} u along the wall, {round(o.sill)} u from the floor")

    # ---------- Edges (V): Hammer's vertex tool in a flat view ----------
    def edge_brushes(self, context):
        """The selected plain brushes (a room's or a wall's settings would be built over the edit)."""
        return [o for o in self.picked(context) if is_brush(o) and not o.ps_maker.kind and not o.get("ps_parts")]

    def corners_seen(self, context, axis):
        """Each corner of the brushes this flat view shows: (object, the vertices behind it along the view (an edge seen
        end on), its point (world)). The corners in one place on screen are one handle."""
        out = []
        for o in self.edge_brushes(context):
            mw = o.matrix_world
            groups = {}
            for v in o.data.vertices:
                w = mw @ v.co
                key = tuple(round(w[k] / (0.1 * UNIT)) for k in range(3) if k != axis)
                g = groups.setdefault(key, ([], w))
                g[0].append(v.index)
            out += [(o, idx, w) for idx, w in groups.values()]
        return out

    def corner_at(self, context, region, rv3d, axis, mouse):
        """The corner handle under the mouse: (object name, its vertices, its point), or None."""
        if axis is None or mouse is None:
            return None
        px = view3d_utils.location_3d_to_region_2d
        best, near = None, self.PICK + 1
        for o, idx, w in self.corners_seen(context, axis):
            s = px(region, rv3d, w)
            if s is None:
                continue
            d = max(abs(s.x - mouse[0]), abs(s.y - mouse[1]))
            if d < near:
                best, near = (o.name, idx, w), d
        return best

    @staticmethod
    def convex_mesh(points, polygons):
        """Every face flat and every corner behind every face (no dent): Hammer keeps a brush so."""
        eps = 1e-4
        for f in polygons:
            pts = [points[i] for i in f]
            n = Vector()
            for i in range(len(pts)):
                a, b = pts[i], pts[(i + 1) % len(pts)]
                n += Vector(((a.y - b.y) * (a.z + b.z), (a.z - b.z) * (a.x + b.x), (a.x - b.x) * (a.y + b.y)))
            if n.length < 1e-9:
                continue  # squashed to nothing (two corners moved onto each other): merged on release
            n.normalize()
            d = n.dot(sum(pts, Vector()) / len(pts))
            side = [n.dot(p) - d for p in points]
            if any(abs(n.dot(p) - d) > eps for p in pts) or (max(side) > eps and min(side) < -eps):
                return False
        return True

    def drag_corner(self, context, value):
        """The dragged edge to the mouse (on the grid), along the view's two directions; not where the brush would get a
        dent or a bent face (it stays at the last place that was fine)."""
        _, axis, name, idx, anchor, start = self.cdrag
        o = bpy.data.objects.get(name)
        if o is None:
            return
        move = value - anchor
        move[axis] = 0.0
        moved = set(idx)
        points = [w + move if i in moved else w for i, w in enumerate(start)]
        if not self.convex_mesh(points, [list(p.vertices) for p in o.data.polygons]):
            self.status(context, "Edges: not there — the brush would get a dent or a bent face")
            return
        inv = o.matrix_world.inverted()
        for v, p in zip(o.data.vertices, points):
            v.co = inv @ p
        o.data.update()
        self.status(context, f"Edges: moved {round(move.length / UNIT)} u")

    def end_corner(self, context):
        """Corners dragged onto each other made one (a box's edge onto another: a wedge)."""
        import bmesh
        o = bpy.data.objects.get(self.cdrag[2])
        if o is None:
            return
        bm = bmesh.new()
        bm.from_mesh(o.data)
        bmesh.ops.remove_doubles(bm, verts=bm.verts[:], dist=0.05 * UNIT)
        bmesh.ops.dissolve_degenerate(bm, edges=bm.edges[:], dist=0.05 * UNIT)
        bm.to_mesh(o.data)
        bm.free()
        o.data.update()
        origin_to_corner(o)
        from . import world_uvs
        world_uvs(o)

    @staticmethod
    def bounds(objs):
        boxes = [world_box(o) for o in objs]
        return (Vector([min(b[0][k] for b in boxes) for k in range(3)]),
                Vector([max(b[1][k] for b in boxes) for k in range(3)]))

    def grab(self, context, region, rv3d, axis, mouse):
        """The sides [(axis, 0 low / 1 high)] of the selection's box under the mouse in this flat view, or None."""
        objs = self.picked(context)
        if not objs or mouse is None:
            return None
        lo, hi = self.bounds(objs)
        px = view3d_utils.location_3d_to_region_2d
        m = Vector(mouse)
        got, inside = [], []
        for k in (k for k in range(3) if k != axis):
            q = lo.copy()
            q[k] = hi[k]
            s0, s1 = px(region, rv3d, lo), px(region, rv3d, q)
            if s0 is None or s1 is None:
                return None
            d = s1 - s0
            n = d.length
            if n < 1e-6:
                return None
            t = (m - s0).dot(d / n)
            inside.append(-self.PICK <= t <= n + self.PICK)
            if abs(t) <= self.PICK:
                got.append((k, 0))
            elif abs(t - n) <= self.PICK:
                got.append((k, 1))
        if not all(inside) or not got:
            return None
        return got

    def where(self, context, region, rv3d, mouse):
        step = context.scene.ps_grid_units * UNIT
        p = view3d_utils.region_2d_to_location_3d(region, rv3d, mouse, context.scene.cursor.location)
        return Vector([round(v / step) * step for v in p])

    def apply(self, context, value):
        """The grabbed sides to where the mouse is: the corners lying on each such side move there."""
        region, rv3d, axis, sides, start_lo, start_hi, names, start = self.drag
        step = context.scene.ps_grid_units * UNIT
        moves, text = [], []
        for k, end in sides:
            old = (start_lo, start_hi)[end][k]
            # Not through the other side: at least a step (or the brush's own size when thinner) left.
            least = min(step, start_hi[k] - start_lo[k])
            new = max(value[k], start_lo[k] + least) if end == 1 else min(value[k], start_hi[k] - least)
            moves.append((k, old, new))
            size = (new - start_lo[k]) if end == 1 else (start_hi[k] - new)
            text.append(f"{'XYZ'[k]}: {round((start_hi[k] - start_lo[k]) / UNIT)} -> {round(size / UNIT)} u")
        from . import makers
        for name in names:
            o = bpy.data.objects.get(name)
            if o is None:
                continue
            if name in self.maker_start:
                lo0, hi0, kept = self.maker_start[name]
                lo, hi = lo0.copy(), hi0.copy()
                for k, old, new in moves:
                    if abs(lo0[k] - old) < 1e-5:
                        lo[k] = new
                    if abs(hi0[k] - old) < 1e-5:
                        hi[k] = new
                if all(hi[k] - lo[k] > 1e-4 for k in range(3)):
                    makers.fill_box(o, lo, hi, kept)
                continue
            inv = o.matrix_world.inverted()
            for v, w in zip(o.data.vertices, start[name]):
                p = w.copy()
                for k, old, new in moves:
                    if abs(w[k] - old) < 1e-5:
                        p[k] = new
                v.co = inv @ p
            o.data.update()
        self.status(context, "Resize: " + ",   ".join(text))

    def modal(self, context, event):
        dragging = self.drag or self.odrag or self.hdrag or self.cdrag
        if (context.mode != "OBJECT" or event.type in DONE_KEYS and event.value == "PRESS") and not dragging:
            # Into Edit Mode (Tab), a menu (Q), Blender's own move, scale...: done, its handles gone; the key goes on.
            self.finish(context)
            return {"FINISHED", "PASS_THROUGH"} if self.moved else {"CANCELLED", "PASS_THROUGH"}
        for area in context.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()
        if event.type in {"RET", "NUMPAD_ENTER", "ESC", "RIGHTMOUSE"} and event.value == "PRESS" and not dragging:
            self.finish(context)
            return {"FINISHED"} if self.moved else {"CANCELLED"}
        if event.type == "V" and event.value == "PRESS" and not dragging:
            self.edges = not self.edges
            self.hover = self.ohover = self.hhover = self.chover = None
            self.status(context)
            if self.edges and not self.edge_brushes(context):
                self.status(context, "Resize, edges: select a plain brush (a room or a wall with openings: Split into "
                                     "brushes first)   |   V: sides again")
            return {"RUNNING_MODAL"}
        region, rv3d, axis = flat_view_at(context, event)
        mouse = (event.mouse_x - region.x, event.mouse_y - region.y) if region else None
        if self.edges:
            return self.modal_edges(context, event, region, rv3d, axis, mouse)
        if event.type == "MOUSEMOVE":
            if self.hdrag:
                d_region, d_rv3d = self.hdrag[0]
                self.drag_hole(context, self.where(context, d_region, d_rv3d,
                                                   (event.mouse_x - d_region.x, event.mouse_y - d_region.y)))
                return {"RUNNING_MODAL"}
            if self.odrag:
                d_region, d_rv3d = self.odrag[0][0], self.odrag[0][1]
                self.drag_opening(context, self.where(context, d_region, d_rv3d,
                                                      (event.mouse_x - d_region.x, event.mouse_y - d_region.y)))
                return {"RUNNING_MODAL"}
            if self.drag:
                d_region, d_rv3d = self.drag[0], self.drag[1]
                self.apply(context, self.where(context, d_region, d_rv3d,
                                               (event.mouse_x - d_region.x, event.mouse_y - d_region.y)))
                return {"RUNNING_MODAL"}
            self.ohover = (region, self.opening_at(context, region, rv3d, axis, mouse)) if axis is not None else None
            self.hhover = (region, None if self.ohover and self.ohover[1] else
                           self.hole_at(context, region, rv3d, axis, mouse)) if axis is not None else None
            taken = (self.ohover and self.ohover[1]) or (self.hhover and self.hhover[1])
            self.hover = (region, None if taken else self.grab(context, region, rv3d, axis, mouse)) \
                if axis is not None else None
            return {"PASS_THROUGH"}
        if event.type == "LEFTMOUSE":
            if event.value == "PRESS":
                if region is None:
                    # A button: done first, as Enter, and the click goes on to it.
                    self.finish(context)
                    return {"FINISHED", "PASS_THROUGH"} if self.moved else {"CANCELLED", "PASS_THROUGH"}
                if axis is None:
                    return {"PASS_THROUGH"}
                hit = self.opening_at(context, region, rv3d, axis, mouse)
                if hit:
                    # A door's or a window's frame: it, not the room, is dragged.
                    obj = bpy.data.objects[hit[0]]
                    o = obj.ps_maker.openings[hit[1]]
                    seen = next(x for x in self.openings_seen(context, axis) if x[0] == obj and x[1] == hit[1])
                    place, a, facing = seen[2][2], seen[3], seen[5]
                    origin = place(0.0, 0.0, 0.0)
                    at = self.where(context, region, rv3d, mouse)
                    self.odrag = ((region, rv3d), [("up", 0)] if facing else [], hit[0], hit[1], hit[2],
                                  (o.offset, o.width, o.sill, o.height), (at - origin).dot(a) / UNIT,
                                  (at.z - origin.z) / UNIT, origin, a)
                    return {"RUNNING_MODAL"}
                hit = self.hole_at(context, region, rv3d, axis, mouse)
                if hit:
                    # A hole in a floor or a ceiling: it, not the slab, is dragged.
                    obj = bpy.data.objects[hit[0]]
                    h = obj.ps_maker.holes[hit[1]]
                    dims = next(x[3] for x in self.holes_seen(context, axis) if x[0] == obj and x[1] == hit[1])
                    local = obj.matrix_world.inverted() @ self.where(context, region, rv3d, mouse)
                    self.hdrag = ((region, rv3d), hit[0], hit[1], hit[2], dims,
                                  {"x": (h.x, h.size_x), "y": (h.y, h.size_y)}, {"x": local.x / UNIT, "y": local.y / UNIT})
                    return {"RUNNING_MODAL"}
                sides = self.grab(context, region, rv3d, axis, mouse)
                if not sides:
                    return {"PASS_THROUGH"}  # not on a side: a click selects as usual
                objs = self.picked(context)
                step = context.scene.ps_grid_units * UNIT
                from . import makers
                for o in objs:
                    if not o.ps_maker.kind:
                        tidy(o, step)  # scale and turn into the mesh: the corners are where they look
                lo, hi = self.bounds(objs)
                start = {o.name: [o.matrix_world @ v.co for v in o.data.vertices] for o in objs}
                self.maker_start = {o.name: (*world_box(o), makers.box_start(o)) for o in objs if o.ps_maker.kind}
                self.drag = (region, rv3d, axis, sides, lo, hi, [o.name for o in objs], start)
                return {"RUNNING_MODAL"}
            if event.value == "RELEASE" and self.hdrag:
                self.hdrag = None
                self.moved += 1
                bpy.ops.ed.undo_push(message="Move the hole")
                self.status(context)
                return {"RUNNING_MODAL"}
            if event.value == "RELEASE" and self.odrag:
                self.odrag = None
                self.moved += 1
                bpy.ops.ed.undo_push(message="Move the opening")
                self.status(context)
                return {"RUNNING_MODAL"}
            if event.value == "RELEASE" and self.drag:
                for name in self.drag[6]:
                    o = bpy.data.objects.get(name)
                    if o is not None and not o.ps_maker.kind:
                        origin_to_corner(o)
                self.drag = None
                self.moved += 1
                bpy.ops.ed.undo_push(message="Resize")
                self.status(context)
                return {"RUNNING_MODAL"}
        return {"PASS_THROUGH"}

    def modal_edges(self, context, event, region, rv3d, axis, mouse):
        if event.type == "MOUSEMOVE":
            if self.cdrag:
                d_region, d_rv3d = self.cdrag[0]
                self.drag_corner(context, self.where(context, d_region, d_rv3d,
                                                     (event.mouse_x - d_region.x, event.mouse_y - d_region.y)))
                return {"RUNNING_MODAL"}
            self.chover = (region, self.corner_at(context, region, rv3d, axis, mouse)) if axis is not None else None
            return {"PASS_THROUGH"}
        if event.type == "LEFTMOUSE" and event.value == "PRESS":
            if region is None:
                self.finish(context)
                return {"FINISHED", "PASS_THROUGH"} if self.moved else {"CANCELLED", "PASS_THROUGH"}
            hit = self.corner_at(context, region, rv3d, axis, mouse)
            if not hit:
                return {"PASS_THROUGH"}  # not on a corner: a click selects as usual
            o = bpy.data.objects[hit[0]]
            tidy(o, context.scene.ps_grid_units * UNIT)  # scale and turn into the mesh: the corners are where they look
            hit = self.corner_at(context, region, rv3d, axis, mouse) or hit
            start = [o.matrix_world @ v.co for v in o.data.vertices]
            self.cdrag = ((region, rv3d), axis, hit[0], hit[1], hit[2].copy(), start)
            return {"RUNNING_MODAL"}
        if event.type == "LEFTMOUSE" and event.value == "RELEASE" and self.cdrag:
            self.end_corner(context)
            self.cdrag = None
            self.moved += 1
            bpy.ops.ed.undo_push(message="Move the edge")
            self.status(context)
            return {"RUNNING_MODAL"}
        return {"PASS_THROUGH"}

    def draw_corners(self, context, region, rv3d, axis, shader):
        """The edges mode's handles: a square at each corner the view shows (white), the one under the mouse filled."""
        px = view3d_utils.location_3d_to_region_2d
        hot = None
        if self.cdrag and self.cdrag[0][0] == region:
            hot = (self.cdrag[2], tuple(self.cdrag[3]))
        elif self.chover and self.chover[0] == region and self.chover[1]:
            hot = (self.chover[1][0], tuple(self.chover[1][1]))
        from gpu_extras.batch import batch_for_shader
        shader.uniform_float("color", (1.0, 1.0, 1.0, 1.0))
        for o, idx, w in self.corners_seen(context, axis):
            s = px(region, rv3d, w)
            if s is None:
                continue
            square = [(s.x - 4, s.y - 4), (s.x + 4, s.y - 4), (s.x + 4, s.y + 4), (s.x - 4, s.y + 4)]
            mine = hot is not None and hot[0] == o.name and set(hot[1]) & set(idx)
            batch_for_shader(shader, "TRI_FAN" if mine else "LINE_LOOP", {"pos": square}).draw(shader)

    def draw_handles(self, context):
        """Hammer's handles on the selection's box in the flat views: a square at each side's middle and each corner,
        those under the mouse filled."""
        import gpu
        from gpu_extras.batch import batch_for_shader
        context = bpy.context  # the view being drawn now (not the one the tool started in)
        if context.mode != "OBJECT":
            return  # Edit Mode: no handles (the tool ends on its next event)
        region, rv3d = context.region, context.region_data
        if rv3d is None or rv3d.view_perspective != "ORTHO":
            return
        look = rv3d.view_rotation @ Vector((0, 0, -1))
        axis = max(range(3), key=lambda k: abs(look[k]))
        if abs(look[axis]) < 0.999:
            return
        if self.edges:
            try:
                self.draw_corners(context, region, rv3d, axis, gpu.shader.from_builtin("UNIFORM_COLOR"))
            except ReferenceError:
                pass
            return
        try:
            objs = self.picked(context)
        except ReferenceError:
            return
        if not objs:
            return
        lo, hi = self.bounds(objs)
        a, b = [k for k in range(3) if k != axis]
        px = view3d_utils.location_3d_to_region_2d
        hot = set(self.drag[3]) if self.drag else set(self.hover[1]) if self.hover and self.hover[0] == region and \
            self.hover[1] else set()
        empty, full = [], []
        for ea in (0, 0.5, 1):
            for eb in (0, 0.5, 1):
                if ea == 0.5 and eb == 0.5:
                    continue
                p = lo.copy()
                p[a] = lo[a] + (hi[a] - lo[a]) * ea
                p[b] = lo[b] + (hi[b] - lo[b]) * eb
                s = px(region, rv3d, p)
                if s is None:
                    continue
                mine = set()
                if ea != 0.5:
                    mine.add((a, int(ea)))
                if eb != 0.5:
                    mine.add((b, int(eb)))
                quad = [(s.x - 4, s.y - 4), (s.x + 4, s.y - 4), (s.x + 4, s.y + 4), (s.x - 4, s.y + 4)]
                (full if mine == hot else empty).append(quad)
        shader = gpu.shader.from_builtin("UNIFORM_COLOR")
        shader.uniform_float("color", (1.0, 0.85, 0.2, 1.0))
        for quad in empty:
            batch_for_shader(shader, "LINE_LOOP", {"pos": quad}).draw(shader)
        for quad in full:
            batch_for_shader(shader, "TRI_FAN", {"pos": quad}).draw(shader)
        self.draw_openings(context, region, rv3d, axis, shader)
        self.draw_holes(context, region, rv3d, axis, shader)

    def draw_holes(self, context, region, rv3d, axis, shader):
        """The holes' frames and handles (cyan), as the doors'."""
        import gpu
        from gpu_extras.batch import batch_for_shader
        px = view3d_utils.location_3d_to_region_2d
        hot = self.hdrag[1:4] if self.hdrag else self.hhover[1] if self.hhover and self.hhover[0] == region else None
        gpu.state.blend_set("ALPHA")
        for obj, i, (z0, z1), dims in self.holes_seen(context, axis):
            h = obj.ps_maker.holes[i]
            mw = obj.matrix_world
            x0, x1 = h.x * UNIT, (h.x + h.size_x) * UNIT
            y0, y1 = h.y * UNIT, (h.y + h.size_y) * UNIT
            if dims == {"x", "y"}:
                pts = [(x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1)]
                lines = {("x", 0): (0, 3), ("x", 1): (1, 2), ("y", 0): (0, 1), ("y", 1): (3, 2)}
            elif dims == {"x"}:
                pts = [(x0, y0, z0), (x1, y0, z0), (x1, y0, z1), (x0, y0, z1)]
                lines = {("x", 0): (0, 3), ("x", 1): (1, 2)}
            else:
                pts = [(x0, y0, z0), (x0, y1, z0), (x0, y1, z1), (x0, y0, z1)]
                lines = {("y", 0): (0, 3), ("y", 1): (1, 2)}
            quad = [px(region, rv3d, mw @ Vector(c)) for c in pts]
            if any(q is None for q in quad):
                continue
            mine = hot is not None and hot[0] == obj.name and hot[1] == i
            if mine:
                shader.uniform_float("color", (0.2, 0.9, 1.0, 0.18))
                batch_for_shader(shader, "TRI_FAN", {"pos": quad}).draw(shader)
            shader.uniform_float("color", (0.2, 0.9, 1.0, 1.0))
            gpu.state.line_width_set(2.0 if mine else 1.0)
            batch_for_shader(shader, "LINE_LOOP", {"pos": quad}).draw(shader)
            gpu.state.line_width_set(1.0)
            grabbed = set(hot[2]) if mine and hot[2] != "move" else set()
            handles = [((quad[a] + quad[b]) / 2, {e}) for e, (a, b) in lines.items()]
            if dims == {"x", "y"}:
                handles += [(quad[0], {("x", 0), ("y", 0)}), (quad[1], {("x", 1), ("y", 0)}),
                            (quad[2], {("x", 1), ("y", 1)}), (quad[3], {("x", 0), ("y", 1)})]
            for c, edges in handles:
                square = [(c.x - 4, c.y - 4), (c.x + 4, c.y - 4), (c.x + 4, c.y + 4), (c.x - 4, c.y + 4)]
                batch_for_shader(shader, "TRI_FAN" if edges == grabbed else "LINE_LOOP", {"pos": square}).draw(shader)
        gpu.state.blend_set("NONE")

    def draw_openings(self, context, region, rv3d, axis, shader):
        """The doors' and windows' frames (cyan), the one under the mouse or dragged filled faintly, its edge under the
        mouse thicker."""
        import gpu
        from gpu_extras.batch import batch_for_shader
        px = view3d_utils.location_3d_to_region_2d
        hot = self.odrag[2:5] if self.odrag else self.ohover[1] if self.ohover and self.ohover[0] == region else None
        gpu.state.blend_set("ALPHA")
        for obj, i, (length, height, place, t), a, n, facing in self.openings_seen(context, axis):
            o = obj.ps_maker.openings[i]
            s0, s1 = o.offset * UNIT, (o.offset + o.width) * UNIT
            z0, z1 = (o.sill * UNIT, (o.sill + o.height) * UNIT) if facing else (0.0, 0.0)
            d1 = 0.0 if facing else t
            corners = [place(s0, z0, 0.0), place(s1, z0, 0.0), place(s1, z1, d1), place(s0, z1, d1)] if facing else \
                [place(s0, 0.0, 0.0), place(s1, 0.0, 0.0), place(s1, 0.0, t), place(s0, 0.0, t)]
            quad = [px(region, rv3d, c) for c in corners]
            if any(q is None for q in quad):
                continue
            mine = hot is not None and hot[0] == obj.name and hot[1] == i
            if mine:
                shader.uniform_float("color", (0.2, 0.9, 1.0, 0.18))
                batch_for_shader(shader, "TRI_FAN", {"pos": quad}).draw(shader)
            shader.uniform_float("color", (0.2, 0.9, 1.0, 1.0))
            gpu.state.line_width_set(2.0 if mine else 1.0)
            batch_for_shader(shader, "LINE_LOOP", {"pos": quad}).draw(shader)
            gpu.state.line_width_set(1.0)
            # Handles as on a brush (a square at each corner and each side's middle), those grabbed or under the mouse
            # filled: the edges along low (0-3), along high (1-2), up low (0-1), up high (3-2). From above: along only.
            grabbed = set(hot[2]) if mine and hot[2] != "move" else set()
            handles = [((quad[0] + quad[3]) / 2, {("along", 0)}), ((quad[1] + quad[2]) / 2, {("along", 1)})]
            if facing:
                handles += [((quad[0] + quad[1]) / 2, {("up", 0)}), ((quad[3] + quad[2]) / 2, {("up", 1)}),
                            (quad[0], {("along", 0), ("up", 0)}), (quad[1], {("along", 1), ("up", 0)}),
                            (quad[2], {("along", 1), ("up", 1)}), (quad[3], {("along", 0), ("up", 1)})]
            for c, edges in handles:
                square = [(c.x - 4, c.y - 4), (c.x + 4, c.y - 4), (c.x + 4, c.y + 4), (c.x - 4, c.y + 4)]
                batch_for_shader(shader, "TRI_FAN" if edges == grabbed else "LINE_LOOP", {"pos": square}).draw(shader)
        gpu.state.blend_set("NONE")


class MAP_OT_snap_to_grid(bpy.types.Operator):
    bl_idname = "psmap.snap_to_grid"
    bl_label = "Snap to grid"
    bl_description = ("Every corner of the selected brushes onto the grid (Hammer's Snap selected to grid): after scaling (S), "
                      "which goes by factors, not by the grid. Also puts the brush's origin at its corner, so that moving "
                      "it (G) keeps it on the grid. Round pieces (cylinders, arches) are left as they are")
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        if context.object is not None and context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        step = context.scene.ps_grid_units * UNIT
        moved = 0
        for obj in selected_brushes(context):
            # Stairs: steps of their own depth, off this grid (rounded, they would fold up).
            if obj.get("ps_round") or obj.get("ps_cut") or obj.get("ps_parts") or obj.children:
                continue
            bake_transform(obj)
            # A finer step where this one would flatten it (an 8-unit wall on the 16 grid), as after a move.
            if corners_onto_grid(obj, step):
                moved += 1
            origin_to_corner(obj)  # moved with G from now on, it stays on the grid
        self.report({"INFO"}, f"{moved} brushes put on the {context.scene.ps_grid_units}-unit grid")
        return {"FINISHED"}


class MAP_OT_square(bpy.types.Operator):
    bl_idname = "psmap.square"
    bl_label = "Square up"
    bl_description = ("Each selected brush becomes a plain box of its bounds, its corners on the grid: a box gone crooked "
                      "(corners moved apart, a face slanted). Its materials and settings stay")
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        if context.object is not None and context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        step = context.scene.ps_grid_units * UNIT
        made = []
        for obj in selected_brushes(context):
            if obj.get("ps_parts"):
                continue  # stairs: their own shape
            lo, hi = world_box(obj)
            s = step
            while True:
                a = Vector([round(c / s) * s for c in lo])
                b = Vector([round(c / s) * s for c in hi])
                if min(b - a) > 1e-6 or s < UNIT * 1.5:
                    break
                s /= 2
            if min(b - a) <= 1e-6:
                continue
            name, mats, col = obj.name, materials_of(obj), obj.users_collection[0]
            settings = {k: obj[k] for k in ("ps_entity", "ps_surface", "ps_nocollide") if k in obj}
            bpy.data.objects.remove(obj, do_unlink=True)
            box = box_brush(name, a, b, mats, col)
            for k, v in settings.items():
                box[k] = v
            made.append(box)
        select_only(context, made)
        self.report({"INFO"}, f"{len(made)} brushes squared up")
        return {"FINISHED"}


def finish_buttons(layout):
    """Apply and Cancel under a tool's settings in its panel (bottom left, F9): the panel changes the result live, these end it."""
    row = layout.row(align=True)
    row.scale_y = 1.2
    row.operator("psmap.apply_last", text="Apply", icon="CHECKMARK")
    row.operator("psmap.cancel_last", text="Cancel", icon="CANCEL")


class Adjustable:
    """A tool whose panel (bottom left, F9) changes its result live: its settings, then Apply / Cancel."""

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        for p in self.properties.bl_rna.properties:
            if p.identifier != "rna_type" and not p.is_hidden:
                layout.prop(self, p.identifier)
        finish_buttons(layout)


def on_grid(value, step, least=None):
    """A size or a shift in units to the nearest whole number of grid steps (sizes not below one step)."""
    v = int(round(value / step)) * step
    return max(least, v) if least is not None else v


class MAP_OT_apply_last(bpy.types.Operator):
    bl_idname = "psmap.apply_last"
    bl_label = "Apply"
    bl_description = "Keep it as it is now (the panel's changes are already in) and close the panel"
    # The last operation to redo now (Blender shows no panel for one with nothing to set): the tool's panel goes.
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}

    def execute(self, context):
        return {"FINISHED"}


class MAP_OT_cancel_last(bpy.types.Operator):
    bl_idname = "psmap.cancel_last"
    bl_label = "Cancel"
    bl_description = "Undo what this tool just did (as Ctrl+Z)"
    bl_options = {"INTERNAL"}

    def execute(self, context):
        # Not now: the button is in the tool's own panel (F9), which an undo frees while Blender still draws and runs it
        # (Blender went down on Cancel after a tool from the pie menu). A moment later, from the window, as Ctrl+Z.
        window, screen = context.window, context.screen

        def later():
            try:
                area = next((a for a in screen.areas if a.type == "VIEW_3D"), None)
                with bpy.context.temp_override(window=window, screen=screen, area=area):
                    bpy.ops.ed.undo()
            except (RuntimeError, ReferenceError, TypeError):
                pass
            return None
        bpy.app.timers.register(later, first_interval=0.05)
        return {"FINISHED"}


class MAP_OT_box(Adjustable, bpy.types.Operator):
    bl_idname = "psmap.box"
    bl_label = "Box"
    bl_description = ("A box brush at the 3D cursor (standing on it), in the map's Seen collection; its size in the panel at "
                      "the bottom left (F9), or scale it after (S, snapped to the grid)")
    bl_options = {"REGISTER", "UNDO"}
    width: bpy.props.IntProperty(name="Width (units)", default=128, min=1, max=16384)
    length: bpy.props.IntProperty(name="Length (units)", default=128, min=1, max=16384)
    height: bpy.props.IntProperty(name="Height (units)", default=128, min=1, max=16384)
    grid: bpy.props.BoolProperty(name="Snap to grid", default=False,
                                 description="The sizes in whole grid steps (the grid's step: [ and ])")

    def execute(self, context):
        if context.object is not None and context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        if self.grid:
            g = context.scene.ps_grid_units
            self.width, self.length, self.height = (on_grid(v, g, g) for v in (self.width, self.length, self.height))
        ensure_materials()
        c = snapped_cursor(context)
        w, l, h = self.width * UNIT, self.length * UNIT, self.height * UNIT
        obj = box_brush("Brush", (c.x - w / 2, c.y - l / 2, c.z), (c.x + w / 2, c.y + l / 2, c.z + h),
                        [material("Dev Grey", (0.55, 0.55, 0.55))], child_collection(context.scene, "Seen"))
        select_only(context, [obj])
        return {"FINISHED"}


class MAP_OT_hollow(Adjustable, bpy.types.Operator):
    bl_idname = "psmap.hollow"
    bl_label = "Make a room"
    bl_description = ("The selected box becomes a room: a floor, a ceiling and four walls of this thickness (Hammer's Hollow). "
                      "Several selected (the parts of a room, say) make one room of the space they take together")
    bl_options = {"REGISTER", "UNDO"}
    thickness: bpy.props.IntProperty(name="Thickness (units)", default=16, min=1, max=256)
    ceiling: bpy.props.BoolProperty(name="Ceiling", default=True)

    def execute(self, context):
        if context.object is not None and context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        t = self.thickness * UNIT
        made = []
        objs = stairs_left_alone(self, selected_brushes(context))
        if not objs:
            self.report({"WARNING"}, "Select a box brush first (Box or Draw brush makes one)")
            return {"CANCELLED"}
        boxes = [world_box(o) for o in objs]
        lo = Vector([min(b[0][k] for b in boxes) for k in range(3)])
        hi = Vector([max(b[1][k] for b in boxes) for k in range(3)])
        if min(hi - lo) <= 2 * t:
            size = " x ".join(str(round(v / UNIT)) for v in hi - lo)
            self.report({"WARNING"}, f"Too thin for walls of {self.thickness} units: {size}")
            return {"CANCELLED"}
        obj = context.active_object if context.active_object in objs else objs[-1]
        mats, col, like = materials_of(obj), obj.users_collection[0], Likeness(obj)
        from . import makers
        room = makers.make(context, "room", {"room_size": tuple((hi - lo) / UNIT), "room_thickness": self.thickness,
                                             "ceiling": self.ceiling}, lo, 0.0, mats, col, like)
        for o in objs:
            bpy.data.objects.remove(o, do_unlink=True)
        select_only(context, [room])
        return {"FINISHED"}


def arch_curve(a0, a1, z0, z1, segments):
    """The round top of an opening a0..a1 by z0..z1 (Door's and Arch's alike, so a tunnel meets a door cut with the same
    sizes point for point): half an ellipse as wide as the opening, as high as it allows (a half circle when the opening
    is at least half as high as it is wide), its points at even angles. Returns (middle, spring height, rise, points)."""
    radius = (a1 - a0) / 2
    rise = min(radius, z1 - z0)
    cx, spring = (a0 + a1) / 2, z1 - rise
    pts = [(cx + radius * math.cos(math.pi * i / segments), spring + rise * math.sin(math.pi * i / segments))
           for i in range(segments + 1)]
    return cx, spring, rise, pts


def on_units(poly):
    """The points on whole units (as Hammer has them), the doubled ones dropped; [] when too little is left."""
    pts = []
    for x, z in poly:
        q = (round(x / UNIT) * UNIT, round(z / UNIT) * UNIT)
        if not pts or abs(q[0] - pts[-1][0]) + abs(q[1] - pts[-1][1]) > 1e-6:
            pts.append(q)
    if len(pts) > 2 and abs(pts[0][0] - pts[-1][0]) + abs(pts[0][1] - pts[-1][1]) < 1e-6:
        pts.pop()
    return pts if len(pts) >= 3 else []


def arch_fill(a0, a1, z0, z1, segments, outer=None):
    """The wall over the round top of an opening a0..a1 by z0..z1, a brush a segment, each convex: inside along the curve
    (arch_curve); outside along the opening's rectangle (and its top corner where one falls in the segment), or, with
    `outer` (a thickness), along a curve that much bigger (a round arch). Returns the pieces' outlines (x, z)."""
    if min(a1 - a0, z1 - z0) <= 1e-4:
        return []
    cx, spring, rise, curve = arch_curve(a0, a1, z0, z1, segments)
    radius = (a1 - a0) / 2

    def outward(x, z):
        """Where the line from the middle through (x, z) meets the opening's rectangle."""
        dx, dz = x - cx, z - spring
        hits = []
        if dz > 1e-9:
            hits.append((z1 - spring) / dz)
        if dx > 1e-9:
            hits.append((a1 - cx) / dx)
        if dx < -1e-9:
            hits.append((a0 - cx) / dx)
        k = min(hits)
        return cx + dx * k, spring + dz * k

    corners = [(math.atan2(z1 - spring, a1 - cx), (a1, z1)), (math.atan2(z1 - spring, a0 - cx), (a0, z1))]
    out = []
    for i in range(segments):
        p0, p1 = curve[i], curve[i + 1]
        if outer is not None:
            u0, u1 = math.pi * i / segments, math.pi * (i + 1) / segments
            q0 = (cx + (radius + outer) * math.cos(u0), spring + (rise + outer) * math.sin(u0))
            q1 = (cx + (radius + outer) * math.cos(u1), spring + (rise + outer) * math.sin(u1))
            ring = [p0, q0, q1, p1]
        else:
            t0, t1 = math.atan2(p0[1] - spring, p0[0] - cx), math.atan2(p1[1] - spring, p1[0] - cx)
            ring = [p0, outward(*p0)] + [c for t, c in corners if t0 < t < t1] + [outward(*p1), p1]
        pts = on_units(ring)
        if pts:
            out.append(pts)
    return out


def extruded(outline, place, t0, t1):
    """An outline (x, z points around it) made a prism from t0 to t1 across: (corners, faces); `place(x, z, t)` puts a
    point in the world."""
    verts = [place(x, z, t) for x, z in outline for t in (t0, t1)]
    n = len(outline)
    faces = [[2 * k for k in range(n)], [2 * k + 1 for k in reversed(range(n))]]
    faces += [(2 * k, 2 * k + 1, 2 * ((k + 1) % n) + 1, 2 * ((k + 1) % n)) for k in range(n)]
    return verts, faces


class MAP_OT_opening(Adjustable, bpy.types.Operator):
    bl_idname = "psmap.opening"
    bl_label = "Cut an opening"
    bl_description = ("A door or a window in the selected wall, or a hole in the selected floor or ceiling, centred at the "
                      "3D cursor (in the middle when the cursor is off it): the brush becomes brushes around the hole")
    bl_options = {"REGISTER", "UNDO"}
    width: bpy.props.IntProperty(name="Width (units)", default=64, min=8, max=1024)
    height: bpy.props.IntProperty(name="Height (units)", default=112, min=8, max=1024)
    sill: bpy.props.IntProperty(name="From the floor (units)", default=0, min=0, max=1024,
                                description="0 for a door; about 40 for a window")
    # The moves are this opening's own (SKIP_SAVE): the next Door starts at the cursor again.
    shift: bpy.props.IntProperty(name="Along the wall (units)", default=0, min=-4096, max=4096, options={"SKIP_SAVE"},
                                 description="Moves the opening along the wall (a floor's hole along x) from where the cursor "
                                             "put it, a unit at a time (off the grid too)")
    shift_across: bpy.props.IntProperty(name="Along y (units)", default=0, min=-4096, max=4096, options={"SKIP_SAVE"},
                                        description="A floor's or ceiling's hole: moves it along y")
    grid: bpy.props.BoolProperty(name="Snap to grid", default=False,
                                 description="Sizes, height from the floor and the moves in whole grid steps (the grid's "
                                             "step: [ and ])")
    # What was cut last time: a floor or a ceiling (lying flat) shows other settings in the panel.
    flat: bpy.props.BoolProperty(default=False, options={"HIDDEN", "SKIP_SAVE"})
    top: bpy.props.EnumProperty(name="Top", items=[("flat", "Flat", "A plain rectangle"),
                                                   ("arch", "Arch", "Round at the top: a half circle as wide as the "
                                                                    "opening (flatter when the opening is lower than that)")],
                                options={"SKIP_SAVE"})
    arc_segments: bpy.props.IntProperty(name="Arch segments", default=8, min=2, max=32,
                                        description="Brushes along the arch: more, rounder")

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        if self.flat:
            layout.prop(self, "width", text="Along x (units)")
            layout.prop(self, "height", text="Along y (units)")
            layout.prop(self, "shift", text="Move along x (units)")
            layout.prop(self, "shift_across", text="Move along y (units)")
        else:
            for name in ("width", "height", "sill", "shift"):
                layout.prop(self, name)
            layout.prop(self, "top", expand=True)
            if self.top == "arch":
                layout.prop(self, "arc_segments")
        layout.prop(self, "grid")
        finish_buttons(layout)

    def execute(self, context):
        object_mode(context)
        made = []
        g = context.scene.ps_grid_units
        if self.grid:
            self.width, self.height = on_grid(self.width, g, g), on_grid(self.height, g, g)
            self.sill, self.shift, self.shift_across = on_grid(self.sill, g, 0), on_grid(self.shift, g), on_grid(self.shift_across, g)
        cursor = context.scene.cursor.location
        step = g * UNIT
        for obj in [o for o in context.selected_objects if o.type == "MESH" and o.ps_maker.kind in ("wall", "room")]:
            from . import makers
            level, at = makers.room_hole_at(obj, cursor) if obj.ps_maker.kind == "room" else (None, None)
            if level:
                # The cursor on the room's floor or ceiling: a hole there (its size the panel's along x and y).
                self.flat = True
                p = obj.ps_maker
                sx, sy = p.room_size[0], p.room_size[1]
                w, d = min(self.width, sx), min(self.height, sy)
                x = min(max(round((at[0] - w / 2) / g) * g + self.shift, 0.0), sx - w)
                y = min(max(round((at[1] - d / 2) / g) * g + self.shift_across, 0.0), sy - d)
                makers._building[0] = True
                try:
                    h = p.holes.add()
                    h.level, h.x, h.y, h.size_x, h.size_y = level, x, y, w, d
                finally:
                    makers._building[0] = False
                makers.rebuild(obj)
                made.append(obj)
                continue
            self.flat = False
            if self.add_to(obj, cursor, g):
                made.append(obj)
        for obj in stairs_left_alone(self, [o for o in selected_brushes(context) if o.ps_maker.kind in ("", "slab")]):
            try:
                obj.name
            except ReferenceError:
                continue  # cut already with a slab selected with it
            lo, hi = world_box(obj)
            size = hi - lo
            thin = min(range(3), key=lambda i: size[i])
            mats, col, like = materials_of(obj), obj.users_collection[0], Likeness(obj)

            def centred(axis, length, moved):
                """The opening's low side on `axis`: at the cursor (the middle when it is off), on the grid, then moved."""
                mid = cursor[axis] if lo[axis] + length / 2 <= cursor[axis] <= hi[axis] - length / 2 else (lo[axis] + hi[axis]) / 2
                return round((mid - length / 2) / step) * step + moved * UNIT

            def box(p_lo, p_hi, name):
                b = like.give(box_brush(name, p_lo, p_hi, mats, col))
                if b:
                    made.append(b)

            if thin == 2:
                # Lying flat (a floor, a ceiling): a hole through it, the brush around it in four.
                self.flat = True
                w, l = self.width * UNIT, self.height * UNIT
                x0 = centred(0, w, self.shift)
                y0 = centred(1, l, self.shift_across)
                x1, y1 = x0 + w, y0 + l
                if x0 < lo.x - 1e-4 or x1 > hi.x + 1e-4 or y0 < lo.y - 1e-4 or y1 > hi.y + 1e-4:
                    self.report({"WARNING"}, f"The hole does not fit in {obj.name}")
                    continue
                # Through the slabs lying right on it or under it too (a ceiling that is the floor of the room above,
                # made as two brushes): a hole cut in one alone left the other closing it.
                stack, z_lo, z_hi = [obj], lo.z, hi.z
                grown = True
                while grown:
                    grown = False
                    for other in context.scene.objects:
                        if other in stack or not is_brush(other) or other.type != "MESH" or \
                                (other.get("ps_parts") and other.ps_maker.kind != "slab"):
                            continue
                        olo, ohi = world_box(other)
                        osize = ohi - olo
                        if min(range(3), key=lambda i: osize[i]) != 2:
                            continue
                        if olo.z > z_hi + 1e-4 or ohi.z < z_lo - 1e-4:
                            continue  # not touching the stack
                        if olo.x > x0 - 1e-4 or ohi.x < x1 + 1e-4 or olo.y > y0 - 1e-4 or ohi.y < y1 + 1e-4:
                            continue  # the hole is not wholly inside it: left alone
                        stack.append(other)
                        z_lo, z_hi = min(z_lo, olo.z), max(z_hi, ohi.z)
                        grown = True
                # Each a floor with its holes from now on (its settings: the holes changed, removed, added later).
                from . import makers
                for slab in stack:
                    if slab.ps_maker.kind != "slab":
                        slo, shi = world_box(slab)
                        size = shi - slo
                        floor = makers.make(context, "slab", {"slab_x": size.x / UNIT, "slab_y": size.y / UNIT,
                                                              "slab_thickness": size.z / UNIT}, slo, 0.0,
                                            materials_of(slab), slab.users_collection[0], Likeness(slab),
                                            name=slab.name)
                        bpy.data.objects.remove(slab, do_unlink=True)
                        slab = floor
                    at = slab.matrix_basis.inverted() @ Vector((x0, y0, 0.0))
                    hole = slab.ps_maker.holes.add()
                    makers._building[0] = True
                    try:
                        hole.x, hole.y = at.x / UNIT, at.y / UNIT
                        hole.size_x, hole.size_y = self.width, self.height
                    finally:
                        makers._building[0] = False
                    makers.rebuild(slab)
                    made.append(slab)
                if len(stack) > 1:
                    self.report({"INFO"}, f"The hole goes through {len(stack)} brushes lying one on another")
                continue
            self.flat = False
            # A wall: one object from now on, its openings its settings (changed in the map tools' panel later).
            from . import makers
            along = 1 - thin  # the wall's thickness is x or y
            size = hi - lo
            if along == 0:
                location, turn = lo.copy(), 0.0
            else:
                location, turn = Vector((hi.x, lo.y, lo.z)), math.pi / 2  # its own x along the world's y
            wall = makers.make(context, "wall", {"wall_length": size[along] / UNIT, "wall_height": size.z / UNIT,
                                                 "wall_thickness": size[thin] / UNIT}, location, turn, mats, col, like,
                               name=obj.name)
            bpy.data.objects.remove(obj, do_unlink=True)
            if self.add_to(wall, cursor, g):
                made.append(wall)
            else:
                bpy.data.objects.remove(wall, do_unlink=True)
        select_only(context, made)
        return {"FINISHED"}

    def add_to(self, obj, cursor, g):
        """This opening into a wall or a room made with the map tools (its settings): at the cursor along the wall (the
        middle when it does not fit there), its sides on the grid, then moved. False when it does not fit."""
        from . import makers
        p = obj.ps_maker
        if p.kind == "room":
            side, at = makers.nearest_wall(obj, cursor)
            length, height = makers.wall_size(p, side)
        else:
            side, at = 0, (obj.matrix_world.inverted() @ cursor).x / UNIT
            length, height = p.wall_length, p.wall_height
        w = self.width
        mid = at if w / 2 <= at <= length - w / 2 else length / 2
        offset = round((mid - w / 2) / g) * g + self.shift
        if offset < -1e-4 or offset + w > length + 1e-4 or self.sill >= height:
            self.report({"WARNING"}, f"The opening does not fit in {obj.name}")
            return False
        item = p.openings.add()
        makers._building[0] = True
        try:
            item.side = str(side)
            item.offset, item.width, item.height, item.sill = offset, w, self.height, self.sill
            item.top, item.segments = self.top, self.arc_segments
        finally:
            makers._building[0] = False
        makers.rebuild(obj)
        return True


class MAP_OT_clip(Adjustable, bpy.types.Operator):
    bl_idname = "psmap.clip"
    bl_label = "Cut with a plane"
    bl_description = ("Cut the selected brushes in two by a plane through the 3D cursor (Hammer's Clip tool); "
                      "turn and tilt it in the panel that opens (F9)")
    bl_options = {"REGISTER", "UNDO"}
    turn: bpy.props.FloatProperty(name="Turn", subtype="ANGLE", default=0.0, description="About the vertical")
    tilt: bpy.props.FloatProperty(name="Tilt", subtype="ANGLE", default=0.0, description="From upright: a slope or a ramp")
    # Not remembered (SKIP_SAVE): a cut keeps both halves unless this one is told otherwise.
    keep: bpy.props.EnumProperty(name="Keep", items=[("both", "Both", ""), ("front", "Front", ""), ("back", "Back", "")],
                                 options={"SKIP_SAVE"})

    def execute(self, context):
        object_mode(context)
        normal = Matrix.Rotation(self.turn, 3, "Z") @ Matrix.Rotation(-self.tilt, 3, "Y") @ Vector((1, 0, 0))
        point = context.scene.cursor.location.copy()
        made = []
        for obj in stairs_left_alone(self, selected_brushes(context)):
            halves = []
            for side, clear in (("front", "clear_inner"), ("back", "clear_outer")):
                if self.keep not in ("both", side):
                    continue
                bm = bmesh.new()
                bm.from_mesh(obj.data)
                bm.transform(placed(obj))
                geom = bm.verts[:] + bm.edges[:] + bm.faces[:]
                res = bmesh.ops.bisect_plane(bm, geom=geom, plane_co=point, plane_no=normal, **{clear: True})
                cut = [e for e in res["geom_cut"] if isinstance(e, bmesh.types.BMEdge)]
                if cut:
                    bmesh.ops.holes_fill(bm, edges=cut, sides=0)
                if len(bm.faces) >= 4:
                    bm.verts.index_update()
                    verts = [v.co.copy() for v in bm.verts]
                    faces = [[v.index for v in f.verts] for f in bm.faces]
                    halves.append((verts, faces, [f.material_index for f in bm.faces]))
                bm.free()
            if not halves:
                continue
            mats, col, like = materials_of(obj), obj.users_collection[0], Likeness(obj)
            for verts, faces, indices in halves:
                half = mesh_brush(obj.name, verts, faces, mats, col, indices)
                for k, v in like.settings.items():
                    half[k] = v  # the faces keep their own materials through the cut
                half["ps_cut"] = 1  # a slanted cut: its corners need not be on the grid
                made.append(half)
            bpy.data.objects.remove(obj, do_unlink=True)
        select_only(context, made)
        return {"FINISHED"}


STAND, CROUCH = 72, 54  # a player's height standing and crouched (CS units)
MAX_SLOPE = 45.57  # degrees: steeper is not ground (a floor normal under 0.7, as in CS), players slide


def prism(bm, plan, bottom, top, mat):
    """A convex piece over a convex plan (x, y points, counter-clockwise from above), its bottom and top heights given at
    each plan point (a sloped or twisted top or bottom). Corners where the bottom meets the top merge (a wedge)."""
    lo = [bm.verts.new((x, y, z)) for (x, y), z in zip(plan, bottom)]
    hi = [bm.verts.new((x, y, z)) for (x, y), z in zip(plan, top)]
    n = len(plan)
    faces = [bm.faces.new(hi), bm.faces.new(list(reversed(lo)))]
    for k in range(n):
        faces.append(bm.faces.new((lo[k], lo[(k + 1) % n], hi[(k + 1) % n], hi[k])))
    for f in faces:
        f.material_index = mat
    verts = lo + hi
    bmesh.ops.remove_doubles(bm, verts=verts, dist=1e-6)
    piece = list({f for v in verts if v.is_valid for f in v.link_faces})
    for f in piece:
        f.normal_update()
    bmesh.ops.dissolve_degenerate(bm, edges=list({e for f in piece if f.is_valid for e in f.edges}), dist=1e-6)
    # A twisted top (a ramp turning) is not flat: in triangles, each flat.
    twisted = [f for f in {f for v in verts if v.is_valid for f in v.link_faces}
               if len(f.verts) > 3 and any(abs((v.co - f.verts[0].co).dot(f.normal)) > 1e-5 for v in f.verts)]
    if twisted:
        bmesh.ops.triangulate(bm, faces=twisted)


class MAP_OT_stairs(bpy.types.Operator):
    bl_idname = "psmap.stairs"
    bl_label = "Stairs"
    bl_description = ("Stairs from the 3D cursor, straight or turning (90°: a corner, 360° and more: a spiral round the cursor). "
                      "A box brush selected: a straight flight fills it (up along its long side, as many steps as its height "
                      "takes, none over 18 units). "
                      "One object to move: the steps are seen (no collision), a player clip ramp over them is what players "
                      "walk on (smooth, as in CS2). Settings in the panel at the bottom left (F9)")
    bl_options = {"REGISTER", "UNDO"}
    shape: bpy.props.EnumProperty(name="Shape", items=[("straight", "Straight", "One flight along the turn"),
                                                       ("turning", "Turning", "Round the 3D cursor: a corner, a spiral")])
    direction: bpy.props.EnumProperty(name="Up toward", items=[("auto", "Auto", "Along the box's long side")] + [
        (k, k, f"Climbing toward {k}") for k in ("+X", "-X", "+Y", "-Y")], options={"SKIP_SAVE"})
    other_way: bpy.props.BoolProperty(name="Up the other way", default=False, options={"SKIP_SAVE", "HIDDEN"},
                                      description="From a box: climbing toward its other end")
    boxed: bpy.props.StringProperty(default="", options={"HIDDEN", "SKIP_SAVE"})  # what the box made of it, for the panel
    rise: bpy.props.IntProperty(name="Step height (units)", default=16, min=2, max=18,
                                description="18 at most: higher than that is a jump, not a step")
    solid: bpy.props.BoolProperty(name="Solid below", default=True,
                                  description="Down to the floor (nothing gets under it); off: a slab, one can walk under it")
    thickness: bpy.props.IntProperty(name="Slab thickness (units)", default=16, min=2, max=256)
    turn: bpy.props.FloatProperty(name="Turn", subtype="ANGLE", default=0.0, description="Which way it starts")
    # Straight
    steps: bpy.props.IntProperty(name="Steps", default=8, min=1, max=128)
    run: bpy.props.IntProperty(name="Step depth (units)", default=16, min=4, max=128)
    width: bpy.props.IntProperty(name="Width (units)", default=96, min=16, max=1024)
    # Turning
    angle: bpy.props.FloatProperty(name="Turns by", subtype="ANGLE", default=math.pi / 2, min=math.radians(15),
                                   max=math.radians(3600), description="90°: a corner; 360°: one full turn; 720°: two")
    per_turn: bpy.props.IntProperty(name="Steps a full turn", default=16, min=4, max=96)
    inner: bpy.props.IntProperty(name="Inner radius (units)", default=48, min=0, max=2048,
                                 description="0: the steps meet at the middle; more: a hole or a column there")
    outer: bpy.props.IntProperty(name="Outer radius (units)", default=144, min=16, max=4096)
    clockwise: bpy.props.BoolProperty(name="Clockwise", default=False)

    def headroom(self):
        """Units between a turn of a spiral and the one above it (None: it does not come round over itself)."""
        if self.shape != "turning" or self.angle <= 2 * math.pi + 1e-4:
            return None
        return 0 if self.solid else self.per_turn * self.rise - self.thickness

    def draw(self, context):
        layout = self.layout
        if self.boxed:
            layout.label(text=self.boxed, icon="MESH_CUBE")
            layout.prop(self, "rise", text="Step height about (units)")
            from .makers import direction_row
            direction_row(layout, self, "direction")
            layout.prop(self, "solid")
            if not self.solid:
                layout.prop(self, "thickness")
            finish_buttons(layout)
            return
        layout.prop(self, "shape", expand=True)
        layout.prop(self, "rise")
        if self.shape == "straight":
            for p in ("steps", "run", "width"):
                layout.prop(self, p)
        else:
            for p in ("angle", "per_turn", "inner", "outer", "clockwise"):
                layout.prop(self, p)
        layout.prop(self, "turn")
        layout.prop(self, "solid")
        if not self.solid:
            layout.prop(self, "thickness")
        if self.shape == "turning":
            steps = max(1, round(self.angle / (2 * math.pi) * self.per_turn))
            layout.label(text=f"{steps} steps, {steps * self.rise} units up; a full turn {self.per_turn * self.rise} units")
            # Nearer the middle the ramp is steeper (the same rise over a shorter way round).
            walkable = self.rise / (math.tan(math.radians(MAX_SLOPE)) * 2 * math.pi / self.per_turn)
            if walkable > self.inner:
                text = (f"Too steep within {walkable:.0f} units of the middle: players slide there"
                        if walkable < self.outer else "Too steep all over: players slide (more steps a turn, lower steps)")
                layout.label(text=text, icon="ERROR")
        else:
            slope = math.degrees(math.atan2(self.rise, self.run))
            if slope > MAX_SLOPE:
                layout.label(text=f"Ramp {slope:.1f}°, steeper than {MAX_SLOPE}°: players slide (surf)", icon="ERROR")
        room = self.headroom()
        if room is not None:
            if self.solid:
                layout.label(text="Solid below fills the turns under it: untick it for a spiral", icon="ERROR")
            elif room < CROUCH:
                layout.label(text=f"No way through: {room} units between turns, {CROUCH} needed crouched", icon="ERROR")
            elif room < STAND:
                layout.label(text=f"Crouched only: {room} units between turns, {STAND} to walk", icon="ERROR")
            else:
                layout.label(text=f"{room} units between turns: walks through", icon="CHECKMARK")
        finish_buttons(layout)

    def execute(self, context):
        if context.object is not None and context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        ensure_materials()
        r, t = self.rise * UNIT, self.thickness * UNIT
        origin, turn, gone, seen_mat = snapped_cursor(context), self.turn, None, material("Dev Grey", (0.55, 0.55, 0.55))
        boxes = [o for o in selected_brushes(context) if box_like(o) and not o.get("ps_parts") and not o.get("ps_round")]
        self.boxed = ""
        if boxes:
            # A flight filling the box drawn for it: up along its long side, steps as near the step height asked as the
            # box's height allows (never over 18: a jump), each as deep as the length shared out.
            box = context.active_object if context.active_object in boxes else boxes[-1]
            lo, hi = world_box(box)
            from .makers import stairs_fill
            if self.direction == "auto":
                # Up along the long side (the first time; the arrows then turn it within the same box).
                self.direction = "+X" if hi.x - lo.x >= hi.y - lo.y else "+Y"
            n, r, d, w, origin, turn = stairs_fill(lo, hi, self.direction, r)
            self.boxed = (f"From {box.name}: {n} steps of {r / UNIT:.1f} x {d / UNIT:.1f} units, "
                          f"{round(w / UNIT)} wide")
            seen_mat, gone = materials_of(box)[0], box
        from . import makers
        settings = {k: getattr(self, k) for k in ("shape", "steps", "solid", "thickness", "angle", "per_turn", "inner",
                                                  "outer", "clockwise", "run", "width")}
        settings["rise"] = self.rise
        if boxes:
            settings.update(shape="straight", steps=n, rise=r / UNIT, run=d / UNIT, width=w / UNIT)
        clip = next(m for m in bpy.data.materials if m.get("ps_tool") == "clip")
        obj = makers.make(context, "stairs", settings, origin, turn, [seen_mat, clip],
                          gone.users_collection[0] if gone is not None else None)
        if gone is not None:
            bpy.data.objects.remove(gone, do_unlink=True)
        select_only(context, [obj])
        room = makers.headroom(obj.ps_maker)
        if room is not None and room < STAND:
            self.report({"WARNING"}, "Too low between the turns: see the panel at the bottom left (F9)")
        return {"FINISHED"}


class MAP_OT_cylinder(Adjustable, bpy.types.Operator):
    bl_idname = "psmap.cylinder"
    bl_label = "Cylinder"
    bl_description = "A round brush (a column, a tower) standing at the 3D cursor"
    bl_options = {"REGISTER", "UNDO"}
    sides: bpy.props.IntProperty(name="Sides", default=12, min=3, max=64)
    radius: bpy.props.IntProperty(name="Radius (units)", default=32, min=2, max=2048)
    height: bpy.props.IntProperty(name="Height (units)", default=128, min=1, max=4096)

    def execute(self, context):
        object_mode(context)
        ensure_materials()
        from . import makers
        b = makers.make(context, "cylinder", {"sides": self.sides, "radius": self.radius, "cylinder_height": self.height},
                        snapped_cursor(context), 0.0, [material("Dev Grey", (0.55, 0.55, 0.55))])
        select_only(context, [b])
        return {"FINISHED"}


class MAP_OT_arch(Adjustable, bpy.types.Operator):
    bl_idname = "psmap.arch"
    bl_label = "Arch"
    bl_description = ("An arch or a tunnel (Hammer's Arch tool), the round top as Door's with the same sizes: a tunnel meets "
                      "a door cut alike. A box brush selected: the arch fills it (its walls this thick inside it); else "
                      "it stands on the 3D cursor, across X. Each segment a brush")
    bl_options = {"REGISTER", "UNDO"}
    width: bpy.props.IntProperty(name="Opening width (units)", default=64, min=8, max=4096)
    height: bpy.props.IntProperty(name="Opening height (units)", default=112, min=8, max=4096)
    segments: bpy.props.IntProperty(name="Segments", default=8, min=2, max=32, description="Along the curve: more, rounder")
    thickness: bpy.props.IntProperty(name="Thickness (units)", default=16, min=1, max=512)
    depth: bpy.props.IntProperty(name="Depth (units)", default=16, min=1, max=16384, description="A tunnel: its length")
    outside: bpy.props.EnumProperty(name="Outside", items=[("square", "Square", "Flat outside, as a wall: meets other brushes"),
                                                           ("round", "Round", "Round outside too, as thick all over")])
    turn: bpy.props.FloatProperty(name="Turn", subtype="ANGLE", default=0.0)
    other_way: bpy.props.BoolProperty(name="Along the long side", default=False, options={"SKIP_SAVE"},
                                      description="From a box: through its long side (a tunnel) rather than its short one")
    grid: bpy.props.BoolProperty(name="Snap to grid", default=True,
                                 description="The sizes in whole grid steps (the grid's step: [ and ]); the corners "
                                             "along the curve on whole units, as Hammer has them")
    boxed: bpy.props.StringProperty(default="", options={"HIDDEN", "SKIP_SAVE"})  # what the box made of it, for the panel

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        if self.boxed:
            layout.label(text=self.boxed, icon="MESH_CUBE")
            layout.prop(self, "other_way")
        else:
            for name in ("width", "height", "depth", "turn"):
                layout.prop(self, name)
        for name in ("thickness", "segments"):
            layout.prop(self, name)
        layout.row().prop(self, "outside", expand=True)
        layout.prop(self, "grid")
        finish_buttons(layout)

    def execute(self, context):
        object_mode(context)
        ensure_materials()
        g = context.scene.ps_grid_units
        if self.grid:
            self.width, self.height, self.thickness, self.depth = (
                on_grid(v, g, g) for v in (self.width, self.height, self.thickness, self.depth))
        t = self.thickness * UNIT
        boxes = [o for o in selected_brushes(context) if box_like(o) and not o.get("ps_parts") and not o.get("ps_round")]
        like, mats, col, gone = None, [material("Dev Grey", (0.55, 0.55, 0.55))], child_collection(context.scene, "Seen"), None
        if boxes:
            # Fills the box: its outside the arch's, the opening inside its walls; through its short side (an archway)
            # or its long one (a tunnel).
            box = context.active_object if context.active_object in boxes else boxes[-1]
            lo, hi = world_box(box)
            short = 0 if hi.x - lo.x <= hi.y - lo.y else 1
            through = 1 - short if self.other_way else short
            across = 1 - through
            a0, a1 = lo[across] + t, hi[across] - t
            z0, z1 = lo.z, hi.z - t
            if a1 - a0 < UNIT or z1 - z0 < UNIT:
                self.report({"WARNING"}, f"{box.name}: too small for walls {self.thickness} units thick")
                return {"CANCELLED"}
            self.boxed = (f"From {box.name}: opening {round((a1 - a0) / UNIT)} x {round((z1 - z0) / UNIT)}, "
                          f"{round((hi[through] - lo[through]) / UNIT)} deep")
            like, mats, col, gone = Likeness(box), materials_of(box), box.users_collection[0], box
            # Its own space: across x, through y from 0, standing on 0; turned so its y runs through the box.
            turn = 0.0 if through == 1 else -math.pi / 2
            location = Vector((0.0, 0.0, lo.z))
            location[across] = (lo[across] + hi[across]) / 2
            location[through] = lo[through]
            settings = {"opening_width": (a1 - a0) / UNIT, "opening_height": (z1 - z0) / UNIT,
                        "depth": (hi[through] - lo[through]) / UNIT}
        else:
            self.boxed = ""
            c = snapped_cursor(context)
            turn = self.turn
            half = (int(self.depth / 2 / g) * g if self.grid else self.depth / 2) * UNIT
            location = c + Matrix.Rotation(turn, 3, "Z") @ Vector((0.0, -half, 0.0))
            settings = {"opening_width": self.width, "opening_height": self.height, "depth": self.depth}
        from . import makers
        settings.update(segments=self.segments, arch_thickness=self.thickness, outside=self.outside)
        obj = makers.make(context, "arch", settings, location, turn, mats, col, like)
        if gone is not None:
            bpy.data.objects.remove(gone, do_unlink=True)
        select_only(context, [obj])
        return {"FINISHED"}


CLASSES = [MAP_OT_draw_brush, MAP_OT_resize, MAP_OT_snap_to_grid, MAP_OT_square, MAP_OT_apply_last, MAP_OT_cancel_last, MAP_OT_box, MAP_OT_hollow, MAP_OT_opening, MAP_OT_clip, MAP_OT_stairs, MAP_OT_cylinder, MAP_OT_arch]


def draw(layout, context):
    box = layout.box()
    box.label(text="Brush tools", icon="TOOL_SETTINGS")
    draw_buttons(box)


def draw_buttons(box):
    grid = box.grid_flow(columns=2, align=True)
    grid.operator("psmap.hollow", icon="MOD_SOLIDIFY")
    op = grid.operator("psmap.opening", text="Door", icon="MOD_BOOLEAN")
    op.width, op.height, op.sill = 64, 112, 0
    op = grid.operator("psmap.opening", text="Window", icon="MOD_BOOLEAN")
    op.width, op.height, op.sill = 48, 48, 40
    op = grid.operator("psmap.opening", text="Hole", icon="MOD_BOOLEAN")
    op.width, op.height, op.sill = 64, 64, 0
    grid.operator("psmap.clip", icon="SCULPTMODE_HLT")
    grid.operator("psmap.stairs", icon="MOD_ARRAY")
    grid.operator("psmap.cylinder", icon="MESH_CYLINDER")
    grid.operator("psmap.arch", icon="SPHERECURVE")
    row = box.row(align=True)
    row.operator("psmap.cut_through", icon="MOD_BOOLEAN")
    row.operator("psmap.apply_cut", icon="CHECKMARK")
    row = box.row(align=True)
    row.operator("psmap.map_edge", icon="MOD_EDGESPLIT")
    row.prop(bpy.context.scene, "ps_map_ceiling", text="Ceiling")
    box.label(text="Size and turn: the panel at the bottom left (F9)", icon="INFO")


# ---------- Ctrl+Z in a tool's panel (F9) ----------
# Blender's redo panel changes the tool's result all in one undo step (Ctrl+Z took the whole door away). Each change in
# the panel is kept here, and Ctrl+Z (psmap.panel_undo) brings the panel back to the settings before it: the tool is
# undone and run again with them. Back at the first ones, Ctrl+Z is Blender's own (the tool undone).
_panel = {"ptr": 0, "op": "", "states": [], "carry": None}


def tool_settings(op):
    out = {}
    for prop in op.properties.bl_rna.properties:
        if prop.identifier == "rna_type" or prop.is_hidden or prop.type in ("POINTER", "COLLECTION"):
            continue
        v = getattr(op.properties, prop.identifier)
        out[prop.identifier] = tuple(v) if getattr(prop, "is_array", False) else v
    return out


def remembered(cls):
    """The tool's settings kept each time it runs (a new use starts its list afresh; a change in its panel adds to it)."""
    run = cls.execute

    def execute(self, context):
        # Where everything is, worked out first: run again from its panel (F9), the tool comes right after Blender's undo,
        # the objects' world places not yet made again (a room taken for at the world's middle: the window went into the
        # wall on the other side).
        context.view_layer.update()
        done = run(self, context)
        if "FINISHED" in done:
            ptr, state = self.as_pointer(), tool_settings(self)
            if _panel["carry"] is not None:
                # Run again by Ctrl+Z with the settings before: the list goes on, this run is its last entry already.
                _panel.update(ptr=ptr, op=self.bl_idname, states=_panel["carry"], carry=None)
            elif ptr != _panel["ptr"] or self.bl_idname != _panel["op"]:
                _panel.update(ptr=ptr, op=self.bl_idname, states=[state])
            elif not _panel["states"] or _panel["states"][-1] != state:
                _panel["states"].append(state)
        return done
    cls.execute = execute
    return cls


class MAP_OT_panel_undo(bpy.types.Operator):
    bl_idname = "psmap.panel_undo"
    bl_label = "Undo the last change in the tool's panel"
    bl_description = "Ctrl+Z after changing a tool's settings in its panel: the settings before (not the whole tool)"
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        wm = context.window_manager
        last = wm.operators[-1] if wm.operators else None
        if last is None or last.as_pointer() != _panel["ptr"] or len(_panel["states"]) < 2:
            return {"PASS_THROUGH"}  # nothing changed in a panel: Blender's own Ctrl+Z
        states = _panel["states"][:-1]
        before = dict(states[-1])
        idname = _panel["op"]
        window, screen = context.window, context.screen

        def later():
            try:
                area = next((a for a in screen.areas if a.type == "VIEW_3D"), None)
                region = next((r for r in area.regions if r.type == "WINDOW"), None) if area else None
                with bpy.context.temp_override(window=window, screen=screen, area=area, region=region):
                    bpy.ops.ed.undo()
                    _panel["carry"] = states
                    # PSMAP_OT_box, as Blender keeps it, is bpy.ops.psmap.box.
                    module, name = idname.split("_OT_") if "_OT_" in idname else idname.split(".")
                    module, name = module.lower(), name.lower()
                    getattr(getattr(bpy.ops, module), name)("EXEC_DEFAULT", **before)
            except (RuntimeError, ReferenceError, TypeError, AttributeError, StopIteration) as e:
                print(f"Panel undo: {e}")
            finally:
                _panel["carry"] = None
            return None
        # A moment later, from the window (an undo run from inside an operator, or under the panel, is not safe).
        bpy.app.timers.register(later, first_interval=0.02)
        return {"FINISHED"}


def tool_material(tool):
    ensure_materials()
    return next(m for m in bpy.data.materials if m.get("ps_tool") == tool)


def map_ceiling(context):
    """The height (metres) the map's edge is closed up to by player clips: the map's own (Play → map ceiling, units), else
    its highest brush and 128 units over it."""
    scene = context.scene
    if scene.ps_map_ceiling > 0:
        return scene.ps_map_ceiling * UNIT
    from . import map_collection, map_objects
    tops = [world_box(o)[1].z for o in map_objects(map_collection(scene)) if is_brush(o) and not o.get("ps_edge_clip")]
    return (max(tops) if tops else 0.0) + 128 * UNIT


class MAP_OT_map_edge(bpy.types.Operator):
    bl_idname = "psmap.map_edge"
    bl_label = "Map edge"
    bl_description = ("The selected walls are the map's edge: their side turned away from the spawns is not drawn "
                      "(Nodraw: nobody sees it), and a player clip over them up to the map's ceiling: nobody gets over")
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        object_mode(context)
        from . import map_collection, map_objects, makers
        scene = context.scene
        spawns = [o.matrix_world.translation for o in map_objects(map_collection(scene)) if o.get("ps_entity") == "spawn"]
        walls = [o for o in selected_brushes(context) if o.ps_maker.kind in ("", "wall") and not o.get("ps_parts")
                 or o.ps_maker.kind == "wall"]
        if not walls:
            self.report({"WARNING"}, "Select the walls at the map's edge")
            return {"CANCELLED"}
        if spawns:
            middle = sum(spawns, Vector()) / len(spawns)
        else:
            boxes = [world_box(o) for o in walls]
            middle = sum(((a + b) / 2 for a, b in boxes), Vector()) / len(boxes)
        nodraw, clip = tool_material("nodraw"), tool_material("clip")
        ceiling = map_ceiling(context)
        made = []
        for o in walls:
            lo, hi = world_box(o)
            centre = (lo + hi) / 2
            away = Vector((centre.x - middle.x, centre.y - middle.y, 0.0))
            if away.length < 1e-6:
                continue
            # The side looking most away from the middle of the map (its spawns).
            k = 0 if abs(away.x) * (hi.y - lo.y) >= abs(away.y) * (hi.x - lo.x) else 1
            out = Vector()
            out[k] = 1.0 if away[k] > 0 else -1.0
            if nodraw.name not in o.data.materials:
                o.data.materials.append(nodraw)
            slot = list(o.data.materials).index(nodraw)
            if o.ps_maker.kind == "wall":
                local = o.matrix_basis.to_3x3().inverted() @ out
                i = max(range(6), key=lambda j: local.dot(makers.DIRECTIONS[j]))
                o.ps_maker.dir_mats[i] = slot
                makers.rebuild(o)
            else:
                rot = placed(o).to_3x3()
                for f in o.data.polygons:
                    if (rot @ f.normal).dot(out) > 0.999:
                        f.material_index = slot
                o.data.update()
            o["ps_edge"] = 1
            had = any(c.get("ps_edge_clip") and (world_box(c)[0] - Vector((lo.x, lo.y, hi.z))).length < 1e-3
                      for c in map_objects(map_collection(scene)) if c.type == "MESH")
            if ceiling > hi.z + UNIT and not had:
                b = box_brush("Edge clip", (lo.x, lo.y, hi.z), (hi.x, hi.y, ceiling), [clip],
                              child_collection(scene, "Clips"))
                if b:
                    b["ps_edge_clip"] = 1
                    made.append(b)
        select_only(context, walls)
        self.report({"INFO"}, f"{len(walls)} walls made the map's edge, {len(made)} clips up to "
                              f"{round(ceiling / UNIT)} units")
        return {"FINISHED"}


CLASSES.append(MAP_OT_map_edge)
remembered(MAP_OT_box)
remembered(MAP_OT_hollow)
remembered(MAP_OT_opening)
remembered(MAP_OT_clip)
remembered(MAP_OT_stairs)
remembered(MAP_OT_cylinder)
remembered(MAP_OT_arch)
CLASSES.append(MAP_OT_panel_undo)
