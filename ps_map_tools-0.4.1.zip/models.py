"""Models: meshes made elsewhere (a plant, a pot, a staircase from a library) put on the map as they are — their own UVs,
materials and smooth shading, their modifiers and particles applied at export — lit by the probes as players are, never
made brushes (they live in the map's Models collection). A model does not collide itself: its boxes do, brushes of the
Collision tool (invisible, stopping players and bullets) parented to it, so they move and turn with it; Resize trims
them, and a model may have several."""
import bpy
from mathutils import Vector

from . import BRUSH_KEYS, child_collection, is_brush, make_brush, material, object_mode, TOOLS

MODELS = "Models"


def is_model(obj):
    return obj is not None and obj.get("ps_entity") == "model"


def boxes_of(obj):
    return [c for c in obj.children if c.get("ps_model_box")]


def collision_material():
    _, name, colour, _ = next(t for t in TOOLS if t[0] == "collide")
    return material(name, colour, "collide")


def add_box(model, collection):
    """A box round the model (its own axes, its modifiers counted), a brush of the Collision tool parented to it."""
    corners = [Vector(c) for c in model.bound_box]
    lo = Vector([min(c[k] for c in corners) for k in range(3)])
    hi = Vector([max(c[k] for c in corners) for k in range(3)])
    for k in range(3):
        if hi[k] - lo[k] < 1e-3:  # a flat model (a leaf): a thin box all the same
            lo[k] -= 0.01
            hi[k] += 0.01
    verts = [(x, y, z) for x in (lo.x, hi.x) for y in (lo.y, hi.y) for z in (lo.z, hi.z)]
    faces = [(0, 1, 3, 2), (4, 6, 7, 5), (0, 4, 5, 1), (2, 3, 7, 6), (0, 2, 6, 4), (1, 5, 7, 3)]
    mesh = bpy.data.meshes.new(f"{model.name} collision")
    mesh.from_pydata(verts, [], faces)
    mesh.materials.append(collision_material())
    mesh.update()
    box = bpy.data.objects.new(f"{model.name} collision", mesh)
    collection.objects.link(box)
    box.parent = model
    box.matrix_parent_inverse.identity()  # in the model's own space: its corners are the model's box
    box["ps_model_box"] = 1
    box.display_type = "WIRE"
    box.hide_render = True
    make_brush(box)
    surface = next((str(m.get("ps_surface")) for m in model.data.materials if m and m.get("ps_surface")), "")
    if surface:
        box["ps_surface"] = surface  # what bullets meet
    return box


class MAP_OT_make_model(bpy.types.Operator):
    bl_idname = "psmap.make_model"
    bl_label = "Make model"
    bl_description = ("The selected meshes as models: seen as they are (their own UVs, materials, smoothing; modifiers and "
                      "particles applied at export), lit as players are, not brushes; into the map's Models collection. "
                      "Each gets a collision box round it (players and bullets), moving with it: trim it with Resize, add "
                      "more with Add collision box, delete it for none")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return any(o.type == "MESH" and not is_model(o) and not o.get("ps_model_box") for o in context.selected_objects)

    def execute(self, context):
        object_mode(context)
        col = child_collection(context.scene, MODELS)
        made = []
        for o in [o for o in context.selected_objects if o.type == "MESH" and not is_model(o) and not o.get("ps_model_box")]:
            kind = o.get("ps_entity")
            if kind not in (None, "world", "solid", "detail"):
                continue  # a zone, a clip: not a model
            for c in list(o.users_collection):
                c.objects.unlink(o)
            col.objects.link(o)
            for key in BRUSH_KEYS + ("ps_entity", "ps_edge", "ps_edge_clip", "ps_keep"):
                if key in o:
                    del o[key]
            o["ps_entity"] = "model"
            o.display_type = "TEXTURED"
            if not flat_box(o):
                add_box(o, col)  # (a flat one, a leaf: no box — nothing walks on a leaf)
            made.append(o)
        self.report({"INFO"}, f"{len(made)} model(s), each with a collision box (Resize it, or delete it for none)")
        return {"FINISHED"}


class MAP_OT_add_collision_box(bpy.types.Operator):
    bl_idname = "psmap.add_collision_box"
    bl_label = "Add collision box"
    bl_description = "Another collision box round the selected model (then Resize it to the part that should collide)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return any(is_model(o) for o in context.selected_objects)

    def execute(self, context):
        object_mode(context)
        col = child_collection(context.scene, MODELS)
        boxes = [add_box(o, col) for o in context.selected_objects if is_model(o)]
        for o in context.selected_objects:
            o.select_set(False)
        for b in boxes:
            b.select_set(True)
        if boxes:
            context.view_layer.objects.active = boxes[-1]
        return {"FINISHED"}


class MAP_OT_model_back(bpy.types.Operator):
    bl_idname = "psmap.model_back"
    bl_label = "Make brush again"
    bl_description = "The selected model a brush again (into Seen; its collision boxes deleted)"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return any(is_model(o) for o in context.selected_objects)

    def execute(self, context):
        object_mode(context)
        seen = child_collection(context.scene, "Seen")
        for o in [o for o in context.selected_objects if is_model(o)]:
            for b in boxes_of(o):
                bpy.data.objects.remove(b, do_unlink=True)
            for c in list(o.users_collection):
                c.objects.unlink(o)
            seen.objects.link(o)
            del o["ps_entity"]
            make_brush(o)
        return {"FINISHED"}


# ---------- Lighter (fewer triangles) ----------
SIMPLIFY = "PS simplify"  # the Decimate modifier made here (the export applies it; the mesh itself is kept)
AUTO_PER_METRE = 1500     # Auto: triangles a metre of the model's size (a chair: a couple of thousand)


def simplify_of(obj):
    return obj.modifiers.get(SIMPLIFY) if obj.type == "MESH" else None


def triangles(mesh):
    return sum(len(p.vertices) - 2 for p in mesh.polygons)


def triangles_now(obj, depsgraph):
    """The model's triangles as the game gets them (its modifiers, the simplifying too)."""
    return triangles(obj.evaluated_get(depsgraph).data)


class MAP_OT_model_simplify(bpy.types.Operator):
    bl_idname = "psmap.model_simplify"
    bl_label = "Simplify"
    bl_description = ("The selected models lighter: fewer triangles (Blender's Decimate, the last modifier, applied at "
                      "export; the mesh itself is kept). Auto: by the model's size (about 1 500 triangles a metre); the "
                      "Keep slider then sets it. Off: as it was")
    bl_options = {"REGISTER", "UNDO"}
    how: bpy.props.EnumProperty(items=[("auto", "Auto", ""), ("off", "Off", "")], default="auto",
                                options={"SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        return any(is_model(o) for o in context.selected_objects)

    def execute(self, context):
        import math
        done = []
        for o in [o for o in context.selected_objects if is_model(o)]:
            mod = simplify_of(o)
            if self.how == "off":
                if mod is not None:
                    o.modifiers.remove(mod)
                    done.append(o.name)
                continue
            if mod is None:
                mod = o.modifiers.new(SIMPLIFY, "DECIMATE")
                mod.decimate_type = "COLLAPSE"
                mod.use_collapse_triangulate = True
            mod.show_viewport = mod.show_render = True
            # Its triangles before it, and how many its size asks for.
            mod.show_viewport = False
            context.view_layer.update()
            dg = context.evaluated_depsgraph_get()
            before = max(1, triangles_now(o, dg))
            mod.show_viewport = True
            size = max(o.dimensions) if max(o.dimensions) > 0 else 1.0
            want = max(300, int(AUTO_PER_METRE * size))
            mod.ratio = min(1.0, want / before)
            done.append(f"{o.name} {before:,} → about {int(before * mod.ratio):,}")
        self.report({"INFO"}, ("Simplified: " if self.how == "auto" else "Back as it was: ") + "; ".join(done)
                    if done else "Nothing to do")
        return {"FINISHED"}


# ---------- Flat parts as pictures (cards) ----------
def card_sources(model):
    """What of a model can be a card: the objects its particles scatter (a plant's leaves), or the model itself when it
    has none."""
    out = [p.settings.instance_object for p in model.particle_systems
           if p.settings.render_type == "OBJECT" and p.settings.instance_object is not None]
    return out or [model]


def flat_box(obj):
    """Whether an object looks flat by its box (a leaf): cheap enough for a panel's draw."""
    if obj is None or obj.type != "MESH":
        return False
    corners = [Vector(c) for c in obj.bound_box]
    ext = [max(c[k] for c in corners) - min(c[k] for c in corners) for k in range(3)]
    return max(ext) > 0 and min(ext) <= 0.05 * max(ext) and len(obj.data.polygons) >= 16


def cards_on(model):
    return any(p.settings.get("ps_card_source") for p in model.particle_systems) or \
        any(c.get("ps_card_of") == model.name for c in model.children)


def card_object(src, size, folder):
    """The card standing for `src` (made once: its picture is kept in the map's cards folder, its object reused)."""
    import os
    from .overlay import exporter
    kept = bpy.data.objects.get(str(src.get("ps_card", "")))
    if kept is not None:
        return kept
    name = "".join(ch if ch.isalnum() or ch in "-_ " else "_" for ch in src.data.name)
    mesh = exporter().card_mesh(src.data, size, os.path.join(folder, name + ".png"))
    if mesh is None:
        return None
    card = bpy.data.objects.new(f"{src.name} card", mesh)
    for c in src.users_collection:
        c.objects.link(card)
    card.matrix_world = src.matrix_world.copy()
    card["ps_card_of"] = src.name
    if src.get("ps_entity") == "model":
        card["ps_entity"] = "model"
    src["ps_card"] = card.name
    return card


def hide_original(obj, hide):
    """The original kept as it was, hidden and left out of the export while its card stands for it (shown again after)."""
    if hide:
        obj["ps_card_hidden"] = 1
        obj["ps_card_render"] = int(obj.hide_render)
        obj.hide_set(True)
        obj.hide_render = True
    else:
        obj.hide_render = bool(obj.get("ps_card_render", 0))
        obj.pop("ps_card_hidden", None)
        obj.pop("ps_card_render", None)
        if obj.name in bpy.context.view_layer.objects:
            obj.hide_set(False)


class MAP_OT_model_cards(bpy.types.Operator):
    bl_idname = "psmap.model_cards"
    bl_label = "Leaves as pictures"
    bl_description = ("The selected models' flat parts (a plant's leaves, scattered by its particles; or the model itself, "
                      "flat) drawn as pictures: a square of two triangles each, its outside transparent — the same look, "
                      "a few hundredth of the triangles (a modelled leaf of 948 faces, thousands of them). Seen here at "
                      "once; the originals are kept, hidden, and left out of the export. The pictures are kept in the "
                      "map's cards folder (made once). Again: the originals back")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return any(is_model(o) or o.get("ps_card_of") for o in context.selected_objects)

    def execute(self, context):
        import os
        object_mode(context)
        picked = set()
        for o in context.selected_objects:
            if o.get("ps_card_of"):
                # A card selected: the model it stands for (its own card), or the plants whose particles scatter it.
                if o.parent is not None and o.parent.name == o["ps_card_of"]:
                    picked.add(o.parent)
                else:
                    picked.update(x for x in context.scene.objects
                                  if any(p.settings.instance_object == o for p in x.particle_systems))
                continue
            if is_model(o):
                picked.add(o)
        folder = bpy.path.abspath("//cards") if bpy.data.filepath else os.path.join(bpy.app.tempdir, "cards")
        size = min(int(getattr(context.scene, "ps_texture_size", "1024") or 1024), 512)
        made = gone = 0
        # One way for all the selection: any of it as pictures, all back; else all as pictures (plants sharing their
        # particle settings: the second one turned back what the first had just made).
        back = any(cards_on(model) for model in picked)
        for model in picked:
            if back:
                for p in model.particle_systems:
                    s = p.settings
                    src = bpy.data.objects.get(str(s.get("ps_card_source", "")))
                    if src is None:
                        continue
                    card = s.instance_object
                    s.instance_object = src
                    del s["ps_card_source"]
                    hide_original(src, False)
                    src.pop("ps_card", None)
                    if card is not None and card.get("ps_card_of") and not any(
                            x.instance_object == card for x in bpy.data.particles):
                        bpy.data.objects.remove(card, do_unlink=True)
                    gone += 1
                for c in [c for c in model.children if c.get("ps_card_of") == model.name]:
                    bpy.data.objects.remove(c, do_unlink=True)
                    hide_original(model, False)
                    model.pop("ps_card", None)
                    gone += 1
                continue
            if model.particle_systems:
                for p in model.particle_systems:
                    s = p.settings
                    src = s.instance_object
                    if s.render_type != "OBJECT" or src is None or s.get("ps_card_source"):
                        continue
                    card = card_object(src, size, folder)
                    if card is None:
                        continue
                    s["ps_card_source"] = src.name
                    s.instance_object = card
                    hide_original(src, True)
                    made += 1
            else:
                card = card_object(model, size, folder)
                if card is None:
                    continue
                card.parent = model
                card.matrix_parent_inverse.identity()
                card.matrix_basis.identity()
                hide_original(model, True)
                made += 1
        self.report({"INFO"}, f"{made} part(s) as pictures, {gone} back as they were" if made or gone
                    else "Nothing flat to make a picture of (a leaf: thinner than a 20th of its size)")
        return {"FINISHED"}


CLASSES = [MAP_OT_make_model, MAP_OT_add_collision_box, MAP_OT_model_back, MAP_OT_model_cards, MAP_OT_model_simplify]
