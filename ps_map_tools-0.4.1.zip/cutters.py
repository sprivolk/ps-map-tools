"""Cutters: a brush that cuts its shape out of others, live (a tunnel's way through a slanted wall). The cut is Blender's
Boolean modifier (Difference, Exact) on each brush cut, the cutter its object: moved or resized, the hole follows. The
cutter is drawn as a wire, is never exported (ps_cutter), and gives the hole's sides its material. The export takes the
brushes as cut (export_map.cut_brushes); Apply cut makes a cut for good."""
import bpy

from . import is_brush

CUT = "PS cut"  # the name of the modifiers made here (others are left alone)


def is_cutter(obj):
    return obj is not None and bool(obj.get("ps_cutter"))


def cuts_of(obj):
    """The cut modifiers on a brush."""
    return [m for m in obj.modifiers if m.type == "BOOLEAN" and m.name.startswith(CUT)] if obj.type == "MESH" else []


def cut_by(cutter, objects):
    """The brushes the cutter cuts."""
    return [o for o in objects if any(m.object is cutter for m in cuts_of(o))]


def make_cutter(obj):
    obj["ps_cutter"] = 1
    obj["ps_entity"] = "cutter"  # not a seen brush: Solid, Detail and the checks leave it alone
    obj.display_type = "WIRE"
    obj.show_in_front = True  # seen inside the wall it cuts


class MAP_OT_cut_through(bpy.types.Operator):
    bl_idname = "psmap.cut_through"
    bl_label = "Cut through"
    bl_description = ("Cuts the brush selected last (the cutter) out of the other selected brushes, live: move or resize "
                      "the cutter and the hole follows. The cutter becomes a wire, not exported; the hole's sides take its "
                      "material. Apply cut makes it for good")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return is_brush(context.active_object) and len(context.selected_objects) > 1

    def execute(self, context):
        cutter = context.active_object
        targets = [o for o in context.selected_objects if o is not cutter and is_brush(o) and not is_cutter(o)]
        if not targets:
            self.report({"WARNING"}, "Select the brushes to cut, then the cutter last (Shift+click)")
            return {"CANCELLED"}
        if cuts_of(cutter):
            self.report({"WARNING"}, f"{cutter.name} is cut itself: Apply cut on it first")
            return {"CANCELLED"}
        make_cutter(cutter)
        for o in targets:
            if any(m.object is cutter for m in cuts_of(o)):
                continue
            m = o.modifiers.new(f"{CUT} {cutter.name}", "BOOLEAN")
            m.operation = "DIFFERENCE"
            m.solver = "EXACT"
            m.object = cutter
            # A brush of pieces touching (a room's walls, floor, ceiling): without it the cut came out wrong (half the
            # room gone, a face where the cutter ends).
            m.use_self = True
            m.material_mode = "TRANSFER"  # the hole's sides of the cutter's material
            m.show_expanded = False
        for o in targets:
            o.select_set(False)
        self.report({"INFO"}, f"{cutter.name} cuts {len(targets)} brush(es): move it (G) or Resize it")
        return {"FINISHED"}


def apply_cuts(context, obj, only=None):
    """The brush's cuts (or only those of one cutter) put into its mesh for good: a plain brush of what it is then."""
    from . import makers
    done = 0
    for m in cuts_of(obj):
        if m.object is None:
            obj.modifiers.remove(m)  # its cutter deleted: nothing cut
            continue
        if only is not None and m.object is not only:
            continue
        with context.temp_override(object=obj, active_object=obj, selected_objects=[obj]):
            bpy.ops.object.modifier_apply(modifier=m.name)
        done += 1
    if done and obj.ps_maker.kind:
        makers.plain(obj, "cut")
    return done


class MAP_OT_apply_cut(bpy.types.Operator):
    bl_idname = "psmap.apply_cut"
    bl_label = "Apply cut"
    bl_description = ("The cut made for good: a cutter selected — the holes it makes go into the brushes and it is "
                      "deleted; a brush selected — its holes go into it. A brush made with the map tools (a room, a wall) "
                      "becomes a plain brush then (no more settings)")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return any(is_cutter(o) or cuts_of(o) for o in context.selected_objects if o.type == "MESH")

    def execute(self, context):
        from . import object_mode
        object_mode(context)
        objects = list(context.scene.objects)
        cutters = [o for o in context.selected_objects if is_cutter(o)]
        brushes = [o for o in context.selected_objects if not is_cutter(o) and cuts_of(o)]
        used = set(cutters) | {m.object for o in brushes for m in cuts_of(o) if m.object is not None}
        done = 0
        for c in cutters:
            for o in cut_by(c, objects):
                done += apply_cuts(context, o, only=c)
        for o in brushes:
            done += apply_cuts(context, o)
        # A cutter that cuts nothing any more goes.
        for c in used:
            if not cut_by(c, objects):
                bpy.data.objects.remove(c, do_unlink=True)
        self.report({"INFO"}, f"{done} cut(s) applied")
        return {"FINISHED"}


CLASSES = [MAP_OT_cut_through, MAP_OT_apply_cut]
