"""Symmetric maps (Build → Mirror): the selected copied onto the other half of the map, through the mirror centre — mirrored
across X or Y, or turned 180° round it (whichever side one plays, the same map). A copy stays linked to its original: it
follows every move and change of it, and moved by hand it goes back. Unlink lets it be changed on its own; Reset and link
puts it back where the symmetry has it and links it again. T and CT swap on the copy (spawns, buy zones).

A pair is two objects with the same ps_mirror_pair (an int: it survives renames and the export's extras): the original
(ps_mirror_role 1) and its copy (2, with ps_mirror_linked and the ps_mirror_mode it was made with). ps_mirror_name is the
object's own name when it was paired: a Shift+D duplicate (the same pair, another name) is no part of it."""
import math

import bmesh
import bpy
import gpu
import numpy as np
from bpy.app.handlers import persistent
from gpu_extras.batch import batch_for_shader
from mathutils import Matrix, Vector

from . import UNIT, _undoing, is_brush

ROLE, PAIR, LINKED, MODE, NAME = "ps_mirror_role", "ps_mirror_pair", "ps_mirror_linked", "ps_mirror_mode", "ps_mirror_name"
OWN = (ROLE, PAIR, LINKED, MODE, NAME, "ps_maker", "_RNA_UI")  # what is not copied from the original
MODES = [("x", "Mirror X", "Mirrored across the centre's X: left and right swap (x → −x)"),
         ("y", "Mirror Y", "Mirrored across the centre's Y: front and back swap (y → −y)"),
         ("turn", "Turn 180°", "Turned half round the centre: whichever side one plays, the same map")]
SWAP_TEAM = {"T": "CT", "CT": "T"}
SWAP_OPEN = {"front": "back", "back": "front"}
FLIP_Y = Matrix.Diagonal((1.0, -1.0, 1.0))
_busy = [False]
_in_background = [False]  # the handler in a background Blender (the tests); else only with a window
_draw = [None]


# ---------- The symmetry ----------
def centre(scene):
    o = scene.ps_mirror_centre
    return o.matrix_world.translation.copy() if o is not None else Vector()


def symmetry(mode, c):
    """The map's symmetry as a matrix: a point of one half to the other."""
    s = {"x": (-1.0, 1.0, 1.0), "y": (1.0, -1.0, 1.0)}.get(mode, (-1.0, -1.0, 1.0))
    return Matrix.Translation(c) @ Matrix.Diagonal(s).to_4x4() @ Matrix.Translation(-c)


def plain_path(orig):
    """A brush is its corners (its object only placed): its copy too, the symmetry put into the mesh. Anything else
    (entities, models, what has children) keeps a turn of its own: the copy is placed by the symmetry, its mesh mirrored
    in its own Y where the symmetry mirrors (so it is still turned, not mirrored: a spawn looks where it should)."""
    return is_brush(orig) and not orig.children


def placing(orig, mode, c):
    """(the copy's matrix in the world, what its mesh is of the original's: its own corners through this)."""
    t = symmetry(mode, c)
    if plain_path(orig):
        mw = orig.matrix_world
        return Matrix.Translation(t @ mw.translation), t.to_3x3() @ mw.to_3x3()
    k = FLIP_Y if mode != "turn" else Matrix.Identity(3)
    return t @ orig.matrix_world @ k.to_4x4(), k


# ---------- Pairs ----------
def pairs(scene):
    """Pair → [original, copy] (either None when gone). A duplicate of one (Shift+D: the same pair, another name) is let
    go: an object of its own. One renamed keeps its pair (its name noted again)."""
    found, extra = {}, []
    for o in scene.objects:
        pid = o.get(PAIR)
        if pid is None:
            continue
        slot = found.setdefault(int(pid), [None, None])
        i = 0 if o.get(ROLE) == 1 else 1
        if slot[i] is None:
            slot[i] = o
        elif o.name == o.get(NAME) and slot[i].name != slot[i].get(NAME):
            extra.append(slot[i])
            slot[i] = o
        else:
            extra.append(o)
    for o in extra:
        forget(o)
    for slot in found.values():
        for o in slot:
            if o is not None and o.get(NAME) != o.name:
                o[NAME] = o.name
    return found


def forget(o):
    for k in (ROLE, PAIR, LINKED, MODE, NAME):
        if k in o:
            del o[k]


def partner(scene, o):
    pid = o.get(PAIR)
    if pid is None:
        return None, None
    orig, copy = pairs(scene).get(int(pid), (None, None))
    return orig, copy


# ---------- A copy made like its original ----------
def same_mesh(orig, copy, k):
    a, b = orig.data, copy.data
    if (len(a.vertices) != len(b.vertices) or len(a.polygons) != len(b.polygons)
            or list(a.materials) != list(b.materials)):
        return False
    n = len(a.vertices)
    ca, cb = np.empty(n * 3, np.float32), np.empty(n * 3, np.float32)
    a.vertices.foreach_get("co", ca)
    b.vertices.foreach_get("co", cb)
    if not np.allclose(ca.reshape(-1, 3) @ np.array(k, np.float32).T, cb.reshape(-1, 3), atol=1e-4):
        return False
    ia, ib = np.empty(len(a.polygons), np.int32), np.empty(len(b.polygons), np.int32)
    a.polygons.foreach_get("material_index", ia)
    b.polygons.foreach_get("material_index", ib)
    if not (ia == ib).all():
        return False
    # The faces' own texture shift, turn and scale (the Art tab's Faces) go to the copy too.
    for name in ("ps_tex_off", "ps_tex_scale", "ps_tex_rot"):
        x, y = a.attributes.get(name), b.attributes.get(name)
        if (x is None) != (y is None):
            return False
        if x is None or x.data_type != y.data_type:
            continue
        key, w = ("value", 1) if x.data_type == "FLOAT" else ("vector", 3 if x.data_type == "FLOAT_VECTOR" else 2)
        ax, bx = np.empty(len(x.data) * w, np.float32), np.empty(len(y.data) * w, np.float32)
        x.data.foreach_get(key, ax)
        y.data.foreach_get(key, bx)
        if ax.shape != bx.shape or not np.allclose(ax, bx, atol=1e-6):
            return False
    return True


def copy_mesh(orig, copy, k):
    """The copy's mesh: the original's through k (its faces turned outward again where k mirrors). Into the copy's own
    mesh (no new data-block: this runs in a handler too)."""
    me = copy.data
    me.materials.clear()
    for m in orig.data.materials:
        me.materials.append(m)
    bm = bmesh.new()
    try:
        bm.from_mesh(orig.data)
        bm.transform(k.to_4x4())
        if k.determinant() < 0:
            bmesh.ops.reverse_faces(bm, faces=bm.faces[:])
        bm.to_mesh(me)
    finally:
        bm.free()
    me.update()


def _value(v):
    return v.to_list() if hasattr(v, "to_list") else v


def door_axes(orig):
    """A door's thickness and width axes (doors.frame: the thinner of its own x and y is its thickness)."""
    corners = [Vector(c) for c in orig.bound_box]
    ext = [max(c[i] for c in corners) - min(c[i] for c in corners) for i in range(3)]
    t = 0 if ext[0] <= ext[1] else 1
    return t, 1 - t


def copy_settings(orig, copy, k):
    """The original's settings on the copy: T and CT swapped; a door's hinge and front where the mirror puts them."""
    want = {}
    for key in orig.keys():
        if key in OWN:
            continue
        v = orig[key]
        if hasattr(v, "to_dict"):
            continue  # a group of settings (an add-on's own)
        want[key] = _value(v)
    if want.get("ps_team") in SWAP_TEAM:
        want["ps_team"] = SWAP_TEAM[want["ps_team"]]
    if orig.get("ps_entity") == "door" and orig.type == "MESH":
        t, w = door_axes(orig)
        if all(abs(k[i][j]) < 1e-6 for i in range(3) for j in range(3) if i != j):  # straight: its axes stay its axes
            if k[w][w] < 0:
                want["ps_door_hinge"] = 1 - int(want.get("ps_door_hinge", 0))
            if k[t][t] < 0 and want.get("ps_door_open") in SWAP_OPEN:
                want["ps_door_open"] = SWAP_OPEN[want["ps_door_open"]]
    for key, v in want.items():
        if _value(copy.get(key)) != v:
            copy[key] = v
    for key in list(copy.keys()):
        if key not in OWN and key not in want and not hasattr(copy[key], "to_dict"):
            del copy[key]
    maker = getattr(copy, "ps_maker", None)
    if maker is not None and maker.kind:
        maker.kind = ""  # a copy is a plain brush: built again from its settings it would be the original, unmirrored


def follow(orig, copy, mode, c, geometry=True):
    """The copy where the symmetry puts the original, made like it."""
    mw, k = placing(orig, mode, c)
    if any(abs(a - b) > 1e-6 for ra, rb in zip(copy.matrix_world, mw) for a, b in zip(ra, rb)):
        copy.matrix_world = mw
    if geometry and orig.type == "MESH" and copy.type == "MESH" and not same_mesh(orig, copy, k):
        copy_mesh(orig, copy, k)
    if orig.type == "EMPTY":
        copy.empty_display_type, copy.empty_display_size = orig.empty_display_type, orig.empty_display_size
    copy_settings(orig, copy, k)


def depth(o):
    n = 0
    while o is not None and o.parent is not None:
        n, o = n + 1, o.parent
    return n


@persistent
def on_depsgraph(scene, depsgraph):
    """An original changed (moved, reshaped, its settings): its linked copy follows. A linked copy moved by hand: back. The
    centre moved: every linked copy."""
    if _busy[0] or _undoing[0] or (bpy.app.background and not _in_background[0]) or not hasattr(scene, "ps_mirror_centre"):
        return
    centre_obj = scene.ps_mirror_centre
    work, everything = {}, False
    for u in depsgraph.updates:
        if not isinstance(u.id, bpy.types.Object):
            continue
        o = u.id.original
        if centre_obj is not None and o == centre_obj and u.is_updated_transform:
            everything = True
        pid = o.get(PAIR)
        if pid is not None:
            work[int(pid)] = True
    if not work and not everything:
        return
    _busy[0] = True
    try:
        table = pairs(scene)
        if everything:
            for pid in table:
                work.setdefault(pid, False)
        c = centre(scene)
        todo = [(pid, table[pid]) for pid in work if pid in table]
        todo.sort(key=lambda item: depth(item[1][0]) if item[1][0] is not None else 0)
        for pid, (orig, copy) in todo:
            if orig is None or copy is None or not copy.get(LINKED):
                continue
            if orig.mode != "OBJECT" or copy.mode != "OBJECT":
                continue  # in Edit Mode: when it is left
            follow(orig, copy, str(copy.get(MODE, "x")), c)
    except (ReferenceError, RuntimeError, AttributeError) as e:
        print(f"Mirror: {e}")
    finally:
        _busy[0] = False


def watch_settings():
    """Twice a second: a setting changed on an original (its team, surface, a door's way: no update tells of those) goes
    over to its linked copy."""
    try:
        scene = bpy.context.scene
        if scene is not None and not _busy[0] and not _undoing[0] and hasattr(scene, "ps_mirror_centre"):
            _busy[0] = True
            try:
                for orig, copy in pairs(scene).values():
                    if orig is not None and copy is not None and copy.get(LINKED) and orig.mode == "OBJECT":
                        copy_settings(orig, copy, placing(orig, str(copy.get(MODE, "x")), centre(scene))[1])
            finally:
                _busy[0] = False
    except (ReferenceError, RuntimeError, AttributeError):
        pass
    return 0.5


# ---------- Operators ----------
def ensure_centre(scene):
    o = scene.ps_mirror_centre
    if o is not None and o.name in scene.objects:
        return o
    o = bpy.data.objects.new("Mirror centre", None)
    o.empty_display_type = "PLAIN_AXES"
    o.empty_display_size = 64 * UNIT
    o.hide_render = True
    scene.collection.objects.link(o)  # outside the map's collection: nothing of the map, the export leaves it out
    scene.ps_mirror_centre = o
    return o


def with_children(objs):
    out, seen = [], set()

    def add(o):
        if o.name in seen:
            return
        seen.add(o.name)
        out.append(o)
        for ch in o.children:
            add(ch)
    for o in objs:
        add(o)
    return out


class MAP_OT_mirror_copy(bpy.types.Operator):
    bl_idname = "psmap.mirror_copy"
    bl_label = "Copy to the other half"
    bl_description = ("The selected (with what is parented to them) copied onto the other half of the map through the mirror "
                      "centre, as the symmetry chosen above has it; each copy linked to its original (it follows it). "
                      "T and CT swap on the copies")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT" and bool(context.selected_objects)

    def execute(self, context):
        scene = context.scene
        ensure_centre(scene)
        mode, c = scene.ps_mirror_mode, centre(scene)
        table = pairs(scene)
        picked, skipped = [], 0
        for o in with_children(context.selected_objects):
            if o == scene.ps_mirror_centre:
                continue
            pid = o.get(PAIR)
            if pid is not None:
                orig, copy = table.get(int(pid), (None, None))
                if o.get(ROLE) != 1 or copy is not None:
                    skipped += 1  # a copy, or one that has its copy already
                    continue
                forget(o)  # its copy was deleted: a new pair
            picked.append(o)
        if not picked:
            self.report({"WARNING"}, "Nothing to copy: the selected are copies or have theirs already")
            return {"CANCELLED"}
        next_id = 1 + max([int(o.get(PAIR)) for o in bpy.data.objects if o.get(PAIR) is not None] or [0])
        made = {}
        _busy[0] = True
        try:
            for o in sorted(picked, key=depth):
                copy = o.copy()
                if o.type == "MESH":
                    copy.data = o.data.copy()
                for col in o.users_collection:
                    col.objects.link(copy)
                copy.name = f"{o.name} mirror"
                if o.parent is not None:
                    copy.parent = made.get(o.parent.name, o.parent)
                    copy.matrix_parent_inverse = Matrix.Identity(4) if o.parent.name in made else o.matrix_parent_inverse
                o[PAIR], o[ROLE], o[NAME] = next_id, 1, o.name
                copy[PAIR], copy[ROLE], copy[NAME], copy[LINKED], copy[MODE] = next_id, 2, copy.name, 1, mode
                next_id += 1
                made[o.name] = copy
            context.view_layer.update()
            for o in sorted(picked, key=depth):
                follow(o, made[o.name], mode, c)
                context.view_layer.update()
        finally:
            _busy[0] = False
        more = f" ({skipped} skipped: copies or with theirs already)" if skipped else ""
        self.report({"INFO"}, f"{len(made)} copied onto the other half, linked{more}")
        return {"FINISHED"}


def selected_pairs(context):
    """(original, copy) of each pair one of the selected belongs to, both there."""
    table = pairs(context.scene)
    out, seen = [], set()
    for o in context.selected_objects:
        pid = o.get(PAIR)
        if pid is None or int(pid) in seen:
            continue
        orig, copy = table.get(int(pid), (None, None))
        if orig is not None and copy is not None:
            seen.add(int(pid))
            out.append((orig, copy))
    return out


class MAP_OT_mirror_unlink(bpy.types.Operator):
    bl_idname = "psmap.mirror_unlink"
    bl_label = "Unlink"
    bl_description = ("The selected copies (or the copies of the selected) no longer follow their originals: each can be "
                      "changed on its own. Reset and link puts one back")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return any(o.get(PAIR) is not None for o in context.selected_objects)

    def execute(self, context):
        n = 0
        for orig, copy in selected_pairs(context):
            if copy.get(LINKED):
                copy[LINKED] = 0
                n += 1
        self.report({"INFO"}, f"{n} unlinked" if n else "Nothing linked among the selected")
        return {"FINISHED"}


class MAP_OT_mirror_reset(bpy.types.Operator):
    bl_idname = "psmap.mirror_reset"
    bl_label = "Reset and link"
    bl_description = ("The selected copies (or the copies of the selected) back where the symmetry puts their originals, "
                      "made like them again, and linked: what was changed on a copy is undone")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT" and any(o.get(PAIR) is not None for o in context.selected_objects)

    def execute(self, context):
        scene = context.scene
        c = centre(scene)
        todo = sorted(selected_pairs(context), key=lambda p: depth(p[0]))
        _busy[0] = True
        try:
            for orig, copy in todo:
                copy[LINKED] = 1
                follow(orig, copy, str(copy.get(MODE, scene.ps_mirror_mode)), c)
                context.view_layer.update()
        finally:
            _busy[0] = False
        self.report({"INFO"}, f"{len(todo)} reset and linked" if todo else "No pair among the selected")
        return {"FINISHED"}


class MAP_OT_mirror_select(bpy.types.Operator):
    bl_idname = "psmap.mirror_select"
    bl_label = "Select the other half"
    bl_description = "The copies of the selected originals and the originals of the selected copies selected instead"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return context.mode == "OBJECT" and any(o.get(PAIR) is not None for o in context.selected_objects)

    def execute(self, context):
        chosen = set(o.name for o in context.selected_objects)
        others = [(c if o.name in chosen else o) for o, c in selected_pairs(context)]
        others = [x for x in others if x.name not in chosen] or others
        for o in context.selected_objects:
            o.select_set(False)
        for o in others:
            o.select_set(True)
        if others:
            context.view_layer.objects.active = others[-1]
        return {"FINISHED"}


class MAP_OT_mirror_centre(bpy.types.Operator):
    bl_idname = "psmap.mirror_centre"
    bl_label = "Centre to the 3D cursor"
    bl_description = "The mirror centre to the 3D cursor (made if there is none); the linked copies follow it"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        o = ensure_centre(context.scene)
        o.location = context.scene.cursor.location
        return {"FINISHED"}


CLASSES = [MAP_OT_mirror_copy, MAP_OT_mirror_unlink, MAP_OT_mirror_reset, MAP_OT_mirror_select, MAP_OT_mirror_centre]


# ---------- The panel (Build → Mirror) ----------
def draw_panel(layout, context):
    scene = context.scene
    layout.row().prop(scene, "ps_mirror_mode", expand=True)
    row = layout.row(align=True)
    row.prop(scene, "ps_mirror_centre", text="Centre")
    row.operator("psmap.mirror_centre", text="", icon="PIVOT_CURSOR")
    layout.prop(scene, "ps_mirror_show")
    row = layout.row()
    row.scale_y = 1.4
    row.operator("psmap.mirror_copy", icon="MOD_MIRROR")
    linked = unlinked = alone = 0
    for o in context.selected_objects:
        if o.get(PAIR) is None:
            alone += 1
        else:
            orig, copy = partner(scene, o)
            if copy is None or orig is None:
                alone += 1
            elif copy.get(LINKED):
                linked += 1
            else:
                unlinked += 1
    if context.selected_objects:
        parts = [f"{n} {what}" for n, what in ((linked, "linked"), (unlinked, "unlinked"), (alone, "without a pair")) if n]
        layout.label(text="Selected: " + ", ".join(parts), icon="LINKED" if linked else "UNLINKED")
    row = layout.row(align=True)
    row.operator("psmap.mirror_unlink", icon="UNLINKED")
    row.operator("psmap.mirror_reset", icon="FILE_REFRESH")
    layout.operator("psmap.mirror_select", icon="RESTRICT_SELECT_OFF")
    layout.label(text="A linked copy follows its original; moved by hand it goes back", icon="INFO")


# ---------- The views: where the symmetry is ----------
def draw_view():
    scene = bpy.context.scene
    if scene is None or not getattr(scene, "ps_mirror_show", False) or scene.ps_mirror_centre is None:
        return
    c = centre(scene)
    far = 4096 * UNIT
    mode = scene.ps_mirror_mode
    if mode == "x":
        lines = [c + Vector((0, -far, 0)), c + Vector((0, far, 0))]
    elif mode == "y":
        lines = [c + Vector((-far, 0, 0)), c + Vector((far, 0, 0))]
    else:
        r = 64 * UNIT
        ring = [c + Vector((math.cos(a) * r, math.sin(a) * r, 0)) for a in (i * math.pi / 16 for i in range(33))]
        lines = [p for a, b in zip(ring, ring[1:]) for p in (a, b)]
        lines += [c + Vector((-r * 1.5, 0, 0)), c + Vector((r * 1.5, 0, 0)), c + Vector((0, -r * 1.5, 0)), c + Vector((0, r * 1.5, 0))]
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    gpu.state.blend_set("ALPHA")
    gpu.state.depth_test_set("NONE")
    gpu.state.line_width_set(2.0)
    batch = batch_for_shader(shader, "LINES", {"pos": lines})
    shader.uniform_float("color", (0.2, 0.95, 0.9, 0.8))
    batch.draw(shader)
    gpu.state.line_width_set(1.0)
    gpu.state.blend_set("NONE")


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    S = bpy.types.Scene
    S.ps_mirror_mode = bpy.props.EnumProperty(name="Symmetry", items=MODES, default="turn")
    S.ps_mirror_centre = bpy.props.PointerProperty(type=bpy.types.Object, name="Mirror centre",
                                                   description="What the halves mirror or turn round (an empty, outside the map)")
    S.ps_mirror_show = bpy.props.BoolProperty(name="Show the symmetry line", default=True,
                                              description="The line (or the centre's ring) drawn in the views")
    if on_depsgraph not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(on_depsgraph)
    _draw[0] = bpy.types.SpaceView3D.draw_handler_add(draw_view, (), "WINDOW", "POST_VIEW")
    if not bpy.app.timers.is_registered(watch_settings):
        bpy.app.timers.register(watch_settings, first_interval=1.0, persistent=True)


def unregister():
    if bpy.app.timers.is_registered(watch_settings):
        bpy.app.timers.unregister(watch_settings)
    if _draw[0] is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_draw[0], "WINDOW")
        _draw[0] = None
    if on_depsgraph in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(on_depsgraph)
    for prop in ("ps_mirror_mode", "ps_mirror_centre", "ps_mirror_show"):
        delattr(bpy.types.Scene, prop)
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
