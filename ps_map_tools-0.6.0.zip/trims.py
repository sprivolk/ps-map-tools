"""Trims (Art tab): a profile along a line — beams, planks, skirtings, pipes, handrails, angle irons — and a staircase's
stringers and railing, to dress a map fast in any setting.

A trim is a mesh brush made from its settings (obj.ps_trim) and its path, built again whenever they change:
- the path: polylines in the object's space with, for each segment, the direction the profile's "up" faces (a face's
  normal the edge came from), kept as JSON in ps_trim.path. Made from edges selected in Edit Mode (on any brushes:
  chains across brushes become one line); Edit path turns it into a guide of points to move (the trim follows live).
- the profile: Box (width × height: beam, plank, skirting), Round (a pipe, a rail), Angle (an L of two flanges);
  shifted off the line by the offsets; the joints mitred (or the pieces overlapping).
- its own UVs: along the path (the grain runs along the beam on any picture), round the profile across.
- Detail (seen, players and bullets go through) or Solid.
A staircase's trims (Stringer, Railing) take their path from the staircase and follow it when it changes.
Release makes it a plain brush (its shape and UVs kept)."""
import json
import math
import random
import zlib

import bmesh
import bpy
from bpy.app.handlers import persistent
from mathutils import Matrix, Vector

from . import TILE, UNIT

_building = [False]
PROFILES = [("box", "Box", "A beam, a plank, a skirting: width × height"),
            ("round", "Round", "A pipe, a handrail: width across"),
            ("angle", "Angle", "An L of two flanges (angle iron, corner board)")]
GUIDE = "ps_trim_of"   # on a guide mesh: the trim whose path it edits
Z = Vector((0.0, 0.0, 1.0))


# ---------- Path ----------
def load_path(p):
    try:
        lines = json.loads(p.path or "[]")
    except ValueError:
        return []
    out = []
    for ln in lines:
        pts = [Vector(c) for c in ln.get("pts", [])]
        if len(pts) >= 2:
            out.append({"pts": pts, "nrm": [Vector(n) for n in ln.get("nrm", [])], "closed": bool(ln.get("closed"))})
    return out


def save_path(p, lines):
    p.path = json.dumps([{"pts": [list(map(lambda x: round(x, 5), v)) for v in ln["pts"]],
                          "nrm": [list(map(lambda x: round(x, 4), n)) for n in ln.get("nrm", [])],
                          "closed": ln.get("closed", False)} for ln in lines])


def up_of(t, hint=None):
    """The profile's up for a segment along t: the hint made square to t, else the world's up, else X."""
    for n in ([hint] if hint is not None else []) + [Z, Vector((1.0, 0.0, 0.0))]:
        n = n - t * n.dot(t)
        if n.length > 1e-4:
            return n.normalized()
    return Vector((0.0, 1.0, 0.0))


def chains(segs):
    """Segments [(a, b, normal)] joined at shared ends into lines [{"pts", "nrm", "closed"}]; a point where more than
    two meet ends the lines there."""
    key = lambda v: (round(v.x, 4), round(v.y, 4), round(v.z, 4))
    at = {}
    for i, (a, b, _) in enumerate(segs):
        at.setdefault(key(a), []).append(i)
        at.setdefault(key(b), []).append(i)
    used = set()
    out = []

    def walk(start, first):
        pts, nrm = [start], []
        cur, seg = start, first
        while seg is not None and seg not in used:
            used.add(seg)
            a, b, n = segs[seg]
            nxt = b if key(a) == key(cur) else a
            pts.append(nxt)
            nrm.append(n)
            cur = nxt
            nb = [s for s in at[key(cur)] if s not in used]
            seg = nb[0] if len(at[key(cur)]) == 2 and nb else None
        closed = len(pts) > 2 and key(pts[0]) == key(pts[-1])
        if closed:
            pts.pop()
        return {"pts": pts, "nrm": nrm, "closed": closed}
    for k, ss in at.items():  # lines from their ends (and from where several meet)
        if len(ss) != 2:
            for s in ss:
                if s not in used:
                    a, b, _ = segs[s]
                    out.append(walk(a if key(a) == k else b, s))
    for s in range(len(segs)):  # what is left: loops
        if s not in used:
            out.append(walk(segs[s][0], s))
    for ln in out:  # straight runs of one line made one segment
        pts, nrm = ln["pts"], ln["nrm"]
        i = 1
        while i < len(pts) - 1:
            t0, t1 = (pts[i] - pts[i - 1]).normalized(), (pts[i + 1] - pts[i]).normalized()
            if t0.dot(t1) > 0.9999 and (nrm[i - 1] - nrm[i]).length < 1e-3:
                del pts[i]
                del nrm[i]
            else:
                i += 1
    return out


# ---------- Profile and mesh ----------
def profile_pieces(p):
    """The profile as convex pieces, each [(s, t)] counter-clockwise, in metres, centred, then shifted by the offsets."""
    w, h, th = p.width * UNIT, p.height * UNIT, p.thick * UNIT
    if p.profile == "round":
        r = w / 2
        n = max(3, p.sides)
        pieces = [[(r * math.cos(2 * math.pi * i / n + math.pi / n), r * math.sin(2 * math.pi * i / n + math.pi / n))
                   for i in range(n)]]
    elif p.profile == "angle":
        th = min(th, w, h)
        pieces = [[(-w / 2, -h / 2), (w / 2, -h / 2), (w / 2, -h / 2 + th), (-w / 2, -h / 2 + th)],
                  [(-w / 2, -h / 2 + th), (-w / 2 + th, -h / 2 + th), (-w / 2 + th, h / 2), (-w / 2, h / 2)]]
    else:
        pieces = [[(-w / 2, -h / 2), (w / 2, -h / 2), (w / 2, h / 2), (-w / 2, h / 2)]]
    ds, dt = p.offset_s * UNIT, p.offset_n * UNIT
    return [[(s + ds, t + dt) for s, t in piece] for piece in pieces]


def build(me, lines, p, mat, seed=0):
    """Each piece (a segment of a line) its own bit of the picture: shifted along and across at random and now and
    then turned end for end, so no two beams look alike and every joint shows (the grain breaks there), as separate
    boards do."""
    rng = random.Random(seed)
    bm = bmesh.new()
    uv = bm.loops.layers.uv.new("UVMap")
    pieces = profile_pieces(p)
    reach = max(max(abs(s), abs(t)) for piece in pieces for s, t in piece)
    for ln in lines:
        pts, closed = ln["pts"], ln["closed"]
        n_seg = len(pts) if closed else len(pts) - 1
        if n_seg < 1:
            continue
        T = [(pts[(i + 1) % len(pts)] - pts[i]).normalized() for i in range(n_seg)]
        nrm = ln.get("nrm") or []
        N = [up_of(T[i], nrm[i] if i < len(nrm) else None) for i in range(n_seg)]
        S = [T[i].cross(N[i]) for i in range(n_seg)]
        for i in range(n_seg):
            a, b = pts[i], pts[(i + 1) % len(pts)]
            length = (b - a).length
            if length < 1e-6:
                continue
            prev = T[i - 1] if (closed or i > 0) else None
            nxt = T[(i + 1) % n_seg] if (closed or i < n_seg - 1) else None

            def cut(end_t, neighbour):
                """The plane the segment's end is cut by: the mitre between it and its neighbour, or square."""
                if neighbour is None:
                    return end_t, 0.0
                if p.joint == "overlap":
                    return end_t, reach
                m = (neighbour + end_t).normalized() if (neighbour + end_t).length > 1e-6 else end_t
                return m, None
            m0, ext0 = cut(T[i], prev)
            m1, ext1 = cut(T[i], nxt)
            shift_u, shift_v = rng.uniform(0.0, 8.0), rng.uniform(0.0, 4.0)
            flip = rng.random() < 0.5
            for piece in pieces:
                ring0, ring1 = [], []
                for s, t in piece:
                    o = S[i] * s + N[i] * t
                    if ext0 is None:
                        d = m0.dot(T[i])
                        u0 = -o.dot(m0) / d if abs(d) > 1e-6 else 0.0
                    else:
                        u0 = -ext0
                    if ext1 is None:
                        d = m1.dot(T[i])
                        u1 = length - o.dot(m1) / d if abs(d) > 1e-6 else length
                    else:
                        u1 = length + ext1
                    ring0.append((a + o + T[i] * u0, u0))
                    ring1.append((a + o + T[i] * u1, u1))
                v0 = [bm.verts.new(co) for co, _ in ring0]
                v1 = [bm.verts.new(co) for co, _ in ring1]
                k = len(piece)
                per = [0.0]
                for j in range(k):
                    (s0, t0), (s1, t1) = piece[j], piece[(j + 1) % k]
                    per.append(per[-1] + math.hypot(s1 - s0, t1 - t0))
                for j in range(k):
                    j2 = (j + 1) % k
                    f = bm.faces.new([v0[j], v0[j2], v1[j2], v1[j]])
                    us = [ring0[j][1], ring0[j2][1], ring1[j2][1], ring1[j][1]]
                    vs = [per[j], per[j + 1], per[j + 1], per[j]]
                    for loop, uu, vv in zip(f.loops, us, vs):
                        uu = (length - uu) if flip else uu
                        loop[uv].uv = (uu / TILE + shift_u, vv / TILE + shift_v)
                for verts, ring in ((list(reversed(v0)), list(reversed(piece))), (v1, piece)):
                    f = bm.faces.new(verts)
                    for loop, (s, t) in zip(f.loops, ring):
                        loop[uv].uv = (s / TILE, t / TILE)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(me)
    bm.free()
    me.materials.clear()
    if mat is not None:
        me.materials.append(mat)


def material_of(p):
    from . import art
    item = art.find(p.material)
    if item is not None:
        return art.art_material(item)
    return bpy.data.materials.get(p.material) or bpy.data.materials.get("Dev Grey")


def world_box(obj):
    mw = obj.matrix_world
    pts = [mw @ v.co for v in obj.data.vertices]
    if not pts:
        return None
    return [min(q[i] for q in pts) for i in range(3)] + [max(q[i] for q in pts) for i in range(3)]


def follow_hand(obj, p, lines):
    """A straight box trim changed by hand since it was built (resized, its mesh edited; a Shift+D copy keeps its
    original's path): its path and size taken from its mesh as it is now, so building it again keeps it there."""
    then, now = obj.get("ps_trim_box"), world_box(obj)
    if then is None or now is None or p.profile != "box" or len(lines) != 1 or len(lines[0]["pts"]) != 2 \
            or lines[0]["closed"]:
        return lines
    size_then = [then[i + 3] - then[i] for i in range(3)]
    size_now = [now[i + 3] - now[i] for i in range(3)]
    if all(abs(a - b) < 1e-4 for a, b in zip(size_then, size_now)):
        return lines  # the same shape (moved, or its origin moved: follow_origin's)
    lo, hi = Vector(now[:3]), Vector(now[3:])
    ext = hi - lo
    a = max(range(3), key=lambda i: ext[i])
    c = (lo + hi) / 2
    p0, p1 = c.copy(), c.copy()
    p0[a], p1[a] = lo[a], hi[a]
    if a == 2:  # upright: its up is X, across it Y (as up_of makes it)
        height, width, hint = ext.x, ext.y, Vector((1.0, 0.0, 0.0))
    else:
        height, width, hint = ext.z, (ext.y if a == 0 else ext.x), Z.copy()
    inv = obj.matrix_world.inverted()
    lines = [{"pts": [inv @ p0, inv @ p1], "nrm": [inv.to_3x3() @ hint], "closed": False}]
    _building[0] = True
    try:
        p.width, p.height = round(width / UNIT, 3), round(height / UNIT, 3)
        p.offset_s = p.offset_n = 0.0
        save_path(p, lines)
    finally:
        _building[0] = False
    return lines


def follow_origin(obj, p, lines):
    """The path is kept in the trim's own space. When its origin was moved and its mesh stayed (Origin to Geometry, a
    snap), the path is put back where it was in the world, not carried off by the move; when the trim was moved with
    its mesh (G), the path goes with it."""
    cur = obj.matrix_world
    built = obj.get("ps_trim_built")
    if built is None:
        # A trim from before this was kept: its path in its own space as its mesh shows (it stays), or else where
        # the world is (it was made there; its origin moved since).
        now = world_box(obj)
        pts = [v for ln in lines for v in ln["pts"]]
        if now is None or not pts:
            return lines
        centre = Vector([(now[i] + now[i + 3]) / 2 for i in range(3)])
        here = sum((cur @ v for v in pts), Vector()) / len(pts)
        there = sum(pts, Vector()) / len(pts)
        if (here - centre).length <= (there - centre).length:
            return lines
        old = Matrix.Identity(4)
    else:
        old = Matrix([list(built[i * 4:(i + 1) * 4]) for i in range(4)])
        if all(abs(old[i][j] - cur[i][j]) < 1e-6 for i in range(4) for j in range(4)):
            return lines
        then, now = obj.get("ps_trim_box"), world_box(obj)
        if then is None or now is None or any(abs(a - b) > 1e-4 for a, b in zip(then, now)):
            return lines  # moved with its mesh: the path goes with it
    conv = cur.inverted() @ old
    rot = conv.to_3x3()
    for ln in lines:
        ln["pts"] = [conv @ v for v in ln["pts"]]
        ln["nrm"] = [(rot @ n).normalized() for n in ln.get("nrm", [])]
    save_path(p, lines)
    return lines


def stairs_space(trim):
    """World → the trim's space for a staircase's trim, with the trim's own move kept (ps_trim_shift: moved with G it
    stays there, not back at the stairs)."""
    shift = Vector(trim.get("ps_trim_shift", (0.0, 0.0, 0.0)))
    return trim.matrix_world.inverted() @ Matrix.Translation(shift)


def keep_move(obj):
    """A staircase's trim moved (with its mesh) since it was built: the move kept as its shift. Its origin moved alone
    (the mesh stayed): nothing to keep."""
    built = obj.get("ps_trim_built")
    if built is None:
        return
    old = Matrix([list(built[i * 4:(i + 1) * 4]) for i in range(4)])
    cur = obj.matrix_world
    if all(abs(old[i][j] - cur[i][j]) < 1e-6 for i in range(4) for j in range(4)):
        return
    then, now = obj.get("ps_trim_box"), world_box(obj)
    if then is None or now is None:
        return
    delta = Vector(now[:3]) - Vector(then[:3])
    if delta.length > 1e-5:
        obj["ps_trim_shift"] = list(Vector(obj.get("ps_trim_shift", (0.0, 0.0, 0.0))) + delta)


def rebuild(obj):
    if _building[0] or obj is None or obj.type != "MESH":
        return
    p = obj.ps_trim
    if not p.on or obj.get("ps_mirror_role") == 2:  # a mirror copy takes its original's mesh
        return
    panel = None
    if p.stairs:
        keep_move(obj)
        st = bpy.data.objects.get(p.stairs)
        if p.role == "stringer":
            panel, lines = (stringer_panel(st, p, obj) if st is not None else None), []
        else:
            lines = stairs_lines(st, p, obj) if st is not None else []
    else:
        lines = follow_hand(obj, p, follow_origin(obj, p, load_path(p)))
    _building[0] = True
    try:
        if panel is not None:
            build_panel(obj.data, *panel, material_of(p))
        else:
            build(obj.data, lines, p, material_of(p), zlib.crc32(obj.name.split(" mirror")[0].encode()))
        obj["ps_brush"] = 1
        obj["ps_own_uv"] = 1
        obj["ps_entity"] = "world" if p.solid else "detail"
        obj.data.update()
        # Where it was built (follow_origin tells a moved origin from a moved trim by these).
        obj["ps_trim_built"] = [obj.matrix_world[i][j] for i in range(4) for j in range(4)]
        box = world_box(obj)
        if box is not None:
            obj["ps_trim_box"] = box
    finally:
        _building[0] = False


def changed(self, context):
    rebuild(self.id_data)


class PSTrim(bpy.types.PropertyGroup):
    on: bpy.props.BoolProperty(default=False)
    profile: bpy.props.EnumProperty(name="Profile", update=changed, items=PROFILES)
    width: bpy.props.FloatProperty(name="Width", default=8.0, min=0.25, max=256.0, step=100, precision=1, update=changed,
                                   description="Across the line, in units (8 = 20 cm)")
    height: bpy.props.FloatProperty(name="Height", default=8.0, min=0.25, max=256.0, step=100, precision=1,
                                    update=changed, description="Up from the line, in units")
    thick: bpy.props.FloatProperty(name="Flange", default=2.0, min=0.25, max=64.0, step=50, precision=1, update=changed,
                                   description="An angle's flange thickness, in units")
    sides: bpy.props.IntProperty(name="Sides", default=8, min=3, max=32, update=changed)
    offset_s: bpy.props.FloatProperty(name="Shift across", default=0.0, step=100, precision=1, update=changed,
                                      description="The profile moved off the line sideways, in units")
    offset_n: bpy.props.FloatProperty(name="Shift up", default=0.0, step=100, precision=1, update=changed,
                                      description="The profile moved off the line along its up (out of the face), in units")
    joint: bpy.props.EnumProperty(name="Joints", update=changed, items=[
        ("mitre", "Mitre", "Pieces cut to meet at the corners (a picture frame)"),
        ("overlap", "Overlap", "Pieces going on past the corners, one through the other")])
    solid: bpy.props.BoolProperty(name="Solid", default=True, update=changed,
                                  description="Players and bullets stop (else Detail: seen only)")
    material: bpy.props.StringProperty(name="Material", default="", update=changed,
                                       description="A library material (or any material's name)")
    path: bpy.props.StringProperty()
    stairs: bpy.props.StringProperty(description="The staircase whose stringer or railing this is")
    role: bpy.props.EnumProperty(items=[("stringer", "Stringer", ""), ("railing", "Railing", "")], update=changed)
    side: bpy.props.IntProperty(default=1, update=changed)  # -1: the low side across the stairs, 1: the high side
    rail_height: bpy.props.FloatProperty(name="Rail height", default=36.0, min=4.0, max=128.0, step=100, precision=0,
                                         update=changed, description="The handrail over the nosings, in units (36 = 90 cm)")
    over: bpy.props.FloatProperty(name="Over the steps", default=3.0, min=0.0, max=64.0, step=100, precision=1,
                                  update=changed, description="A stringer's top edge over the steps' line, in units")
    panel: bpy.props.EnumProperty(name="Stringer", update=changed, items=[
        ("band", "Plank", "A plank along the steps (Height across it), its foot on the floor"),
        ("full", "Full", "The whole side under the steps (the triangle), its top a little over them")])
    post_every: bpy.props.IntProperty(name="Post every", default=3, min=1, max=32, update=changed,
                                      description="A post every this many steps")


# ---------- Making trims ----------
def new_trim(context, name, like=None):
    from . import art
    me = bpy.data.meshes.new(name)
    obj = bpy.data.objects.new(name, me)
    cols = like.users_collection if like is not None else [context.collection]
    for c in cols:
        c.objects.link(obj)
    if like is not None and art.group_of(like):
        obj[art.GROUP] = art.group_of(like)
    return obj


def default_material(context):
    from . import art
    cur = art.current(context.scene)
    if cur:
        return cur
    lib = art.items()
    return lib[0]["name"] if lib else "Dev Grey"


class MAP_OT_trim_from_edges(bpy.types.Operator):
    bl_idname = "psmap.trim_from_edges"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Trim from selected edges"
    bl_description = ("A trim (beam, plank, pipe...) along the edges selected in Edit Mode, on one brush or several: "
                      "edges meeting end to end become one line. Its material: the current one")
    profile: bpy.props.EnumProperty(name="Profile", items=PROFILES)
    width: bpy.props.FloatProperty(name="Width", default=8.0, min=0.25, max=256.0)
    height: bpy.props.FloatProperty(name="Height", default=8.0, min=0.25, max=256.0)

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.mode == "EDIT"

    def execute(self, context):
        segs, like = [], None
        for o in [o for o in context.objects_in_mode if o.type == "MESH"]:
            bm = bmesh.from_edit_mesh(o.data)
            mw = o.matrix_world
            rot = mw.to_3x3()
            for e in bm.edges:
                if not e.select:
                    continue
                normals = [(rot @ f.normal).normalized() for f in e.link_faces]
                n = max(normals, key=lambda v: abs(v.z)) if normals else Z
                segs.append((mw @ e.verts[0].co, mw @ e.verts[1].co, n))
                like = like or o
        if not segs:
            self.report({"WARNING"}, "Select edges (Edit Mode, edge select)")
            return {"CANCELLED"}
        lines = chains(segs)
        bpy.ops.object.mode_set(mode="OBJECT")
        obj = new_trim(context, "Trim", like)
        p = obj.ps_trim
        _building[0] = True
        try:
            p.on = True
            p.profile, p.width, p.height = self.profile, self.width, self.height
            p.material = default_material(context)
            save_path(p, lines)
        finally:
            _building[0] = False
        rebuild(obj)
        for o in context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        self.report({"INFO"}, f"{obj.name}: {len(lines)} line(s), {sum(len(l['pts']) - (0 if l['closed'] else 1) for l in lines)} piece(s)")
        return {"FINISHED"}


# ---------- Editing the path ----------
def guide_of(trim):
    return next((o for o in bpy.data.objects if o.get(GUIDE) == trim.name), None)


class MAP_OT_trim_path(bpy.types.Operator):
    bl_idname = "psmap.trim_path"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Edit path"
    bl_description = ("The trim's path as points to move (G), add (E: extrude) or remove (X), in Edit Mode; the trim "
                      "follows. Done: back to the trim")
    done: bpy.props.BoolProperty(options={"SKIP_SAVE"})

    def execute(self, context):
        obj = context.active_object
        if obj is not None and obj.get(GUIDE):
            trim = bpy.data.objects.get(obj[GUIDE])
        else:
            trim = obj
        if trim is None or not trim.ps_trim.on or trim.ps_trim.stairs:
            self.report({"WARNING"}, "Select a trim (a staircase's follows the staircase)")
            return {"CANCELLED"}
        guide = guide_of(trim)
        if obj is not None and obj.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        if self.done or guide is not None:
            if guide is not None:
                sync(guide)
                me = guide.data
                bpy.data.objects.remove(guide, do_unlink=True)
                bpy.data.meshes.remove(me)
            for o in context.selected_objects:
                o.select_set(False)
            trim.select_set(True)
            context.view_layer.objects.active = trim
            return {"FINISHED"}
        me = bpy.data.meshes.new(f"{trim.name} path")
        verts, edges = [], []
        for ln in load_path(trim.ps_trim):
            base = len(verts)
            verts += [tuple(v) for v in ln["pts"]]
            n = len(ln["pts"])
            edges += [(base + i, base + i + 1) for i in range(n - 1)]
            if ln["closed"]:
                edges.append((base + n - 1, base))
        me.from_pydata(verts, edges, [])
        guide = bpy.data.objects.new(f"{trim.name} path", me)
        guide[GUIDE] = trim.name
        guide.show_in_front = True
        context.scene.collection.objects.link(guide)  # outside the map: not exported
        guide.matrix_world = trim.matrix_world
        for o in context.selected_objects:
            o.select_set(False)
        guide.select_set(True)
        context.view_layer.objects.active = guide
        bpy.ops.object.mode_set(mode="EDIT")
        bpy.ops.mesh.select_mode(type="VERT")
        return {"FINISHED"}


def sync(guide):
    """The trim's path from its guide's points and edges (in Edit Mode too), the old segments' up kept by index."""
    trim = bpy.data.objects.get(guide.get(GUIDE, ""))
    if trim is None:
        return
    if guide.mode == "EDIT":
        bm = bmesh.from_edit_mesh(guide.data)
        segs = [(e.verts[0].co.copy(), e.verts[1].co.copy(), None) for e in bm.edges]
    else:
        me = guide.data
        segs = [(me.vertices[e.vertices[0]].co.copy(), me.vertices[e.vertices[1]].co.copy(), None) for e in me.edges]
    if not segs:
        return
    old = load_path(trim.ps_trim)
    lines = chains([(a, b, Z) for a, b, _ in segs])
    for i, ln in enumerate(lines):
        if i < len(old) and len(old[i]["nrm"]) == len(ln["nrm"]):
            ln["nrm"] = old[i]["nrm"]
    _building[0] = True
    try:
        save_path(trim.ps_trim, lines)
    finally:
        _building[0] = False
    rebuild(trim)


# ---------- Stairs ----------
def stair_shape(o):
    """A straight staircase read from its mesh: (width axis, its two sides, length axis, the step nosings [(l, z)] from
    the bottom up, the floor z, the top z), or None."""
    if o is None or o.type != "MESH" or not o.get("ps_stairs"):
        return None
    mw = o.matrix_world
    mats = list(o.data.materials)
    pts = [mw @ v.co for v in o.data.vertices]
    if not pts:
        return None
    vals = [sorted({round(p[i], 4) for p in pts}) for i in range(2)]
    # Across it few places (its two sides, the clip ramp a millimetre in), along it one per step and more.
    if len(vals[0]) == len(vals[1]) or min(len(vals[0]), len(vals[1])) > 4:
        return None
    w, l = (0, 1) if len(vals[0]) < len(vals[1]) else (1, 0)
    z0, z1 = min(p.z for p in pts), max(p.z for p in pts)
    treads = []
    for f in o.data.polygons:
        m = mats[f.material_index] if f.material_index < len(mats) else None
        n = (mw.to_3x3() @ f.normal).normalized()
        if (m is not None and m.get("ps_tool")) or n.z < 0.9:
            continue
        cs = [mw @ o.data.vertices[i].co for i in f.vertices]
        z = sum(c.z for c in cs) / len(cs)
        if z > z0 + 1e-3:
            treads.append((min(c[l] for c in cs), max(c[l] for c in cs), z))
    if len(treads) < 2:
        return None
    treads.sort(key=lambda t: t[2])
    up = 1 if (treads[-1][0] + treads[-1][1]) > (treads[0][0] + treads[0][1]) else -1
    nosings = [(t[0] if up > 0 else t[1], t[2]) for t in treads]
    return w, (vals[w][0], vals[w][-1]), l, up, nosings, z0, z1


def stringer_panel(st, p, trim):
    """A stringer: the staircase's side shape (the triangle under the steps) a little over the steps' line, flat
    against its side, Width thick out of it. Full: down to the floor; Band: Height high along the steps. Its outline
    in the trim's space, the direction it is thick to, the thickness."""
    shape = stair_shape(st)
    if shape is None:
        return None
    w, sides, l, up, nosings, z0, z1 = shape
    ls = [(st.matrix_world @ v.co)[l] for v in st.data.vertices]
    low_end, high_end = (min(ls), max(ls)) if up > 0 else (max(ls), min(ls))
    (la, za), (lb, zb) = nosings[0], nosings[-1]
    over = p.over * UNIT
    slope = (zb - za) / (lb - la) if abs(lb - la) > 1e-6 else 0.0
    top = [(low_end, za + over + slope * (low_end - la)), (lb, zb + over), (high_end, zb + over)]
    if p.panel == "full":
        outline = [(low_end, z0)] + top + [(high_end, z0)]
    else:
        # A plank: Height across it (square to the slope), its top a little over the nosings, going on flat over the
        # top step; its foot on the floor, cut upright where its underside meets the floor (as on the concept).
        h = p.height * UNIT
        hs = h * (1 + slope * slope) ** 0.5  # Height measured upright on the slope

        def top_at(lv):
            return min(za + over + slope * (lv - la), zb + over)
        knee = lb + (hs - h) / slope if slope else lb  # where the sloped underside meets the flat one
        l_floor = la + (z0 + hs - za - over) / slope if slope else low_end  # the underside on the floor
        under = [(high_end, zb + over - h), (knee, zb + over - h)]
        if (l_floor - low_end) * up >= 0:  # the underside meets the floor over the steps: the foot runs to their end
            outline = [(low_end, top_at(low_end)), (lb, zb + over), (high_end, zb + over)] + under + \
                      [(l_floor, z0), (low_end, z0)]
        else:  # before them: the plank's end a little in front of the first step, upright
            outline = [(l_floor, top_at(l_floor)), (lb, zb + over), (high_end, zb + over)] + under + [(l_floor, z0)]
    nw = 1 if p.side > 0 else -1
    side = sides[1] if p.side > 0 else sides[0]
    inv = stairs_space(trim)
    pts = []
    for lv, z in outline:
        v = Vector((0.0, 0.0, z))
        v[w] = side
        v[l] = lv
        pts.append(inv @ v)
    out = Vector((0.0, 0.0, 0.0))
    out[w] = nw
    return pts, (inv.to_3x3() @ out).normalized(), p.width * UNIT


def build_panel(me, pts, out, thick, mat):
    """A flat shape (its outline) made thick along `out`; UVs flat on its sides (the grain along it), along its edge."""
    bm = bmesh.new()
    uv = bm.loops.layers.uv.new("UVMap")
    inner = [bm.verts.new(v) for v in pts]
    outer = [bm.verts.new(v + out * thick) for v in pts]
    # its own flat frame: across = the outline's first long edge, up = out × across
    d = max(((pts[i + 1] - pts[i]) for i in range(len(pts) - 1)), key=lambda v: v.length)
    across = (d - out * d.dot(out)).normalized()
    upv = out.cross(across).normalized()

    def flat(v):
        return (v.dot(across) / TILE, v.dot(upv) / TILE)
    faces = [bm.faces.new(inner), bm.faces.new(list(reversed(outer)))]
    for f in faces:
        for loop in f.loops:
            loop[uv].uv = flat(loop.vert.co)
    n = len(pts)
    run = 0.0
    for i in range(n):
        j = (i + 1) % n
        f = bm.faces.new([inner[i], inner[j], outer[j], outer[i]])
        seg = (pts[j] - pts[i]).length
        for loop, c in zip(f.loops, ((run, 0), (run + seg, 0), (run + seg, thick), (run, thick))):
            loop[uv].uv = (c[0] / TILE, c[1] / TILE)
        run += seg
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
    bm.to_mesh(me)
    bm.free()
    me.materials.clear()
    if mat is not None:
        me.materials.append(mat)


def stairs_lines(st, p, trim):
    """A staircase trim's lines in the trim's space: the stringer along the nosings on its side, or the railing's
    handrail over them and its posts."""
    shape = stair_shape(st)
    if shape is None:
        return []
    w, sides, l, up, nosings, z0, z1 = shape
    (la, za), (lb, zb) = nosings[0], nosings[-1]
    slope = (zb - za) / (lb - la) if abs(lb - la) > 1e-6 else 0.0
    side = sides[1] if p.side > 0 else sides[0]
    inv = stairs_space(trim)

    def P(lv, z, dw=0.0):
        v = Vector((0.0, 0.0, z))
        v[w] = side + dw
        v[l] = lv
        return inv @ v
    t = Vector((0.0, 0.0, 0.0))
    t[l] = lb - la
    t.z = zb - za
    t.normalize()
    across = Vector((0.0, 0.0, 0.0))
    across[w] = 1.0
    n = up_of(t, Z)
    lines = []
    if p.role == "railing":
        rail = p.rail_height * UNIT
        inside = -(p.width * UNIT) if p.side > 0 else p.width * UNIT  # over the steps' edge
        lines.append({"pts": [P(la, za + rail, inside), P(lb, zb + rail, inside)], "nrm": [inv.to_3x3() @ n],
                      "closed": False})
        for i in range(0, len(nosings), max(1, p.post_every)):
            lv, z = nosings[i]
            lv += up * 0.12  # on the tread, not its nosing
            lines.append({"pts": [P(lv, z, inside), P(lv, z + slope * up * 0.12 + rail, inside)],
                          "nrm": [inv.to_3x3() @ across], "closed": False})
        lv, z = nosings[-1]
        lines.append({"pts": [P(lv, z, inside), P(lv, z + rail, inside)], "nrm": [inv.to_3x3() @ across], "closed": False})
    return lines


def open_side(context, st, shape, nw):
    """Is the staircase's side (nw = -1 / 1 across it) out in the open (no wall right against it)?"""
    w, sides, l, up, nosings, z0, z1 = shape
    p = Vector((0.0, 0.0, (z0 + z1) / 2))
    p[w] = (sides[0] if nw < 0 else sides[1]) + nw * 0.03
    p[l] = (nosings[0][0] + nosings[-1][0]) / 2
    d = Vector((0.0, 0.0, 0.0))
    d[w] = nw
    hit, loc, normal, _, obj, _ = context.scene.ray_cast(context.evaluated_depsgraph_get(), p, d, distance=50.0)
    # Inside a wall the first face the ray meets looks the way it goes (it leaves the wall there).
    return not (hit and normal.dot(d) > 0)


class MAP_OT_trim_stairs(bpy.types.Operator):
    bl_idname = "psmap.trim_stairs"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Staircase trim"
    bl_description = "A stringer (the side panel) or a railing on the selected staircase's open sides; it follows the stairs"
    role: bpy.props.EnumProperty(items=[("stringer", "Stringer", ""), ("railing", "Railing", "")], options={"SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        o = context.active_object
        return o is not None and o.get("ps_stairs") and o.mode == "OBJECT"

    def execute(self, context):
        st = context.active_object
        shape = stair_shape(st)
        if shape is None:
            self.report({"WARNING"}, "A straight staircase only")
            return {"CANCELLED"}
        made = []
        for nw in (-1, 1):
            if not open_side(context, st, shape, nw):
                continue
            obj = new_trim(context, f"{st.name} {self.role}", st)
            p = obj.ps_trim
            _building[0] = True
            try:
                p.on = True
                p.stairs, p.role, p.side = st.name, self.role, nw
                p.material = default_material(context)
                if self.role == "stringer":
                    p.profile, p.width, p.height, p.over, p.panel = "box", 3.0, 7.0, 3.0, "band"
                else:
                    p.profile, p.width, p.height, p.sides = "round", 2.5, 2.5, 8
            finally:
                _building[0] = False
            rebuild(obj)
            made.append(obj)
        if not made:
            self.report({"WARNING"}, "Both sides are against walls")
            return {"CANCELLED"}
        for o in context.selected_objects:
            o.select_set(False)
        for o in made:
            o.select_set(True)
        context.view_layer.objects.active = made[0]
        return {"FINISHED"}


class MAP_OT_trim_release(bpy.types.Operator):
    bl_idname = "psmap.trim_release"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Release"
    bl_description = "The trim as a plain brush: its shape and UVs kept, edited by hand from now on (its settings go)"

    def execute(self, context):
        for o in context.selected_objects:
            if o.type == "MESH" and o.ps_trim.on:
                g = guide_of(o)
                if g is not None:
                    me = g.data
                    bpy.data.objects.remove(g, do_unlink=True)
                    bpy.data.meshes.remove(me)
                o.ps_trim.on = False
                o.ps_trim.stairs = ""
        return {"FINISHED"}


class MAP_OT_trim_material(bpy.types.Operator):
    bl_idname = "psmap.trim_material"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Current material"
    bl_description = "The selected trims made of the current material (the Materials panel's: picked or last put)"

    def execute(self, context):
        from . import art
        cur = art.current(context.scene)
        if not cur:
            return {"CANCELLED"}
        for o in context.selected_objects:
            if o.type == "MESH" and o.ps_trim.on:
                o.ps_trim.material = cur
        return {"FINISHED"}


class MAP_OT_trim_unmove(bpy.types.Operator):
    bl_idname = "psmap.trim_unmove"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Back to the stairs"
    bl_description = "The staircase's trim where the stairs put it (its own move forgotten)"

    def execute(self, context):
        for o in context.selected_objects:
            if o.type == "MESH" and o.ps_trim.on and o.ps_trim.stairs:
                rebuild(o)  # the move so far counted first, then forgotten
                o["ps_trim_shift"] = [0.0, 0.0, 0.0]
                rebuild(o)
        return {"FINISHED"}


class MAP_OT_trim_fit(bpy.types.Operator):
    bl_idname = "psmap.trim_fit"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Fit to the active"
    bl_description = ("The selected stringer made to meet the active object (a beam along the landing, selected last): "
                      "as thick as it and in line with it across, its flat end as high as it, top and bottom")

    @classmethod
    def poll(cls, context):
        a = context.active_object
        return a is not None and a.type == "MESH" and any(
            o is not a and o.type == "MESH" and o.ps_trim.on and o.ps_trim.stairs and o.ps_trim.role == "stringer"
            for o in context.selected_objects)

    def execute(self, context):
        target = context.active_object
        box = world_box(target)
        if box is None:
            return {"CANCELLED"}
        lo, hi = Vector(box[:3]), Vector(box[3:])
        done = 0
        for o in [o for o in context.selected_objects if o is not target and o.type == "MESH" and o.ps_trim.on
                  and o.ps_trim.stairs and o.ps_trim.role == "stringer"]:
            shape = stair_shape(bpy.data.objects.get(o.ps_trim.stairs))
            if shape is None:
                continue
            w, sides, l, up, nosings, z0, z1 = shape
            p = o.ps_trim
            nw = 1 if p.side > 0 else -1
            side = sides[1] if p.side > 0 else sides[0]
            zb = nosings[-1][1]
            _building[0] = True
            try:
                p.width = round((hi[w] - lo[w]) / UNIT, 3)
                p.over = round((hi.z - zb) / UNIT, 3)
                p.height = round((hi.z - lo.z) / UNIT, 3)
                if p.panel != "band":
                    p.panel = "band"
            finally:
                _building[0] = False
            shift = Vector((0.0, 0.0, 0.0))
            shift[w] = (lo[w] - side) if nw > 0 else (hi[w] - side)
            o["ps_trim_shift"] = list(shift)
            rebuild(o)
            done += 1
        self.report({"INFO"}, f"{done} stringer(s) fitted to {target.name}")
        return {"FINISHED"}


@persistent
def on_depsgraph(scene, depsgraph):
    """A guide moved: its trim follows; a staircase changed: its stringers and railings follow."""
    if _building[0]:
        return
    for u in depsgraph.updates:
        ob = u.id.original if isinstance(u.id, bpy.types.Object) else None
        if ob is None or not (u.is_updated_geometry or u.is_updated_transform):
            continue
        if ob.get(GUIDE):
            sync(ob)
        elif ob.get("ps_stairs"):
            for t in [t for t in scene.objects if t.type == "MESH" and t.ps_trim.on and t.ps_trim.stairs == ob.name]:
                rebuild(t)


CLASSES = [PSTrim, MAP_OT_trim_from_edges, MAP_OT_trim_path, MAP_OT_trim_stairs, MAP_OT_trim_release,
           MAP_OT_trim_material, MAP_OT_trim_unmove, MAP_OT_trim_fit]


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    bpy.types.Object.ps_trim = bpy.props.PointerProperty(type=PSTrim)
    if on_depsgraph not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(on_depsgraph)


def unregister():
    if on_depsgraph in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(on_depsgraph)
    del bpy.types.Object.ps_trim
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
