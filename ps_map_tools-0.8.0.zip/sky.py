"""The map's sky and light (the Play tab's Light panel): the sky's 360° picture (an Image in the file, packed or not:
equirectangular 2:1, its middle the map's north, Blender +Y), how it is turned, what lies below its horizon in the bake;
how deep the shade is and how soft the sun's shadows; the sky seen in the views. Make sky paints one (a clear sky and
clouds), Load sky takes any panorama, Clear day is the add-on's own. The export writes it beside the map (sky.jpg,
"skyRotation") and the bake lights the map by it (compiler/bake_light.sky_light)."""
import math
import os

import bpy
from .translations import tr
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SKIES = os.path.join(HERE, "skies")
LIBRARY = [("clear_day", "Clear day", "a clear day's sky, cumulus clouds (Training's)")]
PREVIEW_WORLD = "PS sky (views)"
MAX_WIDE = 4096


# ---------- In the views ----------
def preview(scene):
    """The sky behind the map in the views (Material and Rendered shading): a world of its own, turned as the game turns
    it. Without a sky, the world the file had (if any) back."""
    image = scene.ps_sky_image
    world = bpy.data.worlds.get(PREVIEW_WORLD)
    if image is None or not scene.ps_sky_preview:
        if world is not None and scene.world == world:
            scene.world = bpy.data.worlds.get(scene.get("ps_world_before", "")) if scene.get("ps_world_before") else None
        return
    if world is None:
        world = bpy.data.worlds.new(PREVIEW_WORLD)
        world.use_nodes = True
    nodes, links = world.node_tree.nodes, world.node_tree.links
    bg = next((n for n in nodes if n.type == "BACKGROUND"), None)
    env = nodes.get("PS sky") or nodes.new("ShaderNodeTexEnvironment")
    env.name = "PS sky"
    turn = nodes.get("PS turn") or nodes.new("ShaderNodeMapping")
    turn.name = "PS turn"
    coord = nodes.get("PS coord") or nodes.new("ShaderNodeTexCoord")
    coord.name = "PS coord"
    env.image = image
    links.new(coord.outputs["Generated"], turn.inputs[0])
    links.new(turn.outputs[0], env.inputs[0])
    links.new(env.outputs[0], bg.inputs[0])
    # Blender's middle of the picture looks along +X, ours along +Y; then the map's own turn.
    turn.inputs["Rotation"].default_value = (0.0, 0.0, -math.radians(90.0 + scene.ps_sky_rotation))
    bg.inputs[1].default_value = 1.0
    if scene.world is not None and scene.world != world:
        scene["ps_world_before"] = scene.world.name
    scene.world = world


def _changed(self, context):
    preview(context.scene)


# ---------- Making one ----------
def _noise(x, y, seed):
    """Smooth value noise at points (x, y), arrays, 0..1."""
    fx, fy = np.floor(x), np.floor(y)
    xf, yf = (x - fx).astype(np.float32), (y - fy).astype(np.float32)
    xi, yi = fx.astype(np.int64).astype(np.uint32), fy.astype(np.int64).astype(np.uint32)
    u, v = xf * xf * (3 - 2 * xf), yf * yf * (3 - 2 * yf)
    s = np.uint32((seed * 2246822519) & 0xFFFFFFFF)

    def h(ix, iy):
        with np.errstate(over="ignore"):
            n = ix * np.uint32(374761393) + iy * np.uint32(668265263) + s
            n = (n ^ (n >> np.uint32(13))) * np.uint32(1274126177)
        return (n & np.uint32(0xFFFF)).astype(np.float32) * np.float32(1.0 / 65535.0)
    a, b, c, d = h(xi, yi), h(xi + 1, yi), h(xi, yi + 1), h(xi + 1, yi + 1)
    return (a * (1 - u) + b * u) * (1 - v) + (c * (1 - u) + d * u) * v


def paint_sky(wide, horizon, zenith, clouds, height, size, seed):
    """A sky picture (wide × wide/2, linear RGB, rows bottom first): pale at the horizon, `zenith` overhead, cumulus over
    a `clouds` share of it (0..1) on a sheet `height` up, of `size` (bigger: bigger clouds), fading far off; below the
    horizon the horizon's colour, darker."""
    high = wide // 2
    hz, zn = np.array(horizon, np.float32), np.array(zenith, np.float32)
    img = np.empty((high, wide, 3), np.float32)
    img[:] = hz * 0.55                               # below the horizon
    # Above it (rows bottom first: the upper half), a little over the horizon on.
    first = high // 2 + max(1, high // 180)
    rows = (np.arange(first, high, dtype=np.float32) + 0.5) / high
    cols = (np.arange(wide, dtype=np.float32) + 0.5) / wide
    el = ((rows - 0.5) * math.pi)[:, None]           # elevation
    az = ((cols - 0.5) * 2.0 * math.pi)[None, :]     # 0 at the middle: north
    sin_el, cos_el = np.sin(el), np.cos(el)
    t = np.clip(sin_el, 0.0, 1.0) ** 0.6
    top = hz * (1 - t[..., None]) + zn * t[..., None]
    top = np.broadcast_to(top, (len(rows), wide, 3)).copy()
    if clouds > 0.0:
        # Where the view meets a sheet `height` up (metres), its noise (five octaves), thresholded by the cover.
        reach = cos_el / np.maximum(sin_el, 1e-3) * height
        px = (np.sin(az) * reach).astype(np.float32)
        py = (np.cos(az) * reach).astype(np.float32)
        scale = 1.0 / (900.0 * size)
        fbm, amp, total = np.zeros(px.shape, np.float32), 1.0, 0.0
        for octave in range(5):
            f = scale * (2.0 ** octave)
            fbm += np.float32(amp) * _noise(px * f, py * f, seed + octave)
            total += amp
            amp *= 0.5
        fbm /= np.float32(total)
        edge = 0.35 + 0.35 * (1.0 - clouds)
        cover = np.clip((fbm - edge) / 0.12, 0.0, 1.0) * np.exp(-reach / (height * 14.0)).astype(np.float32)
        # Lit tops, a cooler grey underneath where it is thick.
        thick = np.clip((fbm - edge) / 0.3, 0.0, 1.0)[..., None]
        cloud = (1 - thick) + np.array([0.62, 0.66, 0.74], np.float32) * thick
        top = top * (1 - cover[..., None]) + cloud * cover[..., None]
    img[first:] = top
    return img


def store(name, img):
    """The picture (linear RGB, rows bottom first) as an Image in the file, packed (it goes with the .blend)."""
    high, wide = img.shape[:2]
    image = bpy.data.images.get(name)
    if image is not None and (image.size[0] != wide or image.size[1] != high):
        bpy.data.images.remove(image)
        image = None
    if image is None:
        image = bpy.data.images.new(name, wide, high, alpha=False)
    srgb = np.where(img <= 0.0031308, img * 12.92, 1.055 * np.power(np.clip(img, 0, None), 1 / 2.4) - 0.055)
    rgba = np.concatenate([np.clip(srgb, 0, 1), np.ones((high, wide, 1), np.float32)], axis=2)
    image.pixels.foreach_set(rgba.astype(np.float32).ravel())
    # Packed as a JPEG (a PNG of 4096 × 2048 takes half a minute and many times the size).
    image.file_format = "JPEG"
    image.pack()
    return image


class MAP_OT_make_sky(bpy.types.Operator):
    bl_idname = "psmap.make_sky"
    bl_label = "Make sky"
    bl_description = "Paints a sky for the map: its colours at the horizon and overhead, clouds (how many, how high, how big)"
    bl_options = {"REGISTER", "UNDO"}

    horizon: bpy.props.FloatVectorProperty(name="Horizon", subtype="COLOR", size=3, min=0, max=1,
                                           default=(0.74, 0.83, 0.93))
    zenith: bpy.props.FloatVectorProperty(name="Overhead", subtype="COLOR", size=3, min=0, max=1,
                                          default=(0.22, 0.42, 0.76))
    clouds: bpy.props.FloatProperty(name="Clouds", min=0.0, max=1.0, default=0.45, subtype="FACTOR",
                                    description="How much of the sky they cover")
    height: bpy.props.FloatProperty(name="Cloud height (m)", min=200.0, max=8000.0, default=2200.0)
    size: bpy.props.FloatProperty(name="Cloud size", min=0.2, max=5.0, default=1.0)
    seed: bpy.props.IntProperty(name="Variant", min=0, max=999, default=1)
    wide: bpy.props.EnumProperty(name="Picture", items=[("2048", "2048 × 1024", ""), ("4096", "4096 × 2048", "")],
                                 default="4096")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=320)

    def execute(self, context):
        img = paint_sky(int(self.wide), tuple(self.horizon), tuple(self.zenith), self.clouds, self.height, self.size,
                        self.seed)
        scene = context.scene
        scene.ps_sky_image = store("Sky (made)", img)
        self.report({"INFO"}, tr("Sky made: in the views (Material / Rendered shading), the bake and the game", "reports"))
        return {"FINISHED"}


class MAP_OT_load_sky(bpy.types.Operator):
    bl_idname = "psmap.load_sky"
    bl_label = "Load sky…"
    bl_description = ("A 360° picture of your own (equirectangular, twice as wide as high: its middle the map's north). "
                      "Packed into the file, so the map moves with it")
    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    filter_image: bpy.props.BoolProperty(default=True, options={"HIDDEN"})
    filter_folder: bpy.props.BoolProperty(default=True, options={"HIDDEN"})

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        try:
            image = bpy.data.images.load(self.filepath, check_existing=True)
        except RuntimeError as e:
            self.report({"ERROR"}, tr(f"Not a picture Blender reads: {e}", "reports"))
            return {"CANCELLED"}
        image.pack()
        context.scene.ps_sky_image = image
        return {"FINISHED"}


class MAP_OT_library_sky(bpy.types.Operator):
    bl_idname = "psmap.library_sky"
    bl_label = "Sky from the add-on"
    bl_description = "One of the add-on's own skies"
    which: bpy.props.EnumProperty(items=LIBRARY)

    def execute(self, context):
        path = os.path.join(SKIES, self.which + ".jpg")
        if not os.path.isfile(path):
            self.report({"ERROR"}, tr(f"Missing in the add-on: {path}", "reports"))
            return {"CANCELLED"}
        image = bpy.data.images.load(path, check_existing=True)
        image.pack()
        context.scene.ps_sky_image = image
        return {"FINISHED"}


class MAP_OT_clear_sky(bpy.types.Operator):
    bl_idname = "psmap.clear_sky"
    bl_label = "No sky"
    bl_description = "The map without a sky picture: the game's plain sky colour, the bake's plain blue sky"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        context.scene.ps_sky_image = None
        return {"FINISHED"}


# ---------- Lightmap density ----------
DENSITY = "ps_lightmap_density"   # an object's key, and a face attribute (its faces' own): as compiler/bake_light reads it
DENSITIES = (1, 2, 4, 8)


def faces_own(obj):
    """How many of the mesh's faces have a density of their own (set in Edit Mode)."""
    if obj.type != "MESH" or obj.mode == "EDIT":
        return 0
    attr = obj.data.attributes.get(DENSITY)
    if attr is None or attr.domain != "FACE":
        return 0
    values = [0.0] * len(obj.data.polygons)
    attr.data.foreach_get("value", values)
    return sum(1 for v in values if v > 0.0)


class MAP_OT_lightmap_density(bpy.types.Operator):
    bl_idname = "psmap.lightmap_density"
    bl_label = "Lightmap density"
    bl_description = ("How many times finer the baked light is here than on the rest of the map (×4: 2.5 cm a pixel "
                      "at Final): next to small lamps, sharp shadows. In Edit Mode on the selected faces only")
    bl_options = {"REGISTER", "UNDO"}
    value: bpy.props.IntProperty(default=1, min=1, max=16)

    def execute(self, context):
        import bmesh
        done = 0
        if context.mode == "EDIT_MESH":
            for obj in {o for o in context.objects_in_mode if o.type == "MESH"}:
                bm = bmesh.from_edit_mesh(obj.data)
                layer = bm.faces.layers.float.get(DENSITY) or bm.faces.layers.float.new(DENSITY)
                for f in bm.faces:
                    if f.select:
                        f[layer] = float(self.value)
                        done += 1
                bmesh.update_edit_mesh(obj.data)
            self.report({"INFO"}, tr(f"Lightmap ×{self.value} on {done} face(s)", "reports"))
            return {"FINISHED"}
        for obj in context.selected_objects:
            if obj.type != "MESH":
                continue
            if self.value == 1:
                obj.pop(DENSITY, None)
            else:
                obj[DENSITY] = float(self.value)
            done += 1
        self.report({"INFO"}, tr(f"Lightmap ×{self.value} on {done} object(s)", "reports"))
        return {"FINISHED"}


class MAP_OT_lightmap_density_clear(bpy.types.Operator):
    bl_idname = "psmap.lightmap_density_clear"
    bl_label = "Faces' own density off"
    bl_description = "The selected objects' faces take the object's lightmap density again (their own set in Edit Mode goes)"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        for obj in context.selected_objects:
            if obj.type == "MESH" and obj.mode != "EDIT" and obj.data.attributes.get(DENSITY) is not None:
                obj.data.attributes.remove(obj.data.attributes[DENSITY])
        return {"FINISHED"}


def draw_density(layout, obj, context):
    """A brush's lightmap density: ×1 ×2 ×4 ×8 (on the object, or in Edit Mode on its selected faces)."""
    editing = context.mode == "EDIT_MESH"
    current = int(round(float(obj.get(DENSITY) or 1.0)))
    layout.label(text=tr("Light detail of the selected faces:" if editing else f"Light detail of {obj.name}:"),
                 icon="LIGHTPROBE_PLANE")
    row = layout.row(align=True)
    for v in DENSITIES:
        row.operator("psmap.lightmap_density", text=tr(f"×{v}"), depress=(not editing and v == current)).value = v
    own = faces_own(obj)
    if own:
        row = layout.row(align=True)
        row.label(text=tr(f"{own} face(s) with their own"))
        row.operator("psmap.lightmap_density_clear", text="", icon="X")


def draw(layout, scene):
    """The sky and the baked light, one under the other."""
    draw_sky(layout, scene)
    draw_baked(layout, scene)


def draw_sky(layout, scene):
    """The Light tab's Sky: a 360° picture, its middle the map's north."""
    box = layout
    row = box.row(align=True)
    row.template_ID(scene, "ps_sky_image", open="psmap.load_sky")
    row = box.row(align=True)
    row.operator("psmap.make_sky", icon="SHADERFX")
    row.operator_menu_enum("psmap.library_sky", "which", text=tr("Library"), icon="ASSET_MANAGER")
    from . import sky_texture
    if sky_texture.sky_world(scene)[0] is not None:
        # The world has a Sky Texture: the map's sky made from it (and its sun turned to it).
        box.operator("psmap.sky_from_world", icon="WORLD", text=tr("Sky from Blender's Sky Texture"))
    if scene.ps_sky_image is not None:
        row.operator("psmap.clear_sky", text="", icon="X")
        box.prop(scene, "ps_sky_rotation", text=tr("Turn (°)"))
        box.prop(scene, "ps_sky_preview", text=tr("Show in the views"))
        row = box.row(align=True)
        row.prop(scene, "ps_sky_ground_own", text=tr("Ground below the horizon"))
        sub = row.row(align=True)
        sub.enabled = scene.ps_sky_ground_own
        sub.prop(scene, "ps_sky_ground", text="")
        box.prop(scene, "ps_sky_own_sun", text=tr("Photo with its own sun"))


def draw_baked(layout, scene):
    """The Light tab's Baked light: how deep the shade, how soft the sun."""
    box = layout
    box.prop(scene, "ps_shadow_depth", text=tr("Shadow depth"), slider=True)
    box.prop(scene, "ps_sun_softness", text=tr("Sun shadow softness (°)"))


def issues(scene, add):
    """Check map: a sky picture that the game and the bake read wrong."""
    image = scene.ps_sky_image
    if image is None:
        return
    w, h = image.size
    if w == 0 or h == 0:
        add("warning", f"Sky {image.name}: its picture cannot be read (moved or deleted?)")
    elif abs(w - 2 * h) > 2:
        add("warning", f"Sky {image.name}: {w} × {h}, not twice as wide as high — a 360° sky (equirectangular) is: "
                       "it shows stretched")
    elif w > MAX_WIDE:
        add("info", f"Sky {image.name}: {w} wide, the export makes it {MAX_WIDE}")


from .sky_texture import MAP_OT_sky_from_world  # noqa: E402  (the sky made from Blender's Sky Texture)

CLASSES = [MAP_OT_make_sky, MAP_OT_load_sky, MAP_OT_library_sky, MAP_OT_clear_sky, MAP_OT_lightmap_density,
           MAP_OT_lightmap_density_clear, MAP_OT_sky_from_world]


def register_props():
    S = bpy.types.Scene
    S.ps_sky_image = bpy.props.PointerProperty(type=bpy.types.Image, name="Sky", update=_changed,
                                               description="The map's sky: a 360° picture (equirectangular)")
    S.ps_sky_rotation = bpy.props.FloatProperty(name="Sky turn", min=-180.0, max=180.0, default=0.0, update=_changed,
                                                description="Where the picture's north (its middle) is: degrees round")
    S.ps_sky_preview = bpy.props.BoolProperty(
        name="Show the sky", default=True, update=_changed,
        description="The sky round the map in the 3D view (in Material Preview and Rendered shading)")
    S.ps_sky_ground_own = bpy.props.BoolProperty(
        name="Own ground colour", default=False,
        description="What lies below the horizon in the bake (it lights the map from below a little): your colour; "
                    "off: the sky's own horizon, darker")
    S.ps_sky_ground = bpy.props.FloatVectorProperty(name="Ground", subtype="COLOR", size=3, min=0, max=1,
                                                    default=(0.36, 0.32, 0.27))
    S.ps_sky_own_sun = bpy.props.BoolProperty(
        name="Its own sun", default=False,
        description="A photo with the sun in it: its brightest spot left out of the bake's sky light (the map's sun "
                    "lights the map; else twice)")
    S.ps_shadow_depth = bpy.props.FloatProperty(
        name="Shadow depth", min=-1.0, max=1.5, default=0.5, subtype="FACTOR",
        description="How much darker the shade is than where the sun falls: under 0 lighter still (the sky fills it "
                    "more: soft, airy), 0 light shade (as before), 0.5 chosen, 1 deep (sky and ambient zones fill it less)")
    S.ps_sun_softness = bpy.props.FloatProperty(
        name="Sun softness", min=0.0, max=10.0, default=1.5,
        description="How soft the sun's shadows are: its size in the sky, degrees (0.5 sharp as CS2, 1.5 as before, "
                    "3–5 soft)")


def unregister_props():
    for name in ("ps_sky_image", "ps_sky_rotation", "ps_sky_preview", "ps_sky_ground_own", "ps_sky_ground",
                 "ps_sky_own_sun", "ps_shadow_depth", "ps_sun_softness"):
        if hasattr(bpy.types.Scene, name):
            delattr(bpy.types.Scene, name)
