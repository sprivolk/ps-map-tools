"""The map in parts, so several people can make it at once (the GitHub tab → Parts).

A part is a collection of the map, and parts can hold parts (A site → A long → A long doors):
- by role: the map's own collections Clips, Collision, Entities (spawns, sites, lamps), Models, Prefabs — one person
  can place the clips while another builds (and Clips can hold Player clips and Grenade clips);
- by place: collections inside Seen (A site, Mid, T spawn…), made by Split; what lies right in Seen is the part Common;
- Settings: the scene's own (mode, sky, light, the map's card), in no collection.

Show parts paints each part a colour of its own in the 3D view, its name over it (the objects' own colours are kept and
put back). Split shows its proposal that way before anything moves. A sub-zone is made from the selected objects.

Every object of the map gets a lasting id (psmap_id): names are not enough (two people both make «Brush.042»), and a
copy (Shift+D) gets an id of its own. A part's fingerprint (a hash of what is in it) tells whether it changed.
New objects the tools put in a part go on into the part you are working in, when that one is inside it."""
import colorsys
import contextlib
import hashlib
import time
import json
import math
import uuid

import blf
import bpy
import numpy as np
from bpy_extras.view3d_utils import location_3d_to_region_2d
from mathutils import Vector

from . import map_collection

UID = "psmap_id"          # not ps_…: the export copies every ps_ key into the game's map
PART = "ps_part"          # on a collection: "role" or "place"
KEPT = "_psmap_color"     # an object's own colour while Show parts paints it
ROLES = ("Clips", "Collision", "Entities", "Models", "Prefabs")
COMMON = "Common"
SETTINGS = "Settings"

_uids = {}                 # psmap_id → the object's name, to tell a copy (Shift+D) from the original
_guard = [False]
# Show parts: on or not, the shading each 3D view had, the labels to draw, the draw handler.
_view = {"on": False, "shading": {}, "labels": [], "handle": None}


# ---------- quiet: what the add-on itself changes is not someone's edit ----------
_quiet = {"depth": 0, "until": 0.0}


@contextlib.contextmanager
def quiet():
    """Painting, putting parts in place, moving between parts: not an edit (Blender tells of it a moment later, so the
    quiet lasts a second after)."""
    _quiet["depth"] += 1
    try:
        yield
    finally:
        _quiet["depth"] -= 1
        _quiet["until"] = time.time() + 1.0


def is_quiet():
    return _quiet["depth"] > 0 or time.time() < _quiet["until"]


# ---------- the parts ----------
def seen_of(root):
    return next((c for c in root.children if c.name.split(".")[0] == "Seen"), None) if root else None


def _all_collections(root):
    out, stack = [], [root]
    while stack:
        c = stack.pop()
        out.append(c)
        stack.extend(c.children)
    return out


def is_split(scene):
    root = map_collection(scene)
    return bool(root) and any(c.get(PART) for c in _all_collections(root))


def parts(scene):
    """[(name, collection or None, kind, depth)]: the role parts (and theirs), Common, the place parts (and theirs),
    Settings — as a tree, in order."""
    root = map_collection(scene)
    if root is None:
        return []
    out = []

    def walk(col, depth, skip=None):
        for ch in col.children:
            if ch is skip:
                continue
            kind = ch.get(PART)
            if kind:
                out.append((ch.name, ch, kind, depth))
                walk(ch, depth + 1)
            else:
                walk(ch, depth)
    seen = seen_of(root)
    walk(root, 0, skip=seen)
    if seen is not None:
        out.append((COMMON, seen, "common", 0))
        walk(seen, 1)
    out.append((SETTINGS, None, "settings", 0))
    return out


def part_map(scene):
    """{object name: its part}, walking the map's tree once: an object belongs to its nearest part collection."""
    root = map_collection(scene)
    out = {}
    if root is None:
        return out

    def walk(c, part, depth):
        if depth > 64:
            return
        part = c.name if c.get(PART) else part
        for o in c.objects:
            if o is not None:
                # In two collections: the deeper part wins (a place inside Seen over Common).
                if o.name not in out or out[o.name] == COMMON:
                    out[o.name] = part
        for ch in c.children:
            walk(ch, part, depth + 1)
    walk(root, COMMON, 0)
    return out


def part_of(obj, scene):
    return part_map(scene).get(obj.name)


def part_objects(scene, name, pm=None):
    """The objects of a part itself (not of the parts inside it; Common: what lies in no part)."""
    if name == SETTINGS:
        return []
    pm = part_map(scene) if pm is None else pm
    return [bpy.data.objects[n] for n, part in pm.items() if part == name and n in bpy.data.objects]


def part_collection(scene, name):
    """The collection new objects of a part go to (Common: Seen)."""
    if name == COMMON:
        return seen_of(map_collection(scene))
    col = bpy.data.collections.get(name)
    return col if col is not None and col.get(PART) else None


def _objects_under(col):
    found, seen = [], set()
    for c in _all_collections(col):
        for o in c.objects:
            if o is not None and o.name not in seen:
                seen.add(o.name)
                found.append(o)
    return found


def _move(o, target, root):
    """The object into the target collection, out of the map's other collections."""
    if target.name not in [c.name for c in o.users_collection]:
        target.objects.link(o)
    mine = set(c.name for c in _all_collections(root))
    for c in list(o.users_collection):
        if c != target and c.name in mine:
            c.objects.unlink(o)


# ---------- lasting ids ----------
def ensure_uids(scene):
    """Every object of the map has its own psmap_id; a copy that carried its original's id gets a new one."""
    root = map_collection(scene)
    if root is None:
        return 0
    made, taken = 0, {}
    for o in sorted(_objects_under(root), key=lambda o: o.name):
        uid = o.get(UID)
        if not uid or (uid in taken and taken[uid] != o.name):
            o[UID] = uid = uuid.uuid4().hex[:16]
            made += 1
        taken[uid] = o.name
    _uids.clear()
    _uids.update(taken)
    return made


# ---------- fingerprints ----------
def _arr(coll, attr, dtype, width):
    a = np.empty(len(coll) * width, dtype=dtype)
    if len(coll):
        coll.foreach_get(attr, a)
    return a


def _value(v):
    if hasattr(v, "to_list"):
        return v.to_list()
    if hasattr(v, "to_dict"):
        return v.to_dict()
    if isinstance(v, (int, float, str, bool)) or v is None:
        return v
    try:
        return list(v)
    except TypeError:
        return str(v)


def object_print(o, h):
    """What makes an object what it is, into the hash: its id, name, place, data, materials, settings."""
    h.update(json.dumps([o.get(UID), o.name, o.type, o.parent.get(UID) if o.parent else None,
                         [round(x, 5) for row in o.matrix_world for x in row],
                         sorted((k, _value(o[k])) for k in o.keys() if k != UID and not k.startswith("_")),
                         [(m.name, m.type, getattr(getattr(m, "object", None), "name", None)) for m in o.modifiers],
                         [s.material.name if s.material else None for s in o.material_slots],
                         sorted(c.name for c in o.users_collection),
                         o.hide_render, o.display_type], default=str).encode())
    if o.type == "MESH":
        me = o.data
        h.update(np.round(_arr(me.vertices, "co", np.float32, 3), 5).tobytes())
        h.update(_arr(me.polygons, "loop_total", np.int32, 1).tobytes())
        h.update(_arr(me.loops, "vertex_index", np.int32, 1).tobytes())
        h.update(_arr(me.polygons, "material_index", np.int32, 1).tobytes())
        uv = me.uv_layers.active
        if uv is not None:
            h.update(np.round(_arr(uv.data, "uv", np.float32, 2), 5).tobytes())
    elif o.type == "EMPTY":
        h.update(json.dumps([o.empty_display_type, o.empty_display_size,
                             o.instance_type, o.instance_collection.name if o.instance_collection else None]).encode())
    elif o.type == "LIGHT":
        d = o.data
        h.update(json.dumps([d.type, list(d.color), d.energy, getattr(d, "shadow_soft_size", 0)]).encode())


def settings_print(scene, h):
    h.update(json.dumps(sorted((k, str(getattr(scene, k))) for k in dir(scene) if k.startswith("ps_")
                               and k not in ("ps_status", "ps_issues", "ps_current_part"))).encode())
    w = scene.world
    h.update((w.name if w else "").encode())


def fingerprint(scene, name, pm=None):
    h = hashlib.sha1()
    if name == SETTINGS:
        settings_print(scene, h)
    else:
        for o in sorted(part_objects(scene, name, pm), key=lambda o: o.get(UID) or o.name):
            object_print(o, h)
    return h.hexdigest()


def fingerprints(scene):
    pm = part_map(scene)
    return {name: fingerprint(scene, name, pm) for name, _, _, _ in parts(scene)}


# ---------- colours and Show parts ----------
# Colours far apart from each other, handed out in the order parts are first shown (the panel's tree order).
PALETTE = [(0.95, 0.3, 0.25), (0.25, 0.6, 1.0), (0.35, 0.85, 0.3), (1.0, 0.8, 0.15), (0.7, 0.4, 1.0),
           (0.1, 0.85, 0.8), (1.0, 0.45, 0.75), (0.65, 0.85, 0.2), (1.0, 0.55, 0.1), (0.45, 0.45, 0.95),
           (0.85, 0.85, 0.5), (0.4, 0.95, 0.6)]
_colours = {}


def part_color(name):
    """A part's colour: Common grey; the others from the palette, each name keeping its colour for the session."""
    if name == COMMON:
        return (0.55, 0.55, 0.55, 1.0)
    if name not in _colours:
        if len(_colours) < len(PALETTE):
            c = PALETTE[len(_colours)]
        else:
            hue = int(hashlib.md5(name.encode()).hexdigest()[:6], 16) / 0xFFFFFF
            c = colorsys.hsv_to_rgb(hue, 0.65, 0.95)
        _colours[name] = (c[0], c[1], c[2], 1.0)
    return _colours[name]


def _spaces():
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                yield area, area.spaces.active


def paint(scene, colours):
    """{object name: colour} painted (each object's own colour kept once); the 3D views show object colours."""
    with quiet():
        _paint(colours)


def _paint(colours):
    for name, c in colours.items():
        o = bpy.data.objects.get(name)
        if o is None:
            continue
        if KEPT not in o:
            o[KEPT] = list(o.color)
        o.color = c
    for area, space in _spaces():
        key = space.as_pointer()
        if key not in _view["shading"]:
            _view["shading"][key] = (space.shading.type, space.shading.color_type)
        if space.shading.type not in ("SOLID", "WIREFRAME"):
            space.shading.type = "SOLID"
        space.shading.color_type = "OBJECT"
        area.tag_redraw()


def unpaint():
    with quiet():
        _unpaint()


def _unpaint():
    for o in bpy.data.objects:
        if KEPT in o:
            try:
                o.color = o[KEPT]
            except (TypeError, ValueError):
                pass
            del o[KEPT]
    for area, space in _spaces():
        kept = _view["shading"].get(space.as_pointer())
        if kept:
            space.shading.type, space.shading.color_type = kept
        area.tag_redraw()
    _view["shading"].clear()
    _view["labels"] = []


def _centre(objs):
    pts = []
    for o in objs:
        if o.type == "MESH":
            pts += [o.matrix_world @ Vector(c) for c in o.bound_box]
        else:
            pts.append(o.matrix_world.translation.copy())
    if not pts:
        return None
    lo = Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts)))
    hi = Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts)))
    return Vector(((lo.x + hi.x) / 2, (lo.y + hi.y) / 2, hi.z))


def show_groups(scene, groups):
    """{label: [objects]}: each group painted its colour, its name drawn over its middle."""
    colours, labels = {}, []
    for label, objs in groups.items():
        c = part_color(label)
        for o in objs:
            colours[o.name] = c
        mid = _centre(objs)
        if mid is not None and objs:
            labels.append((label, mid, c, len(objs)))
    paint(scene, colours)
    _view["labels"] = labels
    _view["on"] = True
    _ensure_handler()


def show_parts(scene):
    for name, _, kind, _ in parts(scene):  # colours handed out in the tree's order
        if kind != "settings":
            part_color(name)
    pm = part_map(scene)
    groups = {}
    for name, part in pm.items():
        o = bpy.data.objects.get(name)
        if o is not None:
            groups.setdefault(part, []).append(o)
    # Labels of the role parts are left out: they lie all over the map (Entities, Clips).
    show_groups(scene, groups)
    kinds = {n: k for n, _, k, _ in parts(scene)}
    _view["labels"] = [lab for lab in _view["labels"] if kinds.get(lab[0]) in ("place", "common")]


def hide_parts():
    _view["on"] = False
    unpaint()
    _redraw()


def _redraw():
    for area, _ in _spaces():
        area.tag_redraw()


def _draw_labels():
    if not _view["on"] or not _view["labels"]:
        return
    region, rv3d = bpy.context.region, bpy.context.region_data
    if rv3d is None:
        return
    # Names only when looking down on the map: from the side they pile up on each other.
    if abs((rv3d.view_rotation @ Vector((0.0, 0.0, -1.0))).z) < 0.6:
        return
    font, size = 0, int(18 * bpy.context.preferences.system.ui_scale)
    blf.size(font, size)
    blf.enable(font, blf.SHADOW)
    blf.shadow(font, 5, 0.0, 0.0, 0.0, 0.9)
    blf.shadow_offset(font, 1, -1)
    for text, mid, c, count in _view["labels"]:
        p = location_3d_to_region_2d(region, rv3d, mid)
        if p is None:
            continue
        label = f"{text}  ({count})"
        w, h = blf.dimensions(font, label)
        blf.position(font, p.x - w / 2, p.y + 6, 0)
        blf.color(font, min(1.0, c[0] + 0.25), min(1.0, c[1] + 0.25), min(1.0, c[2] + 0.25), 1.0)
        blf.draw(font, label)
    blf.disable(font, blf.SHADOW)


def _ensure_handler():
    if _view["handle"] is None:
        _view["handle"] = bpy.types.SpaceView3D.draw_handler_add(_draw_labels, (), "WINDOW", "POST_PIXEL")


def view_from_above(context):
    for area, space in _spaces():
        region = next((r for r in area.regions if r.type == "WINDOW"), None)
        with context.temp_override(area=area, region=region):
            bpy.ops.view3d.view_axis(type="TOP")
            bpy.ops.view3d.view_all()
        break


class MAP_OT_parts_view(bpy.types.Operator):
    bl_idname = "psmap.parts_view"
    bl_label = "Show parts"
    bl_description = "Paints each part a colour of its own with its name over it (the objects' own colours come back after)"
    above: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})

    def execute(self, context):
        if _view["on"] and not self.above:
            hide_parts()
            return {"FINISHED"}
        show_parts(context.scene)
        if self.above:
            view_from_above(context)
        return {"FINISHED"}


# ---------- Split: proposing parts by place, shown before anything moves ----------
def anchors(scene):
    """Where the places are: the bomb sites, the spawns of each side, and Mid between them."""
    root = map_collection(scene)
    found = {}
    for o in _objects_under(root) if root else []:
        e = o.get("ps_entity")
        p = o.matrix_world.translation
        if e == "bombsite":
            found.setdefault(f"{o.get('ps_site', '?')} site", []).append(p.copy())
        elif e == "spawn" and o.get("ps_team") in ("T", "CT"):
            found.setdefault(f"{o['ps_team']} spawn", []).append(p.copy())
    out = {k: sum(v, Vector()) / len(v) for k, v in found.items()}
    if len(out) >= 2:
        out["Mid"] = sum(out.values(), Vector()) / len(out)
    return out


def propose(scene):
    """{place: [objects]} for what lies right in Seen: each goes to the nearest place (by its middle, seen from above)."""
    seen = seen_of(map_collection(scene))
    places = anchors(scene)
    if seen is None or not places:
        return {}
    out = {k: [] for k in places}
    for o in seen.objects:
        corners = [o.matrix_world @ Vector(c) for c in o.bound_box] if o.type == "MESH" else [o.matrix_world.translation]
        mid = sum(corners, Vector()) / len(corners)
        best = min(places, key=lambda k: math.hypot(places[k].x - mid.x, places[k].y - mid.y))
        out[best].append(o)
    return out


def _show_proposal(self=None, context=None):
    """The proposal painted: each ticked place its colour under its (edited) name, unticked ones grey as Common."""
    wm = bpy.context.window_manager
    scene = bpy.context.scene
    prop = propose(scene)
    groups = {}
    for p in wm.ps_split:
        objs = prop.get(p.key, [])
        label = (p.title.strip() or p.key) if p.take else COMMON
        groups.setdefault(label, []).extend(objs)
    unpaint()
    show_groups(scene, groups)


class PSPlace(bpy.types.PropertyGroup):
    take: bpy.props.BoolProperty(name="Make it", default=True, update=_show_proposal)
    title: bpy.props.StringProperty(name="Name", update=_show_proposal)
    key: bpy.props.StringProperty()
    count: bpy.props.IntProperty()


class MAP_OT_parts_split(bpy.types.Operator):
    bl_idname = "psmap.parts_split"
    bl_label = "Split the map into parts"
    bl_description = ("Shows how the map would split into parts, painted on the map, before anything moves: by role "
                      "(clips, entities…) and by place (sites, spawns, mid). Then Apply or Cancel")

    @classmethod
    def poll(cls, context):
        return map_collection(context.scene) is not None and not context.window_manager.ps_split_active

    def execute(self, context):
        wm = context.window_manager
        wm.ps_split.clear()
        for key, objs in propose(context.scene).items():
            p = wm.ps_split.add()
            p.key, p.count = key, len(objs)
            p["title"], p["take"] = key, bool(objs)  # without the update: painted once below
        wm.ps_split_active = True
        _show_proposal()
        view_from_above(context)
        return {"FINISHED"}


class MAP_OT_parts_split_end(bpy.types.Operator):
    bl_idname = "psmap.parts_split_end"
    bl_label = "Split"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}
    apply: bpy.props.BoolProperty()

    @classmethod
    def description(cls, context, props):
        return ("Makes the parts as shown: the objects move into the parts' collections (nothing else changes)"
                if props.apply else "Leaves the map as it was")

    def execute(self, context):
        wm, scene = context.window_manager, context.scene
        wm.ps_split_active = False
        if not self.apply:
            hide_parts()
            return {"FINISHED"}
        root = map_collection(scene)
        for c in root.children:
            if c.name.split(".")[0] in ROLES:
                c[PART] = "role"
        seen = seen_of(root)
        proposal = propose(scene)
        for p in wm.ps_split:
            objs = proposal.get(p.key, [])
            if not p.take or not objs or seen is None:
                continue
            col = _new_part(p.title.strip() or p.key, seen, "place")
            for o in objs:
                _move(o, col, root)
        ensure_uids(scene)
        if not scene.ps_current_part:
            scene.ps_current_part = COMMON
        unpaint()
        show_parts(scene)
        self.report({"INFO"}, f"The map is in {len(parts(scene))} parts")
        return {"FINISHED"}


def _new_part(title, parent, kind):
    col = bpy.data.collections.get(title)
    if col is None or col.library is not None or col.get(PART):
        col = bpy.data.collections.new(title)
    if col.name not in parent.children:
        parent.children.link(col)
    col[PART] = kind
    return col


# ---------- sub-zones and moving ----------
def parts_search(self, context, edit_text):
    return [n for n, _, k, _ in parts(context.scene) if k != "settings"]


class MAP_OT_parts_subzone(bpy.types.Operator):
    bl_idname = "psmap.parts_subzone"
    bl_label = "Make a sub-zone"
    bl_description = ("The selected objects become a part of their own inside the part they are in (A site → A long; "
                      "Clips → Grenade clips). Sub-zones can hold sub-zones")
    bl_options = {"REGISTER", "UNDO"}
    title: bpy.props.StringProperty(name="Name")

    @classmethod
    def poll(cls, context):
        return is_split(context.scene) and bool(context.selected_objects)

    def invoke(self, context, event):
        inside = self._inside(context)
        self.title = f"{inside} part"
        return context.window_manager.invoke_props_dialog(self, width=380, title="Make a sub-zone", confirm_text="Make it")

    def _inside(self, context):
        pm = part_map(context.scene)
        found = {pm.get(o.name) for o in context.selected_objects if o.name in pm}
        return found.pop() if len(found) == 1 else None

    def draw(self, context):
        inside = self._inside(context)
        self.layout.prop(self, "title")
        if inside:
            self.layout.label(text=f"{len(context.selected_objects)} objects, a part inside {inside}", icon="INFO")
        else:
            self.layout.label(text="Select objects of one part only (they are in different parts)", icon="ERROR")

    def execute(self, context):
        scene = context.scene
        inside = self._inside(context)
        parent = part_collection(scene, inside) if inside else None
        if parent is None or not self.title.strip():
            self.report({"ERROR"}, "Select objects of one part only")
            return {"CANCELLED"}
        kind = "place" if inside == COMMON else parent.get(PART, "place")
        col = _new_part(self.title.strip(), parent, kind)
        root = map_collection(scene)
        for o in context.selected_objects:
            _move(o, col, root)
        if _view["on"]:
            unpaint()
            show_parts(scene)
        self.report({"INFO"}, f"{col.name}: {len(context.selected_objects)} objects")
        return {"FINISHED"}


class MAP_OT_parts_move(bpy.types.Operator):
    bl_idname = "psmap.parts_move"
    bl_label = "Move to part"
    bl_description = "Moves the selected objects into another part"
    bl_options = {"REGISTER", "UNDO"}
    part: bpy.props.StringProperty(name="Part", search=parts_search, search_options=set())

    @classmethod
    def poll(cls, context):
        return is_split(context.scene) and bool(context.selected_objects)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=340, title="Move to part", confirm_text="Move")

    def execute(self, context):
        scene = context.scene
        target = part_collection(scene, self.part)
        if target is None:
            self.report({"ERROR"}, "Pick a part from the list")
            return {"CANCELLED"}
        root = map_collection(scene)
        for o in context.selected_objects:
            _move(o, target, root)
        if _view["on"]:
            unpaint()
            show_parts(scene)
        return {"FINISHED"}


# ---------- Working in: new objects go there ----------
def current_search(self, context, edit_text):
    return [n for n, _, k, _ in parts(context.scene) if k != "settings"]


def _inside_of(col, ancestor):
    return any(c == col for c in _all_collections(ancestor))


@bpy.app.handlers.persistent
def on_depsgraph(scene, depsgraph):
    """New objects: an id of their own; one a tool put in a part that holds the part you work in goes on into it."""
    if _guard[0] or not is_split(scene):
        return
    new = []
    for u in depsgraph.updates:
        o = u.id.original if isinstance(u.id, bpy.types.Object) else None
        if o is None or o.library is not None:
            continue
        uid = o.get(UID)
        if not uid or (_uids.get(uid) not in (None, o.name) and _uids.get(uid) in bpy.data.objects):
            new.append(o)
    if not new:
        return
    _guard[0] = True
    try:
        root = map_collection(scene)
        target = part_collection(scene, scene.ps_current_part) if scene.ps_current_part else None
        under = set(o.name for o in _objects_under(root)) if root else set()
        for o in new:
            if o.name not in under:
                continue
            o[UID] = uuid.uuid4().hex[:16]
            _uids[o[UID]] = o.name
            if target is not None and o.users_collection:
                where = o.users_collection[0]
                if where != target and _inside_of(target, where):
                    _move(o, target, root)
            if _view["on"]:
                o[KEPT] = list(o.color)
                o.color = part_color(part_of(o, scene))
    finally:
        _guard[0] = False


@bpy.app.handlers.persistent
def on_load(_):
    _uids.clear()
    _view["on"] = False
    _view["shading"].clear()
    _view["labels"] = []
    for o in bpy.data.objects:  # saved while Show parts was on: the own colours back
        if KEPT in o:
            try:
                o.color = o[KEPT]
            except (TypeError, ValueError):
                pass
            del o[KEPT]
    for scene in bpy.data.scenes:
        if is_split(scene):
            for o in _objects_under(map_collection(scene)):
                if o.get(UID):
                    _uids.setdefault(o[UID], o.name)


# ---------- the panel ----------
class MAP_OT_parts_select(bpy.types.Operator):
    bl_idname = "psmap.parts_select"
    bl_label = "Select the part"
    bl_description = "Selects the part's objects and shows them"
    part: bpy.props.StringProperty()

    def execute(self, context):
        objs = part_objects(context.scene, self.part)
        for o in context.view_layer.objects.selected:
            o.select_set(False)
        shown = [o for o in objs if o.visible_get()]
        for o in shown:
            o.select_set(True)
        if shown:
            context.view_layer.objects.active = shown[0]
            for area, _ in _spaces():
                region = next((r for r in area.regions if r.type == "WINDOW"), None)
                with context.temp_override(area=area, region=region):
                    bpy.ops.view3d.view_selected()
                break
        return {"FINISHED"}


def _dot(row, colour):
    row.template_node_socket(color=colour)


def draw_parts(layout, context):
    scene, wm = context.scene, context.window_manager
    if map_collection(scene) is None:
        layout.label(text="Open a map to see its parts", icon="INFO")
        return
    if wm.ps_split_active:
        box = layout.box()
        box.label(text="How the map would split (painted on it):", icon="OUTLINER_COLLECTION")
        col = box.column(align=True)
        for p in wm.ps_split:
            row = col.row(align=True)
            row.prop(p, "take", text="")
            _dot(row, part_color((p.title.strip() or p.key) if p.take else COMMON))
            sub = row.row(align=True)
            sub.enabled = p.take
            sub.prop(p, "title", text="")
            sub.label(text=f"{p.count}")
        col = box.column(align=True)
        col.label(text="Unticked: those stay in Common (grey).", icon="BLANK1")
        root = map_collection(scene)
        roles = [c.name for c in root.children if c.name.split(".")[0] in ROLES] if root else []
        col.label(text="Parts by role too: " + (", ".join(roles) or "none"), icon="BLANK1")
        col.label(text="Sub-zones: after Apply, select objects → Make a sub-zone.", icon="BLANK1")
        row = box.row(align=True)
        row.scale_y = 1.3
        row.operator("psmap.parts_split_end", text="Apply", icon="CHECKMARK").apply = True
        row.operator("psmap.parts_split_end", text="Cancel", icon="X").apply = False
        return
    if not is_split(scene):
        col = layout.column(align=True)
        col.label(text="Split the map into parts to make it together:", icon="INFO")
        col.label(text="one places clips while another builds a site;", icon="BLANK1")
        col.label(text="each sends and gets only the parts that changed.", icon="BLANK1")
        row = layout.row()
        row.scale_y = 1.3
        row.operator("psmap.parts_split", icon="OUTLINER_COLLECTION")
        return
    row = layout.row(align=True)
    row.operator("psmap.parts_view", text="Hide parts" if _view["on"] else "Show parts",
                 icon="HIDE_OFF" if not _view["on"] else "HIDE_ON", depress=_view["on"])
    row.operator("psmap.parts_view", text="", icon="VIEW_ORTHO").above = True
    layout.prop(scene, "ps_current_part", text="Working in", icon="OUTLINER_COLLECTION")
    col = layout.column(align=True)
    pm = part_map(scene)
    from .github import account, read_state
    me = account()["login"] if bpy.data.filepath and read_state(bpy.data.filepath) else ""
    for name, coll, kind, depth in parts(scene):
        row = col.row(align=True)
        if depth:
            row.label(text="", icon="BLANK1")
            for _ in range(depth - 1):
                row.label(text="", icon="BLANK1")
        if kind == "settings":
            row.label(text=name, icon="PREFERENCES")
            continue
        _dot(row, part_color(name))
        count = len(part_objects(scene, name, pm))
        row.label(text=f"{name}  ({count})")
        if me:
            from . import editing
            editing.row_badge(row, name, me)
        row.operator("psmap.parts_select", text="", icon="RESTRICT_SELECT_OFF").part = name
    row = layout.row(align=True)
    row.operator("psmap.parts_subzone", icon="ADD")
    row.operator("psmap.parts_move", icon="FORWARD")
    layout.operator("psmap.parts_split", text="Split Common again (sites, spawns, mid)", icon="OUTLINER_COLLECTION")


CLASSES = [PSPlace, MAP_OT_parts_view, MAP_OT_parts_split, MAP_OT_parts_split_end, MAP_OT_parts_subzone,
           MAP_OT_parts_move, MAP_OT_parts_select]


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    bpy.types.Scene.ps_current_part = bpy.props.StringProperty(
        name="Working in", search=current_search, search_options=set(),
        description="The part you are working in: new objects the tools make go into it (when they would go into a "
                    "part that holds it)")
    bpy.types.WindowManager.ps_split = bpy.props.CollectionProperty(type=PSPlace)
    bpy.types.WindowManager.ps_split_active = bpy.props.BoolProperty()
    bpy.app.handlers.depsgraph_update_post.append(on_depsgraph)
    bpy.app.handlers.load_post.append(on_load)


def unregister():
    if _view["on"]:
        hide_parts()
    if _view["handle"] is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_view["handle"], "WINDOW")
        _view["handle"] = None
    for lst, fn in ((bpy.app.handlers.depsgraph_update_post, on_depsgraph), (bpy.app.handlers.load_post, on_load)):
        if fn in lst:
            lst.remove(fn)
    for prop in ("ps_split", "ps_split_active"):
        if hasattr(bpy.types.WindowManager, prop):
            delattr(bpy.types.WindowManager, prop)
    if hasattr(bpy.types.Scene, "ps_current_part"):
        del bpy.types.Scene.ps_current_part
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
