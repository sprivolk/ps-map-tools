"""Making a map together through GitHub (its own tab, GitHub): no git to install, the add-on talks to GitHub's web API itself.

- Sign in with GitHub: a code shown here, typed on github.com/login/device (the PlaceholderShooter map tools GitHub App;
  the token is kept in Blender's config folder, never in a .blend).
- A map = a repository (or a folder in one): Create one for the open map, Connect the map to one, or Open a map from one.
  Invite brings a person in by their GitHub name.
- Send: the .blend (a copy: its outside pictures go beside it as textures/…, the copy points at them), the .psmap files
  and the last export's log, one commit; files GitHub already has are not sent again. It does not overwrite a newer
  .blend someone else sent after you took yours (Get it first, or Send anyway), nor one someone has taken for editing.
- Get: what changed on GitHub since you last took or sent it; your .blend is copied to .backups/ before it is replaced.
- Editing: «I'm editing it» marks the .blend as taken (everyone sees who), Done frees it.
- History: the last sends; any of them can be brought back (then Send makes it the newest).

What the add-on remembers about the map's repository is in .ps_github.json beside the .blend (never sent)."""
import base64
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

import bpy

CLIENT_ID = "Iv23lifSGfzH6zN7F16p"  # the GitHub App «PlaceholderShooter map tools» (not a secret)
APP_PAGE = "https://github.com/apps/placeholdershooter-map-tools"
API = "https://api.github.com"
LIMIT = 100 * 1024 * 1024  # GitHub takes no file bigger
TEAM = ".psmap-team/"      # the team's own files in the map's folder: who edits what, which .blend is the map
LOCKS = TEAM + "locks.json"
PROJECT = TEAM + "project.json"
STATE = ".ps_github.json"
BACKUPS = ".backups"
KEEP_BACKUPS = 5

# The one job running (sign-in, send, get…): its stage for the panel, how it ended, what the main thread does after.
_job = {"thread": None, "stage": "", "result": "", "error": False, "url": "", "conflict": None}
_main = []           # callables the main thread runs (Blender's data only there)
_cache = {"repos": [], "locks": {}, "history": [], "for": "", "code": ""}
_repo_items = []     # the repositories' list for the menus (kept: Blender needs the strings to live)


# ---------- the sign-in ----------
def _account_file():
    return os.path.join(bpy.utils.user_resource("CONFIG"), "ps_map_tools_github.json")


def account():
    try:
        with open(_account_file(), encoding="utf-8") as f:
            data = json.load(f)
        return {"token": str(data.get("token") or ""), "login": str(data.get("login") or "")}
    except (OSError, ValueError):
        return {"token": "", "login": ""}


def _write_account(token, login):
    path = _account_file()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if not token:
        if os.path.exists(path):
            os.remove(path)
        return
    with open(path, "w", encoding="utf-8") as f:
        json.dump({"token": token, "login": login}, f)
    try:
        os.chmod(path, 0o600)  # only this user reads it (on a Mac or Linux)
    except OSError:
        pass


# ---------- talking to GitHub ----------
class GitHubError(Exception):
    pass


class Conflict(Exception):
    """Send stopped: someone else's newer .blend, or the .blend taken by someone else."""


def _request(url, method="GET", body=None, headers=None, form=False, timeout=600):
    data = None
    headers = dict(headers or {})
    headers.setdefault("User-Agent", "ps-map-tools")
    if body is not None:
        data = urllib.parse.urlencode(body).encode() if form else json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/x-www-form-urlencoded" if form else "application/json"
    req = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            text = r.read().decode("utf-8")
            return json.loads(text) if text else {}
    except urllib.error.HTTPError as e:
        try:
            said = json.loads(e.read().decode("utf-8")).get("message", "")
        except Exception:
            said = ""
        raise GitHubError(e.code, said) from None
    except urllib.error.URLError as e:
        raise GitHubError(0, f"no connection to GitHub ({e.reason})") from None


def _call(token, method, path, body=None, timeout=600):
    return _request(API + path, method, body, timeout=timeout, headers={
        "Authorization": "Bearer " + token, "Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"})


def _explain(e, repo=""):
    code, said = (tuple(e.args) + ("", ""))[:2]
    if code == 401:
        return "GitHub signed you out (the sign-in expired or was taken back): Sign in again"
    if code in (403, 404) and repo:
        return (f"No access to {repo}: the map tools app is not installed on it, or you are not invited "
                f"(owner: Install the app; others: accept the invitation). ({said or code})")
    if code == 0:
        return str(said)
    return f"GitHub: {said or code}"


def git_sha(data):
    """The id git gives a file's bytes: an unchanged file is not sent (or taken) again."""
    return hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()


def file_sha(path):
    with open(path, "rb") as f:
        return git_sha(f.read())


def q(text):
    return urllib.parse.quote(text)


class Repo:
    """A map's repository as the add-on uses it: owner/name, the branch, the map's folder in it."""

    def __init__(self, token, full, branch="", folder=""):
        self.token, self.full = token, full
        self.branch = branch
        prefix = (folder or "").strip().strip("/")
        self.prefix = prefix + "/" if prefix else ""

    def call(self, method, path, body=None):
        return _call(self.token, method, f"/repos/{self.full}{path}", body)

    def ensure_branch(self):
        if not self.branch:
            self.branch = self.call("GET", "")["default_branch"] or "main"
        return self.branch

    def head(self, create=False):
        self.ensure_branch()
        try:
            return self.call("GET", f"/git/ref/heads/{q(self.branch)}")["object"]["sha"]
        except GitHubError as e:
            if not create or e.args[0] not in (404, 409):
                raise
        # An empty repository (or no such branch yet): a first file makes it.
        self.call("PUT", f"/contents/{q(self.prefix)}README.md", {
            "message": "Map repository", "branch": self.branch,
            "content": base64.b64encode("# Map\n\nMade with PlaceholderShooter map tools (Blender, the GitHub tab).\n"
                                        .encode("utf-8")).decode("ascii")})
        return self.call("GET", f"/git/ref/heads/{q(self.branch)}")["object"]["sha"]

    def tree_of(self, commit):
        tree = self.call("GET", f"/git/commits/{commit}")["tree"]["sha"]
        files = {}
        for t in self.call("GET", f"/git/trees/{tree}?recursive=1").get("tree", []):
            if t.get("type") == "blob" and t["path"].startswith(self.prefix):
                files[t["path"][len(self.prefix):]] = t["sha"]
        return tree, files

    def blob(self, sha):
        return base64.b64decode(self.call("GET", f"/git/blobs/{sha}")["content"])

    def commit(self, head, base_tree, changes, message):
        """changes: {path in the map's folder: bytes}. The new commit's id."""
        tree = []
        for i, (rel, data) in enumerate(changes.items(), 1):
            if data is None:  # taken out
                tree.append({"path": self.prefix + rel, "mode": "100644", "type": "blob", "sha": None})
                continue
            _stage(f"Sending {rel} ({len(data) / (1024 * 1024):.1f} MB, {i} of {len(changes)})…")
            sha = self.call("POST", "/git/blobs", {"content": base64.b64encode(data).decode("ascii"), "encoding": "base64"})["sha"]
            tree.append({"path": self.prefix + rel, "mode": "100644", "type": "blob", "sha": sha})
        _stage("Making the commit…")
        new_tree = self.call("POST", "/git/trees", {"base_tree": base_tree, "tree": tree})["sha"]
        commit = self.call("POST", "/git/commits", {"message": message, "tree": new_tree, "parents": [head]})["sha"]
        try:
            self.call("PATCH", f"/git/refs/heads/{q(self.branch)}", {"sha": commit})
        except GitHubError as e:
            if e.args[0] == 422:
                raise GitHubError(0, "someone sent to the map just now: press Send again") from None
            raise
        return commit

    def locks(self):
        """{file: {"user", "since"}} and the file's id (None: no such file yet)."""
        try:
            got = self.call("GET", f"/contents/{q(self.prefix + LOCKS)}?ref={q(self.ensure_branch())}")
            return json.loads(base64.b64decode(got["content"]).decode("utf-8") or "{}"), got["sha"]
        except GitHubError as e:
            if e.args[0] == 404:
                return {}, None
            raise

    def set_lock(self, file, user, take):
        for _ in range(3):
            locks, sha = self.locks()
            if take:
                locks[file] = {"user": user, "since": int(time.time())}
            elif locks.get(file, {}).get("user") == user:
                del locks[file]
            else:
                return locks
            body = {"message": f"{file}: {'taken' if take else 'freed'} by {user}", "branch": self.branch,
                    "content": base64.b64encode(json.dumps(locks, indent=1).encode("utf-8")).decode("ascii")}
            if sha:
                body["sha"] = sha
            try:
                self.call("PUT", f"/contents/{q(self.prefix + LOCKS)}", body)
                return locks
            except GitHubError as e:
                if e.args[0] not in (409, 422):
                    raise
        raise GitHubError(0, "the editing marks changed meanwhile: try again")

    def history(self, count=15):
        path = self.prefix.rstrip("/")
        got = self.call("GET", f"/commits?sha={q(self.ensure_branch())}&per_page={count}" + (f"&path={q(path)}" if path else ""))
        out = []
        for c in got:
            who = (c.get("author") or {}).get("login") or c["commit"]["author"].get("name", "")
            out.append({"sha": c["sha"], "message": c["commit"]["message"].splitlines()[0][:80], "who": who,
                        "when": c["commit"]["author"].get("date", "")})
        return out

    def last_author(self, rel):
        try:
            got = self.call("GET", f"/commits?sha={q(self.branch)}&per_page=1&path={q(self.prefix + rel)}")
            return (got[0].get("author") or {}).get("login") or got[0]["commit"]["author"].get("name", "someone")
        except (GitHubError, IndexError, KeyError):
            return "someone"


# ---------- what the add-on remembers about the map (beside the .blend) ----------
def state_path(blend):
    return os.path.join(os.path.dirname(blend), STATE)


def read_state(blend):
    try:
        with open(state_path(blend), encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def write_state(folder, state):
    path = os.path.join(folder, STATE)
    with open(path + ".tmp", "w", encoding="utf-8") as f:
        json.dump(state, f, indent=1)
    os.replace(path + ".tmp", path)


def _repo_of(state, token):
    return Repo(token, state["repo"], state.get("branch", ""), state.get("folder", ""))


# ---------- the files of a send ----------
COPY_SCRIPT = r'''
import bpy, hashlib, json, os, shutil, sys
out_blend, tex_dir, map_dir, listing = sys.argv[sys.argv.index("--") + 1:]
made = {}
here = os.path.normcase(os.path.join(map_dir, "textures")) + os.sep
for img in bpy.data.images:
    if img.library or img.packed_file or img.source != "FILE" or not img.filepath:
        continue
    src = os.path.normpath(bpy.path.abspath(img.filepath))
    if not os.path.isfile(src):
        continue
    with open(src, "rb") as f:
        h = hashlib.sha1(f.read()).hexdigest()[:8]
    base = os.path.basename(src)
    if not os.path.normcase(src).startswith(here):
        stem, ext = os.path.splitext(base)
        if made.get(base, h) != h:
            base = f"{stem}_{h}{ext}"
    made[base] = h
    shutil.copyfile(src, os.path.join(tex_dir, base))
    img.filepath = "//textures/" + base
# What only this computer shows: the parts' colours, someone else's part closed to selection.
for o in bpy.data.objects:
    if "_psmap_color" in o:
        o.color = o["_psmap_color"]
        del o["_psmap_color"]
    if "_psmap_lock" in o:
        o.hide_select = bool(o["_psmap_lock"])
        del o["_psmap_lock"]
bpy.ops.wm.save_as_mainfile(filepath=out_blend, copy=True, compress=True, relative_remap=False)
with open(listing, "w") as f:
    json.dump(sorted(made), f)
'''


def make_copy(blend, tmp):
    """The .blend as a copy whose outside pictures are files in textures/ beside it: {path in the map: file}."""
    tex = os.path.join(tmp, "textures")
    os.makedirs(tex, exist_ok=True)
    script, listing = os.path.join(tmp, "copy.py"), os.path.join(tmp, "textures.json")
    with open(script, "w", encoding="utf-8") as f:
        f.write(COPY_SCRIPT)
    out = os.path.join(tmp, os.path.basename(blend))
    run = subprocess.run([bpy.app.binary_path, "-b", "--factory-startup", blend, "--python", script, "--",
                          out, tex, os.path.dirname(blend), listing],
                         capture_output=True, text=True, timeout=1800, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    if not os.path.isfile(out) or not os.path.isfile(listing):
        tail = (run.stdout + run.stderr).strip().splitlines()[-5:]
        raise GitHubError(0, "could not make the copy of the .blend to send: " + " / ".join(tail))
    with open(listing) as f:
        files = {"textures/" + n: os.path.join(tex, n) for n in json.load(f)}
    files[os.path.basename(blend)] = out
    return files


def beside(blend):
    """The map's other files beside the .blend: its .psmap files and the last export's log."""
    folder, stem = os.path.dirname(blend), os.path.splitext(os.path.basename(blend))[0]
    out = {}
    for name in sorted(os.listdir(folder)):
        if name.lower().endswith(".psmap") and os.path.isfile(os.path.join(folder, name)):
            out[name] = os.path.join(folder, name)
    log = stem + "_export.log"
    if os.path.isfile(os.path.join(folder, log)):
        out[log] = os.path.join(folder, log)
    return out


def _backup(path):
    folder = os.path.join(os.path.dirname(path), BACKUPS)
    os.makedirs(folder, exist_ok=True)
    stem, ext = os.path.splitext(os.path.basename(path))
    shutil.copy2(path, os.path.join(folder, f"{stem}_{time.strftime('%Y-%m-%d_%H-%M-%S')}{ext}"))
    kept = sorted(n for n in os.listdir(folder) if n.startswith(stem + "_") and n.endswith(ext))
    for old in kept[:-KEEP_BACKUPS]:
        os.remove(os.path.join(folder, old))


# ---------- the jobs (each in its own thread) ----------
def _stage(text):
    _job["stage"] = text


def job_send(token, me, blend, message, force):
    folder = os.path.dirname(blend)
    state = read_state(blend)
    repo = _repo_of(state, token)
    main = os.path.basename(blend)
    with tempfile.TemporaryDirectory() as tmp:
        _stage("Making the copy to send (pictures beside it)…")
        files = make_copy(blend, tmp)
        files.update(beside(blend))
        new = {}
        for rel, path in files.items():
            with open(path, "rb") as f:
                new[rel] = f.read()
        new[PROJECT] = json.dumps({"main": main}, indent=1).encode("utf-8")
        for rel, data in new.items():
            if len(data) > LIMIT:
                raise GitHubError(0, f"{rel} is {len(data) // (1024 * 1024)} MB: GitHub takes files up to 100 MB "
                                     "(make it smaller)")

        _stage("Asking GitHub what the map has…")
        head = repo.head(create=True)
        base_tree, remote = repo.tree_of(head)
        synced = state.setdefault("synced", {})
        if not force:
            locks, _ = repo.locks()
            taken = locks.get(main)
            if taken and taken.get("user") != me:
                raise Conflict({"kind": "taken", "file": main, "who": taken.get("user", "someone"), "since": taken.get("since", 0)})
            # A newer .blend someone else sent after you took (or sent) yours.
            newer = [rel for rel in new if rel.endswith(".blend") and rel in remote
                     and remote[rel] != synced.get(rel) and remote[rel] != git_sha(new[rel])]
            if newer:
                raise Conflict({"kind": "newer", "file": newer[0], "who": repo.last_author(newer[0])})

        changes = {rel: data for rel, data in new.items() if remote.get(rel) != git_sha(data)}
        for rel, data in new.items():
            synced[rel] = git_sha(data)
        if not changes:
            write_state(folder, state)
            return f"Nothing new: GitHub already has this version ({len(new)} files)", f"https://github.com/{repo.full}"
        commit = repo.commit(head, base_tree, changes, message)
        state["branch"] = repo.branch
        write_state(folder, state)
        _refresh_info(repo)
        return (f"Sent {len(changes)} file(s)" + (f", {len(new) - len(changes)} unchanged" if len(new) > len(changes) else ""),
                f"https://github.com/{repo.full}/commit/{commit}")


def _take(repo, folder, files, synced, rewrite_all=False):
    """Writes the map's files from GitHub into the folder: {path: id} → what changed (the .blend copied to .backups first)."""
    got = []
    for i, (rel, sha) in enumerate(sorted(files.items()), 1):
        if rel == LOCKS:
            continue
        path = os.path.join(folder, *rel.split("/"))
        if os.path.isfile(path) and file_sha(path) == sha:
            synced[rel] = sha
            continue
        if not rewrite_all and os.path.isfile(path) and synced.get(rel) == sha:
            continue  # GitHub has not changed it since you took or sent it: yours is newer
        _stage(f"Getting {rel} ({i} of {len(files)})…")
        data = repo.blob(sha)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        if rel.endswith(".blend") and os.path.isfile(path):
            _backup(path)
        with open(path + ".part", "wb") as f:
            f.write(data)
        os.replace(path + ".part", path)
        synced[rel] = sha
        got.append(rel)
    return got


def _main_of(folder, files):
    try:
        with open(os.path.join(folder, *PROJECT.split("/")), encoding="utf-8") as f:
            main = json.load(f).get("main")
        if main:
            return main
    except (OSError, ValueError):
        pass
    blends = sorted(rel for rel in files if rel.endswith(".blend") and "/" not in rel)
    return blends[0] if blends else ""


def job_get(token, blend, commit=None):
    """Get (what changed on GitHub), or bring back the version of a commit (commit given)."""
    folder = os.path.dirname(blend)
    state = read_state(blend)
    repo = _repo_of(state, token)
    synced = state.setdefault("synced", {})
    _stage("Asking GitHub what changed…")
    head = repo.head()
    _, remote = repo.tree_of(head)
    if commit:
        _, old = repo.tree_of(commit)
        got = _take(repo, folder, old, {}, rewrite_all=True)
        for rel, sha in remote.items():  # Send after this makes it the newest, without a «newer» stop
            synced[rel] = sha
    else:
        got = _take(repo, folder, remote, synced)
    state["branch"] = repo.branch
    write_state(folder, state)
    _refresh_info(repo)
    main = os.path.basename(blend)
    if main in got:
        _main.append(lambda: _reopen(blend))
    if commit:
        return f"Brought back {commit[:7]} ({len(got)} file(s)): Send makes it the newest", ""
    return (f"Got {len(got)} file(s)" if got else "Up to date: nothing new on GitHub"), ""


def job_open(token, full, parent, folder_in_repo):
    """Open a map from GitHub: its files into <parent>/<repository's name>, then its .blend opens."""
    repo = Repo(token, full, "", folder_in_repo)
    _stage("Asking GitHub what the map has…")
    head = repo.head()
    _, remote = repo.tree_of(head)
    target = os.path.join(parent, full.split("/")[1] + (("_" + repo.prefix.strip("/").replace("/", "_")) if repo.prefix else ""))
    os.makedirs(target, exist_ok=True)
    state = {"repo": full, "branch": repo.branch, "folder": repo.prefix.strip("/"), "synced": {}}
    _take(repo, target, remote, state["synced"])
    write_state(target, state)
    main = _main_of(target, remote)
    if not main:
        return f"{full} has no .blend yet (in this folder): the owner Sends it first", ""
    blend = os.path.join(target, main)
    _main.append(lambda: _reopen(blend))
    if os.path.isfile(os.path.join(target, ".psmap-team", "parts.json")):
        from . import partsync
        _main.append(lambda: partsync.after_open(blend))
    _refresh_info(repo)
    return f"Opened {main} from {full}", ""


def job_lock(token, me, blend, take):
    repo = _repo_of(read_state(blend), token)
    _stage("Telling the others…")
    _cache["locks"] = repo.set_lock(os.path.basename(blend), me, take)
    return ("You are editing it: others see it taken" if take else "Freed: others can send it"), ""


def job_invite(token, blend, user):
    repo = _repo_of(read_state(blend), token)
    _stage(f"Inviting {user}…")
    repo.call("PUT", f"/collaborators/{q(user)}", {"permission": "push"})
    return (f"Invited {user}: they accept on GitHub (e-mail or github.com/notifications), sign in here, "
            f"then Open map from GitHub"), f"https://github.com/{repo.full}/settings/access"


_wizard = {"step": "", "name": "", "full": "", "page": "", "hint": "", "cancel": False}


def repo_name(text):
    """A repository's name as GitHub makes it (letters, digits, . _ -)."""
    return re.sub(r"[^A-Za-z0-9._-]+", "-", text.strip()).strip("-") or "map"


def job_share(token, login, blend, name, parts_spec=None):
    """«Put this map on GitHub»: wait (checking every few seconds) until GitHub lets the map tools into the new
    repository — made on GitHub's page, the app let in — then connect the map and send it."""
    full = f"{login}/{name}"
    _wizard.update(full=full, hint="")
    until = time.time() + 3600
    while True:
        if _wizard["cancel"]:
            _wizard["step"] = ""
            return "Stopped: press «Put this map on GitHub» to start again", ""
        if time.time() > until:
            _wizard["step"] = ""
            raise GitHubError(0, "Stopped waiting after an hour: press «Put this map on GitHub» again")
        try:
            info = _call(token, "GET", f"/repos/{full}")
            break
        except GitHubError as e:
            if e.args[0] not in (403, 404):
                raise
        if _wizard["step"] == "made":  # «I've made it»: now let the app in, unless it is in all the repositories
            mine = [i for i in _call(token, "GET", "/user/installations?per_page=100").get("installations", [])
                    if i["account"]["login"].lower() == login.lower()]
            if mine and mine[0].get("repository_selection") == "all":
                _wizard["step"] = "create"
                _wizard["hint"] = f"GitHub has no {name} yet: press «Create repository» there (keep the name)"
            else:
                _wizard["page"] = (f"https://github.com/settings/installations/{mine[0]['id']}" if mine
                                   else APP_PAGE + "/installations/new")
                _wizard["step"] = "install"
                page = _wizard["page"]
                _main.append(lambda: bpy.ops.wm.url_open(url=page))
        _stage("Waiting for GitHub (it checks by itself)…")
        time.sleep(3)
    _wizard["step"] = "sending"
    write_state(os.path.dirname(blend), {"repo": full, "branch": info.get("default_branch") or "", "folder": "", "synced": {}})
    if parts_spec is not None:  # a map in parts: sent by parts
        from . import partsync
        said, url = partsync.job_send(token, login, blend, "The map's first version", False, *parts_spec)
    else:
        said, url = job_send(token, login, blend, "The map's first version", False)
    _wizard["step"] = "done"
    return said, url


def job_sign_in():
    _stage("Asking GitHub for a code…")
    got = _request("https://github.com/login/device/code", "POST", {"client_id": CLIENT_ID}, form=True,
                   headers={"Accept": "application/json"})
    if "device_code" not in got:
        raise GitHubError(0, "GitHub gave no code: " + str(got.get("error_description") or got.get("error") or got))
    code, url = got["user_code"], got.get("verification_uri", "https://github.com/login/device")
    _cache["code"], _cache["code_url"] = code, f"{url}?user_code={q(code)}"  # filled in unless GitHub asks for the account first

    def show():
        bpy.context.window_manager.clipboard = code
        bpy.ops.wm.url_open(url=_cache["code_url"])
        window = bpy.context.window_manager.windows[0]
        window.cursor_warp(window.width // 2, window.height // 2 + 80)  # Blender puts a popup at the mouse
        with bpy.context.temp_override(window=window, screen=window.screen):
            bpy.ops.psmap.gh_code("INVOKE_DEFAULT")
    _main.append(show)
    _stage("Waiting for GitHub: type the code on the page that opened")
    interval, until = int(got.get("interval", 5)), time.time() + int(got.get("expires_in", 900))
    while time.time() < until:
        time.sleep(interval)
        r = _request("https://github.com/login/oauth/access_token", "POST", {
            "client_id": CLIENT_ID, "device_code": got["device_code"],
            "grant_type": "urn:ietf:params:oauth:grant-type:device_code"}, form=True, headers={"Accept": "application/json"})
        if r.get("access_token"):
            token = r["access_token"]
            login = _call(token, "GET", "/user")["login"]
            _write_account(token, login)
            _cache["code"] = ""
            _refresh_repos(token)
            return f"Signed in as {login}", ""
        error = r.get("error")
        if error == "slow_down":
            interval += 5
        elif error != "authorization_pending":
            _cache["code"] = ""
            raise GitHubError(0, {"access_denied": "Sign-in cancelled on GitHub",
                                  "expired_token": "The code ran out: Sign in again"}.get(error, str(r.get("error_description") or error)))
    _cache["code"] = ""
    raise GitHubError(0, "The code ran out: Sign in again")


def _refresh_repos(token):
    repos = []
    for inst in _call(token, "GET", "/user/installations?per_page=100").get("installations", []):
        page = 1
        while True:
            got = _call(token, "GET", f"/user/installations/{inst['id']}/repositories?per_page=100&page={page}")
            repos += [r["full_name"] for r in got.get("repositories", [])]
            if len(got.get("repositories", [])) < 100:
                break
            page += 1
    _cache["repos"] = sorted(set(repos), key=str.lower)


def _refresh_info(repo):
    try:
        _cache["locks"], _ = repo.locks()
        _cache["history"] = repo.history()
        _cache["for"] = repo.full
    except GitHubError:
        pass


def job_refresh(token, blend):
    _stage("Asking GitHub…")
    _refresh_repos(token)
    state = read_state(blend) if blend else None
    if state:
        _refresh_info(_repo_of(state, token))
    return "", ""


def _run(fn, args, repo=""):
    try:
        _job["result"], _job["url"] = fn(*args)
        _job["error"] = False
    except Conflict as c:
        _job["conflict"], _job["result"], _job["error"], _job["url"] = c.args[0], "", True, ""
        if c.args[0].get("kind") == "parts":
            from . import partsync
            _main.append(partsync.ask_whose)
    except GitHubError as e:
        _job["result"], _job["error"], _job["url"] = _explain(e, repo), True, ""
    except Exception as e:  # anything else still ends the job, said in the panel
        _job["result"], _job["error"], _job["url"] = f"Failed: {e}", True, ""
    _job["stage"] = ""


def start(fn, *args, repo=""):
    _job.update(stage="Starting…", result="", error=False, url="", conflict=None)
    _job["thread"] = threading.Thread(target=_run, args=(fn, args, repo), daemon=True)
    _job["thread"].start()
    if not bpy.app.timers.is_registered(_watch):
        bpy.app.timers.register(_watch, first_interval=0.3)


def running():
    return _job["thread"] is not None


def _reopen(blend):
    window = bpy.context.window_manager.windows[0]
    with bpy.context.temp_override(window=window):
        bpy.ops.wm.open_mainfile(filepath=blend)  # the load handler fixes the pictures' paths


def fix_texture_paths():
    """A .blend sent from Windows may keep its pictures as //textures\\x.png: on a Mac that finds nothing."""
    for img in bpy.data.images:
        if not img.library and img.filepath.startswith("//") and "\\" in img.filepath and os.sep == "/":
            img.filepath = img.filepath.replace("\\", "/")
            img.reload()


def _redraw():
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                area.tag_redraw()


def _watch():
    while _main:
        try:
            _main.pop(0)()
        except Exception as e:
            _job["result"], _job["error"] = f"Failed: {e}", True
    _redraw()
    if _job["thread"] is not None and _job["thread"].is_alive():
        return 0.3
    _job["thread"] = None
    if _main:
        return 0.1
    return None


# ---------- operators ----------
def _ready(op, need_map=True):
    """The sign-in (and the map's repository) or a report why not."""
    if not bpy.app.online_access:
        op.report({"ERROR"}, "Blender is offline: Edit → Preferences → System → Network → Allow Online Access")
        return None
    acc = account()
    if not acc["token"]:
        op.report({"ERROR"}, "Sign in with GitHub first")
        return None
    if need_map and not (bpy.data.filepath and read_state(bpy.data.filepath)):
        op.report({"ERROR"}, "Connect the map to a repository first")
        return None
    return acc


def _save():
    if bpy.data.filepath and bpy.data.is_dirty:
        bpy.ops.wm.save_mainfile()


def _fresh_repos():
    """The repositories' list asked again (an invitation just accepted, a repository just made)."""
    token = account()["token"]
    if token and bpy.app.online_access:
        try:
            _refresh_repos(token)
        except GitHubError:
            pass


def repo_items(self, context):
    _repo_items[:] = [(r, r, "") for r in _cache["repos"]] or [("NONE", "(none: Install the app on a repository)", "")]
    return _repo_items


PASTE = "Cmd+V" if sys.platform == "darwin" else "Ctrl+V"


def say(layout, lines, icon="INFO"):
    """A few short lines: what happens next and what to press."""
    col = layout.column(align=True)
    for i, line in enumerate(lines):
        col.label(text=line, icon=icon if i == 0 else "BLANK1")


class MAP_OT_gh_sign_in(bpy.types.Operator):
    bl_idname = "psmap.gh_sign_in"
    bl_label = "Sign in with GitHub"
    bl_description = "Shows a code and opens github.com/login/device: type the code there and Authorize the map tools"

    @classmethod
    def poll(cls, context):
        return not running()

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=440, title="Sign in with GitHub",
                                                          confirm_text="Open GitHub")

    def draw(self, context):
        say(self.layout, [
            "GitHub opens in your browser. There:",
            "1. If it asks which account: pick yours, press Continue.",
            "2. The code is filled in (if not, paste it: " + PASTE + "): press Continue.",
            "3. The first time only: press Authorize.",
            "Then come back here: you are signed in.",
        ])

    def execute(self, context):
        if not bpy.app.online_access:
            self.report({"ERROR"}, "Blender is offline: Edit → Preferences → System → Network → Allow Online Access")
            return {"CANCELLED"}
        start(job_sign_in)
        return {"FINISHED"}


def draw_code(layout):
    """The sign-in code, big, and what to do with it."""
    box = layout.box()
    row = box.row()
    row.scale_y = 2.0
    row.alignment = "CENTER"
    row.label(text=_cache["code"])
    col = box.column(align=True)
    col.label(text="On the GitHub page that opened: pick your account, Continue.", icon="INFO")
    col.label(text=f"No code in the boxes? It is copied: paste it ({PASTE}), Continue.", icon="BLANK1")
    col.label(text="The first time: Authorize. Then you are signed in here.", icon="BLANK1")
    row = box.row(align=True)
    row.operator("psmap.gh_code_again", text="Copy again", icon="COPYDOWN").open = False
    row.operator("psmap.gh_code_again", text="Open the page again", icon="URL").open = True


class MAP_OT_gh_code(bpy.types.Operator):
    bl_idname = "psmap.gh_code"
    bl_label = "Sign in with GitHub"
    bl_options = {"INTERNAL"}

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=380)

    def draw(self, context):
        self.layout.label(text="Sign in with GitHub", icon="URL")
        draw_code(self.layout)

    def execute(self, context):
        return {"FINISHED"}


class MAP_OT_gh_code_again(bpy.types.Operator):
    bl_idname = "psmap.gh_code_again"
    bl_label = "The code again"
    bl_description = "Copy the sign-in code again (or open GitHub's page for it again)"
    bl_options = {"INTERNAL"}
    open: bpy.props.BoolProperty()

    def execute(self, context):
        context.window_manager.clipboard = _cache["code"]
        if self.open:
            bpy.ops.wm.url_open(url=_cache.get("code_url") or "https://github.com/login/device")
        else:
            self.report({"INFO"}, f"Copied {_cache['code']}: paste it with {PASTE}")
        return {"FINISHED"}


class MAP_OT_gh_share(bpy.types.Operator):
    bl_idname = "psmap.gh_share"
    bl_label = "Put this map on GitHub"
    bl_description = ("Gives the map its own place on GitHub (a repository) and sends it there, step by step: then you "
                      "can invite friends to make it with you")
    name: bpy.props.StringProperty(name="Name on GitHub")
    private: bpy.props.BoolProperty(name="Private (only people you invite see it)", default=True)

    @classmethod
    def poll(cls, context):
        return not running()

    def invoke(self, context, event):
        if not bpy.data.filepath:
            self.report({"WARNING"}, "First choose where to keep the map on this computer, then press it again")
            bpy.ops.wm.save_as_mainfile("INVOKE_DEFAULT")
            return {"CANCELLED"}
        self.name = repo_name(os.path.splitext(os.path.basename(bpy.data.filepath))[0])
        return context.window_manager.invoke_props_dialog(self, width=460, title="Put this map on GitHub",
                                                          confirm_text="Open GitHub")

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "name")
        layout.prop(self, "private")
        say(layout, [
            "What happens:",
            "1. GitHub opens a page for the map's new place, the name filled in.",
            "    Press the green «Create repository» there. Change nothing.",
            "2. The first time only: GitHub asks to let the map tools in.",
            "    Pick this repository (or All repositories), press «Install».",
            "Then the map is sent by itself. Come back here.",
        ])

    def execute(self, context):
        acc = _ready(self, need_map=False)
        if not acc:
            return {"CANCELLED"}
        _save()
        name = repo_name(self.name)
        _wizard.update(step="create", name=name, full="", hint="", cancel=False,
                       page=f"https://github.com/new?name={q(name)}&visibility={'private' if self.private else 'public'}")
        bpy.ops.wm.url_open(url=_wizard["page"])
        from . import parts, partsync
        spec = partsync.local_spec(context.scene) if parts.is_split(context.scene) else None
        start(job_share, acc["token"], acc["login"], bpy.data.filepath, name, spec)
        return {"FINISHED"}


class MAP_OT_gh_wizard(bpy.types.Operator):
    bl_idname = "psmap.gh_wizard"
    bl_label = "Put on GitHub"
    bl_options = {"INTERNAL"}
    action: bpy.props.EnumProperty(items=[("made", "I've made it", ""), ("page", "Open the page again", ""),
                                          ("cancel", "Cancel", ""), ("ok", "OK", "")])

    @classmethod
    def description(cls, context, props):
        return {"made": "You pressed «Create repository» on GitHub: next, let the map tools in",
                "page": "Opens the GitHub page of this step again", "cancel": "Stop putting the map on GitHub",
                "ok": "Close this"}[props.action]

    def execute(self, context):
        if self.action == "made":
            _wizard["step"], _wizard["hint"] = "made", ""
        elif self.action == "page":
            bpy.ops.wm.url_open(url=_wizard["page"])
        elif self.action == "cancel":
            _wizard["cancel"] = True
            if not running():
                _wizard["step"] = ""
        else:
            _wizard["step"] = ""
            _job["result"] = ""
        return {"FINISHED"}


def draw_wizard(layout):
    """The guide while the map goes onto GitHub: the step, what to press, what the add-on does by itself."""
    step, name = _wizard["step"], _wizard["name"]
    box = layout.box()
    if step in ("create", "made"):
        box.label(text="Step 1 of 2: make the map's place on GitHub", icon="ADD")
        say(box, ["On the GitHub page that opened:",
                  "press the green «Create repository» button.",
                  f"Keep the name {name}. Then press the button below."])
        row = box.row()
        row.scale_y = 1.4
        row.enabled = step == "create"
        row.operator("psmap.gh_wizard", text="I've pressed «Create repository»", icon="CHECKMARK").action = "made"
    elif step == "install":
        box.label(text="Step 2 of 2: let the map tools in (once)", icon="PLUGIN")
        say(box, ["On the GitHub page that opened:",
                  "pick your account if asked, then «Only select repositories»,",
                  f"choose {name} in the list and press «Install» (or «Save»).",
                  "The add-on sees it by itself and sends the map."])
    elif step == "sending":
        box.label(text="Sending the map…", icon="EXPORT")
    elif step == "done":
        box.label(text="Done! The map is on GitHub", icon="CHECKMARK")
        say(box, ["Now invite friends to make it with you:",
                  "they get an e-mail, then press «Open a map from GitHub»."])
        row = box.row(align=True)
        row.scale_y = 1.3
        row.operator("psmap.gh_invite", icon="COMMUNITY")
        row.operator("psmap.gh_wizard", text="OK").action = "ok"
        return
    if _wizard["hint"]:
        box.label(text=_wizard["hint"], icon="ERROR")
    if step != "sending":
        row = box.row(align=True)
        row.operator("psmap.gh_wizard", text="Open the page again", icon="URL").action = "page"
        row.operator("psmap.gh_wizard", text="Cancel", icon="X").action = "cancel"
    if _job["stage"]:
        box.label(text=_job["stage"], icon="SORTTIME")


class MAP_OT_gh_sign_out(bpy.types.Operator):
    bl_idname = "psmap.gh_sign_out"
    bl_label = "Sign out"
    bl_description = "Forget the GitHub sign-in on this computer"

    def execute(self, context):
        _write_account("", "")
        _cache.update(repos=[], locks={}, history=[], **{"for": ""})
        return {"FINISHED"}


class MAP_OT_gh_install(bpy.types.Operator):
    bl_idname = "psmap.gh_install"
    bl_label = "Install the app on a repository"
    bl_description = ("The repository's owner, once: lets the map tools into the repositories you pick "
                      "(those you are invited to need nothing)")

    def execute(self, context):
        bpy.ops.wm.url_open(url=APP_PAGE + "/installations/new")
        return {"FINISHED"}


class MAP_OT_gh_refresh(bpy.types.Operator):
    bl_idname = "psmap.gh_refresh"
    bl_label = "Refresh"
    bl_description = "Ask GitHub again: your repositories, who edits what, the history"

    @classmethod
    def poll(cls, context):
        return not running()

    def execute(self, context):
        acc = _ready(self, need_map=False)
        if not acc:
            return {"CANCELLED"}
        start(job_refresh, acc["token"], bpy.data.filepath)
        return {"FINISHED"}


class MAP_OT_gh_connect(bpy.types.Operator):
    bl_idname = "psmap.gh_connect"
    bl_label = "Connect to a repository"
    bl_description = "This map goes into (and comes from) one of your repositories"
    repo: bpy.props.EnumProperty(name="Repository", items=repo_items)
    folder: bpy.props.StringProperty(name="Folder", description="The map's folder in the repository. Empty: the top")

    @classmethod
    def poll(cls, context):
        return bool(bpy.data.filepath) and not running()

    def invoke(self, context, event):
        _fresh_repos()
        return context.window_manager.invoke_props_dialog(self, width=400)

    def draw(self, context):
        self.layout.prop(self, "repo")
        self.layout.prop(self, "folder")
        if not _cache["repos"]:
            self.layout.label(text="None yet: make one (Create) and Install the app on it", icon="INFO")
        self.layout.operator("psmap.gh_install", text="Not in the list? Install the app on it", icon="PLUGIN")

    def execute(self, context):
        if not _ready(self, need_map=False) or self.repo in ("", "NONE"):
            return {"CANCELLED"}
        write_state(os.path.dirname(bpy.data.filepath),
                    {"repo": self.repo, "branch": "", "folder": self.folder.strip().strip("/"), "synced": {}})
        self.report({"INFO"}, f"Connected to {self.repo}: Get takes what is there, Send puts this map there")
        bpy.ops.psmap.gh_refresh()
        return {"FINISHED"}


class MAP_OT_gh_disconnect(bpy.types.Operator):
    bl_idname = "psmap.gh_disconnect"
    bl_label = "Disconnect"
    bl_description = "This map no longer goes to its repository (nothing is deleted there)"

    def execute(self, context):
        path = state_path(bpy.data.filepath)
        if os.path.exists(path):
            os.remove(path)
        return {"FINISHED"}


class MAP_OT_gh_open(bpy.types.Operator):
    bl_idname = "psmap.gh_open"
    bl_label = "Open a map from GitHub"
    bl_description = "Takes a map's files from a repository into a folder of its own and opens its .blend"
    repo: bpy.props.EnumProperty(name="Repository", items=repo_items)
    folder: bpy.props.StringProperty(name="Folder in it", description="The map's folder in the repository. Empty: the top")
    directory: bpy.props.StringProperty(name="Into", subtype="DIR_PATH",
                                        description="Where on this computer (the map gets a folder of its own inside)")

    @classmethod
    def poll(cls, context):
        return not running()

    def invoke(self, context, event):
        if not self.directory:
            self.directory = os.path.expanduser("~/Documents")
        _fresh_repos()
        return context.window_manager.invoke_props_dialog(self, width=460, title="Open a map from GitHub",
                                                          confirm_text="Open the map")

    def draw(self, context):
        layout = self.layout
        say(layout, ["Someone invited you to their map?",
                     "Accept the invitation first: in the GitHub e-mail,",
                     "or on github.com: the bell (Notifications) → Accept.",
                     "Then pick the map below: it is copied here and opens."])
        layout.prop(self, "repo")
        layout.prop(self, "directory")
        if not _cache["repos"]:
            layout.label(text="No maps yet: accept the invitation, then open this again", icon="ERROR")
        layout.prop(self, "folder")

    def execute(self, context):
        acc = _ready(self, need_map=False)
        if not acc or self.repo in ("", "NONE"):
            return {"CANCELLED"}
        if bpy.data.is_dirty and bpy.data.filepath:
            bpy.ops.wm.save_mainfile()
        start(job_open, acc["token"], self.repo, bpy.path.abspath(self.directory), self.folder, repo=self.repo)
        return {"FINISHED"}


class MAP_OT_gh_send(bpy.types.Operator):
    bl_idname = "psmap.gh_send"
    bl_label = "Send"
    bl_description = ("Saves the .blend and sends the map (the .blend, its pictures, the .psmap files, the export log) as "
                      "one commit; stops if someone else sent a newer .blend or is editing it")
    force: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        return bool(bpy.data.filepath) and not running()

    def execute(self, context):
        acc = _ready(self)
        if not acc:
            return {"CANCELLED"}
        _save()
        wm = context.window_manager
        stem = os.path.splitext(os.path.basename(bpy.data.filepath))[0]
        message = wm.ps_github_message.strip() or f"{stem}: {time.strftime('%Y-%m-%d %H:%M')}"
        wm.ps_github_message = ""
        from . import parts, partsync
        if parts.is_split(context.scene):
            spec, values = partsync.local_spec(context.scene)
            start(partsync.job_send, acc["token"], acc["login"], bpy.data.filepath, message, self.force, spec, values,
                  repo=read_state(bpy.data.filepath)["repo"])
            return {"FINISHED"}
        start(job_send, acc["token"], acc["login"], bpy.data.filepath, message, self.force,
              repo=read_state(bpy.data.filepath)["repo"])
        return {"FINISHED"}


class MAP_OT_gh_get(bpy.types.Operator):
    bl_idname = "psmap.gh_get"
    bl_label = "Get"
    bl_description = "Takes what changed on GitHub; your .blend is copied to .backups/ before it is replaced"
    commit: bpy.props.StringProperty(options={"SKIP_SAVE"})
    theirs: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})

    @classmethod
    def poll(cls, context):
        return bool(bpy.data.filepath) and not running()

    def execute(self, context):
        acc = _ready(self)
        if not acc:
            return {"CANCELLED"}
        _save()
        from . import parts, partsync
        if parts.is_split(context.scene):
            if self.commit:
                self.report({"WARNING"}, "Bringing back an old version is not there yet for a map in parts")
                return {"CANCELLED"}
            spec, values = partsync.local_spec(context.scene)
            force = tuple((_job["conflict"] or {}).get("parts", ())) if self.theirs else ()
            start(partsync.job_get, acc["token"], bpy.data.filepath, spec, values, force,
                  repo=read_state(bpy.data.filepath)["repo"])
            return {"FINISHED"}
        start(job_get, acc["token"], bpy.data.filepath, self.commit or None, repo=read_state(bpy.data.filepath)["repo"])
        return {"FINISHED"}


class MAP_OT_gh_lock(bpy.types.Operator):
    bl_idname = "psmap.gh_lock"
    bl_label = "Editing"
    bl_description = "I'm editing it: others see the .blend taken and cannot send it. Done: free it"
    take: bpy.props.BoolProperty(default=True)

    @classmethod
    def poll(cls, context):
        return bool(bpy.data.filepath) and not running()

    def execute(self, context):
        acc = _ready(self)
        if not acc:
            return {"CANCELLED"}
        start(job_lock, acc["token"], acc["login"], bpy.data.filepath, self.take, repo=read_state(bpy.data.filepath)["repo"])
        return {"FINISHED"}


class MAP_OT_gh_invite(bpy.types.Operator):
    bl_idname = "psmap.gh_invite"
    bl_label = "Invite"
    bl_description = "Bring a person into the map: they get an invitation on GitHub, then can Get and Send"
    user: bpy.props.StringProperty(name="GitHub name")

    @classmethod
    def poll(cls, context):
        return bool(bpy.data.filepath) and not running()

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=440, title="Invite a friend to the map",
                                                          confirm_text="Invite")

    def draw(self, context):
        self.layout.prop(self, "user")
        say(self.layout, ["Their name on GitHub (as on their profile page).",
                          "They get an e-mail from GitHub: Accept the invitation,",
                          "then in Blender: the GitHub tab → «Open a map from GitHub»."])

    def execute(self, context):
        acc = _ready(self)
        user = self.user.strip().lstrip("@")
        if not acc or not user:
            return {"CANCELLED"}
        start(job_invite, acc["token"], bpy.data.filepath, user, repo=read_state(bpy.data.filepath)["repo"])
        return {"FINISHED"}


# ---------- the GitHub tab: Account, Map, History ----------
def _since(seconds):
    return time.strftime("%d.%m %H:%M", time.localtime(seconds)) if seconds else ""


def _status(layout):
    if _job["stage"]:
        layout.label(text=_job["stage"], icon="SORTTIME")
    elif _job["result"]:
        row = layout.row(align=True)
        row.label(text=_job["result"], icon="ERROR" if _job["error"] else "CHECKMARK")
        if _job["url"]:
            row.operator("wm.url_open", text="", icon="URL").url = _job["url"]


class GitHubTab:
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "GitHub"


class MAP_PT_github_account(GitHubTab, bpy.types.Panel):
    bl_label = "Account"

    def draw(self, context):
        layout = self.layout
        acc = account()
        busy = running()
        if not bpy.app.online_access:
            layout.label(text="Blender is offline: Preferences → System → Allow Online Access", icon="ERROR")
        if not acc["token"]:
            if busy and _cache["code"]:
                draw_code(layout)
            else:
                say(layout, ["Make maps together with friends:",
                             "put your map on GitHub, invite them,",
                             "everyone gets and sends the newest version."])
                row = layout.row()
                row.scale_y = 1.3
                row.enabled = not busy
                row.operator("psmap.gh_sign_in", icon="URL")
            _status(layout)
            return
        row = layout.row(align=True)
        row.label(text="Signed in as " + acc["login"], icon="USER")
        row.operator("psmap.gh_refresh", text="", icon="FILE_REFRESH")
        row.operator("psmap.gh_sign_out", text="", icon="X")
        layout.operator("psmap.gh_install", icon="PLUGIN")


class MAP_PT_github_map(GitHubTab, bpy.types.Panel):
    bl_label = "Map"

    @classmethod
    def poll(cls, context):
        return bool(account()["token"])

    def draw(self, context):
        layout = self.layout
        acc = account()
        busy = running()
        if _wizard["step"]:
            draw_wizard(layout)
            if _job["result"] and _job["error"]:
                _status(layout)
            return
        state = read_state(bpy.data.filepath) if bpy.data.filepath else None
        if not state:
            layout.label(text="Your map:")
            row = layout.row()
            row.scale_y = 1.5
            row.enabled = not busy
            row.operator("psmap.gh_share", icon="EXPORT")
            layout.separator()
            layout.label(text="A friend's map (they invited you):")
            row = layout.row()
            row.scale_y = 1.3
            row.enabled = not busy
            row.operator("psmap.gh_open", icon="IMPORT")
            row = layout.row()
            row.enabled = not busy and bool(bpy.data.filepath)
            row.operator("psmap.gh_connect", text="Already on GitHub? Connect it", icon="LINKED", emboss=False)
            _status(layout)
            return

        row = layout.row(align=True)
        row.label(text=state["repo"] + (" / " + state["folder"] if state.get("folder") else ""), icon="LINKED")
        row.operator("wm.url_open", text="", icon="URL").url = f"https://github.com/{state['repo']}"
        row.operator("psmap.gh_disconnect", text="", icon="UNLINKED")

        from . import parts
        split = parts.is_split(context.scene)
        main = os.path.basename(bpy.data.filepath)
        taken = _cache["locks"].get(main) if _cache["for"] == state["repo"] else None
        box = layout.box() if not split else layout.column()
        row = box.row(align=True)
        row.enabled = not busy
        if split:
            row.label(text="In parts: Send and Get take only the parts that changed", icon="OUTLINER_COLLECTION")
        elif taken and taken.get("user") == acc["login"]:
            row.label(text="You are editing it", icon="GREASEPENCIL")
            row.operator("psmap.gh_lock", text="Done").take = False
        elif taken:
            row.label(text=f"{taken.get('user')} is editing it since {_since(taken.get('since'))}", icon="LOCKED")
        else:
            row.label(text="Nobody is editing it", icon="UNLOCKED")
            row.operator("psmap.gh_lock", text="I'm editing it").take = True

        layout.prop(context.window_manager, "ps_github_message", text="", placeholder="What changed (optional)")
        row = layout.row(align=True)
        row.scale_y = 1.4
        row.enabled = not busy
        row.operator("psmap.gh_get", icon="IMPORT")
        row.operator("psmap.gh_send", icon="EXPORT")
        row = layout.row()
        row.enabled = not busy
        row.operator("psmap.gh_invite", icon="COMMUNITY")

        conflict = _job["conflict"]
        if conflict and not busy:
            box = layout.box()
            if conflict["kind"] == "editing":
                box.label(text=f"{conflict['who']} is editing {', '.join(conflict['parts'])} now", icon="LOCKED")
                box.label(text="Send yours anyway? Then they choose whose version stays.", icon="BLANK1")
            elif conflict["kind"] == "parts":
                box.label(text="Changed here and there too" + (f" (by {conflict['who']})" if conflict["who"] else "") + ":",
                          icon="ERROR")
                box.label(text=", ".join(conflict["parts"]), icon="BLANK1")
                row = box.row()
                row.scale_y = 1.3
                row.operator("psmap.parts_whose", text="Choose whose version stays…", icon="QUESTION")
            elif conflict["kind"] == "newer":
                box.label(text=f"{conflict['who']} sent a newer {conflict['file']} after you took yours", icon="ERROR")
                box.operator("psmap.gh_get", text="Get theirs (yours goes to .backups)", icon="IMPORT")
            else:
                box.label(text=f"{conflict['who']} is editing {conflict['file']} since {_since(conflict.get('since'))}",
                          icon="LOCKED")
            box.operator("psmap.gh_send", text="Send mine anyway", icon="ERROR").force = True
        _status(layout)


class MAP_PT_github_parts(GitHubTab, bpy.types.Panel):
    bl_label = "Parts"

    def draw(self, context):
        from . import parts
        parts.draw_parts(self.layout, context)


class MAP_PT_github_history(GitHubTab, bpy.types.Panel):
    bl_label = "History"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return bool(account()["token"] and bpy.data.filepath and read_state(bpy.data.filepath))

    def draw(self, context):
        layout = self.layout
        state = read_state(bpy.data.filepath)
        if _cache["for"] != state["repo"] or not _cache["history"]:
            layout.operator("psmap.gh_refresh", text="Show the history", icon="FILE_REFRESH")
            return
        col = layout.column(align=True)
        col.enabled = not running()
        for c in _cache["history"]:
            row = col.row(align=True)
            row.label(text=f"{c['when'][5:16].replace('T', ' ')}  {c['who']}: {c['message']}")
            row.operator("psmap.gh_get", text="", icon="LOOP_BACK").commit = c["sha"]


CLASSES = [MAP_OT_gh_sign_in, MAP_OT_gh_code, MAP_OT_gh_code_again, MAP_OT_gh_sign_out, MAP_OT_gh_install, MAP_OT_gh_refresh, MAP_OT_gh_connect,
           MAP_OT_gh_disconnect, MAP_OT_gh_share, MAP_OT_gh_wizard, MAP_OT_gh_open, MAP_OT_gh_send, MAP_OT_gh_get, MAP_OT_gh_lock,
           MAP_OT_gh_invite, MAP_PT_github_account, MAP_PT_github_map, MAP_PT_github_parts, MAP_PT_github_history]


@bpy.app.handlers.persistent
def _on_load(_):
    if bpy.data.filepath and read_state(bpy.data.filepath):
        fix_texture_paths()


def register():
    from . import parts, editing, partsync
    parts.register()
    editing.register()
    for c in partsync.CLASSES:
        bpy.utils.register_class(c)
    for c in CLASSES:
        bpy.utils.register_class(c)
    if _on_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(_on_load)
    bpy.types.WindowManager.ps_github_message = bpy.props.StringProperty(
        name="Message", description="What changed (the commit's message). Empty: the map's name and the time")


def unregister():
    if _on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load)
    if bpy.app.timers.is_registered(_watch):
        bpy.app.timers.unregister(_watch)
    if hasattr(bpy.types.WindowManager, "ps_github_message"):
        del bpy.types.WindowManager.ps_github_message
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
    from . import parts, editing, partsync
    for c in reversed(partsync.CLASSES):
        bpy.utils.unregister_class(c)
    editing.unregister()
    parts.unregister()
