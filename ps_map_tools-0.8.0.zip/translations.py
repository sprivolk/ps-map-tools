"""The map tools in other languages: they follow Blender's own (Preferences → Interface → Translation → Language).

Each language is a file beside the add-on, <locale>.json (ru_RU.json): {English text: its translation}. The English text
is the key, as it is in the code. Blender itself translates what it draws from the code as it is (tab and panel names,
buttons, tooltips, settings); what the code puts together at run time (a count, a name inside a sentence) goes through
tr(): a key with {} in it is a pattern ("Cutter: cuts {} brush(es)"), its translation takes the pieces in that order
({}) or by number ({0}, {1}) when the language puts them the other way round."""
import json
import os
import re

import bpy

HERE = os.path.dirname(__file__)
_exact = {}      # locale -> {English: translation}
_patterns = {}   # locale -> [(regex, translation)], the longest English first


def _load():
    _exact.clear()
    _patterns.clear()
    for name in os.listdir(HERE):
        if not name.endswith(".json") or not re.fullmatch(r"[a-z]{2}(_[A-Z]{2})?\.json", name):
            continue
        locale = name[:-5]
        try:
            with open(os.path.join(HERE, name), encoding="utf-8") as f:
                table = {k: v for k, v in json.load(f).items() if isinstance(v, str) and v.strip()}
        except (OSError, ValueError) as e:
            print(f"Map tools: {name} not read: {e}")
            continue
        _exact[locale] = table
        pats = []
        for en, out in table.items():
            if "{}" not in en or not en.replace("{}", "").strip():
                continue
            rx = "^" + "(.+?)".join(re.escape(p) for p in en.split("{}")) + "$"
            pats.append((len(en.replace("{}", "")), re.compile(rx, re.S), out))
        pats.sort(key=lambda p: -p[0])
        _patterns[locale] = [(rx, out) for _, rx, out in pats]


def _locale(kind="interface"):
    view = bpy.context.preferences.view
    if not getattr(view, f"use_translate_{kind}", True):
        return None
    loc = bpy.app.translations.locale
    if loc in _exact:
        return loc
    short = loc.split("_")[0]
    return next((k for k in _exact if k.split("_")[0] == short), None)


def tr(text, kind="interface"):
    """The text in Blender's language (as it is when there is none for it). kind: interface, tooltips or reports."""
    if not isinstance(text, str) or not text:
        return text
    loc = _locale(kind)
    if loc is None:
        return text
    hit = _exact[loc].get(text)
    if hit is not None:
        return hit
    for rx, out in _patterns[loc]:
        m = rx.match(text)
        if m:
            # The pieces as they are (a name stays a name); a word that is to be translated is put in through tr() too.
            try:
                return out.format(*m.groups())
            except (IndexError, KeyError, ValueError):
                return text
    return text


CONTEXT = "ps_map_tools"


class own_context:
    """While the add-on registers: its panels, operators and menus translated in a context of their own, so Blender's
    own words (Build → «Сборка», Brushes → «Кисти») don't take the place of the add-on's."""

    def __enter__(self):
        self._register = bpy.utils.register_class

        def register_class(cls, _orig=self._register):
            if issubclass(cls, bpy.types.Panel) and "_ps_category" not in cls.__dict__ and getattr(cls, "bl_category", ""):
                cls._ps_category = cls.bl_category  # the English, for a later change of language
            if (issubclass(cls, (bpy.types.Panel, bpy.types.Operator, bpy.types.Menu))
                    and "bl_translation_context" not in cls.__dict__):
                cls.bl_translation_context = CONTEXT
            if issubclass(cls, bpy.types.Panel) and getattr(cls, "bl_category", ""):
                # A tab's name has no context of its own: put in Blender's language here (again on the next start).
                cls.bl_category = tr(cls.__dict__.get("_ps_category") or cls.bl_category)
            return _orig(cls)
        bpy.utils.register_class = register_class
        return self

    def __exit__(self, *exc):
        bpy.utils.register_class = self._register
        return False


def register():
    _load()
    tables = {}
    for loc, table in _exact.items():
        out = {}
        for en, tr_text in table.items():
            if "{}" in en:
                continue
            # "*": panels, labels, tooltips, settings; "Operator": the buttons' own names (bl_label).
            out[("*", en)] = tr_text
            out[("Operator", en)] = tr_text
            out[(CONTEXT, en)] = tr_text
        tables[loc] = out
    try:
        bpy.app.translations.unregister(__package__)
    except (ValueError, RuntimeError):
        pass
    bpy.app.translations.register(__package__, tables)


def unregister():
    try:
        bpy.app.translations.unregister(__package__)
    except (ValueError, RuntimeError):
        pass
