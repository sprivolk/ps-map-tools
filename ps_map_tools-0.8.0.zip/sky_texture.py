"""The map's sky made from Blender's own (a world with a Sky Texture node: Single / Multiple Scattering, Preetham,
Hosek-Wilkie), done once in Blender: the game gets the same kind of 360° picture as any other sky (nothing more to draw).

The world is rendered (Cycles, a panoramic camera: equirectangular, its middle the map's north, +Y) without the sun's
disc (the map's own sun lights the map), brought to the picture's range (its sky as bright as a picture's sky), and made
the map's sky; the map's sun turned where the Sky Texture's sun is. Asked again at a bake when the world changed since
(its fingerprint, scene key SKY_MARK)."""
import hashlib
import math
import os

import bpy
import numpy as np
from mathutils import Vector

SKY_MARK = "ps_sky_from_world"   # scene key: the fingerprint of the world the sky was made from
PREVIEW_WORLD = "PS sky (views)"  # sky.PREVIEW_WORLD: the add-on's own world showing the sky picture in the views
WIDE = 4096
LUMA = np.array([0.2126, 0.7152, 0.0722], np.float32)


def sky_world(scene):
    """(world, its Sky Texture node) the scene's sky comes from — its world, or the one the add-on's sky preview stood in
    for — or (None, None)."""
    world = scene.world
    if world is not None and world.name == PREVIEW_WORLD:
        world = bpy.data.worlds.get(str(scene.get("ps_world_before", "")))
    if world is None or world.node_tree is None:
        return None, None
    node = next((n for n in world.node_tree.nodes if n.type == "TEX_SKY"), None)
    return (world, node) if node is not None else (None, None)


def fingerprint(world, node):
    """What the sky is now: its node's settings and the world's strength."""
    keys = ("sky_type", "sun_disc", "sun_size", "sun_intensity", "sun_elevation", "sun_rotation", "altitude",
            "air_density", "aerosol_density", "ozone_density", "turbidity", "ground_albedo")
    parts = [getattr(node, k, None) for k in keys]
    parts.append(tuple(round(x, 4) for x in getattr(node, "sun_direction", ())))
    bg = next((n for n in world.node_tree.nodes if n.type == "BACKGROUND"), None)
    if bg is not None and not bg.inputs[1].is_linked:
        parts.append(round(bg.inputs[1].default_value, 4))
    parts = [round(p, 5) if isinstance(p, float) else p for p in parts]
    return hashlib.sha1(repr(parts).encode()).hexdigest()[:16]


def pending(scene):
    """Whether the scene has a Sky Texture world not made the map's sky yet (or changed since)."""
    world, node = sky_world(scene)
    return world is not None and scene.get(SKY_MARK) != fingerprint(world, node)


def render_world(world, wide, samples=4):
    """The world as a 360° picture (wide × wide/2, linear RGB, rows bottom first), its middle looking along +Y (the map's
    north), its right half east (+X): a scene of its own with only a panoramic camera in it."""
    sc = bpy.data.scenes.new("PS sky render")
    cam = None
    path = os.path.join(bpy.app.tempdir, "ps_sky_world.exr")
    try:
        sc.world = world
        sc.render.engine = "CYCLES"
        sc.cycles.samples = samples
        sc.cycles.use_denoising = False
        try:
            prefs = bpy.context.preferences.addons["cycles"].preferences
            if any(d.use and d.type != "CPU" for d in prefs.devices):
                sc.cycles.device = "GPU"
        except Exception:  # noqa: BLE001  (no card it can use: the processor)
            pass
        sc.render.resolution_x, sc.render.resolution_y, sc.render.resolution_percentage = wide, wide // 2, 100
        sc.render.image_settings.file_format = "OPEN_EXR"
        sc.render.image_settings.color_depth = "32"
        sc.render.filepath = path
        sc.render.use_compositing = False
        sc.view_settings.view_transform = "Standard"
        data = bpy.data.cameras.new("PS sky camera")
        data.type = "PANO"
        data.panorama_type = "EQUIRECTANGULAR"
        cam = bpy.data.objects.new("PS sky camera", data)
        sc.collection.objects.link(cam)
        cam.rotation_euler = (math.pi / 2, 0.0, 0.0)  # looking along +Y, up +Z
        sc.camera = cam
        bpy.ops.render.render(write_still=True, scene=sc.name)
        image = bpy.data.images.load(path, check_existing=False)
        w, h = image.size
        px = np.empty(w * h * 4, np.float32)
        image.pixels.foreach_get(px)
        bpy.data.images.remove(image)
        return px.reshape(h, w, 4)[..., :3].copy()
    finally:
        if cam is not None:
            data = cam.data
            bpy.data.objects.remove(cam, do_unlink=True)
            bpy.data.cameras.remove(data)
        bpy.data.scenes.remove(sc)


def direction_at(row, col, h, w):
    """The way a pixel of such a picture looks (Blender space): rows bottom first, its middle +Y, right +X."""
    el = ((row + 0.5) / h - 0.5) * math.pi
    az = ((col + 0.5) / w - 0.5) * 2.0 * math.pi
    return Vector((math.sin(az) * math.cos(el), math.cos(az) * math.cos(el), math.sin(el)))


def sun_toward(world, node):
    """The way to the Sky Texture's sun (Blender space), or None (below the horizon): Preetham and Hosek-Wilkie give it;
    the scattering ones by its elevation and its rotation (round from +Y toward +X: measured, a sun at 60° and 20° up
    rendered where this puts it)."""
    if node.sky_type in ("PREETHAM", "HOSEK_WILKIE"):
        d = Vector(node.sun_direction)
        d = d.normalized() if d.length > 1e-6 else None
    else:
        el, rot = float(node.sun_elevation), float(node.sun_rotation)
        d = Vector((math.sin(rot) * math.cos(el), math.cos(rot) * math.cos(el), math.sin(el)))
    return d if d is not None and d.z > -0.02 else None


def make_sky(scene, world, node, wide=WIDE):
    """The map's sky picture from the world (its sun's disc left out), its brightness brought to a picture's: returns
    (the Image, the way to its sun or None)."""
    from .sky import store
    toward = sun_toward(world, node)
    kept = getattr(node, "sun_disc", None)
    try:
        if kept is not None:
            node.sun_disc = False
        px = render_world(world, wide)
    finally:
        if kept is not None:
            node.sun_disc = kept
    image = store("Sky (from Blender)", to_picture(px))
    return image, toward


SKY_MIDDLE = 0.32  # linear: the sky's middle brightness in the picture (the add-on's painted skies' are about this)
WHITE = 2.5        # brighter than this (by the middle's scale) comes out white


def to_picture(px):
    """A world's light (linear, any brightness: a Sky Texture is thousands) brought to a picture's (0..1): its sky's
    middle (the median over the horizon) at SKY_MIDDLE, the brighter part (the sun's glow) eased in under white, colours
    kept (Reinhard on the brightness)."""
    h = px.shape[0]
    lum = px @ LUMA
    upper = lum[h // 2:]
    middle = float(np.median(upper)) if upper.size else 1.0
    px = px * (SKY_MIDDLE / max(middle, 1e-6))
    lum = px @ LUMA
    eased = lum * (1.0 + lum / (WHITE * WHITE)) / (1.0 + lum)
    out = px * (eased / np.maximum(lum, 1e-6))[..., None] * (1.0 + SKY_MIDDLE)  # (the middle kept where it was)
    return np.clip(out, 0.0, 1.0)


def turn_sun(scene, toward, collection):
    """The map's sun turned to shine from `toward` (one made when the map has none). Returns it."""
    sun = next((o for o in scene.objects if o.get("ps_entity") == "sun"), None)
    if sun is None:
        sun = bpy.data.objects.new("Sun", None)
        sun.empty_display_type = "SINGLE_ARROW"
        sun.empty_display_size = 4.0
        collection.objects.link(sun)
        sun["ps_entity"] = "sun"
        sun["ps_color"] = [1.0, 0.96, 0.88]
        sun["ps_brightness"] = 1.0
        sun.id_properties_ui("ps_color").update(subtype="COLOR", min=0.0, max=1.0, soft_min=0.0, soft_max=1.0)
        sun.location = Vector((0.0, 0.0, 20.0))
    sun["ps_arrow"] = 1  # its +Z: where the light goes
    sun.rotation_mode = "XYZ"
    sun.rotation_euler = (-toward).to_track_quat("Z", "Y").to_euler()
    return sun


def apply(scene, collection):
    """The scene's Sky Texture made the map's sky, its sun the map's sun's way. Returns a line saying what was done, or
    None (no Sky Texture world)."""
    world, node = sky_world(scene)
    if world is None:
        return None
    image, toward = make_sky(scene, world, node)
    scene.ps_sky_image = image
    scene.ps_sky_rotation = 0.0
    scene.ps_sky_own_sun = False
    scene[SKY_MARK] = fingerprint(world, node)
    if toward is None:
        return f"Sky made from {world.name}'s Sky Texture (its sun below the horizon: the map's sun left as it is)"
    turn_sun(scene, toward, collection)
    up = math.degrees(math.asin(max(-1.0, min(1.0, toward.z))))
    return f"Sky made from {world.name}'s Sky Texture; the map's sun turned to it ({up:.0f}° up)"


class MAP_OT_sky_from_world(bpy.types.Operator):
    bl_idname = "psmap.sky_from_world"
    bl_label = "From Blender's sky"
    bl_description = ("The map's sky made from the world's Sky Texture node (rendered once into a 360° picture, without "
                      "the sun's disc), and the map's sun turned where its sun is. The game draws it as any sky picture")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return sky_world(context.scene)[0] is not None

    def execute(self, context):
        from . import child_collection
        from .translations import tr
        said = apply(context.scene, child_collection(context.scene, "Entities"))
        if said is None:
            self.report({"WARNING"}, tr("No world with a Sky Texture node", "reports"))
            return {"CANCELLED"}
        self.report({"INFO"}, tr(said, "reports"))
        return {"FINISHED"}
