"""Doors (CS's func_door_rotating / prop_door_rotating): a brush or a model made a door turns on its hinges, opened with E
(Interact) in the game — away from whoever opens it, 90° in about half a second, staying open (or closing by itself),
stopping where a player blocks it. The hinges go on the narrow edge nearest the 3D cursor (Flip hinges: the other);
the views draw the axis and the swing both ways, Check map tells when the swing hits a wall. The export writes the
door's frame (hinge, up, across, front, its size) and settings; the game moves it (server-authoritative, as CS2)."""
import math

import bpy
from .translations import tr
from mathutils import Vector

from . import BRUSH_KEYS, child_collection, object_mode, UNIT

DOOR_KEYS = {"ps_door_hinge": 0, "ps_door_angle": 90.0, "ps_door_speed": 180.0, "ps_door_open": "both",
             "ps_door_autoclose": 0.0, "ps_door_startsopen": 0, "ps_door_breakable": 1,
             "ps_door_breakradius": 8.75}
OPEN_WAYS = [("both", "Both ways (away from the user)", ""), ("front", "Front only", ""), ("back", "Back only", "")]


def is_door(obj):
    return obj is not None and obj.get("ps_entity") == "door" and obj.type == "MESH"


def frame(obj):
    """The door in the world: (hinge point at its bottom, up, across (hinge → far edge), front (its normal), width,
    height, thickness), from its own box: its thinnest own axis its thickness, its own z up, the rest across."""
    corners = [Vector(c) for c in obj.bound_box]
    lo = Vector([min(c[k] for c in corners) for k in range(3)])
    hi = Vector([max(c[k] for c in corners) for k in range(3)])
    ext = hi - lo
    t = 0 if ext.x <= ext.y else 1  # its thickness: the thinner of its own x and y
    w = 1 - t
    mw = obj.matrix_world
    axes = [mw.to_3x3() @ Vector(v) for v in ((1, 0, 0), (0, 1, 0), (0, 0, 1))]
    scale = [a.length for a in axes]
    hinge_high = int(obj.get("ps_door_hinge", 0)) == 1
    local = Vector((0.0, 0.0, lo.z))
    local[w] = hi[w] if hinge_high else lo[w]
    local[t] = (lo[t] + hi[t]) / 2
    hinge = mw @ local
    up = axes[2].normalized()
    across = axes[w].normalized() * (-1 if hinge_high else 1)
    front = axes[t].normalized()
    return hinge, up, across, front, ext[w] * scale[w], ext.z * scale[2], ext[t] * scale[t]


def swing_points(obj, side, steps=12):
    """The far edge's way when the door opens to one side (+1 front, −1 back): points at its mid height, from closed to
    open."""
    hinge, up, across, front, width, height, _ = frame(obj)
    angle = math.radians(float(obj.get("ps_door_angle", 90.0)))
    mid = up * (height / 2)
    out = []
    for i in range(steps + 1):
        a = angle * i / steps
        d = across * math.cos(a) + front * (side * math.sin(a))
        out.append(hinge + mid + d * width)
    return out


def sides_of(obj):
    way = str(obj.get("ps_door_open", "both"))
    return [s for s, name in ((1, "front"), (-1, "back")) if way in ("both", name)]


def door_settings_ui(obj):
    ui = obj.id_properties_ui
    ui("ps_door_angle").update(min=10.0, max=180.0, soft_min=30.0, soft_max=120.0, description="How far it opens, degrees")
    ui("ps_door_speed").update(min=20.0, max=1000.0, description="How fast it turns, degrees a second (180: 90° in half "
                                                                "a second, as CS:GO's)")
    ui("ps_door_autoclose").update(min=0.0, max=120.0, description="Closes by itself this many seconds after opening "
                                                                   "(0: stays open until someone presses E again)")
    if "ps_door_breakradius" in obj:
        ui("ps_door_breakradius").update(min=0.5, max=20.0, description="An HE going off this close (metres, any part of "
                                                                        "the door in its sight) knocks it out until the next round")


class MAP_OT_make_door(bpy.types.Operator):
    bl_idname = "psmap.make_door"
    bl_label = "Make door"
    bl_description = ("The selected brush or model a door (CS's rotating door): opened with E in the game, away from whoever "
                      "opens it. Its hinges on its narrow edge nearest the 3D cursor (Flip hinges: the other one); the views "
                      "draw its swing. Angle, speed, which ways it opens, closing by itself: the Object tab")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return any(o.type == "MESH" and o.get("ps_entity") in (None, "world", "solid", "detail", "model")
                   for o in context.selected_objects)

    def execute(self, context):
        object_mode(context)
        col = child_collection(context.scene, "Entities")
        cursor = context.scene.cursor.location
        made = []
        for o in [o for o in context.selected_objects if o.type == "MESH"
                  and o.get("ps_entity") in (None, "world", "solid", "detail", "model")]:
            for c in list(o.children):
                if c.get("ps_model_box"):
                    bpy.data.objects.remove(c, do_unlink=True)  # the door's own box collides now
            # Out of Seen (the add-on would make it a brush again there) into Entities.
            for c in list(o.users_collection):
                c.objects.unlink(o)
            col.objects.link(o)
            for key in BRUSH_KEYS + ("ps_entity", "ps_edge", "ps_edge_clip", "ps_keep"):
                if key in o:
                    del o[key]
            o["ps_entity"] = "door"
            for key, value in DOOR_KEYS.items():
                if key not in o:
                    o[key] = value
            door_settings_ui(o)
            # Its hinges on the narrow edge nearest the cursor.
            ends = []
            for side in (0, 1):
                o["ps_door_hinge"] = side
                ends.append((frame(o)[0] - cursor).length)
            o["ps_door_hinge"] = 0 if ends[0] <= ends[1] else 1
            o.display_type = "TEXTURED"
            made.append(o)
        self.report({"INFO"}, tr(f"{len(made)} door(s): E opens them in the game; the Object tab sets them", "reports"))
        return {"FINISHED"} if made else {"CANCELLED"}


class MAP_OT_door_flip(bpy.types.Operator):
    bl_idname = "psmap.door_flip"
    bl_label = "Flip hinges"
    bl_description = "The door's hinges on its other narrow edge"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        for o in context.selected_objects:
            if is_door(o):
                o["ps_door_hinge"] = 1 - int(o.get("ps_door_hinge", 0))
        return {"FINISHED"}


class MAP_OT_door_back(bpy.types.Operator):
    bl_idname = "psmap.door_back"
    bl_label = "Not a door"
    bl_description = "The selected door a brush again (into Seen)"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        from . import make_brush
        seen = child_collection(context.scene, "Seen")
        for o in [o for o in context.selected_objects if is_door(o)]:
            for key in list(o.keys()):
                if key.startswith("ps_door_") or key == "ps_entity":
                    del o[key]
            for c in list(o.users_collection):
                c.objects.unlink(o)
            seen.objects.link(o)
            make_brush(o)
        return {"FINISHED"}


def draw(layout, obj):
    """A door's settings (the Object tab)."""
    box = layout.box()
    box.label(text=tr("Door: E opens it in the game, away from the user"), icon="MOD_SIMPLEDEFORM")
    row = box.row(align=True)
    row.operator("psmap.door_flip", icon="ARROW_LEFTRIGHT")
    row.operator("psmap.door_back", icon="LOOP_BACK")
    col = box.column(align=True)
    for key, text in (("ps_door_angle", "Opens (°)"), ("ps_door_speed", "Speed (°/s)"),
                      ("ps_door_autoclose", "Closes by itself after (s, 0: never)")):
        if key in obj:
            col.prop(obj, f'["{key}"]', text=tr(text))
    if "ps_door_open" in obj:
        row = col.row(align=True)
        for way, text in (("both", "Both ways"), ("front", "Front"), ("back", "Back")):
            op = row.operator("psmap.door_set", text=tr(text), depress=str(obj["ps_door_open"]) == way)
            op.key, op.value = "ps_door_open", way
    if "ps_door_startsopen" in obj:
        op = col.operator("psmap.door_set", text=tr("Starts open" if obj["ps_door_startsopen"] else "Starts closed"),
                          depress=bool(obj["ps_door_startsopen"]), icon="CHECKBOX_HLT" if obj["ps_door_startsopen"] else "CHECKBOX_DEHLT")
        op.key, op.value = "ps_door_startsopen", "0" if obj["ps_door_startsopen"] else "1"
    breakable = bool(obj.get("ps_door_breakable", 1))
    op = col.operator("psmap.door_set", text=tr("Breakable (HE knocks it out)" if breakable else "Unbreakable"),
                      depress=breakable, icon="CHECKBOX_HLT" if breakable else "CHECKBOX_DEHLT")
    op.key, op.value = "ps_door_breakable", "0" if breakable else "1"
    if breakable:
        if "ps_door_breakradius" in obj:
            col.prop(obj, '["ps_door_breakradius"]', text=tr("HE reach (m)"))
        else:
            col.label(text=tr("HE reach: 8.75 m"))
    _, _, _, _, width, height, thick = frame(obj)
    box.label(text=tr(f"{width / UNIT:.0f} × {height / UNIT:.0f} units, {thick / UNIT:.0f} thick; front: the blue swing"))


class MAP_OT_door_set(bpy.types.Operator):
    bl_idname = "psmap.door_set"
    bl_label = "Set"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}
    key: bpy.props.StringProperty()
    value: bpy.props.StringProperty()

    def execute(self, context):
        for o in context.selected_objects:
            if is_door(o):
                o[self.key] = int(self.value) if self.key in ("ps_door_startsopen", "ps_door_breakable") else self.value
                if self.key == "ps_door_breakable" and "ps_door_breakradius" not in o:
                    o["ps_door_breakradius"] = 8.75
                    door_settings_ui(o)
        return {"FINISHED"}


def draw_swings(shader, objs):
    """The views: each selected door's hinge axis (yellow) and its far edge's way opening (front blue, back orange)."""
    from gpu_extras.batch import batch_for_shader
    for o in objs:
        if not is_door(o):
            continue
        hinge, up, _, _, _, height, _ = frame(o)
        shader.uniform_float("color", (1.0, 0.85, 0.2, 1.0))
        batch_for_shader(shader, "LINES", {"pos": [hinge, hinge + up * height]}).draw(shader)
        for side in sides_of(o):
            pts = swing_points(o, side)
            shader.uniform_float("color", (0.3, 0.6, 1.0, 0.9) if side > 0 else (1.0, 0.55, 0.2, 0.9))
            batch_for_shader(shader, "LINE_STRIP", {"pos": pts}).draw(shader)
            batch_for_shader(shader, "LINES", {"pos": [hinge + up * (height / 2), pts[-1]]}).draw(shader)


def swing_issues(objs, tree, add):
    """Check map: a door whose swing (its far edge, at its foot, middle and top) runs into something solid."""
    for o in objs:
        if not is_door(o):
            continue
        hinge, up, across, front, width, height, _ = frame(o)
        angle = math.radians(float(o.get("ps_door_angle", 90.0)))
        for side in sides_of(o):
            hit = None
            for h in (0.1, 0.5, 0.9):
                prev = None
                for i in range(0, 13):
                    a = angle * i / 12
                    p = hinge + up * (height * h) + (across * math.cos(a) + front * (side * math.sin(a))) * (width * 0.97)
                    if prev is not None:
                        d = p - prev
                        loc = tree.ray_cast(prev, d.normalized(), d.length)[0] if d.length > 1e-6 else None
                        if loc is not None:
                            hit = loc
                            break
                    prev = p
                if hit is not None:
                    break
            if hit is not None:
                way = "front (blue)" if side > 0 else "back (orange)"
                add("warning", f"{o.name}: opening to its {way} it runs into something — set it to open the other way "
                    "only, or a smaller angle", o, where=hit)


CLASSES = [MAP_OT_make_door, MAP_OT_door_flip, MAP_OT_door_back, MAP_OT_door_set]
