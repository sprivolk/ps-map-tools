"""Send and Get by parts (the map split in the GitHub tab → Parts).

On GitHub, in the map's folder:
- <map>.blend: the whole map as a starting point for someone who opens it (sent the first time and when the map's
  settings change); the parts below are what counts;
- parts/<part>.blend: each part's own objects (its pictures as textures/…, like the whole map's);
- .psmap-team/parts.json: every part's fingerprint, who sent it and when, where it sits in the tree, the ids of its
  objects; and the map's settings (mode, light, the card…) as values.

Send sends the parts changed here since they were last taken or sent; one changed there too (by someone else) stops it
(both changed: «mine or theirs»). Get takes the parts changed there that were not changed here: their objects are put in
place of the old ones (what points at them — cutters, mirrors, parents — points at the new ones), materials and pictures
already here are used, not doubled. The .blend is copied to .backups/ first."""
import hashlib
import json
import os
import re
import tempfile
import time

import bpy

from . import map_collection
from . import parts as P

MANIFEST = ".psmap-team/parts.json"
PARTS_DIR = "parts/"
SKIP = ("ps_status", "ps_issues", "ps_current_part", "ps_map_collection", "ps_grid_units", "ps_mirror_show")
# Other add-ons' scene settings with the same ps_ start (the animation tools' ps_anim_…): not the map's, and not
# everyone has them on.
OTHERS = ("ps_anim_",)


# ---------- the map's settings as values ----------
def settings_values(scene):
    """The scene's own ps_ settings that are plain values (no objects, no lists)."""
    out = {}
    for prop in scene.bl_rna.properties:
        k = prop.identifier
        if not k.startswith("ps_") or k in SKIP or k.startswith(OTHERS) or                 prop.type not in ("STRING", "INT", "FLOAT", "BOOLEAN", "ENUM"):
            continue
        if getattr(prop, "is_enum_flag", False):
            continue
        v = getattr(scene, k)
        out[k] = list(v) if hasattr(v, "__len__") and not isinstance(v, str) else v
    return out


def apply_settings(scene, values):
    for k, v in values.items():
        if k in SKIP or not hasattr(scene, k):
            continue
        try:
            setattr(scene, k, v)
        except (TypeError, ValueError, AttributeError):
            pass


def settings_fp(values):
    return hashlib.sha1(json.dumps(values, sort_keys=True, default=str).encode()).hexdigest()


# ---------- what is here (main thread) ----------
def safe_file(name):
    return PARTS_DIR + re.sub(r"[^A-Za-z0-9_-]+", "_", name).strip("_")[:40] + "_" + \
        hashlib.md5(name.encode()).hexdigest()[:6] + ".blend"


def local_spec(scene):
    """{part: {fp, kind, parent, file, uids, objects}} of the map here, and its settings."""
    P.ensure_uids(scene)
    pm = P.part_map(scene)
    tree = P.parts(scene)
    parent_of = {}
    for name, col, kind, depth in tree:
        if col is None or kind in ("common", "settings"):
            continue
        holder = next((n for n, c, k, d in tree if c is not None and k != "settings" and col.name in c.children), None)
        parent_of[name] = holder or ("" if kind == "role" else P.COMMON)
    spec = {}
    for name, col, kind, depth in tree:
        if kind == "settings":
            continue
        objs = P.part_objects(scene, name, pm)
        spec[name] = {"fp": P.fingerprint(scene, name, pm), "kind": kind, "parent": parent_of.get(name, ""),
                      "file": safe_file(name), "uids": sorted(o[P.UID] for o in objs if o.get(P.UID)),
                      "objects": [o.name for o in objs]}
    values = settings_values(scene)
    return spec, values


# ---------- putting a part in place (main thread) ----------
def _dedupe(pairs, pool):
    """[(the name it has in the part's file, the datablock loaded)]: one here under exactly that name is used, the
    loaded one removed («Dev Wood.002» stays «Dev Wood.002»: a name's .002 is not a copy's mark)."""
    loaded = {d for _, d in pairs if d is not None}
    for name, d in pairs:
        if d is None:
            continue
        here = pool.get(name)
        if here is not None and here not in loaded and here.library is None:
            d.user_remap(here)
            pool.remove(d)


def apply_part(scene, name, path, entry):
    """The part's objects from its file put in place of the ones here."""
    root = map_collection(scene)
    col = P.part_collection(scene, name)
    if col is None:  # a part made there: its collection made here, in the same place of the tree
        parent = P.part_collection(scene, entry.get("parent") or "") if entry.get("parent") else None
        if parent is None:
            parent = P.seen_of(root) if entry.get("kind") == "place" else root
        col = P._new_part(name, parent, entry.get("kind", "place"))
    wanted = set(entry.get("uids", []))
    here = {o[P.UID]: o for o in P.part_objects(scene, name) if o.get(P.UID)}
    by_uid = {o[P.UID]: o for o in P._objects_under(root) if o.get(P.UID)}
    before = {k: set(getattr(bpy.data, k)) for k in ("objects", "meshes", "materials", "images", "node_groups",
                                                      "lights", "curves")}
    kinds = ("materials", "images", "node_groups")
    with bpy.data.libraries.load(path, link=False) as (data_from, data_to):
        data_to.objects = list(data_from.objects)
        names = {k: list(getattr(data_from, k)) for k in kinds}
        for k in kinds:  # asked for by name: which loaded one had which name there
            setattr(data_to, k, list(names[k]))
    loaded = [o for o in data_to.objects if o is not None]
    mine, deps = [], []
    for o in loaded:
        (mine if o.get(P.UID) in wanted else deps).append(o)
    # Objects of other parts that came along (a cutter, a parent): the ones here are used.
    for o in deps:
        twin = by_uid.get(o.get(P.UID))
        if twin is not None:
            o.user_remap(twin)
        bpy.data.objects.remove(o)
    for o in mine:
        old = here.pop(o[P.UID], None)
        if old is not None:
            keep = old.name
            old.user_remap(o)  # what pointed at the old one points at this one (its collections too)
            bpy.data.objects.remove(old)
            o.name = keep
        elif o.name not in [x.name for x in col.objects]:
            col.objects.link(o)
        if not o.users_collection:
            col.objects.link(o)
    for old in here.values():  # taken out there
        bpy.data.objects.remove(old)
    for k in kinds:
        _dedupe(list(zip(names[k], getattr(data_to, k))), getattr(bpy.data, k))
    for k in ("meshes", "lights", "curves", "materials", "images"):
        pool = getattr(bpy.data, k)
        for d in set(pool) - before[k]:
            if d.users == 0:
                pool.remove(d)
    P.ensure_uids(scene)
    return len(mine)


# ---------- the jobs (threads) ----------
def _manifest(repo, remote):
    sha = remote.get(MANIFEST)
    if not sha:
        return None
    return json.loads(repo.blob(sha).decode("utf-8"))


COPY_PARTS = r'''
import bpy, json, os, sys
spec_path = sys.argv[sys.argv.index("--") + 1]
with open(spec_path) as f:
    spec = json.load(f)
for o in bpy.data.objects:
    if "_psmap_color" in o:
        o.color = o["_psmap_color"]
        del o["_psmap_color"]
for path, names in spec.items():
    objs = {bpy.data.objects[n] for n in names if n in bpy.data.objects}
    os.makedirs(os.path.dirname(path), exist_ok=True)
    bpy.data.libraries.write(path, objs, path_remap="NONE", compress=True)
'''


def write_parts(copy_blend, tmp, files_spec):
    """Each part's file from the copy to send (its pictures already pointing at textures/): {path in repo: file}."""
    import subprocess
    out, spec = {}, {}
    for rel, names in files_spec.items():
        path = os.path.join(tmp, *rel.split("/"))
        spec[path] = names
        out[rel] = path
    spec_path = os.path.join(tmp, "parts_spec.json")
    with open(spec_path, "w") as f:
        json.dump(spec, f)
    script = os.path.join(tmp, "parts.py")
    with open(script, "w", encoding="utf-8") as f:
        f.write(COPY_PARTS)
    run = subprocess.run([bpy.app.binary_path, "-b", "--factory-startup", copy_blend, "--python", script, "--", spec_path],
                         capture_output=True, text=True, timeout=1800, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    missing = [r for r, p in out.items() if not os.path.isfile(p)]
    if missing:
        tail = (run.stdout + run.stderr).strip().splitlines()[-5:]
        from .github import GitHubError
        raise GitHubError(0, "could not make the parts' files: " + " / ".join(tail))
    return out


def job_send(token, me, blend, message, force, spec, values):
    from . import github as G
    folder = os.path.dirname(blend)
    state = G.read_state(blend)
    repo = G._repo_of(state, token)
    main = os.path.basename(blend)
    synced = state.setdefault("parts", {})
    G._stage("Asking GitHub what the map has…")
    head = repo.head(create=True)
    base_tree, remote = repo.tree_of(head)
    manifest = _manifest(repo, remote) or {"format": 1, "parts": {}, "settings": {}}
    there = manifest.get("parts", {})
    local_fp = {n: e["fp"] for n, e in spec.items()}
    local_fp[P.SETTINGS] = settings_fp(values)
    remote_fp = {n: e.get("fp") for n, e in there.items()}
    remote_fp[P.SETTINGS] = manifest.get("settings_fp")
    changed = [n for n in local_fp if local_fp[n] != synced.get(n) and local_fp[n] != remote_fp.get(n)]
    gone = [n for n in there if n not in spec and synced.get(n) == remote_fp.get(n)]  # taken out here, not changed there
    both = [n for n in changed if remote_fp.get(n) and remote_fp[n] != synced.get(n)]
    forced = set(force) if isinstance(force, (list, tuple, set)) else (set(local_fp) if force else set())
    from . import editing
    busy = {p: w for p, w in editing.editing_others([n for n in changed if n != P.SETTINGS], me).items()
            if p not in forced}
    if busy:
        raise G.Conflict({"kind": "editing", "parts": sorted(busy), "who": ", ".join(sorted(set(busy.values())))})
    both = [n for n in both if n not in forced]
    if both:
        raise G.Conflict(conflict_of(both, there, manifest))
    for n in local_fp:  # the same there and here: nothing to send, now in step
        if local_fp[n] == remote_fp.get(n):
            synced[n] = local_fp[n]
    first = main not in remote
    if not changed and not gone and not first:
        G.write_state(folder, state)
        return "Nothing new: GitHub already has every part as it is here", f"https://github.com/{repo.full}"

    with tempfile.TemporaryDirectory() as tmp:
        G._stage("Making the files to send (pictures beside them)…")
        files = G.make_copy(blend, tmp)
        copy_blend = files[main]
        send_parts = [n for n in changed if n != P.SETTINGS]
        made = write_parts(copy_blend, tmp, {spec[n]["file"]: spec[n]["objects"] for n in send_parts})
        new = {}
        for rel, path in made.items():
            with open(path, "rb") as f:
                new[rel] = f.read()
        for rel, path in files.items():
            if rel.startswith("textures/"):
                with open(path, "rb") as f:
                    new[rel] = f.read()
        if first or P.SETTINGS in changed:
            with open(copy_blend, "rb") as f:
                new[main] = f.read()
        for rel, path in G.beside(blend).items():
            with open(path, "rb") as f:
                new[rel] = f.read()
        now = time.strftime("%Y-%m-%dT%H:%M:%S")
        for n in send_parts:
            e = dict(spec[n])
            e.pop("objects", None)
            e.update(by=me, at=now)
            there[n] = e
        for n in gone:
            there.pop(n, None)
        if first or P.SETTINGS in changed:
            manifest["settings"], manifest["settings_fp"] = values, local_fp[P.SETTINGS]
            manifest["settings_by"], manifest["settings_at"] = me, now
        manifest["parts"] = there
        manifest["main"] = main
        new[MANIFEST] = json.dumps(manifest, indent=1, sort_keys=True).encode("utf-8")
        new[G.PROJECT] = json.dumps({"main": main, "parts": True}, indent=1).encode("utf-8")
        for rel, data in new.items():
            if len(data) > G.LIMIT:
                raise G.GitHubError(0, f"{rel} is {len(data) // (1024 * 1024)} MB: GitHub takes files up to 100 MB")
        changes = {rel: data for rel, data in new.items() if remote.get(rel) != G.git_sha(data)}
        for n in gone:
            rel = safe_file(n)
            if rel in remote:
                changes[rel] = None
        commit = repo.commit(head, base_tree, changes, message)
    for n in changed:
        synced[n] = local_fp[n]
    for n in gone:
        synced.pop(n, None)
    state["branch"] = repo.branch
    G.write_state(folder, state)
    editing.sent(token, repo.full, repo.branch, state.get("folder", ""), me, [n for n in changed if n != P.SETTINGS])
    G._refresh_info(repo)
    said = ", ".join(changed) or "the whole map"
    return f"Sent: {said}" + (f"; taken out: {', '.join(gone)}" if gone else ""), \
        f"https://github.com/{repo.full}/commit/{commit}"


def conflict_of(names, there, manifest):
    """The parts changed here and there too, with who changed them there and when."""
    info = {}
    for n in names:
        e = there.get(n, {}) if n != P.SETTINGS else {"by": manifest.get("settings_by"), "at": manifest.get("settings_at")}
        info[n] = {"by": e.get("by") or "someone", "at": (e.get("at") or "").replace("T", " ")[:16]}
    return {"kind": "parts", "parts": list(names), "who": ", ".join(sorted({i["by"] for i in info.values()})),
            "info": info}


def job_get(token, blend, spec, values, force_parts=(), then=None):
    """What changed there and not here: downloaded now; put in place by the main thread."""
    from . import github as G
    folder = os.path.dirname(blend)
    state = G.read_state(blend)
    repo = G._repo_of(state, token)
    synced = state.setdefault("parts", {})
    G._stage("Asking GitHub what changed…")
    head = repo.head()
    _, remote = repo.tree_of(head)
    manifest = _manifest(repo, remote)
    if manifest is None:
        return "GitHub has no parts of this map yet: Send puts them there", ""
    there = manifest.get("parts", {})
    local_fp = {n: e["fp"] for n, e in spec.items()}
    local_fp[P.SETTINGS] = settings_fp(values)
    take, both = [], []
    for n, e in list(there.items()) + [(P.SETTINGS, {"fp": manifest.get("settings_fp")})]:
        r, s, l = e.get("fp"), synced.get(n), local_fp.get(n)
        if not r or r == l:
            if r:
                synced[n] = r
            continue
        if r == s:
            continue  # not changed there
        if l is None or l == s or n in force_parts:
            take.append(n)
        else:
            both.append(n)
    # The other files (pictures, .psmap, the log): as before, the whole map's .blend left as it is.
    others = {rel: sha for rel, sha in remote.items()
              if not rel.startswith(PARTS_DIR) and not rel.startswith(".psmap-team/") and not rel.endswith(".blend")}
    G._take(repo, folder, others, state.setdefault("synced", {}))
    paths = {}
    for i, n in enumerate([n for n in take if n != P.SETTINGS], 1):
        rel = there[n]["file"]
        G._stage(f"Getting {n} ({i} of {len(take)})…")
        data = repo.blob(remote[rel])
        path = os.path.join(folder, *rel.split("/"))
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "wb") as f:
            f.write(data)
        paths[n] = path
    state["branch"] = repo.branch
    G.write_state(folder, state)
    G._refresh_info(repo)
    if not take:
        if both:
            raise G.Conflict(conflict_of(both, there, manifest))
        if then:
            G._main.append(then)
        return "Up to date: nothing new on GitHub", ""
    settings = manifest.get("settings") if P.SETTINGS in take else None
    conflict = conflict_of(both, there, manifest) if both else None
    G._main.append(lambda: _put_in_place(blend, take, paths, there, settings, manifest.get("settings_fp"), conflict,
                                         then))
    return "Putting the parts in place…", ""


def _put_in_place(blend, take, paths, there, settings, settings_fp_, conflict, then=None):
    """Main thread: the downloaded parts into the open map; saved; remembered as taken."""
    from . import github as G
    if bpy.data.filepath != blend:
        G._job.update(result="The map was closed before the parts came: Get again", error=True)
        return
    scene = bpy.context.scene
    bpy.ops.wm.save_mainfile()
    G._backup(blend)
    was_shown = P._view["on"]
    if was_shown:
        P.hide_parts()
    put = []
    with P.quiet():
        _apply_all(scene, take, paths, there, settings, put)
        bpy.context.view_layer.update()
    if was_shown:
        P.show_parts(scene)
    bpy.ops.wm.save_mainfile()
    state = G.read_state(blend)
    synced = state.setdefault("parts", {})
    for n in put:
        synced[n] = settings_fp_ if n == P.SETTINGS else there[n]["fp"]
    G.write_state(os.path.dirname(blend), state)
    G._job.update(result=f"Got: {', '.join(put)}", error=bool(conflict), conflict=conflict)
    if conflict:
        ask_whose()
    if then:
        then()


# ---------- whose version stays: a choice for each part changed here and there ----------
def ask_whose():
    """The window «Mine or theirs» (from a timer: after a Send or a Get found parts changed on both sides)."""
    def show():
        window = bpy.context.window_manager.windows[0]
        window.cursor_warp(window.width // 2, window.height // 2 + 120)  # Blender puts a window at the mouse
        with bpy.context.temp_override(window=window, screen=window.screen):
            bpy.ops.psmap.parts_whose("INVOKE_DEFAULT")
        return None
    bpy.app.timers.register(show, first_interval=0.2)


def _send_mine(mine, message):
    """After theirs were put in place: the parts chosen «mine» sent over theirs."""
    from . import github as G
    def go():
        if G.running():
            return 0.3
        acc = G.account()
        spec, values = local_spec(bpy.context.scene)
        G.start(job_send, acc["token"], acc["login"], bpy.data.filepath, message, list(mine), spec, values,
                repo=G.read_state(bpy.data.filepath)["repo"])
        return None
    bpy.app.timers.register(go, first_interval=0.2)


class PSWhose(bpy.types.PropertyGroup):
    part: bpy.props.StringProperty()
    who: bpy.props.StringProperty()
    at: bpy.props.StringProperty()
    pick: bpy.props.EnumProperty(items=[("theirs", "Theirs", "Take their version of this part (yours goes to .backups)"),
                                        ("mine", "Mine", "Keep yours and send it over theirs (theirs stays in the history)")],
                                 default="theirs")


class MAP_OT_parts_whose(bpy.types.Operator):
    bl_idname = "psmap.parts_whose"
    bl_label = "Whose version stays?"
    bl_description = "These parts were changed here and on GitHub too: for each, keep yours or take theirs"
    choices: bpy.props.CollectionProperty(type=PSWhose)

    @classmethod
    def poll(cls, context):
        from . import github as G
        c = G._job.get("conflict") or {}
        return c.get("kind") == "parts" and bool(c.get("parts")) and not G.running()

    def invoke(self, context, event):
        from . import github as G
        c = G._job["conflict"]
        self.choices.clear()
        for n in c["parts"]:
            i = c.get("info", {}).get(n, {})
            ch = self.choices.add()
            ch.part, ch.who, ch.at = n, i.get("by", "someone"), i.get("at", "")
        return context.window_manager.invoke_props_dialog(self, width=520, title="Whose version stays?",
                                                          confirm_text="Done")

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.label(text="Changed here and on GitHub too. For each part:", icon="INFO")
        col.label(text="Theirs: their version comes here (yours is kept in .backups).", icon="BLANK1")
        col.label(text="Mine: yours is sent over theirs (theirs stays in the history).", icon="BLANK1")
        layout.separator()
        for ch in self.choices:
            row = layout.row(align=True)
            row.label(text=ch.part, icon="OUTLINER_COLLECTION")
            row.label(text=f"{ch.who} {ch.at}".strip())
            row.prop(ch, "pick", expand=True)
            if ch.part != P.SETTINGS:
                row.operator("psmap.parts_select", text="", icon="RESTRICT_SELECT_OFF").part = ch.part
            else:
                row.label(text="", icon="BLANK1")

    def execute(self, context):
        from . import github as G
        acc = G.account()
        theirs = [c.part for c in self.choices if c.pick == "theirs"]
        mine = [c.part for c in self.choices if c.pick == "mine"]
        message = "Kept mine: " + ", ".join(mine) if mine else ""
        G._job["conflict"] = None
        bpy.ops.wm.save_mainfile()
        then = (lambda: _send_mine(mine, message)) if mine else None
        spec, values = local_spec(context.scene)
        if theirs:
            G.start(job_get, acc["token"], bpy.data.filepath, spec, values, tuple(theirs), then,
                    repo=G.read_state(bpy.data.filepath)["repo"])
        elif mine:
            _send_mine(mine, message)
        return {"FINISHED"}


CLASSES = [PSWhose, MAP_OT_parts_whose]


def _apply_all(scene, take, paths, there, settings, put):
    for n in take:
        if n == P.SETTINGS:
            apply_settings(scene, settings or {})
            put.append(n)
            continue
        if n in paths:
            apply_part(scene, n, paths[n], there[n])
            put.append(n)


def after_open(blend):
    """Main thread, the map just opened from GitHub: its parts newer than its .blend put in place from parts/."""
    from . import github as G
    folder = os.path.dirname(blend)
    path = os.path.join(folder, *MANIFEST.split("/"))
    if not os.path.isfile(path):
        return
    with open(path, encoding="utf-8") as f:
        manifest = json.load(f)
    scene = bpy.context.scene
    spec, values = local_spec(scene)
    there = manifest.get("parts", {})
    put = []
    with P.quiet():
        for n, e in there.items():
            if spec.get(n, {}).get("fp") != e.get("fp"):
                part_path = os.path.join(folder, *e["file"].split("/"))
                if os.path.isfile(part_path):
                    apply_part(scene, n, part_path, e)
                    put.append(n)
    if manifest.get("settings") and settings_fp(values) != manifest.get("settings_fp"):
        apply_settings(scene, manifest["settings"])
    if put:
        bpy.ops.wm.save_mainfile()
    state = G.read_state(blend) or {}
    state["parts"] = {n: e.get("fp") for n, e in there.items()}
    state["parts"][P.SETTINGS] = manifest.get("settings_fp")
    G.write_state(folder, state)
