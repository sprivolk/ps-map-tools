"""The map tools' interface: tabs of their own in the 3D view's sidebar (N), in the order of the work — Build, Object,
Entities, Art, Light, Show, Play — each short, its parts folding; the selected object's settings in a popup at the mouse
(F); the brush tools and the materials in pie menus (Q, Shift+Q). Blender's own Properties editor is left as it is.

The panels say what is (counts, problems, what is selected); what a button does is in its tooltip (the mouse over it).
In a file that is not a map only Start here (Build) and Art are shown."""
import os

import bpy
from .translations import tr

from . import (UNIT, DEV, DEV_SURFACES, TOOLS, ENTITIES, GROUPS, group_shown, busy, game_path, has_preview, is_brush,
               is_map_file, _export, HAS_UNITY, MAP_FORMAT, game_reads)
from . import brush_tools, makers, overlay, walk, cutters, mirror, art, faces, trims, dress


class Tab:
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"


class MapTab(Tab):
    """A panel of a map file only (in another file: Start here)."""

    @classmethod
    def poll(cls, context):
        return is_map_file(context.scene)


# ---------- Build ----------
class MAP_PT_build_start(Tab, bpy.types.Panel):
    bl_category = "Build"
    bl_label = "Start here"

    @classmethod
    def poll(cls, context):
        return not is_map_file(context.scene)

    def draw(self, context):
        layout = self.layout
        layout.label(text=tr("This file is not a map yet"), icon="INFO")
        row = layout.row()
        row.scale_y = 1.4
        row.operator("psmap.new_map", text=tr("New map"), icon="FILE_NEW")
        layout.label(text=tr("Or use a collection of this file:"))
        layout.prop(context.scene, "ps_map_collection", text="")
        layout.separator()
        col = layout.column(align=True)
        col.label(text=tr("1. New map"))
        col.label(text=tr("2. Build: draw brushes (Draw brush)"))
        col.label(text=tr("3. Play → Test and play"))
        layout.operator("psmap.manual", icon="HELP")


class MAP_PT_build_map(MapTab, bpy.types.Panel):
    bl_category = "Build"
    bl_label = "Map and grid"

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        row = layout.row(align=True)
        row.prop(scene, "ps_map_collection", text=tr("Map"))
        row.operator("psmap.new_map", text="", icon="FILE_NEW")
        row.operator("psmap.flip_panel", text="", icon="ARROW_LEFTRIGHT")
        row = layout.row(align=True)
        row.operator("psmap.grid", text=tr("[ Finer")).step = -1
        row.label(text=tr(f"{scene.ps_grid_units} u = {scene.ps_grid_units * UNIT:.2f} m"))
        row.operator("psmap.grid", text=tr("Coarser ]")).step = 1
        layout.operator("psmap.quad_view", icon="VIEW_ORTHO")


class MAP_PT_build_brushes(MapTab, bpy.types.Panel):
    bl_category = "Build"
    bl_label = "Brushes"

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.scale_y = 1.4
        row.operator("psmap.draw_brush", icon="ADD")
        row.operator("psmap.resize", text=tr("Resize"), icon="FULLSCREEN_ENTER")
        row = layout.row(align=True)
        row.operator("psmap.box", icon="MESH_CUBE")
        row.operator("psmap.snap_to_grid", text=tr("Snap"), icon="SNAP_GRID")
        row.operator("psmap.square", text=tr("Square"), icon="MESH_CUBE")
        row.operator("psmap.make_brushes", text=tr("Split"), icon="MOD_EXPLODE")


class MAP_PT_build_tools(MapTab, bpy.types.Panel):
    bl_category = "Build"
    bl_label = "Brush tools"

    def draw(self, context):
        brush_tools.draw_buttons(self.layout)


class MAP_PT_build_mirror(MapTab, bpy.types.Panel):
    bl_category = "Build"
    bl_label = "Mirror"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        mirror.draw_panel(self.layout, context)



def collision_box(layout, obj):
    """Whom the brush stops, ticked: players, bullets, grenades (what stops bullets stops grenades too). Stairs: their
    steps, and whether players walk up the clip ramp or the steps."""
    from . import collision_of
    players, bullets, grenades = collision_of(obj)
    stairs = obj.ps_maker.kind == "stairs"
    if players and bullets:
        what = tr("Full")
    elif not (players or bullets or grenades):
        what = tr("None: seen only")
    else:
        what = tr("Only:") + " " + " + ".join(tr(n) for n, on in (("Players", players), ("Bullets", bullets),
                                                                   ("Grenades", grenades)) if on)
    box = layout.box()
    box.label(text=(tr("Steps' collision:") if stairs else tr("Collision:")) + " " + what, icon="MOD_PHYSICS")
    row = box.row(align=True)
    for channel, label, on in (("players", "Players", players), ("bullets", "Bullets", bullets),
                               ("grenades", "Grenades", grenades)):
        row.operator("psmap.collision", text=tr(label), depress=on,
                     icon="CHECKBOX_HLT" if on else "CHECKBOX_DEHLT").channel = channel
    if stairs:
        on = obj.ps_maker.ramp
        box.operator("psmap.collision", depress=on, icon="CHECKBOX_HLT" if on else "CHECKBOX_DEHLT",
                     text=tr("Clip ramp: players walk up it" if on else "Clip ramp: off, players climb the steps")).channel = "ramp"

def material_buttons(layout):
    col = layout.column(align=True)
    col.label(text=tr("Colours:"))
    grid = col.grid_flow(columns=3, align=True)
    for name, _ in DEV:
        grid.operator("psmap.material", text=tr(name[4:])).name = name
    col.separator()
    col.label(text=tr("Surfaces (sound of steps, bullets):"))
    grid = col.grid_flow(columns=3, align=True)
    for surface, name, _ in DEV_SURFACES:
        grid.operator("psmap.material", text=tr(name[4:])).name = name
    col.separator()
    col.label(text=tr("Tool textures (clip, nodraw…):"))
    grid = col.grid_flow(columns=2, align=True)
    for tool, name, _, tip in TOOLS:
        grid.operator("psmap.material", text=tr(name[5:])).name = name


class MAP_PT_build_materials(MapTab, bpy.types.Panel):
    bl_category = "Build"
    bl_label = "Blockout materials"

    def draw(self, context):
        material_buttons(self.layout)


def draw_groups(layout, context, work=False):
    """The groups (Art): make one, select it, work in it only (the rest hidden)."""
    row = layout.row(align=True)
    row.operator("psmap.group_set", icon="ADD")
    row.operator("psmap.group_clear", icon="REMOVE")
    only = art.only_group(context.scene)
    if only:
        box = layout.box()
        box.label(text=tr(f"Working in: {only}" if work else f"Only {only} shown"), icon="SOLO_ON")
        row = box.row(align=True)
        row.operator("psmap.group_select", text=tr("Select it"), icon="RESTRICT_SELECT_OFF").group = only
        row.operator("psmap.group_only", text=tr("Show all"), icon="HIDE_OFF").group = only
    found = art.groups(context.scene)
    if not found:
        layout.label(text=tr("No groups yet"))
        return
    col = layout.column(align=True)
    for name, count in found:
        row = col.row(align=True)
        row.operator("psmap.group_select", text=tr(f"{name} ({count})"), icon="RESTRICT_SELECT_OFF").group = name
        if work:
            row.operator("psmap.group_work", text="", icon="SOLO_ON" if only == name else "SOLO_OFF",
                         depress=only == name).group = name
        else:
            row.operator("psmap.group_only", text="", icon="SOLO_ON" if only == name else "SOLO_OFF",
                         depress=only == name).group = name
        row.operator("psmap.group_rename", text="", icon="GREASEPENCIL").group = name
    obj = context.active_object
    if obj is not None and art.group_of(obj):
        layout.label(text=tr(f"{obj.name}: in {art.group_of(obj)}"), icon="OBJECT_DATA")


# ---------- Art: dressing the map (set dressing) ----------
class MAP_PT_art_group(Tab, bpy.types.Panel):
    bl_category = "Art"
    bl_label = "Groups and prefabs"

    def draw(self, context):
        layout = self.layout
        draw_groups(layout, context, work=True)
        found = art.groups(context.scene)
        if not found:
            return
        box = layout.box()
        box.label(text=tr("Prefabs (linked copies)"), icon="OUTLINER_OB_GROUP_INSTANCE")
        for name, _ in found:
            row = box.row(align=True)
            if dress.prefab_collection(name) is None:
                row.operator("psmap.prefab_make", text=tr(f"Make {name} a prefab"), icon="ADD").group = name
            else:
                row.label(text=name, translate=False, icon="OUTLINER_OB_GROUP_INSTANCE")
                row.operator("psmap.prefab_place", text=tr("Place copy"), icon="CURSOR").group = name
        obj = context.active_object
        if obj is not None and obj.get(dress.PREFAB) and obj.instance_type == "COLLECTION":
            box.operator("psmap.prefab_real", icon="UNLINKED")


class MAP_PT_art_materials(Tab, bpy.types.Panel):
    bl_category = "Art"
    bl_label = "Materials"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        row = layout.row(align=True)
        row.operator("psmap.art_pick", text=tr("Pick"), icon="EYEDROPPER")
        cur = art.current(scene)
        sub = row.row(align=True)
        sub.enabled = bool(cur)
        sub.operator("psmap.art_put", text=tr(f"Put {cur}" if cur else "Put"), icon="BRUSH_DATA")
        row = layout.row(align=True)
        row.operator("psmap.art_new", icon="FILE_IMAGE")
        row.operator("psmap.art_refresh", text="", icon="FILE_REFRESH")
        row.operator("psmap.art_open", text="", icon="FILE_FOLDER")
        lib = art.items()
        if not lib:
            layout.label(text=tr("The library is empty"), icon="INFO")
            return
        row = layout.row(align=True)
        row.prop(scene, "ps_art_columns", text=tr("Columns"))
        row.prop(scene, "ps_art_tile", text=tr("Size"))
        mat = art.active_art(context)
        if mat is not None:
            box = layout.box()
            box.label(text=f"{mat.name}: {tr(mat.get('ps_surface', 'default'))}", translate=False, icon="MATERIAL")
            if mat.get("ps_art_tall"):
                box.label(text=tr("Width × height: in its material.json"))
            else:
                box.prop(mat, "ps_art_size")
            box.operator_menu_enum("psmap.art_surface", "surface", text=tr("Surface (steps, bullets)"))
        obj = context.active_object
        can_replace = obj is not None and obj.active_material is not None and obj.mode == "OBJECT"
        names = {i["name"] for i in lib}
        grid = layout.grid_flow(row_major=True, columns=scene.ps_art_columns, even_columns=True, align=False)
        for item in lib:
            if item["name"].endswith(art.UP) and item["name"][:-len(art.UP)] in names:
                continue  # the upright half of a grain pair: put on with its other half
            cell = grid.column(align=True)
            cell.template_icon(icon_value=art.icon(item), scale=scene.ps_art_tile)
            row = cell.row(align=True)
            label = item["name"].split("_", 1)[-1] if "_" in item["name"] else item["name"]
            row.operator("psmap.art_apply", text=label, translate=False, depress=item["name"] == cur).name = item["name"]
            if can_replace:
                row.operator("psmap.art_replace", text="", icon="ARROW_LEFTRIGHT").name = item["name"]


class MAP_PT_art_faces(Tab, bpy.types.Panel):
    bl_category = "Art"
    bl_label = "Faces"

    def draw(self, context):
        layout = self.layout
        edit = context.active_object is not None and context.active_object.mode == "EDIT"
        layout.label(text=tr("Selected faces" if edit else "All faces of the selected"), icon="FACESEL")
        col = layout.column(align=True)
        row = col.row(align=True)
        for a, icon in (("left", "TRIA_LEFT"), ("right", "TRIA_RIGHT"), ("up", "TRIA_UP"), ("down", "TRIA_DOWN")):
            row.operator("psmap.face_tex", text="", icon=icon).action = a
        row.separator()
        row.operator("psmap.face_tex", text="", icon="LOOP_BACK").action = "ccw"
        row.operator("psmap.face_tex", text="", icon="LOOP_FORWARDS").action = "cw"
        row = col.row(align=True)
        row.operator("psmap.face_tex", text=tr("×2")).action = "bigger"
        row.operator("psmap.face_tex", text=tr("÷2")).action = "smaller"
        row.operator("psmap.face_tex", text=tr("Fit")).action = "fit"
        row.operator("psmap.face_tex", text=tr("Fit ↔")).action = "fit_u"
        row = col.row(align=True)
        row.operator("psmap.face_tex", text=tr("Copy active face"), icon="COPYDOWN").action = "copy"
        row.operator("psmap.face_tex", text=tr("Reset"), icon="X").action = "reset"

        box = layout.box()
        box.label(text=tr("Patchwork"), icon="MOD_TRIANGULATE")
        sub = box.row()
        sub.enabled = edit
        sub.operator("psmap.cut_panels", icon="MOD_EDGESPLIT")
        names = faces.mix_list(context.scene)
        col = box.column(align=True)
        for n in names:
            row = col.row(align=True)
            item = art.find(n)
            row.label(text=n, translate=False, icon_value=art.icon(item) if item else 0)
            op = row.operator("psmap.mix_edit", text="", icon="X")
            op.name, op.remove = n, True
        cur = art.current(context.scene)
        row = box.row(align=True)
        row.enabled = bool(cur)
        row.operator("psmap.mix_edit", text=tr(f"Add {cur}" if cur else "Add the current material"), icon="ADD")
        row = box.row(align=True)
        row.operator("psmap.mix", icon="SHADERFX")
        row.operator("psmap.shuffle", icon="FILE_REFRESH")


class MAP_PT_art_trims(Tab, bpy.types.Panel):
    bl_category = "Art"
    bl_label = "Trims"

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        edit = obj is not None and obj.mode == "EDIT"
        guide = obj is not None and obj.get(trims.GUIDE)
        if guide:
            layout.label(text=tr(f"Path of {obj[trims.GUIDE]}"), icon="CURVE_PATH")
            layout.label(text=tr("G move · E add · X delete"))
            layout.operator("psmap.trim_path", text=tr("Done"), icon="CHECKMARK").done = True
            return
        row = layout.row()
        row.enabled = edit
        row.operator("psmap.trim_from_edges", icon="MOD_SKIN")
        if obj is not None and obj.get("ps_stairs") and obj.mode == "OBJECT":
            row = layout.row(align=True)
            row.operator("psmap.trim_stairs", text=tr("Stringer"), icon="IPO_LINEAR").role = "stringer"
            row.operator("psmap.trim_stairs", text=tr("Railing"), icon="IPO_CONSTANT").role = "railing"
        if obj is not None and not (obj.type == "MESH" and obj.ps_trim.on and obj.ps_trim.role == "stringer" and obj.ps_trim.stairs):
            other = next((o for o in context.selected_objects if o is not obj and o.type == "MESH" and o.ps_trim.on
                          and o.ps_trim.stairs and o.ps_trim.role == "stringer"), None)
            if other is not None:
                layout.operator("psmap.trim_fit", text=tr(f"Fit {other.name} to {obj.name}"), icon="SNAP_FACE")
        if obj is None or obj.type != "MESH" or not obj.ps_trim.on:
            return
        p = obj.ps_trim
        box = layout.box()
        box.label(text=tr(obj.name + (f" ({p.role} of {p.stairs})" if p.stairs else "")), icon="MOD_SKIN")
        if p.stairs and p.role == "stringer":
            box.row().prop(p, "panel", expand=True)
            col = box.column(align=True)
            col.prop(p, "over")
            col.prop(p, "width", text=tr("Thickness"))
            if p.panel == "band":
                col.prop(p, "height")
            box.prop(p, "solid")
            row = box.row(align=True)
            row.prop(p, "material", text="")
            row.operator("psmap.trim_material", text="", icon="EYEDROPPER")
            shift = obj.get("ps_trim_shift")
            if shift is not None and any(abs(c) > 1e-5 for c in shift):
                row = box.row(align=True)
                row.label(text=tr("Moved: " + "  ".join(f"{c / UNIT:+.0f}" for c in shift) + " u"), icon="ORIENTATION_GLOBAL")
                row.operator("psmap.trim_unmove", text="", icon="LOOP_BACK")
            row = box.row()
            row.operator("psmap.trim_fit", icon="SNAP_FACE")
            box.operator("psmap.trim_release", icon="UNLINKED")
            return
        box.row().prop(p, "profile", expand=True)
        col = box.column(align=True)
        col.prop(p, "width")
        if p.profile != "round":
            col.prop(p, "height")
        if p.profile == "angle":
            col.prop(p, "thick")
        if p.profile == "round":
            col.prop(p, "sides")
        col = box.column(align=True)
        col.prop(p, "offset_s")
        col.prop(p, "offset_n")
        if p.stairs and p.role == "railing":
            col = box.column(align=True)
            col.prop(p, "rail_height")
            col.prop(p, "post_every")
        row = box.row(align=True)
        row.prop(p, "joint", expand=True)
        box.prop(p, "solid")
        row = box.row(align=True)
        row.prop(p, "material", text="")
        row.operator("psmap.trim_material", text="", icon="EYEDROPPER")
        row = box.row(align=True)
        if not p.stairs:
            row.operator("psmap.trim_path", text=tr("Edit path"), icon="CURVE_PATH")
        row.operator("psmap.trim_release", icon="UNLINKED")


class MAP_PT_art_props(Tab, bpy.types.Panel):
    bl_category = "Art"
    bl_label = "Props"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        edit = context.active_object is not None and context.active_object.mode == "EDIT"
        row = layout.row(align=True)
        row.operator("psmap.prop_add", icon="ADD")
        row.operator("psmap.dress_refresh", text="", icon="FILE_REFRESH")
        row.operator("psmap.dress_open", text="", icon="FILE_FOLDER").kind = "prop"
        lib = dress.props()
        if not lib:
            layout.label(text=tr("No props yet"))
            return
        grid = layout.grid_flow(row_major=True, columns=scene.ps_art_columns, even_columns=True, align=False)
        for item in lib:
            cell = grid.column(align=True)
            icon = dress.icon_for(item["picture"])
            if icon:
                cell.template_icon(icon_value=icon, scale=scene.ps_art_tile * 0.7)
            row = cell.row(align=True)
            op = row.operator("psmap.place", text=item["name"], translate=False, icon="NONE" if icon else "MESH_CUBE")
            op.kind, op.name = "prop", item["name"]
            sub = row.row(align=True)
            sub.enabled = edit
            sub.operator("psmap.scatter", text="", icon="PARTICLES").name = item["name"]


class MAP_PT_art_decals(Tab, bpy.types.Panel):
    bl_category = "Art"
    bl_label = "Decals"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        row = layout.row(align=True)
        row.operator("psmap.decal_new", icon="FILE_IMAGE")
        row.operator("psmap.dress_open", text="", icon="FILE_FOLDER").kind = "decal"
        lib = dress.decals()
        if not lib:
            layout.label(text=tr("No decals yet"))
            return
        grid = layout.grid_flow(row_major=True, columns=scene.ps_art_columns, even_columns=True, align=False)
        for item in lib:
            cell = grid.column(align=True)
            cell.template_icon(icon_value=dress.icon_for(item["picture"]), scale=scene.ps_art_tile * 0.7)
            op = cell.operator("psmap.place", text=item["name"], translate=False)
            op.kind, op.name = "decal", item["name"]


# ---------- Object: what is selected ----------
def draw_selected(layout, context):
    """The selected brush's or entity's settings (the Object tab, and the popup at the mouse)."""
    obj = context.active_object
    if obj is None or not obj.select_get():
        layout.label(text=tr("Nothing selected"), icon="INFO")
        return
    layout.label(text=obj.name, translate=False, icon="OBJECT_DATA")
    from . import models, doors, training
    if doors.is_door(obj):
        doors.draw(layout, obj)
        return
    if training.is_panel(obj) or training.is_mover(obj) or training.is_stand(obj):
        training.draw(layout, obj)
        return
    if obj.get("ps_card_of"):
        layout.label(text=tr(f"Flat picture of {obj['ps_card_of']}"), icon="IMAGE_RGB_ALPHA")
        layout.operator("psmap.model_cards", icon="LOOP_BACK", text=tr("Back to the real leaves"))
        return
    if models.is_model(obj):
        boxes = models.boxes_of(obj)
        layout.label(text=tr(f"Model · {len(boxes)} collision box(es)"), icon="MESH_MONKEY")
        if not boxes:
            layout.label(text=tr("No collision: players walk through it"), icon="ERROR")
        hb = layout.box()
        corners = [len(b.data.vertices) for b in boxes if b.type == "MESH"]
        r = hb.row()
        r.alert = any(c > models.HULL_WARN for c in corners)
        r.label(text=tr(f"Collision: {len(boxes)} piece(s), {sum(corners)} corners"), icon="MOD_PHYSICS")
        r = hb.row(align=True)
        for mode, label in (("box", "One box"), ("hull", "Hull"), ("parts", "Per part"), ("pieces", "Pieces")):
            r.operator("psmap.model_hulls", text=tr(label), depress=obj.get("ps_hull_mode", "box") == mode).mode = mode
        hb.label(text=tr("Corners and pieces: in the operator's panel (F9)"), icon="INFO")
        row = layout.row(align=True)
        row.operator("psmap.add_collision_box", icon="MESH_CUBE")
        row.operator("psmap.model_back", icon="LOOP_BACK")
        row = layout.row(align=True)
        row.operator("psmap.make_door", icon="MOD_SIMPLEDEFORM", text=tr("Make door"))
        row.operator("psmap.make_mover", icon="TRIA_UP_BAR", text=tr("Make mover"))
        # Lighter: its triangles, as it is and as the game gets it.
        mod = models.simplify_of(obj)
        now = models.triangles_now(obj, context.evaluated_depsgraph_get())
        box = layout.box()
        box.label(text=(tr(f"Triangles: {models.triangles(obj.data):,} → {now:,}" if mod else f"Triangles: {now:,}")),
                  icon="MOD_DECIM")
        row = box.row(align=True)
        if mod is not None:
            row.prop(mod, "ratio", text=tr("Keep"), slider=True)
            row.operator("psmap.model_simplify", text=tr("Auto")).how = "auto"
            row.operator("psmap.model_simplify", text="", icon="X").how = "off"
        else:
            row.operator("psmap.model_simplify", text=tr("Simplify"), icon="MOD_DECIM").how = "auto"
        on = models.cards_on(obj)
        if on or any(models.flat_box(s) for s in models.card_sources(obj)):
            layout.operator("psmap.model_cards", icon="IMAGE_RGB_ALPHA", depress=on, text=tr("Leaves as flat pictures"))
        return
    if obj.get("ps_model_box") and obj.parent is not None:
        layout.label(text=tr(f"Collision box of {obj.parent.name}"), icon="MESH_CUBE")
    if obj.type == "MESH" and not obj.get("ps_model_box") and obj.get("ps_entity") in (None, "world", "solid", "detail"):
        if not is_brush(obj):
            layout.label(text=tr("Not in the map yet (not a brush)"), icon="ERROR")
            layout.operator("psmap.make_model", icon="MESH_MONKEY", text=tr("Make model"))
    if is_brush(obj) and obj.get("ps_entity") == "cutter":
        n = len(cutters.cut_by(obj, context.scene.objects))
        layout.label(text=tr(f"Cutter: cuts {n} brush(es)"), icon="MOD_BOOLEAN")
        layout.operator("psmap.apply_cut", icon="CHECKMARK", text=tr("Apply cut"))
        if obj.ps_maker.kind:
            makers.draw(layout, obj)
        return
    if is_brush(obj):
        col = layout.column(align=True)
        collision_box(col, obj)
        mat = obj.active_material
        if mat is not None and not mat.get("ps_tool"):
            col.operator_menu_enum("psmap.material_surface", "surface",
                                   text=tr(f"{mat.name} surface: {tr(mat.get('ps_surface', 'default'))}"))
        col.operator_menu_enum("psmap.surface", "surface",
                               text=tr(f"Surface: {tr(obj.get('ps_surface', 'from the materials'))}"))
        from . import open_pieces, map_collection, map_objects
        if obj.type == "MESH" and open_pieces(obj):
            layout.label(text=tr("Not closed: has holes"), icon="ERROR")
            row = layout.row(align=True)
            row.operator("psmap.make_solid", icon="MOD_SOLIDIFY", text=tr("Make solid"))
            row.operator("psmap.problem_edges", icon="EDGESEL", text=tr("Show holes"))
        root = map_collection(context.scene)
        if root is not None and obj.name not in {o.name for o in map_objects(root)}:
            layout.label(text=tr("Outside the map's collection"), icon="ERROR")
            layout.operator("psmap.into_map", icon="IMPORT", text=tr("Move into the map"))
        others = [o for o in context.selected_objects if o is not obj and is_brush(o)]
        if others:
            layout.operator("psmap.cut_through", icon="MOD_BOOLEAN",
                            text=tr(f"Cut through: {obj.name} cuts {len(others)} other(s)"))
        cuts = cutters.cuts_of(obj)
        if cuts:
            layout.operator("psmap.apply_cut", icon="CHECKMARK", text=tr(f"Apply cut ({len(cuts)} cutter(s))"))
        layout.label(text=tr("Make into:"))
        row = layout.row(align=True)
        if obj.type == "MESH" and obj.get("ps_entity") in (None, "world", "solid", "detail"):
            row.operator("psmap.make_model", icon="MESH_MONKEY", text=tr("Model"))
        row.operator("psmap.make_door", icon="MOD_SIMPLEDEFORM", text=tr("Door"))
        row.operator("psmap.make_mover", icon="TRIA_UP_BAR", text=tr("Mover"))
        if obj.ps_maker.kind:
            makers.draw(layout, obj)
        else:
            plain = [o for o in context.selected_objects if is_brush(o) and not o.ps_maker.kind]
            if len(plain) > 1 or obj.get("ps_parts"):
                # Pieces round a door (a wall with openings edited by hand, or an old wall of three brushes): one wall
                # with openings again.
                layout.operator("psmap.wall_again", icon="MOD_BUILD",
                                text=tr("Wall with openings again" if len(plain) < 2 else f"Join {len(plain)} into a wall with openings"))
        return
    kind = obj.get("ps_entity")
    if kind not in ("spawn", "bombsite", "buyzone", "light", "sun", "radarcolor", "ambient"):
        layout.label(text=tr("No settings for this object"))
        return
    col = layout.column(align=True)
    if kind in ("spawn", "buyzone"):
        row = col.row(align=True)
        for team in ("T", "CT"):
            op = row.operator("psmap.set", text=team, translate=False, depress=obj.get("ps_team") == team)
            op.key, op.value = "team", team
        if kind == "spawn":
            from . import training
            training.draw_spawn(col, obj)
    if kind == "bombsite":
        row = col.row(align=True)
        for site in ("A", "B"):
            op = row.operator("psmap.set", text=site, translate=False, depress=obj.get("ps_site") == site)
            op.key, op.value = "site", site
    if kind in ("light", "sun", "radarcolor", "ambient"):
        for key in {"light": ("ps_color", "ps_brightness", "ps_range"), "sun": ("ps_color", "ps_brightness"),
                    "radarcolor": ("ps_color",), "ambient": ("ps_color", "ps_brightness", "ps_fade")}[kind]:
            if key in obj:
                col.prop(obj, f'["{key}"]', text=tr(key[3:].capitalize()))
    if kind == "light":
        # How its light fades in the bake: gone at its range (the game's lamps), or as Blender's lights (never cut).
        row = col.row(align=True)
        natural = bool(obj.get("ps_natural"))
        for value, label in (("", "Fade to range"), ("1", "Natural fade")):
            op = row.operator("psmap.set", text=tr(label), depress=natural == bool(value))
            op.key, op.value = "natural", value
    if kind == "sun":
        from . import sun_way, preview_sun
        import math
        way = sun_way(obj)
        down = math.degrees(math.asin(max(-1.0, min(1.0, -way.z))))
        side = math.degrees(math.atan2(way.y, way.x)) % 360
        layout.label(text=tr(f"Light: {down:.0f}° down, {side:.0f}° from +X"), icon="LIGHT_SUN")
        on = preview_sun(context.scene) is not None
        layout.operator("psmap.preview_sun", icon="LIGHT_SUN", depress=on, text=tr("Preview sun shadows"))


class MAP_PT_object(MapTab, bpy.types.Panel):
    bl_category = "Object"
    bl_label = "Selected"

    def draw(self, context):
        draw_selected(self.layout, context)


class MAP_OT_selected_popup(bpy.types.Operator):
    bl_idname = "psmap.selected_popup"
    bl_label = "Settings of the selected"
    bl_description = "The selected brush's or entity's settings at the mouse (as the Object tab): changed, it is built again"

    def invoke(self, context, event):
        if not is_map_file(context.scene):
            return {"PASS_THROUGH"}
        return context.window_manager.invoke_popup(self, width=340)

    def draw(self, context):
        draw_selected(self.layout, context)

    def execute(self, context):
        return {"FINISHED"}


# ---------- Entities ----------
def entity_buttons(layout, kinds, columns=2):
    labels = {k: label for k, label, _ in ENTITIES}
    grid = layout.grid_flow(columns=columns, align=True)
    for k in kinds:
        grid.operator("psmap.add_entity", text=tr(labels[k])).kind = k


class MAP_PT_entities_players(MapTab, bpy.types.Panel):
    bl_category = "Entities"
    bl_label = "Players"

    def draw(self, context):
        entity_buttons(self.layout, ("spawn_t", "spawn_ct", "spawn_bot"))


class MAP_PT_entities_zones(MapTab, bpy.types.Panel):
    bl_category = "Entities"
    bl_label = "Zones"

    def draw(self, context):
        entity_buttons(self.layout, ("site_a", "site_b", "buy_t", "buy_ct", "ladder", "killzone"))


class MAP_PT_entities_radar(MapTab, bpy.types.Panel):
    bl_category = "Entities"
    bl_label = "Radar"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        entity_buttons(self.layout, ("radar_layer", "radar_color", "radar_min", "radar_max"))


class MAP_PT_entities_training(MapTab, bpy.types.Panel):
    bl_category = "Entities"
    bl_label = "Training"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        entity_buttons(self.layout, ("rulepanel", "nobots", "spraytarget", "spraypattern", "aimscreen", "aimboard"))


# ---------- Light ----------
class MAP_PT_light_sky(MapTab, bpy.types.Panel):
    bl_category = "Light"
    bl_label = "Sky"

    def draw(self, context):
        from . import sky
        sky.draw_sky(self.layout, context.scene)


class MAP_PT_light_sun(MapTab, bpy.types.Panel):
    bl_category = "Light"
    bl_label = "Sun and lamps"

    def draw(self, context):
        from . import preview_sun
        on = preview_sun(context.scene) is not None
        self.layout.operator("psmap.preview_sun", icon="LIGHT_SUN", depress=on, text=tr("Preview sun shadows"))
        entity_buttons(self.layout, ("sun", "light", "ambient"), columns=3)


class MAP_PT_light_baked(MapTab, bpy.types.Panel):
    bl_category = "Light"
    bl_label = "Baked light"

    def draw(self, context):
        from . import sky
        sky.draw_baked(self.layout, context.scene)
        obj = context.active_object
        if obj is not None and obj.select_get() and is_brush(obj):
            sky.draw_density(self.layout, obj, context)


class MAP_PT_light_test(MapTab, bpy.types.Panel):
    bl_category = "Light"
    bl_label = "Test light (nothing baked)"

    def draw(self, context):
        self.layout.row(align=True).prop(context.scene, "ps_test_light", expand=True)


# ---------- Show ----------
class MAP_PT_view_groups(MapTab, bpy.types.Panel):
    bl_category = "Show"
    bl_label = "Show / hide"

    def draw(self, context):
        grid = self.layout.grid_flow(columns=3, align=True)
        for g, label, tip in GROUPS:
            shown = group_shown(context, g)
            grid.operator("psmap.toggle", text=tr(label), depress=shown, icon="HIDE_OFF" if shown else "HIDE_ON").group = g


class MAP_PT_view_overlays(MapTab, bpy.types.Panel):
    bl_category = "Show"
    bl_label = "In the views"

    def draw(self, context):
        overlay.draw(self.layout, context)


class MAP_PT_view_timings(MapTab, bpy.types.Panel):
    bl_category = "Show"
    bl_label = "Timings"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        walk.draw(self.layout, context)


# ---------- Play ----------
def draw_status(layout, scene):
    """What the export is doing (its bar, Stop), or why it failed."""
    from . import _export, draw_progress
    if _export["proc"] is not None:
        draw_progress(layout)
    elif busy():
        layout.label(text=tr("Working… (don't press again)"), icon="TIME")
    if scene.ps_status:
        failed = scene.ps_status.startswith("Export failed")
        layout.label(text=tr(scene.ps_status), icon="ERROR" if failed else "TIME" if _export["proc"] is not None else "INFO")
        if failed:
            layout.operator("psmap.open_log", icon="TEXT")


class MAP_PT_play(MapTab, bpy.types.Panel):
    bl_category = "Play"
    bl_label = "1 · Check"

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        layout.operator("psmap.check", icon="VIEWZOOM")
        for i, item in enumerate(scene.ps_issues):
            row = layout.row(align=True)
            icon = {"error": "ERROR", "warning": "ERROR", "info": "INFO", "ok": "CHECKMARK"}.get(item.level, "DOT")
            row.label(text=tr(item.text), icon=icon)
            if item.level != "ok":
                row.operator("psmap.go", text="", icon="VIEWZOOM").index = i
                if "triangles drawn" in item.text:
                    row.operator("psmap.select_heavy", text="", icon="RESTRICT_SELECT_OFF")


class MAP_PT_play_test(MapTab, bpy.types.Panel):
    bl_category = "Play"
    bl_label = "2 · Test on this computer"

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        layout.prop(scene, "ps_ruleset", text=tr("Mode"))
        from . import lights_convert
        if lights_convert.blender_sun(scene) is not None:
            # Which sun the play and the bake take (Bake below too): the map's own, or Blender's sun lamp.
            row = layout.row(align=True)
            row.label(text=tr("Sun"), icon="LIGHT_SUN")
            row.prop(scene, "ps_sun_source", expand=True)
        row = layout.row(align=True)
        row.scale_y = 1.4
        row.enabled = not busy()
        op = row.operator("psmap.export_play", text=tr("Test and play"), icon="PLAY")
        op.play, op.test = True, True
        if not game_path():
            layout.label(text=tr("No game set: Test opens Unity" if HAS_UNITY else "No game set (add-on Preferences)"),
                         icon="ERROR")
        elif (game_reads() or MAP_FORMAT) < MAP_FORMAT:
            layout.label(text=tr("The game is too old: update it"), icon="ERROR")
        draw_status(layout, scene)


class MAP_PT_play_bake(MapTab, bpy.types.Panel):
    bl_category = "Play"
    bl_label = "3 · Bake light and play"

    def draw(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.enabled = not busy()
        op = row.operator("psmap.export_play", text=tr("Bake Fast & play"), icon="LIGHT_SUN")
        op.play, op.test, op.bake = True, True, "fast"
        op = row.operator("psmap.export_play", text=tr("Bake Final & play"), icon="SHADING_RENDERED")
        op.play, op.test, op.bake = True, True, "final"
        row.menu("MAP_MT_bake_again", text="", icon="FILE_REFRESH")
        from . import bake_view
        state, text = bake_view()
        if text:
            layout.label(text=tr(text), icon={"ok": "CHECKMARK", "old": "ERROR", "none": "INFO"}.get(state, "INFO"))
        if state == "ok":
            layout.label(text=tr("Nothing changed: the buttons take this bake (Bake again: ⟳)"), icon="BLANK1")


class MAP_MT_bake_again(bpy.types.Menu):
    bl_label = "Bake again"
    bl_description = "Bake the light again even though nothing changed since the last bake"

    def draw(self, context):
        layout = self.layout
        layout.label(text=tr("Even though nothing changed:"))
        for mode, label, icon in (("fast", "Bake Fast again & play", "LIGHT_SUN"),
                                  ("final", "Bake Final again & play", "SHADING_RENDERED")):
            op = layout.operator("psmap.export_play", text=tr(label), icon=icon)
            op.play, op.test, op.bake, op.force = True, True, mode, True


class MAP_PT_play_share(MapTab, bpy.types.Panel):
    bl_category = "Play"
    bl_label = "4 · Share (.psmap)"

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.enabled = not busy()
        row = col.row(align=True)
        row.scale_y = 1.3
        op = row.operator("psmap.export_play", text=tr("Export .psmap"), icon="PACKAGE")
        op.play, op.test, op.share = False, False, True
        op = col.operator("psmap.export_play", text=tr("Bake Final & export .psmap"), icon="SHADING_RENDERED")
        op.play, op.test, op.share, op.bake = False, False, True, "final"


class MAP_PT_play_settings(MapTab, bpy.types.Panel):
    bl_category = "Play"
    bl_label = "Export settings"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        layout.label(text=tr("Texture size:"))
        layout.row(align=True).prop(scene, "ps_texture_size", expand=True)
        layout.prop(scene, "ps_cull_unseen", text=tr("Leave out faces nobody sees"))


class MAP_PT_play_more(MapTab, bpy.types.Panel):
    bl_category = "Play"
    bl_label = "Unity (the game's project)"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return HAS_UNITY and is_map_file(context.scene)

    def draw(self, context):
        layout = self.layout
        layout.label(text=tr("Baked in the Unity editor:"))
        row = layout.row(align=True)
        row.enabled = not busy()
        op = row.operator("psmap.export_play", text=tr("Export and play"), icon="RENDER_STILL")
        op.play, op.test = True, False
        op = row.operator("psmap.export_play", text=tr("Compile only"))
        op.play, op.test = False, False


class MAP_PT_play_radar(MapTab, bpy.types.Panel):
    bl_category = "Play"
    bl_label = "Radar"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.prop(context.scene, "ps_radar", text="")

    def draw(self, context):
        scene = context.scene
        col = self.layout.column(align=True)
        col.enabled = scene.ps_radar
        col.label(text=tr("Resolution:"))
        col.row(align=True).prop(scene, "ps_radar_resolution", expand=True)
        col.prop(scene, "ps_radar_cover")
        row = col.row(align=True)
        row.prop(scene, "ps_radar_ao", text=tr("Shading"))
        sub = row.row(align=True)
        sub.enabled = scene.ps_radar_ao
        sub.prop(scene, "ps_radar_ao_strength", text=tr("Strength"))
        row = col.row(align=True)
        row.prop(scene, "ps_radar_shadow", text=tr("Outer shadow"))
        row.prop(scene, "ps_radar_tints", text=tr("Zone tints"))
        col.separator()
        col.label(text=tr("Own pictures (instead of the made ones):"))
        for i in range(4):
            col.prop(scene, f"ps_radar_image_{i}", text=tr(f"Layer {i}"))


class MAP_PT_play_workshop(MapTab, bpy.types.Panel):
    bl_category = "Play"
    bl_label = "Workshop card"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        scene = context.scene
        col = self.layout.column(align=True)
        # Empty: the .blend's name, shown greyed in the field.
        col.prop(scene, "ps_map_name", text=tr("Name"),
                 placeholder=os.path.splitext(os.path.basename(bpy.data.filepath))[0] or "the .blend's name")
        col.prop(scene, "ps_author", text=tr("Author"))
        col.prop(scene, "ps_description", text=tr("About"))
        col.prop(scene, "ps_version", text=tr("Version"))
        row = self.layout.row(align=True)
        row.operator("psmap.preview", icon="RESTRICT_RENDER_OFF")
        row.label(text=tr("Has a picture" if has_preview() else "No picture yet"), icon="CHECKMARK" if has_preview() else "INFO")


# ---------- Pie menus ----------
class MAP_MT_tools_pie(bpy.types.Menu):
    bl_idname = "MAP_MT_tools_pie"
    bl_label = "Brush tools"

    def draw(self, context):
        pie = self.layout.menu_pie()
        # Left, right, down, up, then up-left, up-right, down-left, down-right.
        col = pie.column(align=True)
        op = col.operator("psmap.opening", text=tr("Door"), icon="MOD_BOOLEAN")
        op.width, op.height, op.sill = 64, 112, 0
        op = col.operator("psmap.opening", text=tr("Hole"), icon="MOD_BOOLEAN")
        op.width, op.height, op.sill = 64, 64, 0
        col.operator("psmap.cut_through", icon="MOD_BOOLEAN")
        op = pie.operator("psmap.opening", text=tr("Window"), icon="MOD_BOOLEAN")
        op.width, op.height, op.sill = 48, 48, 40
        col = pie.column(align=True)
        col.operator("psmap.box", icon="MESH_CUBE")
        col.operator("psmap.cylinder", icon="MESH_CYLINDER")
        col.operator("psmap.clip", icon="SCULPTMODE_HLT")
        pie.operator("psmap.draw_brush", icon="ADD")
        pie.operator("psmap.hollow", icon="MOD_SOLIDIFY")
        pie.operator("psmap.resize", text=tr("Resize"), icon="FULLSCREEN_ENTER")
        pie.operator("psmap.stairs", icon="MOD_ARRAY")
        pie.operator("psmap.arch", icon="SPHERECURVE")


class MAP_MT_materials_pie(bpy.types.Menu):
    bl_idname = "MAP_MT_materials_pie"
    bl_label = "Materials"

    def draw(self, context):
        pie = self.layout.menu_pie()
        col = pie.column(align=True)
        col.label(text=tr("Colours"))
        for name, _ in DEV:
            col.operator("psmap.material", text=tr(name[4:])).name = name
        col = pie.column(align=True)
        col.label(text=tr("Tool textures"))
        for tool, name, _, tip in TOOLS:
            col.operator("psmap.material", text=tr(name[5:])).name = name
        box = pie.box()
        box.label(text=tr("Surfaces"))
        grid = box.grid_flow(columns=3, align=True)
        for surface, name, _ in DEV_SURFACES:
            grid.operator("psmap.material", text=tr(name[4:])).name = name


class MAP_OT_nudge(bpy.types.Operator):
    bl_idname = "psmap.nudge"
    bl_label = "Nudge"
    bl_description = "The selected one grid step that way in the view under the mouse (Hammer's arrow keys)"
    bl_options = {"REGISTER", "UNDO"}
    dx: bpy.props.IntProperty(options={"HIDDEN"})
    dy: bpy.props.IntProperty(options={"HIDDEN"})

    def invoke(self, context, event):
        if not is_map_file(context.scene) or context.region_data is None or not context.selected_objects:
            return {"PASS_THROUGH"}  # another file, another editor: Blender's own keys (frames)
        from mathutils import Vector
        rot = context.region_data.view_rotation
        right, up = rot @ Vector((1, 0, 0)), rot @ Vector((0, 1, 0))
        if context.region_data.view_perspective != "ORTHO":
            # The 3D view: along the floor (up: away from the eye).
            right.z = up.z = 0.0
            if up.length < 1e-6:
                up = rot @ Vector((0, 0, -1))
                up.z = 0.0

        def axis_of(v):
            k = max(range(3), key=lambda i: abs(v[i]))
            out = Vector()
            out[k] = 1.0 if v[k] > 0 else -1.0
            return out
        move = axis_of(right) * self.dx + axis_of(up) * self.dy
        step = context.scene.ps_grid_units * UNIT
        for o in context.selected_objects:
            if o.parent is None or not o.parent.select_get():
                o.location += move * step
        return {"FINISHED"}


class MAP_OT_pie(bpy.types.Operator):
    bl_idname = "psmap.pie"
    bl_label = "Map tools menu"
    bl_description = "The brush tools (Q) or the materials (Shift+Q) round the mouse, in a map file"
    menu: bpy.props.StringProperty()

    def invoke(self, context, event):
        if not is_map_file(context.scene):
            return {"PASS_THROUGH"}  # another file: Blender's own key
        bpy.ops.wm.call_menu_pie(name=self.menu)
        return {"FINISHED"}


# The order here is the tabs' order in the sidebar (a tab comes where its first panel is registered).
CLASSES = [MAP_MT_bake_again, MAP_PT_build_start, MAP_PT_build_map, MAP_PT_build_brushes, MAP_PT_build_tools, MAP_PT_build_mirror,
           MAP_PT_build_materials,
           MAP_PT_object,
           MAP_PT_entities_players, MAP_PT_entities_zones, MAP_PT_entities_radar, MAP_PT_entities_training,
           MAP_PT_art_group, MAP_PT_art_materials, MAP_PT_art_faces, MAP_PT_art_trims, MAP_PT_art_props, MAP_PT_art_decals,
           MAP_PT_light_sky, MAP_PT_light_sun, MAP_PT_light_baked, MAP_PT_light_test,
           MAP_PT_view_groups, MAP_PT_view_overlays, MAP_PT_view_timings,
           MAP_PT_play, MAP_PT_play_test, MAP_PT_play_bake, MAP_PT_play_share, MAP_PT_play_settings, MAP_PT_play_radar,
           MAP_PT_play_workshop, MAP_PT_play_more,
           MAP_MT_tools_pie, MAP_MT_materials_pie, MAP_OT_pie, MAP_OT_selected_popup, MAP_OT_nudge]
_keys = []


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    kc = bpy.context.window_manager.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name="Object Mode", space_type="EMPTY")
        for key, shift, menu in (("Q", False, "MAP_MT_tools_pie"), ("Q", True, "MAP_MT_materials_pie")):
            kmi = km.keymap_items.new("psmap.pie", key, "PRESS", shift=shift)
            kmi.properties.menu = menu
            _keys.append((km, kmi))
        _keys.append((km, km.keymap_items.new("psmap.selected_popup", "F", "PRESS")))
        _keys.append((km, km.keymap_items.new("psmap.collision_view", "C", "PRESS", shift=True, alt=True)))
        # Ctrl+Z after changing a tool's panel (F9): the settings before, not the whole tool (else Blender's undo).
        _keys.append((km, km.keymap_items.new("psmap.panel_undo", "Z", "PRESS", ctrl=True)))
        for key, dx, dy in (("LEFT_ARROW", -1, 0), ("RIGHT_ARROW", 1, 0), ("UP_ARROW", 0, 1), ("DOWN_ARROW", 0, -1)):
            kmi = km.keymap_items.new("psmap.nudge", key, "PRESS", repeat=True)
            kmi.properties.dx, kmi.properties.dy = dx, dy
            _keys.append((km, kmi))


def unregister():
    for km, kmi in _keys:
        km.keymap_items.remove(kmi)
    _keys.clear()
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
