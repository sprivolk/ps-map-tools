"""Starting out: a new map file made ready (File > New > PlaceholderShooter map), and the help — the keys and the tools in
short, the manual (README.md beside the add-on)."""
import os
import re

import bpy
from mathutils import Vector

from . import UNIT, ADDON_DIR, apply_grid, ensure_materials, material, child_collection

MAPS_FOLDER = os.path.join(os.path.expanduser("~"), "Documents", "PlaceholderShooter Maps")
MANUAL = os.path.join(ADDON_DIR, "README.md")
_pending = []  # (name, path) of the map being made: set up once the empty file is open


def set_up(name, path):
    """The new map's file: its collection (Seen, Collision, Clips, Entities), a floor, a spawn a side, the grid; saved."""
    from .brush_tools import box_brush
    scene = bpy.context.scene
    root = bpy.data.collections.new(f"My {name}")
    scene.collection.children.link(root)
    for part in ("Seen", "Collision", "Clips", "Entities"):
        root.children.link(bpy.data.collections.new(part))
    scene.ps_map_collection = root
    scene.ps_grid_units = 16
    ensure_materials()
    # A floor 1024 x 1024 units, its top at 0; a spawn a side on it, looking at each other.
    floor = box_brush("Floor", (-512 * UNIT, -512 * UNIT, -16 * UNIT), (512 * UNIT, 512 * UNIT, 0.0),
                      [bpy.data.materials.get("Dev Concrete") or material("Dev Grey", (0.55, 0.55, 0.55))],
                      child_collection(scene, "Seen"))
    entities = child_collection(scene, "Entities")
    for team, x, turn in (("T", -320, 0.0), ("CT", 320, 3.14159265)):
        spawn = bpy.data.objects.new(f"Spawn {team}", None)
        spawn.empty_display_type = "ARROWS"
        spawn.empty_display_size = 0.8
        spawn.location = Vector((x * UNIT, 0.0, 0.0))
        spawn.rotation_euler = (0.0, 0.0, turn)
        spawn["ps_entity"] = "spawn"
        spawn["ps_team"] = team
        entities.objects.link(spawn)
    scene.cursor.location = (0.0, 0.0, 0.0)
    for o in list(bpy.context.view_layer.objects.selected):
        o.select_set(False)
    floor.select_set(True)
    bpy.context.view_layer.objects.active = floor
    os.makedirs(os.path.dirname(path), exist_ok=True)
    bpy.ops.wm.save_as_mainfile(filepath=path)
    window = bpy.context.window_manager.windows[0] if bpy.context.window_manager.windows and not bpy.app.background else None
    if window is not None:
        for area in window.screen.areas:
            if area.type == "VIEW_3D":
                region = next(r for r in area.regions if r.type == "WINDOW")
                with bpy.context.temp_override(window=window, area=area, region=region):
                    if not area.spaces[0].region_quadviews:
                        bpy.ops.screen.region_quadview()
                    bpy.ops.view3d.view_all()
                area.spaces[0].show_region_ui = True
                break
        apply_grid(bpy.context)


def finish_new_map():
    if _pending:
        name, path = _pending.pop()
        try:
            set_up(name, path)
        except Exception as e:  # noqa: BLE001  (said in the status bar; the empty file stays)
            print(f"New map: {e}")
    return None


class MAP_OT_new_map(bpy.types.Operator):
    bl_idname = "psmap.new_map"
    bl_label = "New PlaceholderShooter map"
    bl_description = ("A new map file, ready to build in: its collections, a floor, a spawn a side, the grid and four "
                      "views; saved as <folder>/<name>/<name>.blend (the file's name is the map's)")
    name: bpy.props.StringProperty(name="Name", default="de_mymap",
                                   description="Letters, digits and _ (as de_dust2): the map's name in the game")
    folder: bpy.props.StringProperty(name="Folder", subtype="DIR_PATH", default=MAPS_FOLDER)

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "name")
        layout.prop(self, "folder")
        if bpy.data.is_dirty:
            layout.label(text="The open file is saved first" if bpy.data.filepath else
                         "The open file has changes and no name: they are lost", icon="ERROR")

    def execute(self, context):
        name = self.name.strip()
        if not re.fullmatch(r"[A-Za-z0-9_]+", name):
            self.report({"ERROR"}, "The name: letters, digits and _ only (as de_dust2)")
            return {"CANCELLED"}
        folder = bpy.path.abspath(self.folder) or MAPS_FOLDER
        path = os.path.join(folder, name, name + ".blend")
        if os.path.exists(path):
            self.report({"ERROR"}, f"There is a map of that name already: {path}")
            return {"CANCELLED"}
        if bpy.data.is_dirty and bpy.data.filepath:
            bpy.ops.wm.save_mainfile()
        _pending.append((name, path))
        bpy.ops.wm.read_homefile(use_empty=True)
        bpy.app.timers.register(finish_new_map, first_interval=0.2)
        return {"FINISHED"}


HELP = [
    ("Keys (Object Mode, in a map file)", [
        "Q: brush tools round the mouse   Shift+Q: materials",
        "F: the selected's settings at the mouse",
        "[ ]: the grid finer / coarser   Ctrl while moving: off the grid",
    ]),
    ("Building", [
        "Draw brush: drag a rectangle in a flat view, then its height in another",
        "Resize: drag the yellow handles of the selected in a flat view",
        "Make a room / Arch / Stairs: fill the box selected (draw it first)",
        "Door, Window: select a wall (or a room), put the 3D cursor where it goes",
        "Stairs, Arch, Room, walls with doors, floors with holes: their settings",
        "   open at the mouse after the tool (F, Object tab); Ctrl+Z: one change back",
        "Materials: Colours, Surfaces (bullets, steps), Tools (clip, nodraw...)",
    ]),
    ("Entities", [
        "Spawn T / CT, Bomb site A / B, Buy zone: at the 3D cursor",
        "Ladder, zones: a brush selected becomes it",
    ]),
    ("Playing it", [
        "Check the map first (Play tab): what is wrong, and where",
        "With the game on this computer: Test and play (set it in Preferences)",
        "On a phone: Export .psmap, send the file, Workshop → Import map…",
    ]),
]


class MAP_OT_manual(bpy.types.Operator):
    bl_idname = "psmap.manual"
    bl_label = "Open the manual"
    bl_description = "The map tools' manual (README.md beside the add-on), in the system's viewer"

    def execute(self, context):
        if not os.path.exists(MANUAL):
            self.report({"ERROR"}, "The manual is not beside the add-on")
            return {"CANCELLED"}
        bpy.ops.wm.path_open(filepath=MANUAL)
        return {"FINISHED"}


class MAP_PT_help(bpy.types.Panel):
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "Build"
    bl_label = "Help"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        layout = self.layout
        for title, lines in HELP:
            col = layout.column(align=True)
            col.label(text=title, icon="INFO")
            for line in lines:
                col.label(text="   " + line)
        row = layout.row(align=True)
        row.operator("psmap.manual", icon="HELP")
        row.operator("psmap.new_map", text="New map", icon="FILE_NEW")


def file_new(self, context):
    self.layout.operator("psmap.new_map", text="PlaceholderShooter map", icon="FILE_NEW")


CLASSES = [MAP_OT_new_map, MAP_OT_manual, MAP_PT_help]


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    bpy.types.TOPBAR_MT_file_new.append(file_new)


def unregister():
    bpy.types.TOPBAR_MT_file_new.remove(file_new)
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
