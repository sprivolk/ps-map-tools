"""What the views show besides the map: each spawn as a player's box with where it looks, names over the entities, the
size of the selected brushes in units, and the tops of ledges coloured by how a player gets up there."""
import math

import blf
import bpy
import gpu
from bpy_extras.view3d_utils import location_3d_to_region_2d
from gpu_extras.batch import batch_for_shader
from mathutils import Vector
from mathutils.bvhtree import BVHTree

from . import UNIT, map_collection, map_objects, is_brush, solid_faces

_handles = []
_ledges = {"tris": [], "colours": []}
_hidden = {"tris": [], "kept": []}  # the faces the export leaves out (red) and those marked always drawn (cyan)
# Heights a player gets up (CS units): a step walked up, a jump, a jump ducking at its top, a boost on a teammate's head.
REACH = [(18, (0.25, 0.85, 0.3, 0.45), "walk up"), (57, (0.95, 0.85, 0.2, 0.45), "jump"),
         (64, (1.0, 0.55, 0.1, 0.45), "crouch-jump"), (130, (0.7, 0.35, 0.95, 0.45), "boost only"),
         (99999, (0.9, 0.15, 0.15, 0.45), "out of reach")]
TEAM_COLOURS = {"T": (0.95, 0.35, 0.2, 1.0), "CT": (0.3, 0.55, 1.0, 1.0)}


def objects(scene):
    root = map_collection(scene)
    return [o for o in map_objects(root) if o.visible_get()]


def label_of(o):
    kind = o.get("ps_entity")
    if kind == "spawn":
        return f"{o.get('ps_team', 'T')} spawn"
    if kind == "bombsite":
        return f"Site {o.get('ps_site', 'A')}"
    if kind == "buyzone":
        return f"Buy {o.get('ps_team', '')}".strip()
    if kind == "light":
        return "Lamp"
    if kind == "sun":
        return "Sun"
    tools = {str(m.get("ps_tool", "")) for m in o.data.materials if m} if o.type == "MESH" else set()
    if kind == "killzone" or tools == {"killzone"}:
        return "Kill zone"
    if kind == "ladder" or tools == {"ladder"}:
        return "Ladder"
    return None


def draw_view():
    scene = bpy.context.scene
    if scene is None or not hasattr(scene, "ps_show_spawns"):
        return
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    gpu.state.blend_set("ALPHA")
    if scene.ps_show_hidden:
        gpu.state.depth_test_set("LESS_EQUAL")
        for key, colour in (("tris", (1.0, 0.1, 0.1, 0.55)), ("kept", (0.1, 0.9, 1.0, 0.5))):
            if _hidden[key]:
                batch = batch_for_shader(shader, "TRIS", {"pos": [p for t in _hidden[key] for p in t]})
                shader.uniform_float("color", colour)
                batch.draw(shader)
    if scene.ps_show_ledges and _ledges["tris"]:
        gpu.state.depth_test_set("LESS_EQUAL")
        for colour in {tuple(c) for c in _ledges["colours"]}:
            tris = [p for t, c in zip(_ledges["tris"], _ledges["colours"]) if tuple(c) == colour for p in t]
            batch = batch_for_shader(shader, "TRIS", {"pos": tris})
            shader.uniform_float("color", colour)
            batch.draw(shader)
    if scene.ps_show_spawns:
        gpu.state.depth_test_set("LESS_EQUAL")
        gpu.state.line_width_set(2.0)
        hw, h = 16 * UNIT, 72 * UNIT
        for o in objects(scene):
            if o.get("ps_entity") != "spawn":
                continue
            p = o.matrix_world.translation
            yaw = o.matrix_world.to_euler().z
            c = [Vector((p.x + sx * hw, p.y + sy * hw, p.z + sz * h)) for sx in (-1, 1) for sy in (-1, 1) for sz in (0, 1)]
            edges = [(0, 1), (2, 3), (4, 5), (6, 7), (0, 2), (1, 3), (4, 6), (5, 7), (0, 4), (1, 5), (2, 6), (3, 7)]
            eye = p + Vector((0, 0, 64 * UNIT))
            look = eye + Vector((math.cos(yaw), math.sin(yaw), 0)) * 0.9
            lines = [c[a] for e in edges for a in e] + [eye, look]
            batch = batch_for_shader(shader, "LINES", {"pos": lines})
            shader.uniform_float("color", TEAM_COLOURS.get(str(o.get("ps_team", "T")), (1, 1, 1, 1)))
            batch.draw(shader)
        gpu.state.line_width_set(1.0)
    from . import LEAK
    if len(LEAK["path"]) > 1:
        # The leak Check map found (Hammer's pointfile): from a spawn to where the air gets out, seen through walls.
        gpu.state.depth_test_set("NONE")
        gpu.state.line_width_set(4.0)
        pts = [Vector(p) for p in LEAK["path"]]
        batch = batch_for_shader(shader, "LINE_STRIP", {"pos": pts})
        shader.uniform_float("color", (1.0, 0.1, 0.1, 0.9))
        batch.draw(shader)
        gpu.state.line_width_set(1.0)
    gpu.state.depth_test_set("NONE")
    gpu.state.blend_set("NONE")


def draw_text():
    context = bpy.context
    scene = context.scene
    region, rv3d = context.region, context.region_data
    if scene is None or rv3d is None or not hasattr(scene, "ps_show_labels"):
        return
    blf.size(0, 13)
    if scene.ps_show_labels:
        for o in objects(scene):
            text = label_of(o)
            if not text:
                continue
            if o.type == "MESH":
                at = o.matrix_world @ (sum((Vector(b) for b in o.bound_box), Vector()) / 8)
            else:
                at = o.matrix_world.translation + Vector((0, 0, 80 * UNIT if o.get("ps_entity") == "spawn" else 0.2))
            xy = location_3d_to_region_2d(region, rv3d, at)
            if xy is None:
                continue
            blf.color(0, 1.0, 1.0, 1.0, 0.95)
            blf.position(0, xy.x - blf.dimensions(0, text)[0] / 2, xy.y, 0)
            blf.draw(0, text)
    if scene.ps_show_sizes:
        for o in context.selected_objects:
            if not is_brush(o):
                continue
            corners = [o.matrix_world @ Vector(b) for b in o.bound_box]
            size = [max(c[i] for c in corners) - min(c[i] for c in corners) for i in range(3)]
            text = " x ".join(f"{s / UNIT:g}" for s in (round(v / UNIT) * UNIT for v in size)) + " u"
            top = Vector((sum(c.x for c in corners) / 8, sum(c.y for c in corners) / 8, max(c.z for c in corners)))
            xy = location_3d_to_region_2d(region, rv3d, top)
            if xy is None:
                continue
            blf.color(0, 1.0, 0.85, 0.35, 1.0)
            blf.position(0, xy.x - blf.dimensions(0, text)[0] / 2, xy.y + 8, 0)
            blf.draw(0, text)


def collidable_tree(scene):
    points, polygons = [], []  # read only: no data made or removed (see solids in __init__)
    for o in objects(scene):
        if o.type != "MESH":
            continue
        faces = solid_faces(o)
        if faces:
            mw, first = o.matrix_world, len(points)
            points += [mw @ v.co for v in o.data.vertices]
            polygons += [[first + i for i in p.vertices] for p in faces]
    return BVHTree.FromPolygons(points, polygons) if polygons else None


class MAP_OT_ledges(bpy.types.Operator):
    bl_idname = "psmap.ledges"
    bl_label = "Ledge heights"
    bl_description = ("Colour the tops a player stands on by how one gets up there from the floor beside: green walked up "
                      "(18), yellow a jump (57), orange a crouch-jump (64), purple a boost, red out of reach")

    def execute(self, context):
        scene = context.scene
        if scene.ps_show_ledges:
            scene.ps_show_ledges = False
            _ledges["tris"], _ledges["colours"] = [], []
            return {"FINISHED"}
        tree = collidable_tree(scene)
        if tree is None:
            return {"CANCELLED"}
        tris, colours = [], []
        reach_out = 20 * UNIT
        lift = 0.5 * UNIT
        for o in objects(scene):
            if o.type != "MESH" or not is_brush(o) or o.get("ps_entity") not in ("world", "solid") or o.get("ps_nocollide"):
                continue
            mw = o.matrix_world
            rot = mw.to_3x3()
            for f in o.data.polygons:
                n = (rot @ f.normal).normalized()
                if n.z < 0.7:
                    continue
                pts = [mw @ o.data.vertices[i].co for i in f.vertices]
                top = sum((p.z for p in pts)) / len(pts)
                centre = sum(pts, Vector()) / len(pts)
                # The floors around it: just past each edge, straight down from its height.
                below = []
                for i in range(len(pts)):
                    a, b = pts[i], pts[(i + 1) % len(pts)]
                    mid = (a + b) / 2
                    out = Vector((mid.x - centre.x, mid.y - centre.y, 0))
                    if out.length < 1e-6:
                        continue
                    probe = mid + out.normalized() * reach_out + Vector((0, 0, -0.01))
                    hit = tree.ray_cast(probe, Vector((0, 0, -1)), 100.0)
                    if hit[0] is not None:
                        below.append(hit[0].z)
                if not below:
                    continue
                rise = (top - max(below)) / UNIT
                if rise < 1:
                    continue  # level with a floor beside it: a floor, not a ledge
                colour = next(c for limit, c, _ in REACH if rise <= limit)
                for i in range(1, len(pts) - 1):
                    tris.append([pts[0] + Vector((0, 0, lift)), pts[i] + Vector((0, 0, lift)), pts[i + 1] + Vector((0, 0, lift))])
                    colours.append(colour)
        _ledges["tris"], _ledges["colours"] = tris, colours
        scene.ps_show_ledges = True
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}


def exporter():
    """The map exporter itself (ArtSource/Export/export_map.py): the preview runs its own rules."""
    import importlib.util
    from . import EXPORTER
    spec = importlib.util.spec_from_file_location("ps_export_map", EXPORTER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def lifted(points, normal):
    return [p + normal * (0.3 * UNIT) for p in points]


class MAP_OT_hidden(bpy.types.Operator):
    bl_idname = "psmap.hidden"
    bl_label = "Faces left out"
    bl_description = ("Show in red the faces the export leaves out as never seen (covered all over by other brushes, or "
                      "nodraw), in cyan those marked always drawn")

    def execute(self, context):
        scene = context.scene
        if scene.ps_show_hidden:
            scene.ps_show_hidden = False
            _hidden["tris"], _hidden["kept"] = [], []
            return {"FINISHED"}
        if context.object is not None and context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        em = exporter()
        brushes = [o for o in objects(scene) if is_brush(o)]
        # A brush in pieces (stairs) as the exporter takes it: each piece a brush of its own (unlinked, removed after).
        pieces = [p for o in brushes if o.get("ps_parts") for p in em.split_parts(o)]
        brushes = [o for o in brushes if not o.get("ps_parts")] + pieces
        seen, solid = em.brush_roles(brushes)
        tris, kept = [], []
        for o in seen:
            bm, hidden = em.clip_brush(o, solid)
            hidden = set(hidden)
            keep = bm.faces.layers.int.get(em.KEEP)
            for f in bm.faces:
                pts = lifted([v.co.copy() for v in f.verts], f.normal)
                target = tris if f in hidden else kept if keep is not None and f[keep] else None
                if target is not None:
                    target += [[pts[0], pts[i], pts[i + 1]] for i in range(1, len(pts) - 1)]
            bm.free()
        for p in pieces:
            mesh = p.data
            bpy.data.objects.remove(p)
            bpy.data.meshes.remove(mesh)
        _hidden["tris"], _hidden["kept"] = tris, kept
        scene.ps_show_hidden = True
        for area in context.screen.areas:
            area.tag_redraw()
        return {"FINISHED"}


class MAP_OT_keep(bpy.types.Operator):
    bl_idname = "psmap.keep"
    bl_label = "Always draw"
    bl_description = ("Edit Mode: the selected faces are always drawn, never left out as hidden (a spot only a trick "
                      "boost reaches); the lock off clears it")
    bl_options = {"REGISTER", "UNDO"}
    value: bpy.props.IntProperty(default=1)

    @classmethod
    def poll(cls, context):
        return context.object is not None and context.object.mode == "EDIT" and context.object.type == "MESH"

    def execute(self, context):
        import bmesh as bm_
        count = 0
        for obj in context.objects_in_mode:
            bm = bm_.from_edit_mesh(obj.data)
            layer = bm.faces.layers.int.get("ps_keep") or bm.faces.layers.int.new("ps_keep")
            for f in bm.faces:
                if f.select:
                    f[layer] = self.value
                    count += 1
            bm_.update_edit_mesh(obj.data)
        self.report({"INFO"}, f"{count} faces " + ("always drawn" if self.value else "back to normal"))
        return {"FINISHED"}


CLASSES = [MAP_OT_ledges, MAP_OT_hidden, MAP_OT_keep]


def draw(layout, context):
    scene = context.scene
    box = layout.box()
    box.label(text="In the views", icon="OVERLAY")
    row = box.row(align=True)
    row.prop(scene, "ps_show_spawns", text="Players", toggle=True)
    row.prop(scene, "ps_show_labels", text="Names", toggle=True)
    row.prop(scene, "ps_show_sizes", text="Sizes", toggle=True)
    box.operator("psmap.ledges", text="Hide ledge heights" if scene.ps_show_ledges else "Show ledge heights", icon="SORTSIZE")
    row = box.row(align=True)
    row.operator("psmap.hidden", text="Hide the preview" if scene.ps_show_hidden else "Faces left out", icon="HIDE_ON")
    op = row.operator("psmap.keep", text="Always draw", icon="LOCKED")
    op.value = 1
    op = row.operator("psmap.keep", text="", icon="UNLOCKED")
    op.value = 0
    if scene.ps_show_hidden:
        box.label(text=f"Red: {len(_hidden['tris'])} triangles the export leaves out")
        box.label(text="Cyan: marked always drawn (Edit Mode: select faces, Always draw)")
    if scene.ps_show_ledges:
        col = box.column(align=True)
        for limit, colour, text in REACH:
            col.label(text=f"{text}" + (f" (up to {limit} u)" if limit < 99999 else ""))


def register():
    bpy.types.Scene.ps_show_spawns = bpy.props.BoolProperty(name="Players", default=True,
                                                             description="Each spawn as a player's box and where it looks")
    bpy.types.Scene.ps_show_labels = bpy.props.BoolProperty(name="Names", default=True, description="Names over the entities")
    bpy.types.Scene.ps_show_sizes = bpy.props.BoolProperty(name="Sizes", default=True,
                                                            description="The size of the selected brushes in units")
    bpy.types.Scene.ps_show_ledges = bpy.props.BoolProperty(name="Ledges", default=False)
    bpy.types.Scene.ps_show_hidden = bpy.props.BoolProperty(name="Faces left out", default=False)
    for c in CLASSES:
        bpy.utils.register_class(c)
    _handles.append((bpy.types.SpaceView3D.draw_handler_add(draw_view, (), "WINDOW", "POST_VIEW"), "WINDOW"))
    _handles.append((bpy.types.SpaceView3D.draw_handler_add(draw_text, (), "WINDOW", "POST_PIXEL"), "WINDOW"))


def unregister():
    for handle, region in _handles:
        bpy.types.SpaceView3D.draw_handler_remove(handle, region)
    _handles.clear()
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
    for prop in ("ps_show_spawns", "ps_show_labels", "ps_show_sizes", "ps_show_ledges", "ps_show_hidden"):
        delattr(bpy.types.Scene, prop)
