"""
PlaceholderShooter map tools: making a map in Blender the way Hammer makes one.

- Brushes: boxes drawn on the grid (or any mesh put in the map's "Seen" collection). A brush is seen and collides as it is;
  its kind comes from its materials, like Hammer's tool textures (CLIP, NODRAW, GRENADECLIP, BLOCKBULLETS, KILL ZONE,
  LADDER). Its textures keep their size in the world as it moves and grows (texture lock).
- The grid in game units: [ and ] halve and double it (1 to 256 units), everything snaps to it, its size is shown.
- The "Map" tab (N panel): brushes, materials, entities added at the 3D cursor with their settings as fields,
  one-click visibility of collision, triggers, entities and references, a check of the map, and Export and play (the map
  is exported, compiled and baked by Unity and played there).

The map exporter (compiler/export_map.py) reads what this writes: ps_brush, ps_entity and ps_* properties, tool
materials (material["ps_tool"]). Nothing here is needed to read a map: a file made with it exports without it.
"""
bl_info = {
    "name": "PlaceholderShooter Map Tools",
    "author": "PlaceholderShooter",
    "version": (0, 2, 0),
    "blender": (4, 2, 0),
    "location": "3D View > Sidebar (N) > Map",
    "description": "Hammer-like map making: brushes, tool materials, the grid in game units, entities, check, export and play",
    "category": "3D View",
}

import json
import math
import os
import subprocess
import sys
import time

import blf
import bmesh
import bpy
import numpy as np
from bpy.app.handlers import persistent
from mathutils import Vector
from mathutils.bvhtree import BVHTree

UNIT = 0.025                      # metres in a game unit (CS units)
GRID_STEPS = [1, 2, 4, 8, 16, 32, 64, 128, 256]
TILE = 64 * UNIT                  # one tile of the Dev grid textures
DEV = [("Dev Grey", (0.55, 0.55, 0.55)), ("Dev Orange", (0.85, 0.45, 0.15)), ("Dev Blue", (0.25, 0.45, 0.8)),
       ("Dev Green", (0.35, 0.65, 0.3)), ("Dev Dark", (0.25, 0.25, 0.27))]
# Dev materials of a surface (Hammer's $surfaceprop): putting one on sets what bullets go through and what steps and hits
# sound like (Surfaces.json); the plain ones above are the default surface.
DEV_SURFACES = [("concrete", "Dev Concrete", (0.58, 0.58, 0.56)), ("brick", "Dev Brick", (0.62, 0.34, 0.26)),
                ("tile", "Dev Tile", (0.78, 0.78, 0.72)), ("plaster", "Dev Plaster", (0.86, 0.82, 0.72)),
                ("sheetrock", "Dev Sheetrock", (0.92, 0.92, 0.9)), ("wood", "Dev Wood", (0.62, 0.43, 0.24)),
                ("cardboard", "Dev Cardboard", (0.72, 0.6, 0.4)), ("plastic", "Dev Plastic", (0.3, 0.62, 0.72)),
                ("metal", "Dev Metal", (0.45, 0.5, 0.56)), ("solidmetal", "Dev Solid metal", (0.3, 0.33, 0.38)),
                ("metalpanel", "Dev Metal panel", (0.55, 0.6, 0.66)), ("metalvent", "Dev Metal vent", (0.5, 0.56, 0.6)),
                ("metalgrate", "Dev Metal grate", (0.5, 0.55, 0.5)), ("chainlink", "Dev Chain link", (0.6, 0.62, 0.58)),
                ("glass", "Dev Glass", (0.55, 0.8, 0.9)), ("dirt", "Dev Dirt", (0.45, 0.34, 0.24)),
                ("sand", "Dev Sand", (0.86, 0.76, 0.5))]
# Tool materials: id, material name, viewport colour, what it means.
TOOLS = [("clip", "TOOL Player clip", (1.0, 0.45, 0.1), "invisible wall for players"),
         ("nodraw", "TOOL Nodraw", (0.95, 0.85, 0.2), "face not drawn (the brush still collides)"),
         ("grenadeclip", "TOOL Grenade clip", (0.95, 0.4, 0.7), "invisible wall for thrown grenades"),
         ("blockbullets", "TOOL Block bullets", (0.6, 0.3, 0.9), "invisible wall for bullets"),
         ("killzone", "TOOL Kill zone", (0.9, 0.15, 0.15), "whoever enters dies"),
         ("ladder", "TOOL Ladder", (0.3, 0.8, 0.4), "a ladder on the wall behind it")]
SURFACES = ["default", "concrete", "brick", "tile", "plaster", "sheetrock", "metal", "solidmetal", "metalpanel", "metalvent",
            "metalgrate", "chainlink", "wood", "cardboard", "plastic", "glass", "dirt", "sand"]
RULESETS = [("sandbox", "Test run (free play)", "spawn at once and run around: no rounds, no sides to choose, every weapon"),
            ("wingman", "Wingman", "two a side, one site: choose a side, then rounds"),
            ("bomb", "Bomb defuse", "five a side: choose a side, then rounds"),
            ("ffa", "Free for all", ""), ("bomb_practice", "Bomb practice", "")]

ADDON_DIR = os.path.dirname(os.path.realpath(__file__))
ART = os.path.dirname(os.path.dirname(ADDON_DIR))
PROJECT = os.path.dirname(ART)
# The compiler (export, light bake, radar) goes with the add-on: a map is made with Blender and the add-on alone.
COMPILER = os.path.join(ADDON_DIR, "compiler")
EXPORTER = os.path.join(COMPILER, "export_map.py")
# Run from the game's project (the add-on linked from ArtSource/Addon): Unity is there to compile and play maps in.
HAS_UNITY = os.path.isfile(os.path.join(PROJECT, "ProjectSettings", "ProjectVersion.txt"))
REQUEST = os.path.join(PROJECT, "Temp", "ps_map_request.json")
STATUS = os.path.join(PROJECT, "Temp", "ps_map_status.json")  # written by Unity (MapPlayRequests)

_guard = [False]
_undoing = [False]  # Ctrl+Z / Ctrl+Shift+Z under way: the handler keeps its hands off (Blender is rebuilding the data)
_draw_handle = [None]
_grid_handle = [None]
_keymaps = []
_export = {"proc": None, "package": "", "ruleset": "", "log": "", "waiting": False, "since": 0.0, "test": False, "light": "faces"}


# ---------- The map's collections ----------
def map_collection(scene):
    """The collection that goes into the game: the scene's choice, or one named "My ..." with a "Seen" in it."""
    col = scene.ps_map_collection
    if col is not None:
        return col
    for c in bpy.data.collections:
        if c.name.startswith("My ") and any(ch.name.startswith("Seen") for ch in c.children):
            return c
    return None


def map_objects(root):
    """The objects of a collection and of the collections in it, read from the collections themselves. Not
    collection.all_objects: a cache Blender rebuilds later, which right after an undo (Ctrl+Z) can still hold objects
    already freed — read from a panel's draw, that crashed Blender."""
    found, seen = [], set()

    def walk(col, depth):
        if depth > 64:
            return
        for o in col.objects:
            if o is not None and o.name not in seen:
                seen.add(o.name)
                found.append(o)
        for child in col.children:
            walk(child, depth + 1)
    if root is not None:
        walk(root, 0)
    return found


def object_mode(context):
    """Out of Edit Mode (or any other) first: a tool that makes or removes objects, or selects them, works in Object Mode
    (bpy.ops.object.select_all refuses to run in Edit Mode: Arch pressed with a brush in Edit Mode failed on every redo)."""
    obj = context.view_layer.objects.active
    if obj is not None and obj.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")


def deselect_all(context):
    """Nothing selected, through the data (works in any mode, unlike bpy.ops.object.select_all)."""
    for o in [o for o in context.view_layer.objects.selected if o is not None]:  # one just removed is listed as None
        o.select_set(False)


def child_collection(scene, name):
    root = map_collection(scene)
    if root is None:
        root = bpy.data.collections.new("My map")
        scene.collection.children.link(root)
        scene.ps_map_collection = root
    for c in root.children:
        if c.name.split(".")[0] == name:
            return c
    c = bpy.data.collections.new(name)
    root.children.link(c)
    return c


# ---------- Materials ----------
def grid_image(name, colour):
    size, step = 512, 512 * 16 // 64
    px = np.ones((size, size, 4), dtype=np.float32)
    px[..., :3] = colour
    for i in range(0, size, step):
        px[i:i + 2, :, :3] *= 0.75
        px[:, i:i + 2, :3] *= 0.75
    px[0:5, :, :3] *= 0.55
    px[:, 0:5, :3] *= 0.55
    img = bpy.data.images.new(name, size, size, alpha=False)
    img.pixels.foreach_set(px.ravel())
    img.pack()
    return img


def material(name, colour, tool=None, surface=None):
    mat = bpy.data.materials.get(name)
    if mat is not None:
        return mat
    mat = bpy.data.materials.new(name)
    mat.use_nodes = True
    nodes = mat.node_tree.nodes
    nodes.clear()
    out = nodes.new("ShaderNodeOutputMaterial")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.inputs["Roughness"].default_value = 0.9
    mat.node_tree.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    if tool:
        bsdf.inputs["Base Color"].default_value = (*colour, 1.0)
        mat["ps_tool"] = tool
    else:
        tex = nodes.new("ShaderNodeTexImage")
        tex.image = grid_image(name + " grid", colour)
        mat.node_tree.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    if surface:
        mat["ps_surface"] = surface
    mat.diffuse_color = (*colour, 1.0)
    mat.use_fake_user = True
    return mat


def ensure_materials():
    for name, colour in DEV:
        material(name, colour)
    for surface, name, colour in DEV_SURFACES:
        material(name, colour, surface=surface)
    for tool, name, colour, _ in TOOLS:
        material(name, colour, tool)


# ---------- Brushes ----------
def is_brush(obj):
    return obj is not None and obj.type == "MESH" and bool(obj.get("ps_brush"))


def make_brush(obj):
    obj["ps_brush"] = 1
    if obj.get("ps_entity") not in ("world", "solid", "detail"):
        obj["ps_entity"] = "world"
    if not obj.data.materials:
        # Only a material already there (made by an operator): a handler must not make new data-blocks (undo).
        grey = bpy.data.materials.get(DEV[0][0])
        if grey is not None:
            obj.data.materials.append(grey)
    world_uvs(obj)


def world_uvs(obj):
    """Texture lock: box-mapped UVs from the world positions, one Dev tile per 64 units. True when they changed."""
    me = obj.data
    # A mesh shared by linked copies (Alt+D): each would set it to its own place, and the update to that would set it
    # again for the other, without end.
    if obj.mode != "OBJECT" or not len(me.polygons) or me.users > 1:
        return False
    layer = me.uv_layers.active or me.uv_layers.new(name="UVMap")
    mw = np.array(obj.matrix_world)
    co = np.empty(len(me.vertices) * 3, dtype=np.float32)
    me.vertices.foreach_get("co", co)
    co = co.reshape(-1, 3) @ mw[:3, :3].T + mw[:3, 3]
    nrm = np.empty(len(me.polygons) * 3, dtype=np.float32)
    me.polygons.foreach_get("normal", nrm)
    try:
        nrm = nrm.reshape(-1, 3) @ np.linalg.inv(mw[:3, :3])
    except np.linalg.LinAlgError:
        return False
    axis = np.abs(nrm).argmax(axis=1)
    totals = np.empty(len(me.polygons), dtype=np.int32)
    me.polygons.foreach_get("loop_total", totals)
    loop_poly = np.repeat(np.arange(len(me.polygons)), totals)
    verts = np.empty(len(me.loops), dtype=np.int32)
    me.loops.foreach_get("vertex_index", verts)
    p = co[verts]
    a = axis[loop_poly]
    uv = (np.stack([np.where(a == 0, p[:, 1], p[:, 0]), np.where(a == 2, p[:, 1], p[:, 2])], axis=1) / TILE).ravel()
    old = np.empty(len(me.loops) * 2, dtype=np.float32)
    layer.data.foreach_get("uv", old)
    if np.allclose(old, uv, atol=1e-5):
        return False
    layer.data.foreach_set("uv", uv.astype(np.float32))
    me.update()
    return True


def convex(obj):
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    ok = all((v.co - f.calc_center_median()).dot(f.normal) <= 1e-4 for f in bm.faces for v in bm.verts)
    bm.free()
    return ok


@persistent
def undo_begins(*_):
    _undoing[0] = True


@persistent
def undo_ends(*_):
    _undoing[0] = False


@persistent
def on_depsgraph(scene, depsgraph):
    """New meshes in the map's Seen collection become brushes; moved or reshaped brushes keep their texture size."""
    if _guard[0] or _undoing[0]:
        return
    _guard[0] = True
    try:
        root = map_collection(scene)
        seen = None
        if root is not None:
            seen = next((c for c in root.children if c.name.split(".")[0] == "Seen"), None)
        if seen is not None:
            for o in seen.objects:
                if o.type == "MESH" and not o.get("ps_brush") and o.mode == "OBJECT":
                    make_brush(o)
        for u in depsgraph.updates:
            obj = u.id.original if isinstance(u.id, bpy.types.Object) else None
            if is_brush(obj) and (u.is_updated_transform or u.is_updated_geometry):
                world_uvs(obj)
    finally:
        _guard[0] = False


# ---------- The grid ----------
def apply_grid(context):
    """Hammer's grid: one step at every zoom, the one [ and ] set. Blender's own grid in the flat views goes by the zoom
    (and by metres, tens of metres...), and so does its snapping there; here the flat views draw this grid (draw_grid), and
    snapping goes by it: no unit system (whose steps are 1, 10, 100 m), one subdivision (no finer or coarser levels)."""
    units = context.scene.ps_grid_units
    ts = context.scene.tool_settings
    ts.use_snap = True
    # By whole grid steps from where it is (Increment): what is on the grid stays on it by its corners, nothing jumps.
    # (Blender's Grid snap puts the corner nearest the mouse onto the grid point under the mouse: a brush grabbed with G
    # leapt to the mouse; in Edit Mode it put the middle of what moved on the grid.) After a move the brushes' corners
    # go onto the grid anyway (watch_transforms).
    ts.snap_elements = {"INCREMENT"}
    ts.snap_target = "CLOSEST"
    ts.use_snap_grid_absolute = False
    if ts.transform_pivot_point == "ACTIVE_ELEMENT":
        ts.transform_pivot_point = "MEDIAN_POINT"
    context.scene.unit_settings.system = "NONE"
    for screen in bpy.data.screens:
        for area in screen.areas:
            if area.type == "VIEW_3D":
                for space in area.spaces:
                    if space.type == "VIEW_3D":
                        space.overlay.grid_scale = units * UNIT
                        space.overlay.grid_subdivisions = 1
                        space.overlay.show_ortho_grid = False
                        space.clip_end = max(space.clip_end, 2000)
                area.tag_redraw()


# Operators after which the selected brushes are put in order (brush_tools.tidy): a move, a resize, a turn, Edit Mode left.
TIDY_AFTER = {"TRANSFORM_OT_translate", "TRANSFORM_OT_resize", "TRANSFORM_OT_rotate", "TRANSFORM_OT_transform",
              "OBJECT_OT_editmode_toggle", "OBJECT_OT_mode_set", "TRANSFORM_OT_mirror"}
_last_operator = [None]


def operator_values(op):
    """An operator's settings as plain values (arrays as tuples: their objects are new on every read)."""
    out = []
    for p in op.properties.bl_rna.properties:
        if p.identifier == "rna_type" or p.type in ("POINTER", "COLLECTION"):
            continue
        v = getattr(op.properties, p.identifier, None)
        out.append(tuple(v) if getattr(p, "is_array", False) else v)
    return tuple(out)


def keep_grid(scene):
    """The map's grid in every 3D view, whatever happened to it: a view opened or split later (a new one comes with
    Blender's 1 m grid, and snapping goes by it), the units set back to metres (Blender's grid then steps by 1, 10, 100 m
    with the zoom). Snapping on or off is left to the user."""
    want = scene.ps_grid_units * UNIT
    if scene.unit_settings.system != "NONE":
        scene.unit_settings.system = "NONE"
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type != "VIEW_3D":
                continue
            space = area.spaces[0]
            if abs(space.overlay.grid_scale - want) > 1e-6 or space.overlay.grid_subdivisions != 1:
                space.overlay.grid_scale = want
                space.overlay.grid_subdivisions = 1
                space.overlay.show_ortho_grid = False
                area.tag_redraw()


def edit_mode_steps():
    """Moves by whole grid steps from where it was (Increment), in Object and Edit Mode alike: what was on the grid stays
    on it by its corners, what was off it keeps its offset, nothing jumps to the mouse (see apply_grid). Ctrl held while
    moving: no snap, as ever in Blender. A map file of before (Grid) is set so; a snap chosen by hand (to vertices, say)
    is left alone."""
    scene = bpy.context.scene
    if map_collection(scene) is None:
        return
    keep_grid(scene)
    ts = scene.tool_settings
    if set(ts.snap_elements) == {"GRID"}:
        ts.snap_elements = {"INCREMENT"}
    if set(ts.snap_elements) == {"INCREMENT"} and ts.use_snap_grid_absolute:
        ts.use_snap_grid_absolute = False


def watch_transforms():
    """A few times a second: when the last thing done was a transform (or leaving Edit Mode), the selected brushes get
    their scale and turn into the mesh and their corners onto the grid; one undo step of its own."""
    try:
        edit_mode_steps()
        wm = bpy.context.window_manager
        last = wm.operators[-1] if wm.operators else None
        # The operator and its values: a Move changed in its panel (F9) is the same operator again, with another value.
        key = (last.as_pointer(), operator_values(last)) if last else None
        if key == _last_operator[0] or _undoing[0]:
            return 0.25
        _last_operator[0] = key
        if last is None or last.bl_idname not in TIDY_AFTER:
            return 0.25
        scene = bpy.context.scene
        if not hasattr(scene, "ps_grid_units") or map_collection(scene) is None:
            return 0.25
        step = scene.ps_grid_units * UNIT
        changed = 0
        for obj in list(bpy.context.view_layer.objects.selected):
            if is_brush(obj) and obj.mode == "OBJECT" and brush_tools.tidy(obj, step):
                changed += 1
        if changed:
            bpy.ops.ed.undo_push(message="Brushes onto the grid")
    except (AttributeError, ReferenceError, RuntimeError):
        pass
    return 0.25


def is_map_file(scene):
    return scene is not None and map_collection(scene) is not None


def light_pickers():
    """Every lamp's and sun's colour shown as a colour (its swatch and picker), not three numbers; their brightness from
    0 up. For the lamps of before, set up once the file is open (the new ones get it when added)."""
    for o in bpy.data.objects:
        if o.get("ps_entity") not in ("light", "sun", "radarcolor") or "ps_color" not in o:
            continue
        try:
            ui = o.id_properties_ui("ps_color")
            if ui.as_dict().get("subtype") != "COLOR":
                ui.update(subtype="COLOR", min=0.0, max=1.0, soft_min=0.0, soft_max=1.0)
            if "ps_brightness" in o:
                o.id_properties_ui("ps_brightness").update(min=0.0, soft_max=20.0)
        except (TypeError, ValueError, AttributeError):
            pass


def grid_on_start():
    """The add-on just turned on: a map file open gets the grid (its own one-step grid in the flat views)."""
    try:
        if is_map_file(bpy.context.scene):
            apply_grid(bpy.context)
            light_pickers()
    except (AttributeError, RuntimeError):
        pass
    return None


@persistent
def grid_on_load(*_):
    # The ledge heights and the faces left out are drawn from what was worked out in this session, not kept in the file:
    # a file saved with them shown opens with their buttons up (else "Hide" with nothing drawn).
    for scene in bpy.data.scenes:
        for name in ("ps_show_ledges", "ps_show_hidden"):
            if getattr(scene, name, False):
                setattr(scene, name, False)
    LEAK["path"] = []  # the last file's leak
    bpy.app.timers.register(grid_on_start, first_interval=0.2)


def flat_axes(rv3d):
    """For a flat view (orthographic, looking along an axis): the axis it looks along and the two across; else None."""
    if rv3d is None or rv3d.view_perspective != "ORTHO":
        return None
    look = rv3d.view_rotation @ Vector((0, 0, -1))
    axis = max(range(3), key=lambda k: abs(look[k]))
    if abs(look[axis]) < 0.999:
        return None
    return axis, [k for k in range(3) if k != axis], look


MIN_SPACING = 6  # pixels: a grid finer than that on screen shows every 2nd, 4th... line (snapping stays on the full grid)


def shown_step(context, region, rv3d, step):
    """The grid step drawn in a flat view: the grid's, doubled while its lines would be closer than MIN_SPACING pixels."""
    from bpy_extras import view3d_utils
    a = view3d_utils.region_2d_to_location_3d(region, rv3d, (0, 0), rv3d.view_location)
    b = view3d_utils.region_2d_to_location_3d(region, rv3d, (region.width, 0), rv3d.view_location)
    per_pixel = max((b - a).length / max(1, region.width), 1e-9)
    shown = step
    while shown / per_pixel < MIN_SPACING and shown < step * 4096:
        shown *= 2
    return shown


def draw_grid():
    """The grid in the flat views, as Hammer draws it: lines at the grid step, every 64 and 1024 units brighter, the axes
    coloured; behind the brushes."""
    import gpu
    from bpy_extras import view3d_utils
    from gpu_extras.batch import batch_for_shader
    context = bpy.context
    scene, region, rv3d = context.scene, context.region, context.region_data
    if scene is None or not hasattr(scene, "ps_grid_units") or region is None:
        return
    flat = flat_axes(rv3d)
    if flat is None:
        return
    axis, (i, j), look = flat
    step = scene.ps_grid_units * UNIT
    shown = shown_step(context, region, rv3d, step)
    corners = [view3d_utils.region_2d_to_location_3d(region, rv3d, (x, y), rv3d.view_location)
               for x in (0, region.width) for y in (0, region.height)]
    lo = [min(c[k] for c in corners) for k in range(3)]
    hi = [max(c[k] for c in corners) for k in range(3)]
    # Far behind everything in the view (an orthographic view sees half its clip range each side of its middle).
    depth = (rv3d.view_location + look * (context.space_data.clip_end * 0.45))[axis]
    groups = {"line": [], "64": [], "1024": [], "axis_i": [], "axis_j": []}
    for along, across in ((i, j), (j, i)):
        n0, n1 = math.floor(lo[along] / shown), math.ceil(hi[along] / shown)
        for n in range(n0, n1 + 1):
            v = n * shown
            units = round(v / UNIT)
            p, q = Vector(), Vector()
            p[axis] = q[axis] = depth
            p[along] = q[along] = v
            p[across], q[across] = lo[across], hi[across]
            key = ("axis_i" if along == j else "axis_j") if units == 0 else \
                "1024" if units % 1024 == 0 else "64" if units % 64 == 0 else "line"
            groups[key] += [p, q]
    colours = {"line": (1, 1, 1, 0.07), "64": (1, 1, 1, 0.16), "1024": (1, 1, 1, 0.3)}
    axis_colour = [(0.9, 0.3, 0.3, 0.6), (0.4, 0.8, 0.3, 0.6), (0.3, 0.5, 0.95, 0.6)]
    colours["axis_i"], colours["axis_j"] = axis_colour[i], axis_colour[j]
    shader = gpu.shader.from_builtin("UNIFORM_COLOR")
    gpu.state.blend_set("ALPHA")
    gpu.state.depth_test_set("LESS_EQUAL")
    for key, pts in groups.items():
        if pts:
            shader.uniform_float("color", colours[key])
            batch_for_shader(shader, "LINES", {"pos": pts}).draw(shader)
    gpu.state.depth_test_set("NONE")
    gpu.state.blend_set("NONE")


def draw_grid_size():
    context = bpy.context
    scene = context.scene
    if scene is None or not hasattr(scene, "ps_grid_units"):
        return
    u = scene.ps_grid_units
    text = f"Grid {u} u = {u * UNIT:.3f} m    [ ] smaller / bigger"
    if context.region is not None and flat_axes(context.region_data) is not None:
        shown = round(shown_step(context, context.region, context.region_data, u * UNIT) / UNIT)
        if shown != u:
            text += f"    (lines every {shown} u)"
    blf.size(0, 14)
    blf.color(0, 1.0, 0.85, 0.35, 0.9)
    blf.position(0, 70, 40, 0)
    blf.draw(0, text)


class MAP_OT_grid(bpy.types.Operator):
    bl_idname = "psmap.grid"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Grid size"
    bl_description = "Halve or double the grid ([ and ])"
    step: bpy.props.IntProperty(default=1)

    def execute(self, context):
        units = context.scene.ps_grid_units
        i = GRID_STEPS.index(units) if units in GRID_STEPS else 4
        context.scene.ps_grid_units = GRID_STEPS[max(0, min(len(GRID_STEPS) - 1, i + self.step))]
        apply_grid(context)
        return {"FINISHED"}


class MAP_OT_quad_view(bpy.types.Operator):
    bl_idname = "psmap.quad_view"
    bl_label = "Four views (Hammer)"
    bl_description = "Top, front, side and 3D views together (Ctrl+Alt+Q toggles it too)"

    def execute(self, context):
        area = context.area if context.area and context.area.type == "VIEW_3D" else next(
            (a for a in context.screen.areas if a.type == "VIEW_3D"), None)
        if area is None:
            return {"CANCELLED"}
        region = next(r for r in area.regions if r.type == "WINDOW")
        with context.temp_override(area=area, region=region):
            bpy.ops.screen.region_quadview()
        apply_grid(context)
        return {"FINISHED"}


# ---------- Brush tools ----------
class MAP_OT_make_brushes(bpy.types.Operator):
    bl_idname = "psmap.make_brushes"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Split into brushes"
    bl_description = "Each loose part of the selected meshes becomes a brush of its own, in the map's Seen collection"

    def execute(self, context):
        ensure_materials()
        seen = child_collection(context.scene, "Seen")
        made = 0
        for obj in [o for o in context.selected_objects if o.type == "MESH"]:
            if obj.mode != "OBJECT":
                bpy.ops.object.mode_set(mode="OBJECT")
            bpy.ops.object.select_all(action="DESELECT")
            obj.select_set(True)
            context.view_layer.objects.active = obj
            bpy.ops.mesh.separate(type="LOOSE")
            for part in context.selected_objects:
                for c in list(part.users_collection):
                    c.objects.unlink(part)
                seen.objects.link(part)
                bpy.ops.object.select_all(action="DESELECT")
                part.select_set(True)
                context.view_layer.objects.active = part
                bpy.ops.object.origin_set(type="ORIGIN_GEOMETRY", center="BOUNDS")
                part.name = "Brush"
                make_brush(part)
                made += 1
        self.report({"INFO"}, f"{made} brushes")
        return {"FINISHED"}


class MAP_OT_material(bpy.types.Operator):
    bl_idname = "psmap.material"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Material"
    bl_description = "Put this material on the selected brushes (in Edit Mode: on the selected faces)"
    name: bpy.props.StringProperty()

    def execute(self, context):
        ensure_materials()
        mat = bpy.data.materials[self.name]
        obj = context.active_object
        if obj is not None and obj.mode == "EDIT":
            slot = obj.data.materials.find(mat.name)
            if slot < 0:
                obj.data.materials.append(mat)
                slot = len(obj.data.materials) - 1
            obj.active_material_index = slot
            bpy.ops.object.material_slot_assign()
            return {"FINISHED"}
        for o in context.selected_objects:
            if o.type == "MESH":
                o.data.materials.clear()
                o.data.materials.append(mat)
                if not o.get("ps_brush") and o.users_collection and o.users_collection[0].name.split(".")[0] == "Seen":
                    make_brush(o)
        return {"FINISHED"}


class MAP_OT_brush_kind(bpy.types.Operator):
    bl_idname = "psmap.brush_kind"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Brush kind"
    bl_description = "Solid: seen, players and bullets stop. Detail: seen only, nothing stops (grass, wires). No collision: seen and shot, players pass"
    kind: bpy.props.StringProperty()

    def execute(self, context):
        for o in context.selected_objects:
            if not is_brush(o):
                continue
            o["ps_entity"] = "detail" if self.kind == "detail" else "world"
            if self.kind == "nocollide":
                o["ps_nocollide"] = 1
            elif "ps_nocollide" in o:
                del o["ps_nocollide"]
        return {"FINISHED"}


class MAP_OT_set(bpy.types.Operator):
    bl_idname = "psmap.set"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Set"
    bl_description = "Set this on the selected objects"
    key: bpy.props.StringProperty()
    value: bpy.props.StringProperty()

    def execute(self, context):
        for o in context.selected_objects:
            o["ps_" + self.key] = self.value
        return {"FINISHED"}


# ---------- Entities ----------
def find_layer(lc, name):
    if lc.collection.name == name:
        return lc
    for c in lc.children:
        hit = find_layer(c, name)
        if hit:
            return hit
    return None


def snapped_cursor(context):
    step = context.scene.ps_grid_units * UNIT
    c = context.scene.cursor.location
    return Vector((round(c.x / step) * step, round(c.y / step) * step, round(c.z / step) * step))


def volume(name, size, at, col):
    mesh = bpy.data.meshes.new(name)
    bm = bmesh.new()
    bmesh.ops.create_cube(bm, size=1.0)
    for v in bm.verts:
        v.co = Vector((v.co.x * size[0], v.co.y * size[1], v.co.z * size[2] + size[2] * 0.5))
    bm.to_mesh(mesh)
    bm.free()
    obj = bpy.data.objects.new(name, mesh)
    obj.location = at
    obj.display_type = "WIRE"
    obj.hide_render = True
    col.objects.link(obj)
    return obj


ENTITIES = [
    ("spawn_t", "Spawn T", "a terrorists' spawn: on the floor, looks along +X"),
    ("spawn_ct", "Spawn CT", "a counter-terrorists' spawn"),
    ("site_a", "Bomb site A", "where the bomb is planted (a volume on the floor)"),
    ("site_b", "Bomb site B", ""),
    ("buy_t", "Buy zone T", "where the terrorists buy"),
    ("buy_ct", "Buy zone CT", ""),
    ("light", "Lamp", "a lamp the bake lights the map with"),
    ("killzone", "Kill zone", "whoever enters dies"),
    ("ladder", "Ladder", "a thin volume on the wall where a ladder is"),
    ("sun", "Sun", "the sun: shines along +X"),
    ("radar_layer", "Radar layer", "a volume: what lies in its heights is one radar picture (floors over floors, CS2)"),
    ("radar_color", "Radar colour", "an empty: the radar's colour at its height (two or more make the gradient)"),
    ("radar_min", "Radar low", "an empty: the radar gradient's bottom at its height (else the lowest floor)"),
    ("radar_max", "Radar high", "an empty: the radar gradient's top at its height (else the highest floor)"),
]


# The entities that are volumes: their name, their keys (ps_entity, and the team or site).
VOLUMES = {"site_a": ("Bomb site A", {"ps_entity": "bombsite", "ps_site": "A"}),
           "site_b": ("Bomb site B", {"ps_entity": "bombsite", "ps_site": "B"}),
           "buy_t": ("Buy zone T", {"ps_entity": "buyzone", "ps_team": "T"}),
           "buy_ct": ("Buy zone CT", {"ps_entity": "buyzone", "ps_team": "CT"}),
           "killzone": ("Kill zone", {"ps_entity": "killzone"}),
           "ladder": ("Ladder", {"ps_entity": "ladder"}),
           "radar_layer": ("Radar layer", {"ps_entity": "radarlayer"})}
BRUSH_KEYS = ("ps_brush", "ps_surface", "ps_nocollide", "ps_parts", "ps_stairs", "ps_round", "ps_cut", "ps_concave",
              "ps_team", "ps_site")


def tie_to_entity(obj, kind, col):
    """A brush becomes a volume entity (Hammer's Tie to Entity): into Entities, unseen in the game and by the bake, its
    brush settings and materials gone, the entity's keys on it."""
    name, keys = VOLUMES[kind]
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    col.objects.link(obj)
    for key in BRUSH_KEYS:
        if key in obj:
            del obj[key]
    for key, value in keys.items():
        obj[key] = value
    obj.data.materials.clear()
    obj.display_type = "WIRE"
    obj.hide_render = True
    obj.name = name


def ladder_on_wall(context, col):
    """A ladder put onto the wall nearest the 3D cursor (within 2 m, along x or y), turned along it, a little out from it,
    standing on the floor under it; None when there is no wall near."""
    root = map_collection(context.scene)
    tree = solids(root) if root is not None else None
    if tree is None:
        return None
    c = context.scene.cursor.location.copy()
    best = None
    for d in (Vector((1, 0, 0)), Vector((-1, 0, 0)), Vector((0, 1, 0)), Vector((0, -1, 0))):
        # From a little back: the cursor put on the wall itself (Shift+right click) lies on its face.
        hit, normal, _, dist = tree.ray_cast(c - d * 0.1, d, 2.1)
        if hit is not None and abs(normal.z) < 0.3 and (best is None or dist < best[2]):
            best = (hit, d, dist)
    if best is None:
        return None
    hit, d, _ = best
    step = context.scene.ps_grid_units * UNIT
    across = 0 if abs(d.x) > 0.5 else 1  # the axis out of the wall
    along = 1 - across
    thin, wide, tall = 2 * UNIT, 32 * UNIT, 128 * UNIT
    centre = hit.copy()
    centre[across] = hit[across] - d[across] * thin / 2  # its back on the wall
    centre[along] = round(c[along] / step) * step
    down = tree.ray_cast(Vector((centre.x, centre.y, c.z + 0.05)), Vector((0, 0, -1)), 50.0)
    centre.z = down[0].z if down[0] is not None else round(c.z / step) * step
    size = [0.0, 0.0, tall]
    size[across], size[along] = thin, wide
    return volume("Ladder", tuple(size), centre, col)


class MAP_OT_add_entity(bpy.types.Operator):
    bl_idname = "psmap.add_entity"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Add"
    bl_description = "Add it at the 3D cursor (on the grid), in the map's Entities"
    kind: bpy.props.StringProperty()
    # A lamp's and the sun's, in the panel at the bottom left (F9); their usual ones set as the button is pressed.
    light_color: bpy.props.FloatVectorProperty(name="Colour", subtype="COLOR", size=3, min=0.0, max=1.0,
                                               default=(1.0, 0.92, 0.78), options={"SKIP_SAVE"})
    brightness: bpy.props.FloatProperty(name="Brightness", default=3.0, min=0.0, soft_max=20.0, options={"SKIP_SAVE"},
                                        description="How bright: a lamp 3, the sun 1 as they come")
    reach: bpy.props.FloatProperty(name="Range (m)", default=8.0, min=0.5, soft_max=60.0, options={"SKIP_SAVE"},
                                   description="How far a lamp lights")
    lamp_height: bpy.props.IntProperty(name="Over the cursor (units)", default=96, min=0, max=4096, options={"SKIP_SAVE"})
    # Its kind's usual colour and brightness put in once (the sun's differ from a lamp's); then the panel's own.
    tuned: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        if self.kind in ("light", "sun"):
            layout.prop(self, "light_color")
            layout.prop(self, "brightness")
            if self.kind == "light":
                layout.prop(self, "reach")
                layout.prop(self, "lamp_height")
        from .brush_tools import finish_buttons
        finish_buttons(layout)

    @classmethod
    def description(cls, context, properties):
        tip = next((t for e, _, t in ENTITIES if e == properties.kind), "")
        if properties.kind in VOLUMES:
            more = (" A ladder with nothing selected goes onto the wall by the cursor, standing on the floor."
                    if properties.kind == "ladder" else "")
            return (f"{tip}. The selected brushes become it (as Hammer's Tie to Entity: drawn to the size wanted); "
                    f"nothing selected: one of the usual size at the 3D cursor.{more}")
        return f"{tip}. At the 3D cursor (on the grid)"

    def execute(self, context):
        object_mode(context)
        col = child_collection(context.scene, "Entities")
        at = snapped_cursor(context)
        k = self.kind
        if not self.tuned:
            if k == "sun":
                self.light_color, self.brightness = (1.0, 0.95, 0.85), 1.0
            self.tuned = True
        if k in VOLUMES:
            picked = [o for o in context.selected_objects if is_brush(o)]
            if picked:
                for o in picked:
                    tie_to_entity(o, k, col)
                deselect_all(context)
                for o in picked:
                    o.select_set(True)
                context.view_layer.objects.active = picked[-1]
                self.report({"INFO"}, f"{len(picked)} brush(es) made {VOLUMES[k][0].lower()}")
                return {"FINISHED"}
        if k in ("spawn_t", "spawn_ct", "light", "sun"):
            obj = bpy.data.objects.new(dict((e[0], e[1]) for e in ENTITIES)[k], None)
            obj.location = at
            col.objects.link(obj)
            if k.startswith("spawn"):
                obj.empty_display_type = "ARROWS"  # its red X arrow is where it looks
                obj.empty_display_size = 0.8
                obj["ps_entity"] = "spawn"
                obj["ps_team"] = "T" if k == "spawn_t" else "CT"
            elif k == "light":
                obj.location = at + Vector((0, 0, self.lamp_height * UNIT))
                obj.empty_display_type = "SPHERE"
                obj.empty_display_size = 0.2
                obj["ps_entity"] = "light"
                obj["ps_color"] = list(self.light_color)
                obj["ps_brightness"] = self.brightness
                obj["ps_range"] = self.reach
            else:
                obj.location = at + Vector((0, 0, 20))
                obj.rotation_euler = (0.0, math.radians(50), math.radians(30))
                obj.empty_display_type = "SINGLE_ARROW"
                obj["ps_entity"] = "sun"
                obj["ps_color"] = list(self.light_color)
                obj["ps_brightness"] = self.brightness
            if k in ("light", "sun"):
                # A colour picker in the Object tab too (the property a colour, not three numbers).
                ui = obj.id_properties_ui("ps_color")
                ui.update(subtype="COLOR", min=0.0, max=1.0, soft_min=0.0, soft_max=1.0)
                obj.id_properties_ui("ps_brightness").update(min=0.0, soft_max=20.0)
        elif k in ("site_a", "site_b"):
            obj = volume("Bomb site " + k[-1].upper(), (4.0, 4.0, 2.0), at, col)
            obj["ps_entity"] = "bombsite"
            obj["ps_site"] = k[-1].upper()
        elif k in ("buy_t", "buy_ct"):
            obj = volume("Buy zone " + k[4:].upper(), (6.0, 6.0, 3.0), at, col)
            obj["ps_entity"] = "buyzone"
            obj["ps_team"] = k[4:].upper()
        elif k == "killzone":
            obj = volume("Kill zone", (4.0, 4.0, 1.0), at, col)
            obj["ps_entity"] = "killzone"
        elif k == "ladder":
            obj = ladder_on_wall(context, col)
            if obj is None:
                obj = volume("Ladder", (0.8, 0.05, 3.2), at, col)
            obj["ps_entity"] = "ladder"
        elif k == "radar_layer":
            obj = volume("Radar layer", (16.0, 16.0, 3.0), at, col)
            obj["ps_entity"] = "radarlayer"
        elif k in ("radar_color", "radar_min", "radar_max"):
            obj = bpy.data.objects.new(dict((e[0], e[1]) for e in ENTITIES)[k], None)
            obj.location = at
            obj.empty_display_type = "PLAIN_AXES" if k != "radar_color" else "SPHERE"
            obj.empty_display_size = 0.5
            obj["ps_entity"] = k.replace("_", "")
            if k == "radar_color":
                obj["ps_color"] = [0.36, 0.40, 0.45]
            col.objects.link(obj)
        else:
            return {"CANCELLED"}
        deselect_all(context)
        obj.select_set(True)
        context.view_layer.objects.active = obj
        return {"FINISHED"}


# ---------- Visibility ----------
GROUPS = [("collision", "Collision", "collision objects and clip brushes"),
          ("triggers", "Triggers", "bomb sites, buy zones, kill zones, ladders"),
          ("entities", "Entities", "spawns, lamps, the sun"),
          ("brushes", "Brushes", "what is seen"),
          ("reference", "Reference", "collections left out of the map")]


def group_of(obj):
    kind = obj.get("ps_entity")
    tools = {str(m.get("ps_tool", "")) for m in obj.data.materials if m} if obj.type == "MESH" else set()
    if kind in ("collision", "grenadeclip", "blockbullets") or tools & {"clip", "grenadeclip", "blockbullets"} and len(tools) == 1:
        return "collision"
    if kind in ("bombsite", "buyzone", "killzone", "ladder", "radarlayer") or tools & {"killzone", "ladder"} and len(tools) == 1:
        return "triggers"
    if obj.type == "EMPTY" and kind:
        return "entities"
    if kind in ("world", "solid", "detail", "water"):
        return "brushes"
    return None


def reference_layers(view_layer):
    """The view layer's collections left out of the map (ps_export = 0), outermost only."""
    layers = []

    def walk(lc):
        if lc.collection.get("ps_export", 1) in (0, False):
            layers.append(lc)
            return
        for c in lc.children:
            walk(c)
    walk(view_layer.layer_collection)
    return layers


def group_objects(context, group):
    root = map_collection(context.scene)
    # Only live objects: one a tool has just removed (a brush cut into pieces) may still be listed while the panel draws.
    if _undoing[0]:
        return []  # Blender is rebuilding the data: drawn again once it is done
    return [o for o in (map_objects(root) if root else list(context.scene.objects))
            if isinstance(o, bpy.types.Object) and group_of(o) == group]


def group_shown(context, group):
    """Whether any of the group is seen in the views now (the button is down then)."""
    vl = context.view_layer
    if group == "reference":
        return any(not lc.hide_viewport for lc in reference_layers(vl))
    return any(o.name in vl.objects and o.visible_get(view_layer=vl) for o in group_objects(context, group))


def find_layers_of(view_layer, obj):
    """The layer collections that hold the object (directly or through their children), outermost first."""
    found = []

    def walk(lc, path):
        if obj.name in lc.collection.objects:
            found.extend(path + [lc])
        for c in lc.children:
            walk(c, path + [lc])
    walk(view_layer.layer_collection, [])
    return found


class MAP_OT_toggle(bpy.types.Operator):
    bl_idname = "psmap.toggle"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Show / hide"
    group: bpy.props.StringProperty()

    @classmethod
    def description(cls, context, properties):
        tip = next((t for g, _, t in GROUPS if g == properties.group), "")
        return f"Show or hide {tip} (down: shown now)"

    def execute(self, context):
        vl = context.view_layer
        if self.group == "reference":
            layers = reference_layers(vl)
            hide = any(not lc.hide_viewport for lc in layers)
            for lc in layers:
                lc.hide_viewport = hide
            return {"FINISHED"}
        # Only what is in the view layer: an object of a collection unticked (excluded) cannot be shown or hidden there.
        objs = [o for o in group_objects(context, self.group) if o.name in vl.objects]
        hide = group_shown(context, self.group)
        for o in objs:
            o.hide_set(hide)
            if not hide:
                # Shown means seen: a hidden collection round it is opened too (not the map's own top).
                for lc in find_layers_of(vl, o):
                    if lc.hide_viewport and lc.collection.get("ps_export", 1) not in (0, False):
                        lc.hide_viewport = False
        return {"FINISHED"}


# ---------- Check ----------
class PSIssue(bpy.types.PropertyGroup):
    text: bpy.props.StringProperty()
    obj: bpy.props.StringProperty()
    where: bpy.props.FloatVectorProperty(size=3)
    level: bpy.props.StringProperty()


def solids(root):
    """Everything a player stands on: solid brushes, collision objects, clip brushes. Reads the meshes only: making or
    removing data while going over a collection's objects can crash Blender (its object list is rebuilt under the loop)."""
    points, polygons = [], []
    for o in map_objects(root):
        if o is None or o.type != "MESH":
            continue
        faces = solid_faces(o)
        if faces:
            mw, first = o.matrix_world, len(points)
            points += [mw @ v.co for v in o.data.vertices]
            polygons += [[first + i for i in p.vertices] for p in faces]
    return BVHTree.FromPolygons(points, polygons) if polygons else None


def solid_faces(o):
    """The faces of an object players stand on: all of a collision object, a clip or a colliding brush; of a brush in
    pieces (stairs), those of its clip pieces."""
    kind = o.get("ps_entity")
    mats = o.data.materials
    tools = {str(m.get("ps_tool", "")) for m in mats if m}
    if kind == "collision" or tools == {"clip"} or (o.get("ps_brush") and kind in ("world", "solid") and not o.get("ps_nocollide")):
        return list(o.data.polygons)
    if o.get("ps_brush") and o.get("ps_parts"):
        return [p for p in o.data.polygons
                if p.material_index < len(mats) and mats[p.material_index] and mats[p.material_index].get("ps_tool") == "clip"]
    return []


# Entities the game builds from a map made here; the others are left out of it for now.
IN_GAME = {"spawn", "bombsite", "buyzone", "sun", "light", "killzone", "ladder", "world", "solid", "detail", "collision",
           "grenadeclip", "blockbullets", "radarlayer", "radarmin", "radarmax", "radarcolor"}
STAND_HEIGHT = 72 * UNIT


def _unity(v):
    """A Blender point in the game's space (as the export and glTF put it there): x over, y up."""
    return (-v.x, v.z, -v.y)


def walk_issues(objs, add):
    """Walks the map as the radar does (export radar_gen.py: the crouched player's box from the spawns, steps, jumps,
    drops, ladders): which spawns stand nowhere, whether the sides meet, whether the bomb sites and buy zones have floor
    anyone gets onto, where only crouching gets through."""
    import sys
    sys.path.insert(0, COMPILER)
    try:
        import radar_gen as rg
    finally:
        sys.path.pop(0)
    blocks, tris = [], []
    entities, spawns = [], []
    for o in objs:
        if o.type == "MESH":
            faces = solid_faces(o)
            if faces:
                mw = o.matrix_world
                pts = np.array([_unity(mw @ v.co) for v in o.data.vertices], dtype=np.float64)
                t = [(f.vertices[0], f.vertices[i + 1], f.vertices[i])  # turned over with the axes
                     for f in faces for i in range(1, len(f.vertices) - 1)]
                t = np.array(t, dtype=np.int64).reshape(-1, 3)
                whole = len(faces) == len(o.data.polygons) and not o.get("ps_parts") and not o.get("ps_concave")
                blocks.append((pts, t, whole and convex(o)))
                tris.append(pts[t])
        kind = o.get("ps_entity")
        tools = {str(m.get("ps_tool", "")) for m in o.data.materials if m} if o.type == "MESH" else set()
        if o.type == "MESH" and (kind in ("bombsite", "buyzone", "killzone", "ladder") or tools in ({"killzone"}, {"ladder"})):
            mw = o.matrix_world
            pts = [c for v in o.data.vertices for c in (lambda u: (-u[0], u[1], u[2]))(_unity(mw @ v.co))]
            entities.append({"type": kind if kind in ("bombsite", "buyzone", "killzone", "ladder") else next(iter(tools)),
                             "points": pts, "obj": o, "team": str(o.get("ps_team", "")), "site": str(o.get("ps_site", ""))})
        elif kind == "spawn":
            spawns.append((o, str(o.get("ps_team", "T")), _unity(o.matrix_world.translation)))
    if not tris or not spawns:
        return
    solids = rg.Solids(blocks)
    walk_tris = np.concatenate(tris)
    w = rg.walk_map(solids, rg.make_bvh(walk_tris), walk_tris, entities)
    every, started = rg.flood(w, [s[2] for s in spawns])
    side = {}
    for team in ("T", "CT"):
        side[team] = rg.flood(w, [s[2] for s in spawns if s[1] == team])[0]
    for o, team, at in spawns:
        if rg.flood(w, [at])[1] == 0:
            add("error", f"{o.name}: no floor here a player fits on (a ceiling too low, or in a wall)", o)
    if started and side["T"].any() and side["CT"].any() and not (side["T"] & side["CT"]).any():
        add("warning", "T and CT can't get to each other: no way between their spawns")
    x, y, z = w.colx[w.a_col], w.nh, w.colz[w.a_col]
    # Out of the map (Hammer's leak, for a map that needs not be sealed): floor players get to at the very edge of all
    # there is (nothing past it to stop them falling off), or on top of a wall marked the map's edge.
    if started:
        allp = walk_tris.reshape(-1, 3)
        x0, x1, z0, z1 = allp[:, 0].min(), allp[:, 0].max(), allp[:, 2].min(), allp[:, 2].max()
        rim = every & ((x < x0 + 0.5) | (x > x1 - 0.5) | (z < z0 + 0.5) | (z > z1 - 0.5))
        if rim.any():
            i = np.nonzero(rim)[0][0]
            add("warning", f"Players get to the very edge of the map ({int(rim.sum())} spots: nothing past it, they fall "
                "off): wall it in (Map edge), the first here", where=Vector((-x[i], -z[i], y[i])))
        for o in objs:
            if not o.get("ps_edge") or o.type != "MESH" or o.get("ps_entity") not in ("world", "solid"):
                continue
            mw = o.matrix_world
            pts = [mw @ v.co for v in o.data.vertices]
            lo = Vector([min(p[k] for p in pts) for k in range(3)])
            hi = Vector([max(p[k] for p in pts) for k in range(3)])
            on = every & (x >= -hi.x) & (x <= -lo.x) & (z >= -hi.y) & (z <= -lo.y) & (np.abs(y - hi.z) < 0.1)
            if on.any():
                i = np.nonzero(on)[0][0]
                add("warning", f"{o.name}: players get on top of this edge of the map (raise the map's ceiling, or it)",
                    o, where=Vector((-x[i], -z[i], y[i])))
    for e in entities:
        if e["type"] not in ("bombsite", "buyzone"):
            continue
        v = rg.volume(e)
        inside = ((x >= v[0][0]) & (x <= v[1][0]) & (z >= v[0][2]) & (z <= v[1][2]) &
                  (y >= v[0][1] - 1.0) & (y <= v[1][1] + 0.1))
        who = every if e["type"] == "bombsite" or e["team"] not in side else side[e["team"]]
        if not (inside & who).any():
            what = "bomb site" if e["type"] == "bombsite" else f"buy zone{' of ' + e['team'] if e['team'] else ''}"
            add("warning", f"{e['obj'].name}: nobody gets onto the floor of this {what}", e["obj"])
    # Crouching only: reached, but the standing box does not fit.
    idx = np.nonzero(every)[0]
    if len(idx):
        low = ~solids.free(x[idx], y[idx] + 0.02, z[idx], height=STAND_HEIGHT)
        if low.any():
            first = idx[np.nonzero(low)[0][0]]
            area = low.sum() * rg.CELL * rg.CELL
            add("info", f"{area:.1f} m² only crouched (the ceiling under {STAND_HEIGHT / UNIT:.0f} units): the first here",
                where=Vector((-x[first], -z[first], y[first])))


LEAK = {"path": []}  # where the air from the spawns gets out (Check map; the views draw it, as Hammer's pointfile)


def leak_issues(scene, objs, add):
    """Whether the map is closed, as the export floods it (compiler/sealed.py): the air from the spawns kept in by its
    walls (Nodraw too, not details nor glass), its player clips and its ceiling. Closed, the export leaves out every
    face turned to the outside; a leak is shown as a line from a spawn to where the air gets out."""
    import sys
    sys.path.insert(0, COMPILER)
    try:
        import sealed
    finally:
        sys.path.pop(0)
    LEAK["path"] = []
    see_through = {"glass", "chainlink", "metalgrate"}
    pieces, clear, tops, spawns = [], [], [], []
    for o in objs:
        if o.get("ps_entity") == "spawn":
            spawns.append(tuple(o.matrix_world.translation + Vector((0, 0, 32 * UNIT))))
            continue
        if not is_brush(o) or o.type != "MESH" or not o.data.vertices:
            continue
        mats = list(o.data.materials)
        tools = {str(m.get("ps_tool", "")) if m else "" for m in mats} or {""}
        surfaces = {str(o.get("ps_surface", "") or "")} | {str(m.get("ps_surface", "") or "") for m in mats if m}
        if not o.get("ps_edge_clip"):
            tops.append(max((o.matrix_world @ v.co).z for v in o.data.vertices))
        if tools == {"clip"}:
            clear += sealed.convex_pieces(o)  # a player clip closes it (seen through)
        elif not tools & {"", "nodraw"} or o.get("ps_entity") == "detail":
            continue  # a tool brush all over (a clip, a ladder) or a detail: closes nothing
        elif not o.get("ps_nocollide") and not surfaces & see_through:
            pieces += sealed.convex_pieces(o)
    if not pieces or not spawns:
        return
    own = float(getattr(scene, "ps_map_ceiling", 0) or 0)
    ceiling = own * UNIT if own > 0 else (max(tops) if tops else 0.0) + 128 * UNIT
    air = sealed.flood(pieces, spawns, ceiling, clear)
    if air is None:
        return
    if air.leak is None:
        add("ok", f"The map is closed: faces turned to its outside are left out ({air.cell / UNIT:.0f}-unit cells)")
        return
    path = sealed.leak_path(air, spawns)
    LEAK["path"] = [tuple(p) for p in path]
    # Where it gets out: the last point of the way still within the map's brushes.
    lo = Vector([min(p[1][k] for p in pieces) for k in range(3)])
    hi = Vector([max(p[2][k] for p in pieces) for k in range(3)])
    inside = [p for p in path if all(lo[k] <= p[k] <= hi[k] for k in range(2))]
    hole = inside[-1] if inside else (path[-1] if path else air.centre(air.leak))
    add("warning", "Leak: the map is not closed, the air from the spawns gets out along the red line (Show: where it "
        "leaves the map). Close it there: Map edge on the walls round the map (their clips close it up to the ceiling), "
        "or a wall or a player clip over the gap. Until then the faces outside it stay (more to draw)", where=hole)
    for area in bpy.context.screen.areas if bpy.context.screen else []:
        if area.type == "VIEW_3D":
            area.tag_redraw()


def overlap_area(p, q):
    """The area two convex polygons (x, y points) share: q clipped by each of p's sides (Sutherland–Hodgman)."""
    def area(poly):
        return abs(sum(poly[i][0] * poly[i - 1][1] - poly[i - 1][0] * poly[i][1] for i in range(len(poly)))) / 2

    def ccw(poly):
        s = sum(poly[i][0] * poly[i - 1][1] - poly[i - 1][0] * poly[i][1] for i in range(len(poly)))
        return poly if s < 0 else poly[::-1]  # the sum above is minus twice the signed area
    p, out = ccw(p), list(q)
    for i in range(len(p)):
        if not out:
            return 0.0
        (ax, ay), (bx, by) = p[i - 1], p[i]

        def side(c):
            return (bx - ax) * (c[1] - ay) - (by - ay) * (c[0] - ax)
        src, out = out, []
        for k in range(len(src)):
            c, d = src[k - 1], src[k]
            sc, sd = side(c), side(d)
            if sd >= 0:
                if sc < 0:
                    t = sc / (sc - sd)
                    out.append((c[0] + (d[0] - c[0]) * t, c[1] + (d[1] - c[1]) * t))
                out.append(d)
            elif sc >= 0:
                t = sc / (sc - sd)
                out.append((c[0] + (d[0] - c[0]) * t, c[1] + (d[1] - c[1]) * t))
    return area(out) if len(out) >= 3 else 0.0


def doubled_brushes(objs, add):
    """What the compiler cannot mend: a brush the very copy of another (one in another), and seen faces of two brushes
    lying in one plane, looking the same way, over each other — both drawn, they flicker in the game (two surfaces for one
    pixel) and shade each other in the bake. Faces only touching at an edge, or back to back (two brushes side by side),
    are fine."""
    brushes = [o for o in objs if is_brush(o) and o.get("ps_entity") in ("world", "solid", "detail")]
    copies, first = {}, {}
    for o in brushes:
        mw = o.matrix_world
        key = frozenset(tuple(round(c / UNIT, 1) for c in (mw @ v.co)) for v in o.data.vertices)
        if key in first:
            copies.setdefault(first[key], []).append(o)
        else:
            first[key] = o
    for o, more in copies.items():
        add("warning", f"{o.name}: {len(more)} more brush(es) just like it in the same place ({more[0].name}): "
            "they flicker in the game, delete the copies", more[0])
    doubled = set(id(o) for more in copies.values() for o in more)
    planes = {}
    for o in brushes:
        if id(o) in doubled:
            continue
        mw, rot = o.matrix_world, o.matrix_world.to_3x3()
        mats = o.data.materials
        for f in o.data.polygons:
            m = mats[f.material_index] if f.material_index < len(mats) else None
            if m is not None and m.get("ps_tool"):
                continue  # not drawn (nodraw, clips)
            n = (rot @ f.normal).normalized()
            k = max(range(3), key=lambda i: abs(n[i]))
            if abs(n[k]) < 0.9999:
                continue  # squared faces only (a box's): slanted ones are rare one over another
            pts = [mw @ o.data.vertices[i].co for i in f.vertices]
            a, b = [i for i in range(3) if i != k]
            rect = (min(p[a] for p in pts), max(p[a] for p in pts), min(p[b] for p in pts), max(p[b] for p in pts))
            key = (k, n[k] > 0, round(pts[0][k] / UNIT, 1))
            planes.setdefault(key, []).append((o, rect, f.center, [(p[a], p[b]) for p in pts]))
    found, seen_pairs = 0, set()
    where = None
    for faces in planes.values():
        if len(faces) < 2:
            continue
        for i in range(len(faces)):
            for j in range(i + 1, len(faces)):
                (o1, r1, c1, q1), (o2, r2, _, q2) = faces[i], faces[j]
                if o1 is o2:
                    continue
                w = min(r1[1], r2[1]) - max(r1[0], r2[0])
                h = min(r1[3], r2[3]) - max(r1[2], r2[2])
                # Their boxes first (cheap), then the faces themselves (an arch's pieces' boxes overlap, they do not).
                if w > UNIT and h > UNIT and overlap_area(q1, q2) > UNIT * UNIT:
                    pair = (min(o1.name, o2.name), max(o1.name, o2.name))
                    if pair not in seen_pairs:
                        seen_pairs.add(pair)
                        found += 1
                        if where is None:
                            where = (o1, o2, o1.matrix_world @ c1)
    if where is not None:
        o1, o2, p = where
        add("warning", f"{found} pair(s) of brushes with faces one over another in one plane (they flicker in the game): "
            f"e.g. {o1.name} and {o2.name}; move one off, or cut the overlap", o1, where=p)


def check_map(scene):
    issues = []
    root = map_collection(scene)
    if root is None:
        return [("error", "No map collection (choose it at the top of the panel)", "", Vector())]

    def add(level, text, obj=None, where=None):
        if obj is not None and obj.hide_get():
            text += " (hidden in the view, but exported: Show unhides it)"
        issues.append((level, text, obj.name if obj else "", where if where is not None else (obj.matrix_world.translation if obj else Vector())))
    tree = solids(root)
    # What the export takes: not the references inside the map (collections with ps_export = 0, export_map.left_out).
    skipped = set()

    def walk(col, out):
        out = out or col.get("ps_export", 1) in (0, False)
        if out:
            skipped.update(o.name for o in col.objects)
        for child in col.children:
            walk(child, out)
    walk(root, False)
    objs = [o for o in map_objects(root) if o.name not in skipped]
    if tree is None:
        add("error", "Nothing to stand on: no brushes or collision")
    teams = {"T": 0, "CT": 0}
    for o in objs:
        kind = o.get("ps_entity")
        if kind == "spawn":
            teams[str(o.get("ps_team", "T"))] = teams.get(str(o.get("ps_team", "T")), 0) + 1
            if tree is not None:
                p = o.matrix_world.translation
                down = tree.ray_cast(p + Vector((0, 0, 0.05)), Vector((0, 0, -1)), 100.0)
                up = tree.ray_cast(p + Vector((0, 0, 0.05)), Vector((0, 0, 1)), 100.0)
                if up[0] is not None and up[1].z > 0.5:
                    add("error", f"{o.name}: inside a brush", o)
                elif down[0] is None:
                    add("error", f"{o.name}: no floor under it", o)
                elif p.z - down[0].z > 4 * UNIT:
                    add("warning", f"{o.name}: {p.z - down[0].z:.2f} m above the floor (falls)", o)
        elif kind in ("bombsite", "buyzone") and o.type == "MESH" and tree is not None:
            c = o.matrix_world @ (sum((Vector(b) for b in o.bound_box), Vector()) / 8)
            up = tree.ray_cast(c, Vector((0, 0, 1)), 100.0)
            if up[0] is not None and up[1].z > 0.5:
                add("error", f"{o.name}: inside a brush (nobody can get in)", o)
        elif is_brush(o):
            if o.scale.x * o.scale.y * o.scale.z < 0:
                add("warning", f"{o.name}: mirrored (negative scale): its faces look inward", o)
            if not o.get("ps_parts") and not convex(o):
                add("info", f"{o.name}: not convex (exported as it is; fine, but slower than boxes)", o)
            room = o.get("ps_headroom")
            if room is not None and room < 72:
                add("warning", f"{o.name}: {room} units between the turns: " +
                    ("no way through" if room < 54 else "crouched only (72 to walk)"), o)
            mw = o.matrix_world
            off = sum(1 for v in o.data.vertices if any(abs(c / UNIT - round(c / UNIT)) > 0.01 for c in (mw @ v.co)))
            if off and not o.get("ps_round") and not o.get("ps_cut") and not o.get("ps_parts"):
                add("info", f"{o.name}: {off} corners off the grid (thin gaps or overlaps): select, press Snap", o)
    soft = [o for o in objs if is_brush(o) and not o.get("ps_surface") and any(
        not (m.get("ps_surface") or m.get("ps_tool")) for m in (o.data.materials or [None]) if m is not None)]
    if soft:
        add("info", f"{len(soft)} brushes have faces of the default surface (softer to bullets than wood): give them a "
            f"surface material (Concrete, Brick…) or set their material's surface; e.g. {soft[0].name}", soft[0])
    doubled_brushes(objs, add)
    if not teams.get("T"):
        add("error", "No spawn for T")
    if not teams.get("CT"):
        add("error", "No spawn for CT")
    if not any(o.get("ps_entity") == "bombsite" for o in objs):
        add("warning", "No bomb site (the bomb modes need one)")
    left = {}
    for o in objs:
        kind = o.get("ps_entity")
        if kind and kind not in IN_GAME:
            left.setdefault(str(kind), o)
    for kind, o in sorted(left.items()):
        add("warning", f"{kind}: not in the game yet for maps made here (left out); e.g. {o.name}", o)
    if tree is not None:
        try:
            walk_issues(objs, add)
        except Exception as e:  # the walk is a help: a map it cannot walk is still checked otherwise
            add("info", f"Could not walk the map from its spawns: {e}")
    try:
        leak_issues(scene, objs, add)
    except Exception as e:  # noqa: BLE001  (a help too)
        add("info", f"Could not flood the map from its spawns: {e}")
    if not issues:
        add("ok", "No problems found")
    return issues


class MAP_OT_check(bpy.types.Operator):
    bl_idname = "psmap.check"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Check the map"
    bl_description = "Look for what would break the map: spawns in the air or in walls, a buried bomb site, missing pieces"

    def execute(self, context):
        scene = context.scene
        scene.ps_issues.clear()
        order = ["error", "warning", "info", "ok"]
        for level, text, name, where in sorted(check_map(scene), key=lambda i: order.index(i[0]) if i[0] in order else 9):
            item = scene.ps_issues.add()
            item.level, item.text, item.obj, item.where = level, text, name, where
        return {"FINISHED"}


class MAP_OT_go(bpy.types.Operator):
    bl_idname = "psmap.go"
    bl_label = "Show"
    bl_description = "Select it and look at it"
    index: bpy.props.IntProperty()

    def execute(self, context):
        item = context.scene.ps_issues[self.index]
        obj = bpy.data.objects.get(item.obj)
        if obj is not None and obj.name not in context.view_layer.objects:
            obj = None  # in a collection unticked (excluded): the cursor goes there, the view to it
        context.scene.cursor.location = Vector(item.where)
        if obj is not None:
            obj.hide_set(False)
            object_mode(context)
            deselect_all(context)
            obj.select_set(True)
            context.view_layer.objects.active = obj
        for area in context.screen.areas:
            if area.type == "VIEW_3D":
                region = next(r for r in area.regions if r.type == "WINDOW")
                with context.temp_override(area=area, region=region):
                    if obj is not None:
                        bpy.ops.view3d.view_selected()
                    else:
                        bpy.ops.view3d.view_center_cursor()
                break
        return {"FINISHED"}


# ---------- Export and play ----------
class MAP_OT_export_play(bpy.types.Operator):
    bl_idname = "psmap.export_play"
    bl_label = "Export and play"
    bl_description = ("Save, export the map package, and have Unity compile and bake it and open the menu: press Play there "
                      "and the server starts on this map with the chosen mode (Unity must be open)")
    # Not remembered between presses (SKIP_SAVE): each button says all of what it does, else a Test and play after a
    # Bake Final would bake again (Blender gives an operator the values it had last time for what a button leaves unset).
    play: bpy.props.BoolProperty(default=True, options={"SKIP_SAVE"})
    # A quick test: the game builds the map from the package itself (nothing compiled or baked), lit as chosen.
    test: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})
    # For sharing: the package as one file (<map>.psmap beside the .blend), to import in the game's Workshop.
    share: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})
    # The light baked in Blender first (bake_light.py): "fast" or "final" ("" not baked).
    bake: bpy.props.StringProperty(default="", options={"SKIP_SAVE"})
    _timer = None

    @classmethod
    def description(cls, context, properties):
        if properties.bake:
            return ("Save, export the map package with its light baked in Blender (Cycles: sun, lamps, bounced light; "
                    "probes for players), and play it as Test and play does. " +
                    ("Fast: rough light (32 units a pixel), a minute or so" if properties.bake == "fast" else
                     "Final: sharp light (8 units a pixel), for playing and sharing; minutes"))
        if properties.share:
            return ("Pack the map into one file, <map>.psmap beside the .blend: send it to whoever should play it (the "
                    "game's Workshop imports it); the folder opens with it. Baked: the last bake as it is (bake again "
                    "after changes); never baked: exported now, with the test light")
        if properties.test:
            return ("Save, export the map package and play it at once, as it is (no compile, no baked light): in the game "
                    "already running (it goes to this map), else the game set in the add-on's preferences is started on it, "
                    "else Unity opens the menu (press Play)")
        return cls.bl_description

    def execute(self, context):
        if not bpy.data.filepath:
            self.report({"ERROR"}, "Save the file first (its name is the map's name)")
            return {"CANCELLED"}
        if busy():
            self.report({"WARNING"}, "Wait: the map is still being exported or compiled")
            return {"CANCELLED"}
        if bpy.context.object is not None and bpy.context.object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        stem = os.path.join(os.path.dirname(bpy.data.filepath), os.path.splitext(os.path.basename(bpy.data.filepath))[0])
        # A bake goes into a package of its own (<map>_baked): a quick Test and play (<map>_package) leaves it as it is.
        folder = stem + ("_baked" if self.bake else "_package")
        # Shared as last baked: exporting again would leave its light out (a bake is a step of its own, Bake Final).
        baked_at = last_bake(stem + "_baked")
        # (Asked to bake first: baked now, then packed, below.)
        if self.share and baked_at and not self.bake:
            changed = bpy.data.is_dirty or os.path.getmtime(bpy.data.filepath) > baked_at + 1
            bpy.ops.wm.save_mainfile()
            context.scene.ps_status = pack_for_sharing(stem + "_baked")
            if changed:
                self.report({"WARNING"}, "Shared with the light of the last bake: the map changed since, bake it again "
                                         "(Bake Final) to share the changes")
            return {"FINISHED"}
        bpy.ops.wm.save_mainfile()
        _export.update(package=folder, ruleset=context.scene.ps_ruleset, play=self.play, test=self.test or bool(self.bake),
                       light="baked" if self.bake else context.scene.ps_test_light, share=self.share)
        # The export's words go to a file beside the .blend (a long bake says a lot: a pipe read at the end would fill up
        # and hold the export still).
        log = os.path.splitext(bpy.data.filepath)[0] + "_export.log"
        _export["log"] = log
        args = [bpy.app.binary_path, "-b", bpy.data.filepath, "--python", EXPORTER, "--", folder]
        if self.bake:
            args += ["--bake", self.bake]
        with open(log, "w", encoding="utf-8") as out:
            _export["proc"] = subprocess.Popen(args, stdout=out, stderr=subprocess.STDOUT, text=True,
                                               creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        context.scene.ps_status = f"Baking the light ({self.bake})…" if self.bake else "Exporting…"
        self._timer = context.window_manager.event_timer_add(0.5, window=context.window)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def cancel(self, context):
        # Another file opened (or Blender closing) while it runs: the export goes on by itself, the buttons work again.
        try:
            context.window_manager.event_timer_remove(self._timer)
        except (ReferenceError, ValueError, TypeError):
            pass
        _export["proc"] = None
        context.scene.ps_status = ""

    def modal(self, context, event):
        if event.type != "TIMER":
            return {"PASS_THROUGH"}
        proc = _export["proc"]
        if proc is None:
            return self.cancel(context) or {"CANCELLED"}
        if proc.poll() is None:
            # How far a bake has got, from its log.
            try:
                with open(_export["log"], encoding="utf-8", errors="replace") as f:
                    said = [l.strip() for l in f.read().splitlines()
                            if l.startswith(("Bake ", "  atlas ", "Radar:")) or " probes; all " in l]
                if said and said[-1] != context.scene.ps_status:
                    context.scene.ps_status = said[-1][:90]
            except OSError:
                pass
            return {"PASS_THROUGH"}
        try:
            with open(_export["log"], encoding="utf-8", errors="replace") as f:
                out = f.read()
        except OSError:
            out = ""
        _export["proc"] = None
        context.window_manager.event_timer_remove(self._timer)
        line = next((l for l in out.splitlines() if l.startswith("Exported")), None)
        if proc.returncode != 0 or line is None:
            context.scene.ps_status = "Export failed (see the system console)"
            print(out)
            self.report({"ERROR"}, "Export failed")
            return {"CANCELLED"}
        if _export.get("share"):
            context.scene.ps_status = pack_for_sharing(_export["package"])
            self.report({"INFO"}, context.scene.ps_status)
            return {"FINISHED"}
        if _export["test"]:
            context.scene.ps_status = deliver_test(context)
            self.report({"INFO"}, context.scene.ps_status)
            return {"FINISHED"}
        if not HAS_UNITY:
            context.scene.ps_status = "Exported (Unity is not here: Test and play plays it in the game)"
            return {"FINISHED"}
        os.makedirs(os.path.dirname(REQUEST), exist_ok=True)
        with open(REQUEST, "w", encoding="utf-8") as f:
            json.dump({"package": _export["package"], "ruleset": _export["ruleset"], "play": _export["play"]}, f)
        _export["waiting"], _export["since"] = True, time.time()
        context.scene.ps_status = "Exported. Waiting for Unity…"
        self.report({"INFO"}, context.scene.ps_status)
        bring_unity_forward()
        return {"FINISHED"}


# The game's mark that it runs and the request it takes (Bootstrap.MapTestRequests), in its Maps folder.
GAME_RUNNING, GAME_REQUEST = "game_running.txt", "test_request.json"


def game_path():
    prefs = bpy.context.preferences.addons.get(__name__)
    path = bpy.path.abspath(prefs.preferences.game_path) if prefs else ""
    return path if path and os.path.isfile(path) else ""


MAP_FORMAT = 1  # the map package format the compiler writes (compiler/export_map.py FORMAT)


def game_reads():
    """The map format the game set in the preferences reads (its Maps/game_info.json, written as it starts), or None
    when it does not say (a game from before it did)."""
    if not game_path():
        return None
    try:
        with open(os.path.join(os.path.dirname(game_path()), "Maps", "game_info.json"), encoding="utf-8") as f:
            return int(json.load(f).get("mapFormat"))
    except (OSError, ValueError, TypeError, AttributeError):
        return None


def running_games():
    """The Maps folders of the games running now (their mark fresh): the game set in the preferences, and Unity's project
    (the game played in the editor)."""
    folders = [os.path.join(PROJECT, "Maps")] if HAS_UNITY else []
    if game_path():
        folders.insert(0, os.path.join(os.path.dirname(game_path()), "Maps"))
    for folder in folders:
        mark = os.path.join(folder, GAME_RUNNING)
        try:
            if os.path.exists(mark) and time.time() - os.path.getmtime(mark) < 4:
                yield folder
        except OSError:
            pass


def deliver_test(context):
    """The exported package to a game: the one running takes it at once; else the game set in the preferences starts on
    it; else Unity (this project) gets the request and opens the menu. Returns what was done, for the panel."""
    request = {"package": _export["package"], "ruleset": _export["ruleset"], "light": _export["light"]}
    for folder in running_games():
        with open(os.path.join(folder, GAME_REQUEST), "w", encoding="utf-8") as f:
            json.dump(request, f)
        if os.path.normcase(folder) == os.path.normcase(os.path.join(PROJECT, "Maps")):
            bring_unity_forward()
        else:
            bring_forward(game_path())
        return "Sent to the running game: it goes to the map now"
    if game_path():
        game = game_path()
        subprocess.Popen([game, "-map", _export["package"], "-mode", _export["ruleset"], "-light", _export["light"]],
                         cwd=os.path.dirname(game))
        return "Starting the game on the map…"
    if not HAS_UNITY:
        return "No game to play it in: set it in Preferences → Add-ons → PlaceholderShooter map tools → Game"
    os.makedirs(os.path.dirname(REQUEST), exist_ok=True)
    with open(REQUEST, "w", encoding="utf-8") as f:
        json.dump(dict(request, play=True, test=True), f)
    _export["waiting"], _export["since"] = True, time.time()
    bring_unity_forward()
    return "Exported. Waiting for Unity…"


def last_bake(package):
    """When the package's light was baked (its map.json's time), or None when it has none (the test light)."""
    path = os.path.join(package, "map.json")
    try:
        with open(path, encoding="utf-8") as f:
            if '"baked":' not in f.read():
                return None
        return os.path.getmtime(path)
    except OSError:
        return None


def pack_for_sharing(package):
    """The exported package as one file, <map>.psmap (a zip of its files), beside the .blend; the folder opens with it."""
    import zipfile
    name = os.path.basename(package)
    for tail in ("_package", "_baked"):
        if name.endswith(tail):
            name = name[:-len(tail)]
    target = os.path.join(os.path.dirname(package), name + ".psmap")
    with zipfile.ZipFile(target, "w", zipfile.ZIP_DEFLATED) as archive:
        for file in sorted(os.listdir(package)):
            path = os.path.join(package, file)
            # radar_auto_*: the made radar pictures kept to draw over (the map uses radar_*.png), not part of the map.
            if os.path.isfile(path) and not file.startswith("radar_auto"):
                archive.write(path, file)
    if os.name == "nt":
        subprocess.Popen(["explorer", "/select,", target])
    elif sys.platform == "darwin":
        subprocess.Popen(["open", "-R", target])  # Finder, the file selected
    else:
        subprocess.Popen(["xdg-open", os.path.dirname(target)])
    size = os.path.getsize(target) / (1024 * 1024)
    return f"Packed: {os.path.basename(target)} ({size:.1f} MB), ready to send"


class MAP_OT_preview(bpy.types.Operator):
    bl_idname = "psmap.preview"
    bl_label = "Take the picture (this view)"
    bl_description = ("The Workshop card's picture: the 3D view as it is now (the perspective one in four views), saved as "
                      "<map>_preview.png beside the .blend and put in the package at every export")

    def execute(self, context):
        if not bpy.data.filepath:
            self.report({"ERROR"}, "Save the file first")
            return {"CANCELLED"}
        area = context.area if context.area and context.area.type == "VIEW_3D" else next(
            (a for a in context.screen.areas if a.type == "VIEW_3D"), None)
        if area is None:
            self.report({"ERROR"}, "No 3D view")
            return {"CANCELLED"}
        regions = [r for r in area.regions if r.type == "WINDOW"]
        region = next((r for r in regions if r.data and r.data.view_perspective == "PERSP"), regions[-1])
        render = context.scene.render
        kept = (render.resolution_x, render.resolution_y, render.resolution_percentage)
        render.resolution_x, render.resolution_y, render.resolution_percentage = 960, 540, 100
        try:
            with context.temp_override(area=area, region=region):
                bpy.ops.render.opengl(write_still=False, view_context=True)
            path = os.path.splitext(bpy.data.filepath)[0] + "_preview.png"
            bpy.data.images["Render Result"].save_render(path)
        finally:
            render.resolution_x, render.resolution_y, render.resolution_percentage = kept
        context.scene.ps_status = "Picture taken: it goes into the package at the next export"
        return {"FINISHED"}


def has_preview():
    return bool(bpy.data.filepath) and os.path.exists(os.path.splitext(bpy.data.filepath)[0] + "_preview.png")


def bring_forward(executable):
    """A program's window to the front (the game's), by its file."""
    if os.name != "nt" or not executable:
        return
    script = ("$p = Get-Process | Where-Object { $_.Path -eq '" + executable.replace("'", "''") + "' } | Select-Object -First 1; "
              "if ($p) { (New-Object -ComObject WScript.Shell).AppActivate($p.Id) | Out-Null }")
    try:
        subprocess.Popen(["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", script],
                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except OSError:
        pass


class MAP_preferences(bpy.types.AddonPreferences):
    bl_idname = __name__
    game_path: bpy.props.StringProperty(
        name="Game", subtype="FILE_PATH",
        description="The game to test maps in (PlaceholderShooter.exe): Test and play starts it on the map, or sends the map "
                    "to it while it runs. Empty: Unity (this project's editor)")

    def draw(self, context):
        self.layout.prop(self, "game_path")


def busy():
    """An export running, or Unity still on the last request (taken or not)."""
    return _export["proc"] is not None or _export["waiting"]


def poll_unity():
    """Every second while waiting: what Unity says it is doing (its status file), into the panel."""
    if not _export["waiting"]:
        return 1.0
    text, done = None, False
    try:
        if os.path.exists(STATUS) and os.path.getmtime(STATUS) >= _export["since"] - 1:
            with open(STATUS, encoding="utf-8") as f:
                status = json.load(f)
            text = status.get("text")
            done = status.get("state") in ("ready", "playing", "done", "error")
        elif os.path.exists(REQUEST) and time.time() - _export["since"] > 15:
            text = "Unity has not taken it yet: is it open (and not in a dialog)?"
    except (OSError, ValueError):
        pass
    if time.time() - _export["since"] > 600:
        text, done = "No word from Unity for 10 minutes: try again", True
        try:
            os.remove(REQUEST)
        except OSError:
            pass
    if done:
        _export["waiting"] = False
    for scene in bpy.data.scenes:
        if text and scene.ps_status != text:
            scene.ps_status = text
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type in ("VIEW_3D", "PROPERTIES"):
                area.tag_redraw()
    return 1.0


def bring_unity_forward():
    """Unity's window to the front, so its progress (compile, bake, play) is seen: Windows lets the window in front (Blender's)
    hand the focus over."""
    if os.name != "nt":
        return
    script = ("$p = Get-Process Unity -ErrorAction SilentlyContinue | Where-Object { $_.MainWindowTitle -like '*" +
              os.path.basename(PROJECT).replace("'", "''") + "*' } | Select-Object -First 1; "
              "if ($p) { (New-Object -ComObject WScript.Shell).AppActivate($p.Id) | Out-Null }")
    try:
        subprocess.Popen(["powershell", "-NoProfile", "-WindowStyle", "Hidden", "-Command", script],
                         creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except OSError:
        pass


# ---------- The panel: ui.py (tabs in the sidebar, popup, pie menus) ----------
class MAP_OT_surface(bpy.types.Operator):
    bl_idname = "psmap.surface"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Surface"
    bl_description = ("The whole object's surface over its materials' (a special brush): what bullets go through, what hits and steps "
                      "sound like. Usually the material says it")
    surface: bpy.props.EnumProperty(items=[(s, s, "") for s in SURFACES])

    def execute(self, context):
        for o in context.selected_objects:
            if is_brush(o):
                if self.surface == "default":
                    o.pop("ps_surface", None)
                else:
                    o["ps_surface"] = self.surface
        return {"FINISHED"}


class MAP_OT_material_surface(bpy.types.Operator):
    bl_idname = "psmap.material_surface"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Material's surface"
    bl_description = ("The surface of the active material (Hammer's $surfaceprop): every face with it, on every brush, "
                      "is that for bullets, steps and hits")
    surface: bpy.props.EnumProperty(items=[(s, s, "") for s in SURFACES])

    def execute(self, context):
        obj = context.active_object
        mat = obj.active_material if obj is not None else None
        if mat is None:
            return {"CANCELLED"}
        if self.surface == "default":
            mat.pop("ps_surface", None)
        else:
            mat["ps_surface"] = self.surface
        return {"FINISHED"}


class MAP_OT_flip_panel(bpy.types.Operator):
    bl_idname = "psmap.flip_panel"
    bl_label = "Panel to the other side"
    bl_description = "Move this sidebar to the left side of the view (and back)"

    def execute(self, context):
        region = context.region if context.region and context.region.type == "UI" else next(
            (r for r in context.area.regions if r.type == "UI"), None)
        if region is None:
            return {"CANCELLED"}
        with context.temp_override(area=context.area, region=region):
            bpy.ops.screen.region_flip()
        return {"FINISHED"}


CLASSES = [PSIssue, MAP_OT_grid, MAP_OT_quad_view, MAP_OT_make_brushes, MAP_OT_material,
           MAP_OT_brush_kind, MAP_OT_set, MAP_OT_add_entity, MAP_OT_toggle, MAP_OT_check, MAP_OT_go, MAP_OT_export_play,
           MAP_OT_surface, MAP_OT_material_surface, MAP_OT_flip_panel, MAP_OT_preview, MAP_preferences]


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    for c in brush_tools.CLASSES + walk.CLASSES:
        bpy.utils.register_class(c)
    makers.register()
    overlay.register()
    ui.register()
    start.register()
    walk.undo_player_walk(bpy.context.preferences)
    bpy.types.Scene.ps_grid_units = bpy.props.IntProperty(name="Grid (units)", default=16, min=1, max=256)
    bpy.types.Scene.ps_map_collection = bpy.props.PointerProperty(type=bpy.types.Collection, name="Map collection",
                                                                  description="What goes into the game")
    bpy.types.Scene.ps_issues = bpy.props.CollectionProperty(type=PSIssue)
    bpy.types.Scene.ps_ruleset = bpy.props.EnumProperty(items=RULESETS, name="Mode", default="wingman")
    bpy.types.Scene.ps_status = bpy.props.StringProperty()
    bpy.types.Scene.ps_author = bpy.props.StringProperty(name="Author", description="Who made the map (the Workshop shows it)")
    bpy.types.Scene.ps_description = bpy.props.StringProperty(name="About", description="What the map is, in a line or two")
    bpy.types.Scene.ps_version = bpy.props.StringProperty(name="Version", description="The map's own version (1.0, 1.1…)")
    bpy.types.Scene.ps_test_light = bpy.props.EnumProperty(
        name="Test light", default="faces",
        items=[("faces", "By faces", "Faces lit by where they look, no shadows: instant, shows the shapes"),
               ("flat", "Flat", "All equally bright (fullbright)"),
               ("sun", "Sun", "The sun with live shadows and the lamps: nearer the end look, heavier")])
    # The radar the export makes (Docs/radar-generator.md).
    S = bpy.types.Scene
    S.ps_radar = bpy.props.BoolProperty(name="Radar", default=True,
                                        description="Make the radar's pictures at export: the floor players can get to, "
                                                    "walked from the spawns (the export takes longer)")
    S.ps_radar_resolution = bpy.props.EnumProperty(name="Resolution", default="1024",
                                                   items=[("1024", "1024", "Pictures 1024 × 1024"),
                                                          ("2048", "2048", "Pictures 2048 × 2048 (slower, sharper)")])
    S.ps_radar_cover = bpy.props.FloatProperty(name="Cover up to", default=3.0, min=0.5, max=10.0, unit="LENGTH",
                                               description="What stands lower than this over the floor around it is cover "
                                                           "(boxes, low walls); higher is a wall")
    S.ps_radar_ao = bpy.props.BoolProperty(name="Shading", default=True,
                                           description="Floor darker by walls and cover (ambient occlusion)")
    S.ps_radar_ao_strength = bpy.props.FloatProperty(name="Shading strength", default=0.45, min=0.0, max=1.0)
    S.ps_radar_shadow = bpy.props.BoolProperty(name="Outer shadow", default=True,
                                               description="A soft dark shadow around where players go")
    S.ps_radar_tints = bpy.props.BoolProperty(name="Zone tints", default=True,
                                              description="Bomb sites tinted red, buy zones green")
    for i in range(4):
        setattr(S, f"ps_radar_image_{i}", bpy.props.StringProperty(
            name=f"Layer {i} picture", subtype="FILE_PATH",
            description="Your own picture for this radar layer (the same square as the made radar_auto_*.png in the package)"))
    bpy.app.handlers.depsgraph_update_post.append(on_depsgraph)
    bpy.app.timers.register(poll_unity, first_interval=1.0, persistent=True)
    for h in (bpy.app.handlers.undo_pre, bpy.app.handlers.redo_pre):
        h.append(undo_begins)
    for h in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        h.append(undo_ends)
    _draw_handle[0] = bpy.types.SpaceView3D.draw_handler_add(draw_grid_size, (), "WINDOW", "POST_PIXEL")
    _grid_handle[0] = bpy.types.SpaceView3D.draw_handler_add(draw_grid, (), "WINDOW", "POST_VIEW")
    bpy.app.timers.register(grid_on_start, first_interval=0.5)
    bpy.app.timers.register(watch_transforms, first_interval=1.0, persistent=True)
    if grid_on_load not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(grid_on_load)
    kc = bpy.context.window_manager.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name="3D View", space_type="VIEW_3D")
        for key, step in (("LEFT_BRACKET", -1), ("RIGHT_BRACKET", 1)):
            kmi = km.keymap_items.new("psmap.grid", key, "PRESS")
            kmi.properties.step = step
            _keymaps.append((km, kmi))


def unregister():
    for km, kmi in _keymaps:
        km.keymap_items.remove(kmi)
    _keymaps.clear()
    if _draw_handle[0] is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_draw_handle[0], "WINDOW")
        _draw_handle[0] = None
    if _grid_handle[0] is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_grid_handle[0], "WINDOW")
        _grid_handle[0] = None
    if grid_on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(grid_on_load)
    if bpy.app.timers.is_registered(poll_unity):
        bpy.app.timers.unregister(poll_unity)
    if bpy.app.timers.is_registered(watch_transforms):
        bpy.app.timers.unregister(watch_transforms)
    if on_depsgraph in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(on_depsgraph)
    for h in (bpy.app.handlers.undo_pre, bpy.app.handlers.redo_pre):
        if undo_begins in h:
            h.remove(undo_begins)
    for h in (bpy.app.handlers.undo_post, bpy.app.handlers.redo_post):
        if undo_ends in h:
            h.remove(undo_ends)
    for prop in ("ps_grid_units", "ps_map_collection", "ps_issues", "ps_ruleset", "ps_status", "ps_test_light", "ps_author",
                 "ps_description", "ps_version", "ps_radar", "ps_radar_resolution", "ps_radar_cover", "ps_radar_ao",
                 "ps_radar_ao_strength", "ps_radar_shadow", "ps_radar_tints",
                 *(f"ps_radar_image_{i}" for i in range(4))):
        delattr(bpy.types.Scene, prop)
    start.unregister()
    ui.unregister()
    overlay.unregister()
    makers.unregister()
    for c in reversed(brush_tools.CLASSES + walk.CLASSES):
        bpy.utils.unregister_class(c)
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)


from . import brush_tools, makers, overlay, walk, ui, start  # noqa: E402  (they use the names above)
brush_tools.remembered(MAP_OT_add_entity)  # Ctrl+Z in its panel: the settings before
