"""Run timings: the length of a path of points and how long it takes at CS speeds."""
import bpy

from . import UNIT, snapped_cursor

# CS:GO: running 250 u/s with a knife, 215 with a rifle (AK), walking with Shift at 52 % of that.
SPEEDS = [("knife", 250), ("rifle (AK)", 215), ("AWP", 200), ("Shift, knife", 130)]
TIMING = "Timing (not exported)"


def undo_player_walk(prefs):
    """The add-on's former "Walk as a player" set Blender's own Walk navigation to a CS player (gravity, eyes at 64 units):
    back to Blender's free flight."""
    walk = prefs.inputs.walk_navigation
    if walk.use_gravity and abs(walk.view_height - 64 * UNIT) < 1e-4:
        walk.use_gravity = False
        walk.view_height = 1.6
        walk.jump_height = 0.4
        walk.walk_speed = 2.5
        walk.walk_speed_factor = 5.0


def timing_collection(scene):
    col = bpy.data.collections.get(TIMING)
    if col is None:
        col = bpy.data.collections.new(TIMING)
        col["ps_export"] = 0
        scene.collection.children.link(col)
    return col


def timing_points(scene):
    col = bpy.data.collections.get(TIMING)
    return sorted([o for o in col.objects if o.type == "EMPTY"], key=lambda o: o.name) if col else []


class MAP_OT_timing_point(bpy.types.Operator):
    bl_idname = "psmap.timing_point"
    bl_label = "Add a path point"
    bl_description = "A point of the run to time, at the 3D cursor (the points are joined in their order)"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        col = timing_collection(context.scene)
        n = len(timing_points(context.scene)) + 1
        obj = bpy.data.objects.new(f"Path {n:02d}", None)
        obj.empty_display_type = "PLAIN_AXES"
        obj.empty_display_size = 0.5
        obj.location = snapped_cursor(context)
        col.objects.link(obj)
        return {"FINISHED"}


class MAP_OT_timing_clear(bpy.types.Operator):
    bl_idname = "psmap.timing_clear"
    bl_label = "Clear the path"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        for o in timing_points(context.scene):
            bpy.data.objects.remove(o, do_unlink=True)
        return {"FINISHED"}


CLASSES = [MAP_OT_timing_point, MAP_OT_timing_clear]


def draw(layout, context):
    box = layout.box()
    box.label(text="Timings", icon="TIME")
    row = box.row(align=True)
    row.operator("psmap.timing_point", icon="ADD")
    row.operator("psmap.timing_clear", text="", icon="TRASH")
    pts = timing_points(context.scene)
    if len(pts) >= 2:
        length = sum((pts[i + 1].location - pts[i].location).length for i in range(len(pts) - 1))
        col = box.column(align=True)
        col.label(text=f"Path: {length / UNIT:.0f} units ({length:.1f} m), {len(pts)} points")
        for name, speed in SPEEDS:
            col.label(text=f"   {name}: {length / UNIT / speed:.1f} s")
