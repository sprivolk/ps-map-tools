"""Faces no player ever sees, left out of the map (as VBSP leaves out the outside of a sealed map, without the map having
to be sealed): the back of the walls at the map's edge, the tops of roofs nobody gets onto, the sides turned to the void.

Where players can be: every floor a player stands on (radar_gen.walk_map: where the standing box fits), reached from
the spawns or not yet (a map being built: its bomb site not joined to the rest yet still has its walls seen), an eye
there standing (64 units up) and at the top of a jump (121). A face goes only when no eye at all is in front of it (it looks at the
void, down at no floor, or out of the map), whatever stands in between; marked Always draw, it stays.

Blender's space (x, y, z up), metres, the seen objects as the export has them (cut and joined)."""
import math
import os

import bmesh
import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree

EYES = (64 * 0.025, 121 * 0.025)  # standing, at the top of a jump
STEP = 1.6                         # metres between eyes over the floor
TRIES = 400                        # eyes tried per point at most (the nearest first); more in front: the face is kept


def reached_floor(manifest, seen_tris, folder):
    """Every floor a player could stand on (radar_gen's walk: reached from the spawns or not), in the game's space:
    (n, 3) x, floor height, z."""
    import radar_gen as rg
    hull = None
    if manifest.get("hull") and os.path.exists(os.path.join(folder, manifest["hull"])):
        hull = rg.Hull(os.path.join(folder, manifest["hull"]))
    blocks, block_tris = [], []
    for group in manifest.get("collision", []):
        if group.get("kind"):
            continue
        for b in group.get("blocks", []):
            p = np.array(b["p"], dtype=np.float64).reshape(-1, 3)
            t = np.array(b["t"], dtype=np.int64).reshape(-1, 3)
            if not len(p) or not len(t):
                continue
            p[:, 0] = -p[:, 0]
            t = t[:, ::-1]
            blocks.append((p, t, not b.get("c")))
            block_tris.append(p[t])
    solids = rg.Solids([] if hull else blocks, hull)
    walk_tris = np.concatenate([seen_tris] + ([] if hull else block_tris)) if (len(seen_tris) or block_tris) else seen_tris
    if not len(walk_tris):
        return np.zeros((0, 3))
    w = rg.walk_map(solids, rg.make_bvh(walk_tris), walk_tris, manifest.get("entities", []))
    return np.stack([w.colx[w.a_col], w.nh, w.colz[w.a_col]], axis=1)


def eyes_over(floor):
    """Eyes over the floor (game space in, Blender's out): one every STEP square a floor height, at each eye height."""
    if not len(floor):
        return np.zeros((0, 3))
    key = np.stack([np.floor(floor[:, 0] / STEP), np.floor(floor[:, 2] / STEP), np.floor(floor[:, 1] / 1.5)], axis=1)
    _, first = np.unique(key, axis=0, return_index=True)
    f = floor[first]
    out = []
    for h in EYES:
        # Blender (x, y, z) from the game's (x, y up, z): (-x, -z, y).
        out.append(np.stack([-f[:, 0], -f[:, 2], f[:, 1] + h], axis=1))
    return np.concatenate(out)


def blocker(objects, see_through):
    """What sight stops at: the seen objects' faces, but for those of see-through surfaces (a BVH tree, world space)."""
    points, polygons = [], []
    for o in objects:
        me = o.data
        mw = o.matrix_world
        mats = me.materials
        first = len(points)
        points += [mw @ v.co for v in me.vertices]
        for p in me.polygons:
            m = mats[p.material_index] if p.material_index < len(mats) else None
            if m is not None and str(m.get("ps_surface", "")) in see_through:
                continue
            polygons.append([first + i for i in p.vertices])
    return BVHTree.FromPolygons(points, polygons) if polygons else None


def seen_from(points, normal, eyes, tree):
    """Whether some eye in front of the face sees one of its points. None: too many eyes to try (keep it)."""
    for p in points:
        start = p + normal * 0.02
        ahead = (eyes - np.array(start)) @ np.array(normal)
        front = eyes[ahead > 0.01]
        if not len(front):
            continue
        # Some place a player can be is in front of it: kept. (Whether something is in between is not asked: rays from
        # a face to an eye grazed the next step of stairs and the walls round a doorway, and seen faces went.)
        return True
    return False


def leave_out_unseen(objects, manifest, seen_tris, folder, keep_layer, see_through, log=print, air=None, blockers=None):
    """The seen objects' faces no player sees, gone (in place): those with no eye in front, and, the map closed (`air`,
    sealed.py, without a leak), those turned only to the air outside it. The faces gone are added to `blockers` (world
    space: the bake's light still stops at them). Returns how many went."""
    import sealed
    sealed_ok = air is not None and air.leak is None
    floor = reached_floor(manifest, seen_tris, folder)
    eyes = eyes_over(floor)
    if not len(eyes) and not sealed_ok:
        log("Unseen faces: kept (no floor a player stands on)")
        return 0
    tree = blocker(objects, see_through)
    if tree is None:
        return 0
    gone, untold, outside = 0, 0, 0
    for o in objects:
        bm = bmesh.new()
        bm.from_mesh(o.data)
        bm.transform(o.matrix_world)
        bm.normal_update()
        keep = bm.faces.layers.int.get(keep_layer)
        out = []
        for f in bm.faces:
            if keep is not None and f[keep]:
                continue
            c = f.calc_center_median()
            pts = [c] + [v.co.lerp(c, 0.2) for v in f.verts]
            seen = seen_from(pts, f.normal, eyes, tree) if len(eyes) else True
            if seen is None:
                untold += 1
            elif not seen:
                out.append(f)
            elif sealed_ok and not sealed.faces_to_air(air, pts, f.normal):
                out.append(f)
                outside += 1
        if blockers is not None:
            blockers.extend([v.co.copy() for v in f.verts] for f in out)
        if out:
            bmesh.ops.delete(bm, geom=out, context="FACES")
            bm.transform(o.matrix_world.inverted())
            bm.to_mesh(o.data)
            o.data.update()
            gone += len(out)
        bm.free()
    log(f"Unseen faces: {gone} left out (no player sees them; {outside} turned to the outside of the map), {len(eyes)} eyes" +
        (f", {untold} kept untold" if untold else ""))
    return gone
