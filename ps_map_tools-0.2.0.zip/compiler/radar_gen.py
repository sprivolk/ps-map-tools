"""
The map's radar pictures, made at export (Docs/radar-generator.md): only the floor players can get to, found by walking
the map from its spawns with the players' own collision, the way the game's editor generator does (RadarOverview.cs),
with one height gradient for the whole map, cover, shading, the outer shadow and the zones.

Everything here is in the game's (Unity's) space, metres, Y up: the package's glTF space with x turned over
(xU = -xB, yU = zB, zU = -yB). What comes out are the radar_<i>.png files in the package and the manifest's "radar" block,
the very numbers the game's MapRadar takes.
"""
import math
import os
import types
import struct
import time
import zlib

import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree

# ---------- The player (CS:GO, 1 unit = 0.025 m) ----------
HALF = 0.40            # half the box's width (16 units)
CROUCH = 1.35          # the box's height crouched (54 units): what every check uses
CROUCH_HULL = 0.90     # a CS 1.6 map's ducked hull (36 units)
STEP = 0.45            # step height (18 units)
JUMP_UP = 1.66         # the highest one gets onto, crouch-jumping (CS: 66 units; a 64-unit box is climbed)
CELL = 0.20            # the walking grid (8 units): any way 40 units wide holds a grid point
SKIN = 0.005
K = 12                 # surfaces (and floor points) kept per column, highest first
KP = 8                 # surfaces kept per pixel
LAYER_MIN_AREA = 150.0
NEAR = 6.0             # pixels drawn: no farther than this from a reached floor point
OVER_NEAR = 1.5        # a thing on a floor this near is that floor's cover (not the floor below seen through it)
WALL_FILL = 1.2        # gaps between floors up to this wide are walls, drawn (not see-through)

# CS2's overviews: the lowest floor is still a floor (a mid grey), the highest the lightest; only walls and what is not
# the map are dark. A gradient starting near black drew the main floor as if it were the void.
DEFAULT_GRADIENT = [(0.0, (0.33, 0.36, 0.41)), (0.5, (0.52, 0.56, 0.61)), (1.0, (0.78, 0.81, 0.85))]
OUTLINE = (0.8, 0.8, 0.8)
LEDGE = (0.82, 0.86, 0.90)
SITE_TINT = (0.77, 0.295, 0.171)
BUY_TINT = (0.18, 0.83, 0.23)
OTHER_LAYER_ALPHA = 0.28


def unity(p):
    """A glTF point (x, y, z) in the game's space."""
    return (-p[0], p[1], p[2])


# ---------- What is solid to a player ----------
class Solids:
    """The player's collision: the package's convex blocks (and its concave ones, as triangles), or a CS 1.6 map's own
    hull. `free` says whether a crouched player's box fits with its feet at the given points."""

    def __init__(self, blocks, hull=None):
        self.hull = hull
        self.height = CROUCH_HULL if hull else CROUCH
        self.convex, self.concave = [], []
        for points, tris, convex in blocks:
            lo, hi = points.min(axis=0), points.max(axis=0)
            if convex:
                a, b, c = points[tris[:, 0]], points[tris[:, 1]], points[tris[:, 2]]
                n = np.cross(b - a, c - a)
                length = np.linalg.norm(n, axis=1)
                keep = length > 1e-9
                n, a = n[keep] / length[keep, None], a[keep]
                if not len(n):
                    continue
                d = (n * a).sum(axis=1)
                # Facing out: the middle is behind every face (winding turned over somewhere: turn them all).
                middle = points.mean(axis=0)
                if ((n @ middle) - d > 0).sum() > len(n) / 2:
                    n, d = -n, -d
                self.convex.append((lo, hi, n, d))
            else:
                self.concave.append((lo, hi, points[tris]))

    def free(self, x, foot, z, height=None, half=HALF):
        """`height`: the box's height (the crouched one when not given; a hull map has its own). `half`: its half width
        (a thin probe: whether anything lies right on a surface)."""
        x, foot, z = (np.asarray(v, dtype=np.float64) for v in (x, foot, z))
        if self.hull is not None:
            return self.hull.free(x, foot + self.height * 0.5, z)
        blocked = np.zeros(len(x), dtype=bool)
        if not len(x):
            return ~blocked
        hy = (height or self.height) * 0.5
        cy = foot + hy
        # Queries sorted into 2 m cells, so each block looks only at the ones near it.
        size = 2.0
        x0, z0 = x.min() - 1.0, z.min() - 1.0
        cx = np.floor((x - x0) / size).astype(np.int64)
        cz = np.floor((z - z0) / size).astype(np.int64)
        ncx = int(cx.max()) + 1
        key = cz * ncx + cx
        order = np.argsort(key, kind="stable")
        keys = key[order]
        nrows = int(cz.max()) + 1
        h = np.array([half, hy, half])

        def near(lo, hi):
            a0 = max(0, int(math.floor((lo[0] - half - x0) / size)))
            a1 = min(ncx - 1, int(math.floor((hi[0] + half - x0) / size)))
            b0 = max(0, int(math.floor((lo[2] - half - z0) / size)))
            b1 = min(nrows - 1, int(math.floor((hi[2] + half - z0) / size)))
            if a0 > a1 or b0 > b1:
                return None
            parts = []
            for row in range(b0, b1 + 1):
                s = np.searchsorted(keys, row * ncx + a0, "left")
                e = np.searchsorted(keys, row * ncx + a1, "right")
                if e > s:
                    parts.append(order[s:e])
            if not parts:
                return None
            idx = np.concatenate(parts)
            idx = idx[~blocked[idx]]
            ok = ((x[idx] + half > lo[0] + SKIN) & (x[idx] - half < hi[0] - SKIN) &
                  (z[idx] + half > lo[2] + SKIN) & (z[idx] - half < hi[2] - SKIN) &
                  (cy[idx] + hy > lo[1] + SKIN) & (cy[idx] - hy < hi[1] - SKIN))
            idx = idx[ok]
            return idx if len(idx) else None

        for lo, hi, n, d in self.convex:
            idx = near(lo, hi)
            if idx is None:
                continue
            c = np.stack([x[idx], cy[idx], z[idx]], axis=1)
            r = np.abs(n) @ h
            outside = (c @ n.T) - r[None, :] > d[None, :] - SKIN
            blocked[idx[~outside.any(axis=1)]] = True
        for lo, hi, tris in self.concave:
            idx = near(lo, hi)
            if idx is None:
                continue
            chunk = max(1, 200000 // max(1, len(idx)))
            for t0 in range(0, len(tris), chunk):
                t = tris[t0:t0 + chunk]
                live = idx[~blocked[idx]]
                if not len(live):
                    break
                c = np.stack([x[live], cy[live], z[live]], axis=1)
                hit = box_hits_triangles(c, h - SKIN, t)
                blocked[live[hit]] = True
        return ~blocked


def box_hits_triangles(centres, half, tris):
    """For each box (centre, the same half size), whether it meets any of the triangles (separating axes)."""
    v = tris[None, :, :, :] - centres[:, None, None, :]           # (Q, T, 3 corners, 3)
    v0, v1, v2 = v[:, :, 0], v[:, :, 1], v[:, :, 2]
    sep = np.zeros(v0.shape[:2], dtype=bool)
    for k in range(3):
        mn = np.minimum(np.minimum(v0[..., k], v1[..., k]), v2[..., k])
        mx = np.maximum(np.maximum(v0[..., k], v1[..., k]), v2[..., k])
        sep |= (mn > half[k]) | (mx < -half[k])
    e = (v1 - v0, v2 - v1, v0 - v2)
    n = np.cross(e[0], e[1])
    r = (np.abs(n) * half).sum(axis=-1)
    sep |= np.abs((n * v0).sum(axis=-1)) > r
    axes = np.eye(3)
    for ei in e:
        for u in axes:
            a = np.cross(ei, u)
            p0, p1, p2 = (a * v0).sum(-1), (a * v1).sum(-1), (a * v2).sum(-1)
            r = (np.abs(a) * half).sum(-1)
            sep |= (np.minimum(np.minimum(p0, p1), p2) > r) | (np.maximum(np.maximum(p0, p1), p2) < -r)
    return (~sep).any(axis=1)


class Hull:
    """A CS 1.6 map's clip hulls (hull.bin, glTF space): the ducked hull, already grown by the player's size, of the world
    and its brush models; a point is free unless one of them holds it solid."""

    def __init__(self, path):
        data = open(path, "rb").read()
        if data[:4] != b"PSH1":
            raise ValueError("not a hull file")
        p = 4
        (count,) = struct.unpack_from("<i", data, p); p += 4
        self.planes = np.frombuffer(data, dtype="<f4", count=count * 4, offset=p).reshape(-1, 4).astype(np.float64)
        p += count * 16
        (n,) = struct.unpack_from("<i", data, p); p += 4
        nodes = np.frombuffer(data, dtype="<i4", count=n * 3, offset=p).reshape(-1, 3)
        p += n * 12
        self.plane, self.front, self.back = nodes[:, 0].copy(), nodes[:, 1].copy(), nodes[:, 2].copy()
        (m,) = struct.unpack_from("<i", data, p); p += 4
        self.heads = []
        for _ in range(m):
            (length,) = struct.unpack_from("<i", data, p); p += 4 + length
            kind, stand, duck = struct.unpack_from("<Bii", data, p); p += 9
            self.heads.append(duck)

    def free(self, x, cy, z):
        point = np.stack([-x, cy, z], axis=1)  # back in glTF space
        ok = np.ones(len(x), dtype=bool)
        for head in self.heads:
            node = np.full(len(x), head, dtype=np.int64)
            for _ in range(256):
                live = node >= 0
                if not live.any():
                    break
                i = node[live]
                pl = self.planes[self.plane[i]]
                d = (point[live] * pl[:, :3]).sum(axis=1) - pl[:, 3]
                node[live] = np.where(d >= 0, self.front[i], self.back[i])
            ok &= node != -2
        return ok


# ---------- Surfaces ----------
def make_bvh(triangles):
    """A BVH of triangles given as an (N, 3, 3) array."""
    if not len(triangles):
        return None
    verts = triangles.reshape(-1, 3)
    polys = np.arange(len(verts)).reshape(-1, 3)
    return BVHTree.FromPolygons([tuple(v) for v in verts.tolist()], polys.tolist(), all_triangles=True)


def surfaces(bvh, xs, zs, top, depth, min_up, keep):
    """The surfaces facing up in each column, highest first: a ray down, going on from just under each hit."""
    out = np.full((len(xs), keep), np.nan, dtype=np.float32)
    if bvh is None:
        return out
    down = Vector((0.0, -1.0, 0.0))
    cast = bvh.ray_cast
    for i in range(len(xs)):
        origin = Vector((float(xs[i]), top, float(zs[i])))
        left, k, last = depth, 0, None
        for _ in range(12):
            if left <= 0.0:
                break
            loc, normal, _, dist = cast(origin, down, left)
            if loc is None:
                break
            y = loc.y
            if normal.y >= min_up and (last is None or last - y > 0.02):
                out[i, k] = y
                k += 1
                last = y
                if k >= keep:
                    break
            step = dist + 0.02
            origin.y -= step
            left -= step
    return out


# ---------- Pictures ----------
def box_blur(a, radius):
    """A box blur (summed areas), edges clamped."""
    if radius <= 0:
        return a
    padded = np.pad(a, radius, mode="edge")
    s = np.cumsum(np.cumsum(padded, axis=0), axis=1)
    s = np.pad(s, ((1, 0), (1, 0)))
    w = 2 * radius + 1
    total = s[w:, w:] - s[:-w, w:] - s[w:, :-w] + s[:-w, :-w]
    return total / (w * w)


def grow(mask, steps):
    """The mask grown by this many pixels (each step: the 8 neighbours)."""
    m = mask.copy()
    for _ in range(steps):
        g = m.copy()
        g[1:, :] |= m[:-1, :]; g[:-1, :] |= m[1:, :]
        g[:, 1:] |= m[:, :-1]; g[:, :-1] |= m[:, 1:]
        g[1:, 1:] |= m[:-1, :-1]; g[:-1, :-1] |= m[1:, 1:]
        g[1:, :-1] |= m[:-1, 1:]; g[:-1, 1:] |= m[1:, :-1]
        m = g
    return m


def shifted(a, dy, dx, fill):
    """a moved by (dy, dx) pixels: out[y, x] = a[y + dy, x + dx], `fill` past the edges."""
    out = np.full_like(a, fill)
    h, w = a.shape[:2]
    ys, ye = max(0, -dy), min(h, h - dy)
    xs, xe = max(0, -dx), min(w, w - dx)
    if ys < ye and xs < xe:
        out[ys:ye, xs:xe] = a[ys + dy:ye + dy, xs + dx:xe + dx]
    return out


def write_png(path, rgba):
    """An RGBA 8-bit picture, rows given top first."""
    h, w = rgba.shape[:2]
    raw = b"".join(b"\x00" + rgba[y].tobytes() for y in range(h))

    def chunk(kind, body):
        return struct.pack(">I", len(body)) + kind + body + struct.pack(">I", zlib.crc32(kind + body) & 0xFFFFFFFF)
    data = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0)) +
            chunk(b"sRGB", b"\x00") + chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))
    with open(path, "wb") as f:
        f.write(data)


class Gradient:
    """Height to colour, one scale for the whole map (TAR's tar_min / tar_max / tar_color)."""

    def __init__(self, low, high, stops=None):
        self.low, self.high = low, max(high, low + 0.5)
        if stops and len(stops) >= 2:
            stops = sorted(stops)
            self.t = np.array([(h - self.low) / (self.high - self.low) for h, _ in stops])
            self.c = np.array([c for _, c in stops], dtype=np.float64)
        else:
            self.t = np.array([t for t, _ in DEFAULT_GRADIENT])
            self.c = np.array([c for _, c in DEFAULT_GRADIENT], dtype=np.float64)

    def __call__(self, h):
        t = np.clip((h - self.low) / (self.high - self.low), 0.0, 1.0)
        return np.stack([np.interp(t, self.t, self.c[:, k]) for k in range(3)], axis=-1)


def over(dst_rgb, dst_a, rgb, a):
    """Paints (rgb, a) over what is there (straight alpha), in place."""
    a = a[..., None] if a.ndim == dst_a.ndim else a
    out_a = a[..., 0] + dst_a * (1.0 - a[..., 0])
    safe = np.where(out_a > 1e-6, out_a, 1.0)
    dst_rgb[:] = (rgb * a + dst_rgb * (dst_a * (1.0 - a[..., 0]))[..., None]) / safe[..., None]
    dst_a[:] = out_a


# ---------- The generator ----------
def volume(e):
    """A volume entity's box (its lowest and highest corner) in the game's space, or None."""
    pts = np.array(e.get("points") or [], dtype=np.float64).reshape(-1, 3)
    if not len(pts):
        return None
    pts[:, 0] = -pts[:, 0]
    return pts.min(axis=0), pts.max(axis=0)


def walk_map(solids, walk_bvh, walk_tris, entities, mark=lambda name: None):
    """Where a player can stand on the map and where they can go from there: the floor points (crouched box free)
    and the ways between them (steps, jumps, drops, ladders; kill zones dead). `flood` walks it from spawns. All of it
    comes back as one namespace."""
    # ---------- The walking grid: every floor in every column where the crouched box fits ----------
    allp = walk_tris.reshape(-1, 3)
    small = np.all(np.abs(allp) < 2000.0, axis=1)
    allp = allp[small] if small.any() else allp
    lo, hi = allp.min(axis=0), allp.max(axis=0)
    gx0, gz0 = lo[0], lo[2]
    gw = int(math.ceil((hi[0] - lo[0]) / CELL)) + 1
    gh = int(math.ceil((hi[2] - lo[2]) / CELL)) + 1
    top, depth = hi[1] + 5.0, (hi[1] - lo[1]) + 10.0
    cols = gw * gh
    colx = gx0 + (np.arange(cols) % gw) * CELL
    colz = gz0 + (np.arange(cols) // gw) * CELL
    surf = surfaces(walk_bvh, colx, colz, top, depth, 0.6, K)
    mark("surfaces")

    # Where a player can stand in a column: on its own surfaces, or on one of the next columns' that the box reaches over
    # (the box rests on the highest thing under it: at a step's edge the step, though this column's own ray misses it —
    # what the editor's generator found by sweeping the box down).
    # For each surface s of a column: the highest surface under the whole box (±HALF) no more than a step above it —
    # what the box rests on there (a step's edge, the uphill side of a ramp).
    grid3 = surf.reshape(gh, gw, K)
    # Only open surfaces are rested on: one something lies right on (a room's floor slab under its wall) is no floor. Taken
    # from the next column, it put players 0.4 m in the air beside every such wall, and a closed room around those
    # 'floors' was drawn as a crate.
    flat_s = surf.reshape(-1)
    si = np.nonzero(~np.isnan(flat_s))[0]
    open_ = np.zeros(len(flat_s), dtype=bool)
    open_[si] = solids.free(colx[si // K], flat_s[si] + 0.03, colz[si // K], height=0.1, half=0.05)
    open3 = np.where(open_.reshape(gh, gw, K), grid3, np.nan)
    rest = grid3.copy()
    reach = int(round(HALF / CELL))
    for oz in range(-reach, reach + 1):
        for ox in range(-reach, reach + 1):
            if not (ox or oz):
                continue
            nb = shifted(open3, oz, ox, np.nan)                         # (gh, gw, K) the neighbour's open surfaces
            ok = (nb[:, :, None, :] >= grid3[:, :, :, None] - 1e-4) & (nb[:, :, None, :] <= grid3[:, :, :, None] + STEP)
            best = np.where(ok, nb[:, :, None, :], np.nan)
            with np.errstate(invalid="ignore"):
                top_ = np.nanmax(np.where(np.isnan(best), -np.inf, best), axis=3)
            top_ = np.where(np.isinf(top_), np.nan, top_)
            rest = np.fmax(rest, top_)
    cand = np.concatenate([grid3, rest], axis=2).reshape(cols, -1)
    cand = -np.sort(-cand, axis=1)
    same = np.zeros_like(cand, dtype=bool)
    same[:, 1:] = np.abs(cand[:, 1:] - cand[:, :-1]) < 0.02
    cand[same] = np.nan
    cand = -np.sort(-cand, axis=1)[:, :2 * K]
    ci, ki = np.nonzero(~np.isnan(cand))
    s = cand[ci, ki].astype(np.float64)
    fits = solids.free(colx[ci], s + 0.02, colz[ci])
    heights = np.full((cols, 2 * K), np.nan, dtype=np.float32)
    heights[ci[fits], ki[fits]] = s[fits]
    # Highest first, the ones closer than 0.1 m to the one above them merged into it.
    heights = -np.sort(-heights, axis=1)
    for k in range(1, heights.shape[1]):
        close = heights[:, k - 1] - heights[:, k] < 0.1
        heights[close, k] = np.nan
    heights = np.ascontiguousarray(-np.sort(-heights, axis=1)[:, :K])
    valid = ~np.isnan(heights)
    nodes = int(valid.sum())
    mark("floor points")

    # ---------- Ways between them ----------
    dx, dz = (1, -1, 0, 0), (0, 0, 1, -1)
    col_of = np.repeat(np.arange(cols), K).reshape(cols, K)
    a_col, a_k = np.nonzero(valid)
    ha = heights[a_col, a_k].astype(np.float64)
    ax, az = a_col % gw, a_col // gw
    edges = []
    queries = []  # (which edge list, its index, the check)
    for d in range(4):
        bx, bz = ax + dx[d], az + dz[d]
        inside = (bx >= 0) & (bz >= 0) & (bx < gw) & (bz < gh)
        b_col = np.where(inside, bz * gw + bx, 0)
        hb_all = heights[b_col].astype(np.float64)                     # (n, K) highest first
        can = (hb_all <= ha[:, None] + JUMP_UP) & ~np.isnan(hb_all) & inside[:, None]
        has = can.any(axis=1)
        first = can.argmax(axis=1)
        hb = hb_all[np.arange(len(ha)), first]
        edge = has.copy()
        differ = has & (np.abs(hb - ha) > 0.01)
        overh = np.maximum(ha, hb) + 0.02
        # Over the edge or the step, at the higher height.
        check_b = np.nonzero(differ)[0]
        # A jump also needs the room above where it starts.
        check_a = np.nonzero(differ & (hb - ha > STEP))[0]
        # A drop comes down to that floor only if nothing is between (not through a ramp over it).
        drop = np.nonzero(differ & (overh - hb > STEP + 0.05))[0]
        if len(drop):
            sb = surf[b_col[drop]].astype(np.float64)
            between = (sb > hb[drop, None] + 0.1) & (sb < overh[drop, None] - 0.05)
            edge[drop[between.any(axis=1)]] = False
        edges.append((edge, b_col, first))
        queries.append((d, check_b, colx[b_col[check_b]], overh[check_b], colz[b_col[check_b]]))
        queries.append((d, check_a, colx[a_col[check_a]], hb[check_a] + 0.02, colz[a_col[check_a]]))
    # Jumps onto what is higher than a step (a crate, a ledge): a box stands no nearer than half its width to it, so the
    # floor below is never the next point to the top — looked for 2 to 4 points out (0.4–0.8 m), the box free at the
    # top's height over all the points between. A 64-unit crate on a roof was never reached (and drawn as the floor
    # under the roof).
    for d in range(4):
        for k in range(2, 5):
            bx, bz = ax + dx[d] * k, az + dz[d] * k
            inside = (bx >= 0) & (bz >= 0) & (bx < gw) & (bz < gh)
            b_col = np.where(inside, bz * gw + bx, 0)
            hb_all = heights[b_col].astype(np.float64)
            can = ((hb_all > ha[:, None] + STEP) & (hb_all <= ha[:, None] + JUMP_UP) & ~np.isnan(hb_all) &
                   inside[:, None])
            has = can.any(axis=1)
            if not has.any():
                continue
            first = can.argmax(axis=1)
            hb = hb_all[np.arange(len(ha)), first]
            idx = np.nonzero(has)[0]
            e_i = len(edges)
            edges.append((has.copy(), b_col, first))
            foot = hb[idx] + 0.02
            for j in range(k):  # where it starts and the points between (the top's own point is free: it is a floor)
                c = (az[idx] + dz[d] * j) * gw + (ax[idx] + dx[d] * j)
                queries.append((e_i, idx, colx[c], foot, colz[c]))
    qx = np.concatenate([q[2] for q in queries]); qf = np.concatenate([q[3] for q in queries])
    qz = np.concatenate([q[4] for q in queries])
    ok = solids.free(qx, qf, qz)
    at = 0
    for d, idx, _, _, _ in queries:
        edges[d][0][idx[~ok[at:at + len(idx)]]] = False
        at += len(idx)
    target = []
    for edge, b_col, first in edges:
        t = np.where(edge, b_col * K + first, -1)
        target.append(t)
    mark("ways")

    # ---------- Walking it from the spawns ----------
    node_id = a_col * K + a_k
    slot = np.full(cols * K, -1, dtype=np.int64)
    slot[node_id] = np.arange(len(node_id))
    nh = ha
    dead = np.zeros(len(node_id), dtype=bool)
    for e in entities:
        if e.get("type") != "killzone":
            continue
        v = volume(e)
        if v is None:
            continue
        x, y, z = colx[a_col], nh, colz[a_col]
        dead |= ((x >= v[0][0]) & (x <= v[1][0]) & (z >= v[0][2]) & (z <= v[1][2]) &
                 (y >= v[0][1] - 0.05) & (y <= v[1][1] + 0.05))
    ladders = []
    for e in entities:
        if e.get("type") != "ladder":
            continue
        v = volume(e)
        if v is None:
            continue
        g = np.array([HALF + CELL, STEP, HALF + CELL])
        l0, l1 = v[0] - g, v[1] + g
        x, y, z = colx[a_col], nh, colz[a_col]
        on = np.nonzero((x >= l0[0]) & (x <= l1[0]) & (z >= l0[2]) & (z <= l1[2]) & (y >= l0[1]) & (y <= l1[1]))[0]
        if len(on):
            ladders.append(on)
    return types.SimpleNamespace(**locals())


def flood(w, spawns):
    """The floor points reached from these spawns, each starting on the floor point under it: (reached, how many
    spawns started)."""
    gx0, gz0, gw, gh, heights, slot, dead, target, ladders = (w.gx0, w.gz0, w.gw, w.gh, w.heights, w.slot, w.dead,
                                                             w.target, w.ladders)
    node_id = w.node_id
    reached = np.zeros(len(node_id), dtype=bool)
    seeds = 0
    for sp in spawns:
        x = int(round((sp[0] - gx0) / CELL)); z = int(round((sp[2] - gz0) / CELL))
        best, best_gap = -1, 1e9
        for zz in range(max(0, z - 2), min(gh, z + 3)):
            for xx in range(max(0, x - 2), min(gw, x + 3)):
                c = zz * gw + xx
                for k in range(K):
                    h = heights[c, k]
                    if np.isnan(h):
                        break
                    if not (sp[1] - 2.5 <= h <= sp[1] + 0.5):
                        continue
                    gap = abs(sp[1] - h) + (abs(xx - x) + abs(zz - z)) * 0.01
                    if gap < best_gap:
                        best, best_gap = slot[c * K + k], gap
        if best >= 0 and not dead[best] and not reached[best]:
            reached[best] = True
            seeds += 1
    frontier = np.nonzero(reached)[0]
    while len(frontier):
        new = []
        for t in target:
            to = t[frontier]
            to = to[to >= 0]
            to = slot[to]
            to = to[(to >= 0)]
            to = to[~reached[to] & ~dead[to]]
            if len(to):
                to = np.unique(to)
                reached[to] = True
                new.append(to)
        for on in ladders:
            if reached[on].any() and not reached[on].all():
                more = on[~reached[on] & ~dead[on]]
                reached[more] = True
                new.append(more)
        frontier = np.unique(np.concatenate(new)) if new else np.zeros(0, dtype=np.int64)
    return reached, seeds


def generate(manifest, seen_triangles, folder, settings, log=print):
    """Makes the radar of a package's map; returns its manifest block (or None: no radar)."""
    clock = time.time()
    marks = []

    def mark(name):
        marks.append(f"{name} {time.time() - clock:.1f} s")

    resolution = int(settings.get("resolution", 1024))
    cover_max = float(settings.get("cover", 3.0))
    ao_on, ao_strength = bool(settings.get("ao", True)), float(settings.get("ao_strength", 0.45))
    shadow_on, tints_on = bool(settings.get("shadow", True)), bool(settings.get("tints", True))

    # ---------- What the map is made of ----------
    hull = None
    if manifest.get("hull") and os.path.exists(os.path.join(folder, manifest["hull"])):
        hull = Hull(os.path.join(folder, manifest["hull"]))
    blocks, block_tris = [], []
    for group in manifest.get("collision", []):
        if group.get("kind"):
            continue  # grenade and bullet clips: players walk through them
        for b in group.get("blocks", []):
            p = np.array(b["p"], dtype=np.float64).reshape(-1, 3)
            t = np.array(b["t"], dtype=np.int64).reshape(-1, 3)
            if not len(p) or not len(t):
                continue
            p[:, 0] = -p[:, 0]
            t = t[:, ::-1]  # x turned over: the winding turns too
            blocks.append((p, t, not b.get("c")))
            block_tris.append(p[t])
    solids = Solids([] if hull else blocks, hull)
    seen = seen_triangles if len(seen_triangles) else np.zeros((0, 3, 3))
    walk_tris = np.concatenate([seen] + ([] if hull else block_tris)) if (len(seen) or block_tris) else np.zeros((0, 3, 3))
    walk_bvh = make_bvh(walk_tris)
    seen_bvh = make_bvh(seen)
    if walk_bvh is None:
        raise ValueError("nothing on the map to draw")

    entities = manifest.get("entities", [])


    spawns = [unity(e["position"]) for e in entities if e.get("type") == "spawn" and e.get("position")]
    if not spawns:
        raise ValueError("no spawns: nothing to walk the map from")

    w = walk_map(solids, walk_bvh, walk_tris, entities, mark)
    reached, seeds = flood(w, spawns)
    if seeds == 0:
        raise ValueError("no spawn stands on a floor: nothing to walk the map from")
    reached_count = int(reached.sum())
    mark("walk")
    surf, top, depth, colx, colz = w.surf, w.top, w.depth, w.colx, w.colz
    gw, gh, gx0, gz0, cols = w.gw, w.gh, w.gx0, w.gz0, w.cols
    a_col, nh, nodes = w.a_col, w.nh, w.nodes

    rc = a_col[reached]
    rh = nh[reached]
    if settings.get("debug"):
        values, counts = np.unique(np.round(rh, 1), return_counts=True)
        log("Radar heights reached: " + ", ".join(f"{v:.1f}:{c}" for v, c in zip(values, counts)))
    rx, rz = colx[rc], colz[rc]
    # ---------- The square ----------
    margin = HALF + 2.0
    minx, maxx, minz, maxz = rx.min() - margin, rx.max() + margin, rz.min() - margin, rz.max() + margin
    size = max(maxx - minx, maxz - minz)
    mx, mz = (minx + maxx - size) * 0.5, (minz + maxz - size) * 0.5

    # ---------- Layers ----------
    own = []
    for e in entities:
        if e.get("type") == "radarlayer":
            v = volume(e)
            if v is not None:
                own.append(float(v[0][1]))
    if own:
        bottoms = sorted(own)[1:]
    else:
        bottoms = []
        per_col = {}
        order = np.argsort(rc, kind="stable")
        gaps_l, gaps_u = [], []
        floored = len(np.unique(rc))
        cs, hs = rc[order], rh[order]
        starts = np.r_[0, np.nonzero(np.diff(cs))[0] + 1, len(cs)]
        for i in range(len(starts) - 1):
            hh = np.sort(hs[starts[i]:starts[i + 1]])
            for j in range(len(hh) - 1):
                gaps_l.append(hh[j]); gaps_u.append(hh[j + 1])
        if len(gaps_l) * CELL * CELL >= LAYER_MIN_AREA and len(gaps_l) >= floored * 0.1:
            ev = sorted([(l + 0.5, 1) for l in gaps_l] + [(u - 0.1, -1) for u in gaps_u], key=lambda e: (e[0], e[1]))
            open_, best, split = 0, 0, 0.0
            for i in range(len(ev)):
                open_ += ev[i][1]
                if open_ > best and i + 1 < len(ev):
                    best, split = open_, (ev[i][0] + ev[i + 1][0]) * 0.5
            if best * CELL * CELL >= LAYER_MIN_AREA:
                bottoms = [split]
    layers = len(bottoms) + 1

    def layer_of(h):
        out = np.zeros(np.shape(h), dtype=np.int64)
        for i, b in enumerate(bottoms):
            out = np.where(np.asarray(h) >= b - 0.1, i + 1, out)
        return out
    rl = layer_of(rh)

    # ---------- Colours: one gradient for the map ----------
    low = [unity(e["position"])[1] for e in entities if e.get("type") == "radarmin" and e.get("position")]
    high = [unity(e["position"])[1] for e in entities if e.get("type") == "radarmax" and e.get("position")]
    stops = [(unity(e["position"])[1], tuple(float(c) for c in e.get("color", (0.5, 0.5, 0.5))[:3]))
             for e in entities if e.get("type") == "radarcolor" and e.get("position")]
    gradient = Gradient(min(low) if low else float(rh.min()), max(high) if high else float(rh.max()), stops)

    # ---------- Per column: the reached floors near it (whoever stands within a box's half of it) ----------
    KR = 6
    reach_h = np.full((cols, KR), np.nan, dtype=np.float32)
    reach_l = np.full((cols, KR), -1, dtype=np.int8)
    cand_h, cand_l, cand_c = [], [], []
    for oz in range(-2, 3):
        for ox in range(-2, 3):
            x = (rc % gw) + ox; z = (rc // gw) + oz
            ok = (x >= 0) & (z >= 0) & (x < gw) & (z < gh)
            cand_c.append((z * gw + x)[ok]); cand_h.append(rh[ok]); cand_l.append(rl[ok])
    cand_c, cand_h, cand_l = np.concatenate(cand_c), np.concatenate(cand_h), np.concatenate(cand_l)
    order = np.lexsort((-cand_h, cand_c))
    cand_c, cand_h, cand_l = cand_c[order], cand_h[order], cand_l[order]
    keepc = np.ones(len(cand_c), dtype=bool)
    keepc[1:] = ~((cand_c[1:] == cand_c[:-1]) & (np.abs(cand_h[1:] - cand_h[:-1]) < 0.05) & (cand_l[1:] == cand_l[:-1]))
    cand_c, cand_h, cand_l = cand_c[keepc], cand_h[keepc], cand_l[keepc]
    first = np.r_[0, np.nonzero(np.diff(cand_c))[0] + 1]
    rank = np.arange(len(cand_c)) - np.repeat(first, np.diff(np.r_[first, len(cand_c)]))
    fit = rank < KR
    reach_h[cand_c[fit], rank[fit]] = cand_h[fit]
    reach_l[cand_c[fit], rank[fit]] = cand_l[fit]

    # The nearest reached floor of each layer, carried up to NEAR metres out (cover is looked for there).
    near_h = []
    steps = int(math.ceil(NEAR / CELL))
    for L in range(layers):
        grid = np.full((gh, gw), np.nan, dtype=np.float32)
        sel = rl == L
        cc = rc[sel]
        hh = rh[sel].astype(np.float32)
        flat = grid.reshape(-1)
        np.fmax.at(flat, cc, hh)
        # Straight and diagonal steps by turns: an octagon, near enough a circle (straight ones alone made a diamond,
        # its corner cutting a room into a triangle).
        for _ in range(steps):
            g = grid.copy()
            sides = ((1, 0), (-1, 0), (0, 1), (0, -1)) + (((1, 1), (1, -1), (-1, 1), (-1, -1)) if _ % 2 else ())
            for sh in sides:
                moved = shifted(grid, sh[0], sh[1], np.nan)
                fill = np.isnan(g) & ~np.isnan(moved)
                g[fill] = moved[fill]
            grid = g
        near_h.append(grid.reshape(-1))
    # The highest reached floor of each layer within OVER_NEAR: a thing standing on it (a crate on a roof too tall to get
    # onto) is drawn as itself, not as the floor under that roof seen through it.
    over_h = []
    for L in range(layers):
        grid = np.full((gh, gw), np.nan, dtype=np.float32)
        sel = rl == L
        np.fmax.at(grid.reshape(-1), rc[sel], rh[sel].astype(np.float32))
        for _ in range(int(math.ceil(OVER_NEAR / CELL))):
            g = grid.copy()
            for sh in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                g = np.fmax(g, shifted(grid, sh[0], sh[1], np.nan))
            grid = g
        over_h.append(grid.reshape(-1))
    mark("layers")

    # ---------- The pixels: computed at twice the size, then halved ----------
    R = resolution * 2
    p = size / R
    pc = np.arange(R)
    pxx = mx + (pc + 0.5) * p                       # x of each column of pixels
    pzz = mz + (pc + 0.5) * p                       # z of each row (row 0 the lowest z)
    gx = np.clip(np.round((pxx - gx0) / CELL).astype(np.int64), 0, gw - 1)
    gz = np.clip(np.round((pzz - gz0) / CELL).astype(np.int64), 0, gh - 1)
    inx = (pxx >= gx0 - CELL) & (pxx <= gx0 + gw * CELL)
    inz = (pzz >= gz0 - CELL) & (pzz <= gz0 + gh * CELL)
    col_grid = (gz[:, None] * gw + gx[None, :])     # (R, R) the column under each pixel
    inside = inz[:, None] & inx[None, :]
    near_any = np.zeros(cols, dtype=bool)
    for L in range(layers):
        near_any |= ~np.isnan(near_h[L])
    want = inside & near_any[col_grid]
    wy, wx = np.nonzero(want)
    psurf = surfaces(seen_bvh, pxx[wx], pzz[wy], top, depth, 0.3, KP)
    mark(f"pixel surfaces ({len(wy)})")

    pixel_surf = np.full((R, R, KP), np.nan, dtype=np.float32)
    pixel_surf[wy, wx] = psurf
    topmost = pixel_surf[:, :, 0]
    nothing = np.isnan(topmost) & want                # seen nothing at all (an invisible floor of clip)
    floor = np.full((layers, R, R), np.nan, dtype=np.float32)
    cover = np.full((layers, R, R), np.nan, dtype=np.float32)
    colw = col_grid[wy, wx]
    for L in range(layers):
        best = np.full(len(wy), np.nan, dtype=np.float32)
        for j in range(KR):
            h = reach_h[colw, j]
            use = (reach_l[colw, j] == L) & ~np.isnan(h)
            if not use.any():
                continue
            diff = np.abs(psurf - h[:, None])
            match = np.where(diff <= 0.5, psurf, np.nan)
            drawn = np.nanmax(np.where(np.isnan(match), -np.inf, match), axis=1)
            drawn = np.where(np.isinf(drawn), np.nan, drawn)
            drawn = np.where(np.isnan(psurf[:, 0]), h, drawn)
            drawn = np.where(use, drawn, np.nan)
            best = np.fmax(best, drawn)
        # Something solid on a higher floor nearby over the floor drawn here (a crate on a roof over a room): the top seen
        # from above is that thing, not the room's floor — drawn as cover on that floor.
        top_s = psurf[:, 0]
        up = over_h[L][colw]
        on_upper = (~np.isnan(best) & ~np.isnan(top_s) & ~np.isnan(up) & (up >= best + STEP) &
                    (top_s > best + 0.5) & (top_s >= up - 0.1) & (top_s <= up + cover_max))
        best = np.where(on_upper, np.nan, best)
        floor[L, wy, wx] = best
        # Cover: no floor of this layer here, but a surface not too high over the floor nearby.
        H = np.where(on_upper, up, near_h[L][colw])
        # The top seen from above, not the highest surface under the limit: a building taller than that (a closed room)
        # is a wall, and its own floor inside is not cover seen through its roof.
        s_top = np.where(psurf[:, 0] <= H + cover_max, psurf[:, 0], -np.inf)
        is_cover = np.isnan(best) & ~np.isnan(H) & np.isfinite(s_top) & (s_top > H + 0.25)
        cover[L, wy[is_cover], wx[is_cover]] = s_top[is_cover]
    del pixel_surf
    mark("floors and cover")
    probe = settings.get("probe")  # (x, z) in the game's space: what is drawn there, for finding out why
    if probe is not None:
        qy, qx = int((probe[1] - mz) / p), int((probe[0] - mx) / p)
        if 0 <= qy < R and 0 <= qx < R:
            i = np.nonzero((wy == qy) & (wx == qx))[0]
            log(f"Radar probe {probe}: floor {floor[:, qy, qx].tolist()}, cover {cover[:, qy, qx].tolist()}, "
                f"surfaces {psurf[i[0]].tolist() if len(i) else None}, near {[float(n[col_grid[qy, qx]]) for n in near_h]}, "
                f"over {[float(n[col_grid[qy, qx]]) for n in over_h]}, reach {reach_h[col_grid[qy, qx]].tolist()}")

    # ---------- Drawing each layer ----------
    sites = [volume(e) for e in entities if e.get("type") == "bombsite"]
    buys = [volume(e) for e in entities if e.get("type") == "buyzone"]
    xs_px = np.broadcast_to(pxx[None, :], (R, R))
    zs_px = np.broadcast_to(pzz[:, None], (R, R))
    scale = R / 2048.0  # the blur and lines are given for 2048 (1024 shown)
    images = []
    stale = []
    for L in range(layers):
        fl, cv = floor[L], cover[L]
        has_f, has_c = ~np.isnan(fl), ~np.isnan(cv)
        M = has_f | has_c
        rgb = np.zeros((R, R, 3)); a = np.zeros((R, R))
        # Other layers' floors, faint, under everything.
        for O in range(layers):
            if O == L:
                continue
            of = floor[O]
            show = ~np.isnan(of) & ~M & (a == 0)
            if show.any():
                rgb[show] = gradient(of[show]); a[show] = OTHER_LAYER_ALPHA
        if shadow_on:
            blur = box_blur(box_blur(M.astype(np.float64), max(1, int(round(16 * scale)))), max(1, int(round(16 * scale))))
            sh = np.where(M, 0.0, 0.6 * blur)
            over(rgb, a, np.zeros((R, R, 3)), sh)
        ring = grow(M, max(1, int(round(3 * scale)))) & ~M
        over(rgb, a, np.broadcast_to(np.array(OUTLINE), (R, R, 3)), np.where(ring, 0.6, 0.0))
        # Walls inside the map: gaps between floors narrower than WALL_FILL (a wall whose top is not seen, under a roof,
        # or no cover by the rules) are a wall's colour, not holes the HUD shows through.
        reach = max(1, int(round(WALL_FILL * 0.5 / p)))
        grown = box_blur(M.astype(np.float32), reach) > 1e-4               # within `reach` of a floor (a square)
        wall = (box_blur(grown.astype(np.float32), reach) > 1.0 - 1e-4) & ~M  # and every pixel that near is too: closed
        over(rgb, a, np.broadcast_to(np.array(OUTLINE), (R, R, 3)), np.where(wall, 1.0, 0.0))
        col = np.zeros((R, R, 3))
        col[has_f] = gradient(fl[has_f])
        col[has_c] = gradient(cv[has_c])
        # The edge of cover, inside it.
        cover_edge = has_c & grow(~has_c, max(1, int(round(2 * scale))))
        col[cover_edge] = col[cover_edge] * 0.4 + np.array(OUTLINE) * 0.6
        # Ledges: the floor next to it is more than a step higher.
        flz = np.where(has_f, fl, -np.inf)
        ledge = np.zeros((R, R), dtype=bool)
        for dy_, dx_ in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nb = shifted(flz, dy_, dx_, -np.inf)
            ledge |= has_f & (nb - fl > STEP * 1.2)
        col[ledge] = col[ledge] * 0.45 + np.array(LEDGE) * 0.55
        if ao_on:
            ao = np.zeros((R, R)); weight = 0.0
            solid_h = np.where(has_f, fl, np.where(has_c, cv, np.nan))
            wall_top = np.where(np.isnan(topmost), np.inf, topmost)
            for i in range(16):
                ang = i * math.pi / 8.0
                for rad, w in ((0.25, 1.0), (0.5, 0.66), (0.75, 0.33)):
                    ox_ = int(round(math.cos(ang) * rad / p)); oy_ = int(round(math.sin(ang) * rad / p))
                    sh_h = shifted(solid_h, oy_, ox_, np.nan)
                    sh_m = shifted(M, oy_, ox_, False)
                    sh_t = shifted(wall_top, oy_, ox_, np.inf)
                    closed = np.where(sh_m, sh_h > fl + 0.3, sh_t > fl + 0.3)
                    ao += w * (closed & has_f)
                    weight += w
            ao /= weight
            col[has_f] *= (1.0 - ao_strength * ao[has_f])[:, None]
        if tints_on:
            for vols, tint, strength in ((sites, SITE_TINT, 0.35), (buys, BUY_TINT, 0.25)):
                for v in vols:
                    if v is None:
                        continue
                    inz_ = (xs_px >= v[0][0]) & (xs_px <= v[1][0]) & (zs_px >= v[0][2]) & (zs_px <= v[1][2])
                    # The floor within the volume's heights (a thin volume a little over the floor, as CS maps' triggers
                    # often are, still counts).
                    t = has_f & inz_ & (fl >= v[0][1] - 1.0) & (fl <= v[1][1] + 0.1)
                    col[t] = col[t] * (1.0 - strength) + np.array(tint) * strength
        over(rgb, a, col, np.where(M, 1.0, 0.0))
        # Halved, the colours weighed by their cover (premultiplied).
        pm = rgb * a[..., None]
        pm = pm.reshape(resolution, 2, resolution, 2, 3).mean(axis=(1, 3))
        aa = a.reshape(resolution, 2, resolution, 2).mean(axis=(1, 3))
        out = np.where(aa[..., None] > 1e-6, pm / np.maximum(aa, 1e-6)[..., None], 0.0)
        img = np.concatenate([out, aa[..., None]], axis=-1)
        img = (np.clip(img, 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8)
        img = img[::-1]  # the file's first row is the highest z
        auto = os.path.join(folder, f"radar_auto_{L}.png")
        mine = os.path.join(folder, f"radar_{L}.png")
        # The author's own picture: given in the map tools, or a radar_<i>.png left in the package that is not the last
        # one made here.
        given = settings.get("images", {}).get(L)
        made_before = open(auto, "rb").read() if os.path.exists(auto) else None
        own_here = os.path.exists(mine) and (made_before is None or open(mine, "rb").read() != made_before)
        write_png(auto, img)
        if given and os.path.exists(given):
            with open(given, "rb") as f, open(mine, "wb") as g:
                g.write(f.read())
        elif not own_here:
            with open(auto, "rb") as f, open(mine, "wb") as g:
                g.write(f.read())
        images.append(f"radar_{L}.png")
    # Pictures of layers the map no longer has.
    L = layers
    while os.path.exists(os.path.join(folder, f"radar_auto_{L}.png")):
        os.remove(os.path.join(folder, f"radar_auto_{L}.png"))
        if os.path.exists(os.path.join(folder, f"radar_{L}.png")):
            os.remove(os.path.join(folder, f"radar_{L}.png"))
        L += 1
    mark("pictures")
    log(f"Radar: {size:.0f} m across, {layers} layer(s)" +
        (f" from {', '.join(f'{b:.1f}' for b in bottoms)} m" if bottoms else "") +
        f", {reached_count} of {nodes} floor points reached from {seeds} spawns; {', '.join(marks)}")
    layers_json = [{"image": images[0]}] + [{"image": images[i + 1], "bottom": round(float(b), 4)} for i, b in enumerate(bottoms)]
    return {"format": 1, "min": [round(float(mx), 4), round(float(mz), 4)], "size": round(float(size), 4), "layers": layers_json}


def seen_triangles(objects):
    """The seen meshes' triangles in the game's space, (N, 3, 3), winding turned with the axes."""
    import bpy
    depsgraph = bpy.context.evaluated_depsgraph_get()
    out = []
    for o in objects:
        if o.type != "MESH" or o.get("ps_entity") == "water":
            continue
        ev = o.evaluated_get(depsgraph)
        me = ev.to_mesh()
        try:
            me.calc_loop_triangles()
            n = len(me.loop_triangles)
            if not n:
                continue
            co = np.empty(len(me.vertices) * 3, dtype=np.float64)
            me.vertices.foreach_get("co", co)
            co = co.reshape(-1, 3)
            mw = np.array(o.matrix_world)
            co = co @ mw[:3, :3].T + mw[:3, 3]
            co = np.stack([-co[:, 0], co[:, 2], -co[:, 1]], axis=1)
            tri = np.empty(n * 3, dtype=np.int64)
            me.loop_triangles.foreach_get("vertices", tri)
            tri = tri.reshape(-1, 3)[:, ::-1]
            out.append(co[tri])
        finally:
            ev.to_mesh_clear()
    return np.concatenate(out) if out else np.zeros((0, 3, 3))
