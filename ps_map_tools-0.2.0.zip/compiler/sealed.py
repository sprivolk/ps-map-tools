"""The air players are in, as VBSP floods a map from its entities: the space reached from the spawns without going
through a solid brush (Nodraw ones too: they are walls nobody sees) nor over the map's ceiling. A face turned to that air
can be seen; one turned only to the air outside (the back of the map's edge, the ground past it, a floor's underside)
never is. A map not closed all round (Map edge on its walls, its ceiling over them) leaks: the air gets out past
everything there is, and nothing is left out by it (the map tools' Check map shows where).

Blender's space (x, y, z up), metres. The air is a grid of cells; a cell is solid when a brush takes any of it (a
little more than its middle: a thin wall off the grid still closes)."""

import bmesh
import numpy as np
from mathutils import Vector

UNIT = 0.025
CELL = 8 * UNIT        # cell side (a wall 8 units thick still closes)
MAX_CELLS = 24_000_000  # bigger maps get bigger cells
EPS = 0.5 * UNIT        # brushes only touching a cell (a wall's side on its edge) leave it open


def convex_pieces(obj):
    """Each convex loose piece of a mesh object as its planes (normal, distance), world space, and its box (stairs,
    walls with doors: pieces in one mesh). A piece not convex is left out (it does not close anything)."""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.transform(obj.matrix_world)
    bm.normal_update()
    out, done = [], set()
    for f in bm.faces:
        if f.index in done:
            continue
        stack, part = [f], []
        done.add(f.index)
        while stack:
            g = stack.pop()
            part.append(g)
            for v in g.verts:
                for h in v.link_faces:
                    if h.index not in done:
                        done.add(h.index)
                        stack.append(h)
        verts = {v for g in part for v in g.verts}
        pts = [v.co.copy() for v in verts]
        centre = sum(pts, Vector()) / len(pts)
        planes = []
        for g in part:
            if g.normal.length < 0.5:
                continue
            n = g.normal.copy()
            d = n.dot(g.verts[0].co)
            if n.dot(centre) - d > 0:  # faces turned inward (a mesh made inside out): the other way
                n, d = -n, -d
            planes.append((n, d))
        if planes and not any(n.dot(p) - d > 1e-3 for n, d in planes for p in pts):
            lo = Vector(map(min, *pts)) if len(pts) > 1 else pts[0]
            hi = Vector(map(max, *pts)) if len(pts) > 1 else pts[0]
            out.append((planes, lo, hi))
    bm.free()
    return out


class Air:
    """The cells of the map's box: solid, and the air reached from the spawns."""

    def __init__(self, lo, cell, solid, reached, leak, clear=None):
        self.lo, self.cell, self.solid, self.reached, self.leak = lo, cell, solid, reached, leak
        # What is seen from the air: it, and what closes it but is seen through (the clips over the map's edge: a
        # wall's top under one is seen from a roof).
        self.seen = reached if clear is None else reached | clear

    def index(self, p):
        """Cells of points (n, 3), -1 where out of the box."""
        p = np.asarray(p, dtype=np.float64).reshape(-1, 3)
        ijk = np.floor((p - self.lo) / self.cell).astype(np.int64)
        inside = np.all((ijk >= 0) & (ijk < np.array(self.solid.shape)), axis=1)
        return ijk, inside

    def open_at(self, p):
        """Whether each point is in the air reached (out of the box: no)."""
        ijk, inside = self.index(p)
        out = np.zeros(len(ijk), dtype=bool)
        k = ijk[inside]
        out[inside] = self.seen[k[:, 0], k[:, 1], k[:, 2]]
        return out

    def centre(self, ijk):
        return Vector((self.lo + (np.asarray(ijk) + 0.5) * self.cell).tolist())


def _spread(reached, air):
    """The reached air spread through all the air joined to it: along each axis in turn, every run of air cells with a
    reached one in it reached whole, until nothing more is."""
    while True:
        before = int(reached.sum())
        for axis in range(3):
            a = np.moveaxis(air, axis, -1)
            r = np.moveaxis(reached, axis, -1)
            flat_a = a.reshape(-1, a.shape[-1])
            start = flat_a.copy()
            start[:, 1:] &= ~flat_a[:, :-1]
            ids = np.cumsum(start.ravel()).reshape(flat_a.shape)
            hit = np.bincount(ids[r.reshape(flat_a.shape) & flat_a], minlength=int(ids.max()) + 1) > 0
            hit[0] = False
            grown = (flat_a & hit[ids]).reshape(a.shape)
            reached = np.moveaxis(grown, -1, axis) | reached
        if int(reached.sum()) == before:
            return reached


def flood(pieces, starts, ceiling, clear=()):
    """The air reached from `starts` (points) among the convex `pieces` [(planes, lo, hi)] and the `clear` ones (closing
    it, seen through: player clips), under `ceiling` (metres).
    The box: the pieces' with two cells round it, its top the ceiling. Air at the box's sides (past everything) reached:
    a leak (`leak`: the cell where it got there, nearest the starts)."""
    if not pieces or not len(starts):
        return None
    pieces = list(pieces) + list(clear)
    lo = np.array([min(p[1][k] for p in pieces) for k in range(3)], dtype=np.float64)
    hi = np.array([max(p[2][k] for p in pieces) for k in range(3)], dtype=np.float64)
    # Up to the ceiling (over it is the sky: closed, as a Source map's skybox); the bottom the lowest brush's.
    hi[2] = ceiling if ceiling > lo[2] + CELL else hi[2] + 2 * CELL
    cell = CELL
    while np.prod(np.ceil((hi - lo) / cell) + 4) > MAX_CELLS:
        cell *= 2
    # Two cells round it at the sides: air past everything there is (reached: a leak).
    lo[:2] -= 2 * cell
    hi[:2] += 2 * cell
    shape = np.maximum(1, np.ceil((hi - lo) / cell - 1e-4).astype(np.int64))  # (a wall up to the ceiling: no cell over it)
    solid = np.zeros(tuple(shape), dtype=bool)
    see_through = np.zeros(tuple(shape), dtype=bool)
    half = cell / 2
    first_clear = len(pieces) - len(clear)
    for which, (planes, plo, phi) in enumerate(pieces):
        i0 = np.clip(np.floor((np.array(plo) - lo) / cell).astype(int), 0, shape - 1)
        i1 = np.clip(np.ceil((np.array(phi) - lo) / cell).astype(int), 0, shape)
        if np.any(i1 <= i0):
            continue
        axes = [lo[k] + (np.arange(i0[k], i1[k]) + 0.5) * cell for k in range(3)]
        X, Y, Z = np.meshgrid(*axes, indexing="ij")
        inside = np.ones(X.shape, dtype=bool)
        for n, d in planes:
            # A cell is taken when the brush reaches into it (its middle within half a cell, along the plane, of inside).
            reach = half * (abs(n.x) + abs(n.y) + abs(n.z)) - EPS
            inside &= X * n.x + Y * n.y + Z * n.z - d <= reach
        solid[i0[0]:i1[0], i0[1]:i1[1], i0[2]:i1[2]] |= inside
        if which >= first_clear:
            see_through[i0[0]:i1[0], i0[1]:i1[1], i0[2]:i1[2]] |= inside
    air = ~solid
    reached = np.zeros_like(solid)
    started = 0
    for s in starts:
        ijk = np.floor((np.array(s, dtype=np.float64) - lo) / cell).astype(int)
        for up in range(4):  # a spawn on the floor: its cell may be the floor's; the ones over it
            k = ijk + np.array([0, 0, up])
            if np.all(k >= 0) and np.all(k < shape) and air[tuple(k)]:
                reached[tuple(k)] = True
                started += 1
                break
    if not started:
        return None
    reached = _spread(reached, air)
    edge = np.zeros_like(solid)
    edge[0, :, :] = edge[-1, :, :] = True
    edge[:, 0, :] = edge[:, -1, :] = True
    out = reached & edge
    leak = None
    if out.any():
        cells = np.argwhere(out)
        first = np.array(starts[0], dtype=np.float64)
        leak = cells[np.argmin(np.linalg.norm(lo + (cells + 0.5) * cell - first, axis=1))]
    return Air(lo, cell, solid, reached, leak, see_through if len(clear) else None)


def leak_path(air, starts):
    """Where the air gets out: cells from a spawn to the outside, each next to the one before (a breadth-first walk
    through the air reached). A short list of points (Blender space), the spawn's end first."""
    if air is None or air.leak is None:
        return []
    shape = np.array(air.solid.shape)
    open_ = air.reached
    dist = np.full(open_.shape, -1, dtype=np.int32)
    k = np.floor((np.array(starts[0], dtype=np.float64) - air.lo) / air.cell).astype(int)
    for up in range(4):
        q = k + np.array([0, 0, up])
        if np.all(q >= 0) and np.all(q < shape) and open_[tuple(q)]:
            k = q
            break
    else:
        return [air.centre(air.leak)]
    dist[tuple(k)] = 0
    front = np.zeros_like(open_)
    front[tuple(k)] = True
    step = 0
    target = tuple(air.leak)
    while dist[target] < 0 and front.any():
        step += 1
        grown = np.zeros_like(front)
        grown[1:] |= front[:-1]
        grown[:-1] |= front[1:]
        grown[:, 1:] |= front[:, :-1]
        grown[:, :-1] |= front[:, 1:]
        grown[:, :, 1:] |= front[:, :, :-1]
        grown[:, :, :-1] |= front[:, :, 1:]
        front = grown & open_ & (dist < 0)
        dist[front] = step
    if dist[target] < 0:
        return [air.centre(air.leak)]
    path = [np.array(target)]
    cur = np.array(target)
    moves = [np.array(m) for m in ((1, 0, 0), (-1, 0, 0), (0, 1, 0), (0, -1, 0), (0, 0, 1), (0, 0, -1))]
    while dist[tuple(cur)] > 0:
        for m in moves:
            n = cur + m
            if np.all(n >= 0) and np.all(n < shape) and dist[tuple(n)] == dist[tuple(cur)] - 1:
                cur = n
                break
        path.append(cur)
    path.reverse()
    keep = path[::max(1, len(path) // 24)] + [path[-1]]
    return [air.centre(p) for p in keep]


def faces_to_air(air, points, normal):
    """Whether a face (some of its points, its normal) looks into the reached air: a point a little in front of it, up
    to two cells out (a wall's face off the grid: the cell next to it is the wall's), is in it."""
    n = np.array(normal, dtype=np.float64)
    p = np.array([tuple(v) for v in points], dtype=np.float64)
    tries = np.concatenate([p + n * (air.cell * k) for k in (0.25, 0.75, 1.25, 1.75, 2.25)])
    return bool(air.open_at(tries).any())
