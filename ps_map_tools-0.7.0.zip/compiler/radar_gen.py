"""
The map's radar pictures, made at export (Docs/radar-generator.md): only the floor players can get to, found by walking
the map from its spawns with the players' own collision, the way the game's editor generator does (RadarOverview.cs),
with one height gradient for the whole map, cover, shading, the outer shadow and the zones.

Everything here is in the game's (Unity's) space, metres, Y up: the package's glTF space with x turned over
(xU = -xB, yU = zB, zU = -yB). What comes out are the radar_<i>.png files in the package and the manifest's "radar" block,
the very numbers the game's MapRadar takes.
"""
import math
import os
import types
import struct
import time
import zlib

import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree

# ---------- The player (CS:GO, 1 unit = 0.025 m) ----------
HALF = 0.40            # half the box's width (16 units)
CROUCH = 1.35          # the box's height crouched (54 units): what every check uses
CROUCH_HULL = 0.90     # a CS 1.6 map's ducked hull (36 units)
STEP = 0.45            # step height (18 units)
JUMP_UP = 1.66         # the highest one gets onto, crouch-jumping (CS: 66 units; a 64-unit box is climbed)
CELL = 0.20            # the walking grid (8 units): any way 40 units wide holds a grid point
SKIN = 0.005
K = 12                 # surfaces (and floor points) kept per column, highest first
KP = 8                 # surfaces kept per pixel
LAYER_MIN_AREA = 150.0
NEAR = 6.0             # pixels drawn: no farther than this from a reached floor point
OVER_NEAR = 1.5        # a thing on a floor this near is that floor's cover (not the floor below seen through it)
WALL_FILL = 1.2        # gaps between floors up to this wide are walls, drawn (not see-through)
SLOPE_MIN, SLOPE_MAX = 0.7, 6.0  # a slope (rise over run): steeper than one stands on (35°), not yet a wall (80°)
SLOPE_REACH = 4.0      # metres of slope drawn out from a floor
SLOPE_WIDE = 4.0       # metres a slope is drawn up or down from the floor at its foot or top (not along it)
SUPER = 4              # the pictures worked out at this many times their size, then shrunk: smooth edges at any angle
EDGE_REACH = 0.3       # metres a floor is drawn out along its own plane to its real edge (the walk's steps are 0.2)
WALL_ON = 0.5          # metres from a floor a wall standing on it is looked for over lower floors drawn there
LOW_RISE = 1.5         # metres a low place's floor goes up from its lowest (its way out goes on from there)
LOW_OVERLOOK = 5.0     # metres round a floor point a floor a jump higher overlooks it (a trench's bank)
LOW_SHARE = 0.5        # the share of a low place's floor open to the sky and overlooked, at least
SEE_THROUGH = 0.45     # how much of what is over a low place is still seen, from down there

# CS2's overviews: the lowest floor is still a floor (a mid grey), the highest the lightest; only walls and what is not
# the map are dark. A gradient starting near black drew the main floor as if it were the void.
DEFAULT_GRADIENT = [(0.0, (0.33, 0.36, 0.41)), (0.5, (0.52, 0.56, 0.61)), (1.0, (0.78, 0.81, 0.85))]
OUTLINE = (0.8, 0.8, 0.8)
LEDGE = (0.82, 0.86, 0.90)
SITE_TINT = (0.77, 0.295, 0.171)
BUY_TINT = (0.18, 0.83, 0.23)
OTHER_LAYER_ALPHA = 0.28


def unity(p):
    """A glTF point (x, y, z) in the game's space."""
    return (-p[0], p[1], p[2])


# ---------- What is solid to a player ----------
class Solids:
    """The player's collision: the package's convex blocks (and its concave ones, as triangles), or a CS 1.6 map's own
    hull. `free` says whether a crouched player's box fits with its feet at the given points."""

    def __init__(self, blocks, hull=None):
        self.hull = hull
        self.height = CROUCH_HULL if hull else CROUCH
        self.convex, self.concave = [], []
        for points, tris, convex in blocks:
            lo, hi = points.min(axis=0), points.max(axis=0)
            if convex:
                a, b, c = points[tris[:, 0]], points[tris[:, 1]], points[tris[:, 2]]
                n = np.cross(b - a, c - a)
                length = np.linalg.norm(n, axis=1)
                keep = length > 1e-9
                n, a = n[keep] / length[keep, None], a[keep]
                if not len(n):
                    continue
                d = (n * a).sum(axis=1)
                # Facing out: the middle is behind every face, each face turned on its own (a block with only some of its
                # faces wound the other way was hollow to the walk: de_new2's bank had a floor inside it).
                middle = points.mean(axis=0)
                flip = np.where((n @ middle) - d > 0, -1.0, 1.0)
                n, d = n * flip[:, None], d * flip
                self.convex.append((lo, hi, n, d))
            else:
                self.concave.append((lo, hi, points[tris]))

    def free(self, x, foot, z, height=None, half=HALF):
        """`height`: the box's height (the crouched one when not given; a hull map has its own). `half`: its half width
        (a thin probe: whether anything lies right on a surface)."""
        x, foot, z = (np.asarray(v, dtype=np.float64) for v in (x, foot, z))
        if self.hull is not None:
            return self.hull.free(x, foot + self.height * 0.5, z)
        blocked = np.zeros(len(x), dtype=bool)
        if not len(x):
            return ~blocked
        hy = (height or self.height) * 0.5
        cy = foot + hy
        # Queries sorted into 2 m cells, so each block looks only at the ones near it.
        size = 2.0
        x0, z0 = x.min() - 1.0, z.min() - 1.0
        cx = np.floor((x - x0) / size).astype(np.int64)
        cz = np.floor((z - z0) / size).astype(np.int64)
        ncx = int(cx.max()) + 1
        key = cz * ncx + cx
        order = np.argsort(key, kind="stable")
        keys = key[order]
        nrows = int(cz.max()) + 1
        h = np.array([half, hy, half])

        def near(lo, hi):
            a0 = max(0, int(math.floor((lo[0] - half - x0) / size)))
            a1 = min(ncx - 1, int(math.floor((hi[0] + half - x0) / size)))
            b0 = max(0, int(math.floor((lo[2] - half - z0) / size)))
            b1 = min(nrows - 1, int(math.floor((hi[2] + half - z0) / size)))
            if a0 > a1 or b0 > b1:
                return None
            parts = []
            for row in range(b0, b1 + 1):
                s = np.searchsorted(keys, row * ncx + a0, "left")
                e = np.searchsorted(keys, row * ncx + a1, "right")
                if e > s:
                    parts.append(order[s:e])
            if not parts:
                return None
            idx = np.concatenate(parts)
            idx = idx[~blocked[idx]]
            ok = ((x[idx] + half > lo[0] + SKIN) & (x[idx] - half < hi[0] - SKIN) &
                  (z[idx] + half > lo[2] + SKIN) & (z[idx] - half < hi[2] - SKIN) &
                  (cy[idx] + hy > lo[1] + SKIN) & (cy[idx] - hy < hi[1] - SKIN))
            idx = idx[ok]
            return idx if len(idx) else None

        for lo, hi, n, d in self.convex:
            idx = near(lo, hi)
            if idx is None:
                continue
            c = np.stack([x[idx], cy[idx], z[idx]], axis=1)
            r = np.abs(n) @ h
            outside = (c @ n.T) - r[None, :] > d[None, :] - SKIN
            blocked[idx[~outside.any(axis=1)]] = True
        for lo, hi, tris in self.concave:
            idx = near(lo, hi)
            if idx is None:
                continue
            chunk = max(1, 200000 // max(1, len(idx)))
            for t0 in range(0, len(tris), chunk):
                t = tris[t0:t0 + chunk]
                live = idx[~blocked[idx]]
                if not len(live):
                    break
                c = np.stack([x[live], cy[live], z[live]], axis=1)
                hit = box_hits_triangles(c, h - SKIN, t)
                blocked[live[hit]] = True
        return ~blocked


def box_hits_triangles(centres, half, tris):
    """For each box (centre, the same half size), whether it meets any of the triangles (separating axes)."""
    v = tris[None, :, :, :] - centres[:, None, None, :]           # (Q, T, 3 corners, 3)
    v0, v1, v2 = v[:, :, 0], v[:, :, 1], v[:, :, 2]
    sep = np.zeros(v0.shape[:2], dtype=bool)
    for k in range(3):
        mn = np.minimum(np.minimum(v0[..., k], v1[..., k]), v2[..., k])
        mx = np.maximum(np.maximum(v0[..., k], v1[..., k]), v2[..., k])
        sep |= (mn > half[k]) | (mx < -half[k])
    e = (v1 - v0, v2 - v1, v0 - v2)
    n = np.cross(e[0], e[1])
    r = (np.abs(n) * half).sum(axis=-1)
    sep |= np.abs((n * v0).sum(axis=-1)) > r
    axes = np.eye(3)
    for ei in e:
        for u in axes:
            a = np.cross(ei, u)
            p0, p1, p2 = (a * v0).sum(-1), (a * v1).sum(-1), (a * v2).sum(-1)
            r = (np.abs(a) * half).sum(-1)
            sep |= (np.minimum(np.minimum(p0, p1), p2) > r) | (np.maximum(np.maximum(p0, p1), p2) < -r)
    return (~sep).any(axis=1)


class Hull:
    """A CS 1.6 map's clip hulls (hull.bin, glTF space): the ducked hull, already grown by the player's size, of the world
    and its brush models; a point is free unless one of them holds it solid."""

    def __init__(self, path):
        data = open(path, "rb").read()
        if data[:4] != b"PSH1":
            raise ValueError("not a hull file")
        p = 4
        (count,) = struct.unpack_from("<i", data, p); p += 4
        self.planes = np.frombuffer(data, dtype="<f4", count=count * 4, offset=p).reshape(-1, 4).astype(np.float64)
        p += count * 16
        (n,) = struct.unpack_from("<i", data, p); p += 4
        nodes = np.frombuffer(data, dtype="<i4", count=n * 3, offset=p).reshape(-1, 3)
        p += n * 12
        self.plane, self.front, self.back = nodes[:, 0].copy(), nodes[:, 1].copy(), nodes[:, 2].copy()
        (m,) = struct.unpack_from("<i", data, p); p += 4
        self.heads = []
        for _ in range(m):
            (length,) = struct.unpack_from("<i", data, p); p += 4 + length
            kind, stand, duck = struct.unpack_from("<Bii", data, p); p += 9
            self.heads.append(duck)

    def free(self, x, cy, z):
        point = np.stack([-x, cy, z], axis=1)  # back in glTF space
        ok = np.ones(len(x), dtype=bool)
        for head in self.heads:
            node = np.full(len(x), head, dtype=np.int64)
            for _ in range(256):
                live = node >= 0
                if not live.any():
                    break
                i = node[live]
                pl = self.planes[self.plane[i]]
                d = (point[live] * pl[:, :3]).sum(axis=1) - pl[:, 3]
                node[live] = np.where(d >= 0, self.front[i], self.back[i])
            ok &= node != -2
        return ok


# ---------- Surfaces ----------
def make_bvh(triangles):
    """A BVH of triangles given as an (N, 3, 3) array."""
    if not len(triangles):
        return None
    verts = triangles.reshape(-1, 3)
    polys = np.arange(len(verts)).reshape(-1, 3)
    return BVHTree.FromPolygons([tuple(v) for v in verts.tolist()], polys.tolist(), all_triangles=True)


def surfaces(bvh, xs, zs, top, depth, min_up, keep, faces=False):
    """The surfaces facing up in each column, highest first: a ray down, going on from just under each hit. With
    `faces`, also the triangle each one is (its index in the BVH, -1 for none)."""
    out = np.full((len(xs), keep), np.nan, dtype=np.float32)
    ids = np.full((len(xs), keep), -1, dtype=np.int32) if faces else None
    if bvh is None:
        return (out, ids) if faces else out
    down = Vector((0.0, -1.0, 0.0))
    cast = bvh.ray_cast
    for i in range(len(xs)):
        origin = Vector((float(xs[i]), top, float(zs[i])))
        left, k, last = depth, 0, None
        for _ in range(12):
            if left <= 0.0:
                break
            loc, normal, index, dist = cast(origin, down, left)
            if loc is None:
                break
            y = loc.y
            if normal.y >= min_up and (last is None or last - y > 0.02):
                out[i, k] = y
                if faces:
                    ids[i, k] = index
                k += 1
                last = y
                if k >= keep:
                    break
            step = dist + 0.02
            origin.y -= step
            left -= step
    return (out, ids) if faces else out


def triangle_pixels(t, R, mx, mz, p):
    """The pixels a triangle (3 × 3: game space, y up) is over, seen from above: ((z0, z1, x0, x1) of its box, which of
    them, its height at each) — or None (off the picture, seen edge-on)."""
    xs = (t[:, 0] - mx) / p - 0.5
    zs = (t[:, 2] - mz) / p - 0.5
    x0, x1 = max(0, int(math.floor(xs.min()))), min(R - 1, int(math.ceil(xs.max())))
    z0, z1 = max(0, int(math.floor(zs.min()))), min(R - 1, int(math.ceil(zs.max())))
    if x0 > x1 or z0 > z1:
        return None
    (xa, xb, xc), (za, zb, zc) = xs, zs
    den = (zb - zc) * (xa - xc) + (xc - xb) * (za - zc)
    if abs(den) < 1e-9:
        return None
    X = np.arange(x0, x1 + 1, dtype=np.float64)[None, :]
    Z = np.arange(z0, z1 + 1, dtype=np.float64)[:, None]
    l1 = ((zb - zc) * (X - xc) + (xc - xb) * (Z - zc)) / den
    l2 = ((zc - za) * (X - xc) + (xa - xc) * (Z - zc)) / den
    l3 = 1.0 - l1 - l2
    inside = (l1 >= -1e-6) & (l2 >= -1e-6) & (l3 >= -1e-6)
    return (z0, z1 + 1, x0, x1 + 1), inside, l1 * t[0, 1] + l2 * t[1, 1] + l3 * t[2, 1]


def raster(tris, R, mx, mz, p, out, mask=None, band=None, cap=None):
    """Draws triangles (n, 3, 3: game space, y up) seen from above into `out` (R × R, row 0 the lowest z): each pixel the
    highest y of those over its middle. Triangles seen edge-on (walls) leave nothing. `mask` (R × R): only there.
    `band` (lowest, highest: R × R each, and a margin): only where the heights there meet the triangle's own. `cap`
    (R × R): only where the triangle is no higher than that."""
    for t in tris:
        got = triangle_pixels(t, R, mx, mz, p)
        if got is None:
            continue
        (z0, z1, x0, x1), inside, h = got
        if mask is not None:
            inside &= mask[z0:z1, x0:x1]
        if band is not None:
            lo, hi, margin = band
            inside &= (lo[z0:z1, x0:x1] <= t[:, 1].max() + margin) & (hi[z0:z1, x0:x1] >= t[:, 1].min() - margin)
        if not inside.any():
            continue
        if cap is not None:
            inside &= ~(h > cap[z0:z1, x0:x1])
        sub = out[z0:z1, x0:x1]
        np.fmax(sub, np.where(inside, h, np.nan).astype(sub.dtype), out=sub)
    return out


def draw_faces(seen, seen_bvh, seen_planes, points, grid, near_h, layers, col_grid, frame, cover_max, log=print):
    """The radar's floors and cover from the map's own faces (as the CS tools TAR and RadGen draw the meshes their author
    marks, here marked by the walk): a face players stood on is floor — and the rest of its plane joined to it, and the
    slopes joined to it (too steep to stand on, slid down) —, a face facing up a little over a floor nearby that nobody
    walks under is cover. Each set drawn from above (its edges the faces' own, at any angle). Returns floor and cover
    per layer and the top of everything seen (R × R each)."""
    rx, rz, rh, rl, rc = points
    gw, gh, gx0, gz0 = grid
    R, mx, mz, p = frame
    n = len(seen)
    a_, b_, c_ = seen[:, 0], seen[:, 1], seen[:, 2]
    nrm = np.cross(b_ - a_, c_ - a_)
    nrm /= np.maximum(np.linalg.norm(nrm, axis=1), 1e-12)[:, None]
    ny = nrm[:, 1]
    is_slope = (ny >= 0.17) & (ny < 0.82)     # 80° … 35°: too steep to stand on, not yet a wall
    # The faces the walk stood on: straight down from each floor point.
    down = Vector((0.0, -1.0, 0.0))
    stood = [set() for _ in range(layers)]
    for i in range(len(rx)):
        _, _, idx, _ = seen_bvh.ray_cast(Vector((float(rx[i]), float(rh[i]) + 0.25, float(rz[i]))), down, 0.7)
        if idx is not None:
            stood[int(rl[i])].add(idx)
    # Faces joined by a corner (to the millimetre).
    keys = np.round(seen.reshape(-1, 3) * 1000.0).astype(np.int64)
    _, vid = np.unique(keys, axis=0, return_inverse=True)
    vid = vid.reshape(-1, 3)
    by_vertex = {}
    for t in range(n):
        for v in vid[t]:
            by_vertex.setdefault(int(v), []).append(t)
    # The slopes going on from any layer's floor (a trench's sides meet its banks' faces corner to corner, not its bottom's:
    # the trench's own layer found none): each layer draws those near its own floor.
    slopes_all = {t for s in stood for t in s if is_slope[t]}
    flat_all = set().union(*stood) - slopes_all
    todo = list(flat_all | slopes_all)
    while todo:
        t = todo.pop()
        for v in vid[t]:
            for u in by_vertex[int(v)]:
                if u in flat_all or u in slopes_all:
                    continue
                if seen_planes[u] == seen_planes[t] and not is_slope[u] and ny[u] > 0.0:
                    flat_all.add(u)
                    todo.append(u)
                elif is_slope[u]:
                    slopes_all.add(u)
                    todo.append(u)
    floor_sets, slope_sets, own_slopes = [], [], []
    for L in range(layers):
        # A face too steep to stand on that a ray from a floor point met (a slope at the foot of which a player stood) is a
        # slope, not a floor.
        slopes = {t for t in stood[L] if is_slope[t]}
        stood[L] -= slopes
        flat = set(stood[L])
        todo = list(stood[L] | slopes)
        # Not on over faces another layer stood on: one plane under both (a pit's floor and a trench's bottom, level) is
        # each one's own where it was walked.
        theirs = set().union(*(stood[O] for O in range(layers) if O != L)) - stood[L]
        while todo:
            t = todo.pop()
            for v in vid[t]:
                for u in by_vertex[int(v)]:
                    if u in flat or u in slopes or u in theirs:
                        continue
                    if seen_planes[u] == seen_planes[t] and not is_slope[u] and ny[u] > 0.0:
                        flat.add(u)          # the rest of that floor
                        todo.append(u)
                    elif is_slope[u]:
                        slopes.add(u)        # a slope going on from it
                        todo.append(u)
        floor_sets.append(flat)
        own_slopes.append(slopes)
        slope_sets.append(slopes | slopes_all)
    # Where each layer's walk got to, carried out a little (floors) and a slope's width (slopes), and at what heights:
    # a face is drawn only near floor points at its own height (a canal's slope under a room walked over is not).
    def near_band(L, metres):
        lo = np.full(gh * gw, np.inf, dtype=np.float32)
        hi = np.full(gh * gw, -np.inf, dtype=np.float32)
        sel = rl == L
        np.fmin.at(lo, rc[sel], rh[sel].astype(np.float32))
        np.fmax.at(hi, rc[sel], rh[sel].astype(np.float32))
        lo, hi = lo.reshape(gh, gw), hi.reshape(gh, gw)
        for _ in range(int(math.ceil(metres / CELL))):
            l2, h2 = lo.copy(), hi.copy()
            for sh in ((1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)):
                l2 = np.fmin(l2, shifted(lo, sh[0], sh[1], np.inf))
                h2 = np.fmax(h2, shifted(hi, sh[0], sh[1], -np.inf))
            lo, hi = l2, h2
        return lo.reshape(-1)[col_grid], hi.reshape(-1)[col_grid], 0.6
    # Cover: faces facing up, over a floor nearby by more than a little and at most cover_max, with nobody under them
    # (else a ceiling or a roof over a room).
    taken = set().union(*floor_sets, *slope_sets)
    low = np.full(gh * gw, np.inf, dtype=np.float32)
    np.fmin.at(low, rc, rh.astype(np.float32))
    cover_sets = [[] for _ in range(layers)]
    centre = seen.mean(axis=1)
    for t in np.nonzero(ny >= 0.7)[0]:
        if t in taken:
            continue
        top_y = float(seen[t, :, 1].max())
        samples = [centre[t]] + [centre[t] * 0.3 + seen[t, k] * 0.7 for k in range(3)]
        cols_t = []
        for s in samples:
            gx_ = int(round((s[0] - gx0) / CELL)); gz_ = int(round((s[2] - gz0) / CELL))
            if 0 <= gx_ < gw and 0 <= gz_ < gh:
                cols_t.append(gz_ * gw + gx_)
        if not cols_t or any(low[c] <= top_y - CROUCH for c in cols_t):
            continue
        for L in range(layers):
            H = near_h[L][cols_t[0]]
            if not np.isnan(H) and H + 0.25 < top_y <= H + cover_max:
                cover_sets[L].append(t)
                break
    floor = np.full((layers, R, R), np.nan, dtype=np.float32)
    cover = np.full((layers, R, R), np.nan, dtype=np.float32)
    for L in range(layers):
        # Faces stood on: within a metre of the walk at their height (a ground plane going on far past the walls ends
        # there). Faces joined to them (the rest of a floor, slopes): whole or not at all — by whether the walk came near
        # them at their height —, their edges their own (a cut by the walk's grid would be steps).
        if stood[L]:
            raster(seen[sorted(stood[L])], R, mx, mz, p, floor[L], band=near_band(L, 1.0))
        # Faces joined to them (the rest of a floor, slopes): near the floor drawn at their height — half a metre (the rest of
        # a floor out to its edge), a slope's width (a slope) —, measured on the picture, so their edges stay their own
        # and a long slope does not run on under a building past the floor it goes down to.
        drawn = floor[L]  # (what is drawn so far: a slope drawn holds up the next one, up a canal side of two faces)
        # Not over this layer's own walked floor by more than a player's height (a trench's side over the pipe out of
        # it, seen from inside the pipe).
        cap = np.where(np.isnan(floor[L]), np.inf, floor[L] + CROUCH).astype(np.float32)
        reach_mask = np.zeros((R, R), dtype=bool)
        joined_faces = sorted((floor_sets[L] - stood[L]) | slope_sets[L])
        for t in [f for _ in range(3) for f in joined_faces]:  # three times round: each face from the ones before
            r_px = max(1, int(round((SLOPE_WIDE if t in slope_sets[L] else 0.5) / p)))
            xs, zs = (seen[t, :, 0] - mx) / p, (seen[t, :, 2] - mz) / p
            x0, x1 = max(0, int(xs.min()) - r_px - 1), min(R, int(xs.max()) + r_px + 2)
            z0, z1 = max(0, int(zs.min()) - r_px - 1), min(R, int(zs.max()) + r_px + 2)
            if x0 >= x1 or z0 >= z1:
                continue
            sub = drawn[z0:z1, x0:x1]
            with np.errstate(invalid="ignore"):
                if t in own_slopes[L]:
                    src = (sub >= seen[t, :, 1].min() - 0.6) & (sub <= seen[t, :, 1].max() + 0.6)
                else:  # another layer's slope: only from this one's floor at its foot (a trench's side, not a pipe's)
                    src = np.abs(sub - seen[t, :, 1].min()) <= 0.15
            if not src.any():
                continue
            if t in slope_sets[L]:
                # Up and down the slope only (its fall line, from its normal), not along it: across its whole width from
                # the floor at its foot or top, and no farther along than that floor goes.
                fall = np.array([nrm[t, 0], nrm[t, 2]])
                fall /= max(np.linalg.norm(fall), 1e-9)
                m = src.copy()
                for sign in (1, -1):
                    a = src.copy()
                    k = 1
                    while k <= r_px:  # by doubling steps: a line of r_px
                        a |= shifted(a, int(round(sign * k * fall[1])), int(round(sign * k * fall[0])), False)
                        k *= 2
                    m |= a
                reach_mask[z0:z1, x0:x1] = m
            else:
                reach_mask[z0:z1, x0:x1] = box_blur(src.astype(np.float32), r_px) > 1e-6
            raster(seen[t:t + 1], R, mx, mz, p, floor[L], reach_mask, cap=cap)
            probe_xz = os.environ.get("PS_RADAR_PROBE")
            if probe_xz:
                qx, qz = (float(v) for v in probe_xz.split(","))
                ix, iz = int((qx - mx) / p), int((qz - mz) / p)
                A, B, C = seen[t][:, [0, 2]]
                def side(P, Q, S):
                    return (Q[0] - P[0]) * (S[1] - P[1]) - (Q[1] - P[1]) * (S[0] - P[0])
                q = (qx, qz)
                d1, d2, d3 = side(A, B, q), side(B, C, q), side(C, A, q)
                if (d1 >= 0 and d2 >= 0 and d3 >= 0) or (d1 <= 0 and d2 <= 0 and d3 <= 0):
                    log(f"  probe in face {t} (slope {t in slope_sets[L]}): mask {bool(reach_mask[iz, ix])}, "
                        f"floor now {float(floor[L][iz, ix])}, drawn before {float(drawn[iz, ix])}, "
                        f"bbox z {z0}..{z1} x {x0}..{x1}, at {iz},{ix}")
            if os.environ.get("PS_RADAR_FACES") and t in slope_sets[L]:
                log(f"  slope {t}: ny {ny[t]:.2f} y {seen[t, :, 1].min():.1f}..{seen[t, :, 1].max():.1f} "
                    f"x {seen[t, :, 0].min():.1f}..{seen[t, :, 0].max():.1f} z {seen[t, :, 2].min():.1f}..{seen[t, :, 2].max():.1f} "
                    f"src {int(src.sum())} mask {int(reach_mask[z0:z1, x0:x1].sum())}")
            reach_mask[z0:z1, x0:x1] = False
        if cover_sets[L]:
            near = ~np.isnan(near_h[L])[col_grid]
            raster(seen[cover_sets[L]], R, mx, mz, p, cover[L], near)
        # Cover over the floor drawn there (a crate standing on it) is shown; cover under it is not.
        with np.errstate(invalid="ignore"):
            above = ~np.isnan(cover[L]) & (np.isnan(floor[L]) | (cover[L] > floor[L] + 0.25))
        floor[L][above] = np.nan
        cover[L][~above] = np.nan
    topmost = raster(seen, R, mx, mz, p, np.full((R, R), np.nan, dtype=np.float32))
    log(f"Radar faces: {sum(len(s) for s in stood)} stood on, {sum(len(s) for s in floor_sets)} floor, "
        f"{sum(len(s) for s in slope_sets)} slope, {sum(len(s) for s in cover_sets)} cover of {n}")
    return floor, cover, topmost


def planes_of(triangles):
    """Each triangle's plane, as a number shared by all the triangles in one plane (a floor's two triangles, all the
    pieces of a slope): its normal and its distance, rounded."""
    if not len(triangles):
        return np.zeros(0, dtype=np.int32)
    a, b, c = triangles[:, 0], triangles[:, 1], triangles[:, 2]
    n = np.cross(b - a, c - a)
    n /= np.maximum(np.linalg.norm(n, axis=1), 1e-12)[:, None]
    d = (n * a).sum(axis=1)
    key = np.column_stack([np.round(n * 100.0), np.round(d * 50.0)]).astype(np.int64)
    _, plane = np.unique(key, axis=0, return_inverse=True)
    return plane.reshape(-1).astype(np.int32)


# ---------- Pictures ----------
def box_blur(a, radius):
    """A box blur (summed areas), edges clamped."""
    if radius <= 0:
        return a
    padded = np.pad(a, radius, mode="edge")
    s = np.cumsum(np.cumsum(padded, axis=0), axis=1)
    s = np.pad(s, ((1, 0), (1, 0)))
    w = 2 * radius + 1
    total = s[w:, w:] - s[:-w, w:] - s[w:, :-w] + s[:-w, :-w]
    return total / (w * w)


def grow(mask, steps):
    """The mask grown by this many pixels (each step: the 8 neighbours)."""
    m = mask.copy()
    for _ in range(steps):
        g = m.copy()
        g[1:, :] |= m[:-1, :]; g[:-1, :] |= m[1:, :]
        g[:, 1:] |= m[:, :-1]; g[:, :-1] |= m[:, 1:]
        g[1:, 1:] |= m[:-1, :-1]; g[:-1, :-1] |= m[1:, 1:]
        g[1:, :-1] |= m[:-1, 1:]; g[:-1, 1:] |= m[1:, :-1]
        m = g
    return m


def shifted(a, dy, dx, fill):
    """a moved by (dy, dx) pixels: out[y, x] = a[y + dy, x + dx], `fill` past the edges."""
    out = np.full_like(a, fill)
    h, w = a.shape[:2]
    ys, ye = max(0, -dy), min(h, h - dy)
    xs, xe = max(0, -dx), min(w, w - dx)
    if ys < ye and xs < xe:
        out[ys:ye, xs:xe] = a[ys + dy:ye + dy, xs + dx:xe + dx]
    return out


def write_png(path, rgba):
    """An RGBA 8-bit picture, rows given top first; (h, w) only: one grey channel, its values as they are (no sRGB)."""
    h, w = rgba.shape[:2]
    grey = rgba.ndim == 2
    raw = b"".join(b"\x00" + rgba[y].tobytes() for y in range(h))

    def chunk(kind, body):
        return struct.pack(">I", len(body)) + kind + body + struct.pack(">I", zlib.crc32(kind + body) & 0xFFFFFFFF)
    data = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 0 if grey else 6, 0, 0, 0)) +
            (b"" if grey else chunk(b"sRGB", b"\x00")) + chunk(b"IDAT", zlib.compress(raw, 6)) + chunk(b"IEND", b""))
    with open(path, "wb") as f:
        f.write(data)


class Gradient:
    """Height to colour, one scale for the whole map (TAR's tar_min / tar_max / tar_color)."""

    def __init__(self, low, high, stops=None):
        self.low, self.high = low, max(high, low + 0.5)
        if stops and len(stops) >= 2:
            stops = sorted(stops)
            self.t = np.array([(h - self.low) / (self.high - self.low) for h, _ in stops])
            self.c = np.array([c for _, c in stops], dtype=np.float64)
        else:
            self.t = np.array([t for t, _ in DEFAULT_GRADIENT])
            self.c = np.array([c for _, c in DEFAULT_GRADIENT], dtype=np.float64)

    def __call__(self, h):
        t = np.clip((h - self.low) / (self.high - self.low), 0.0, 1.0)
        return np.stack([np.interp(t, self.t, self.c[:, k]) for k in range(3)], axis=-1)


def over(dst_rgb, dst_a, rgb, a):
    """Paints (rgb, a) over what is there (straight alpha), in place."""
    a = a[..., None] if a.ndim == dst_a.ndim else a
    out_a = a[..., 0] + dst_a * (1.0 - a[..., 0])
    safe = np.where(out_a > 1e-6, out_a, 1.0)
    dst_rgb[:] = (rgb * a + dst_rgb * (dst_a * (1.0 - a[..., 0]))[..., None]) / safe[..., None]
    dst_a[:] = out_a


# ---------- The generator ----------
def volume(e):
    """A volume entity's box (its lowest and highest corner) in the game's space, or None."""
    pts = np.array(e.get("points") or [], dtype=np.float64).reshape(-1, 3)
    if not len(pts):
        return None
    pts[:, 0] = -pts[:, 0]
    return pts.min(axis=0), pts.max(axis=0)


def walk_map(solids, walk_bvh, walk_tris, entities, mark=lambda name: None):
    """Where a player can stand on the map and where they can go from there: the floor points (crouched box free)
    and the ways between them (steps, jumps, drops, ladders; kill zones dead). `flood` walks it from spawns. All of it
    comes back as one namespace."""
    # ---------- The walking grid: every floor in every column where the crouched box fits ----------
    allp = walk_tris.reshape(-1, 3)
    small = np.all(np.abs(allp) < 2000.0, axis=1)
    allp = allp[small] if small.any() else allp
    lo, hi = allp.min(axis=0), allp.max(axis=0)
    gx0, gz0 = lo[0], lo[2]
    gw = int(math.ceil((hi[0] - lo[0]) / CELL)) + 1
    gh = int(math.ceil((hi[2] - lo[2]) / CELL)) + 1
    top, depth = hi[1] + 5.0, (hi[1] - lo[1]) + 10.0
    cols = gw * gh
    colx = gx0 + (np.arange(cols) % gw) * CELL
    colz = gz0 + (np.arange(cols) // gw) * CELL
    surf = surfaces(walk_bvh, colx, colz, top, depth, 0.6, K)
    mark("surfaces")

    # Where a player can stand in a column: on its own surfaces, or on one of the next columns' that the box reaches over
    # (the box rests on the highest thing under it: at a step's edge the step, though this column's own ray misses it —
    # what the editor's generator found by sweeping the box down).
    # For each surface s of a column: the highest surface under the whole box (±HALF) no more than a step above it —
    # what the box rests on there (a step's edge, the uphill side of a ramp).
    grid3 = surf.reshape(gh, gw, K)
    # Only open surfaces are rested on: one something lies right on (a room's floor slab under its wall) is no floor. Taken
    # from the next column, it put players 0.4 m in the air beside every such wall, and a closed room around those
    # 'floors' was drawn as a crate.
    flat_s = surf.reshape(-1)
    si = np.nonzero(~np.isnan(flat_s))[0]
    open_ = np.zeros(len(flat_s), dtype=bool)
    open_[si] = solids.free(colx[si // K], flat_s[si] + 0.03, colz[si // K], height=0.1, half=0.05)
    open3 = np.where(open_.reshape(gh, gw, K), grid3, np.nan)
    rest = grid3.copy()
    reach = int(round(HALF / CELL))
    for oz in range(-reach, reach + 1):
        for ox in range(-reach, reach + 1):
            if not (ox or oz):
                continue
            nb = shifted(open3, oz, ox, np.nan)                         # (gh, gw, K) the neighbour's open surfaces
            ok = (nb[:, :, None, :] >= grid3[:, :, :, None] - 1e-4) & (nb[:, :, None, :] <= grid3[:, :, :, None] + STEP)
            best = np.where(ok, nb[:, :, None, :], np.nan)
            with np.errstate(invalid="ignore"):
                top_ = np.nanmax(np.where(np.isnan(best), -np.inf, best), axis=3)
            top_ = np.where(np.isinf(top_), np.nan, top_)
            rest = np.fmax(rest, top_)
    cand = np.concatenate([grid3, rest], axis=2).reshape(cols, -1)
    cand = -np.sort(-cand, axis=1)
    same = np.zeros_like(cand, dtype=bool)
    same[:, 1:] = np.abs(cand[:, 1:] - cand[:, :-1]) < 0.02
    cand[same] = np.nan
    cand = -np.sort(-cand, axis=1)[:, :2 * K]
    ci, ki = np.nonzero(~np.isnan(cand))
    s = cand[ci, ki].astype(np.float64)
    fits = solids.free(colx[ci], s + 0.02, colz[ci])
    heights = np.full((cols, 2 * K), np.nan, dtype=np.float32)
    heights[ci[fits], ki[fits]] = s[fits]
    # Highest first, the ones closer than 0.1 m to the one above them merged into it.
    heights = -np.sort(-heights, axis=1)
    for k in range(1, heights.shape[1]):
        close = heights[:, k - 1] - heights[:, k] < 0.1
        heights[close, k] = np.nan
    heights = np.ascontiguousarray(-np.sort(-heights, axis=1)[:, :K])
    valid = ~np.isnan(heights)
    nodes = int(valid.sum())
    mark("floor points")

    # ---------- Ways between them ----------
    dx, dz = (1, -1, 0, 0), (0, 0, 1, -1)
    col_of = np.repeat(np.arange(cols), K).reshape(cols, K)
    a_col, a_k = np.nonzero(valid)
    ha = heights[a_col, a_k].astype(np.float64)
    ax, az = a_col % gw, a_col // gw
    edges = []
    queries = []  # (which edge list, its index, the check)
    for d in range(4):
        bx, bz = ax + dx[d], az + dz[d]
        inside = (bx >= 0) & (bz >= 0) & (bx < gw) & (bz < gh)
        b_col = np.where(inside, bz * gw + bx, 0)
        hb_all = heights[b_col].astype(np.float64)                     # (n, K) highest first
        can = (hb_all <= ha[:, None] + JUMP_UP) & ~np.isnan(hb_all) & inside[:, None]
        has = can.any(axis=1)
        first = can.argmax(axis=1)
        hb = hb_all[np.arange(len(ha)), first]
        edge = has.copy()
        differ = has & (np.abs(hb - ha) > 0.01)
        overh = np.maximum(ha, hb) + 0.02
        # Over the edge or the step, at the higher height.
        check_b = np.nonzero(differ)[0]
        # A jump also needs the room above where it starts.
        check_a = np.nonzero(differ & (hb - ha > STEP))[0]
        # A drop comes down to that floor only if nothing is between (not through a ramp over it).
        drop = np.nonzero(differ & (overh - hb > STEP + 0.05))[0]
        if len(drop):
            sb = surf[b_col[drop]].astype(np.float64)
            between = (sb > hb[drop, None] + 0.1) & (sb < overh[drop, None] - 0.05)
            edge[drop[between.any(axis=1)]] = False
        edges.append((edge, b_col, first))
        queries.append((d, check_b, colx[b_col[check_b]], overh[check_b], colz[b_col[check_b]]))
        queries.append((d, check_a, colx[a_col[check_a]], hb[check_a] + 0.02, colz[a_col[check_a]]))
    # Jumps onto what is higher than a step (a crate, a ledge): a box stands no nearer than half its width to it, so the
    # floor below is never the next point to the top — looked for 2 to 4 points out (0.4–0.8 m), the box free at the
    # top's height over all the points between. A 64-unit crate on a roof was never reached (and drawn as the floor
    # under the roof).
    for d in range(4):
        for k in range(2, 5):
            bx, bz = ax + dx[d] * k, az + dz[d] * k
            inside = (bx >= 0) & (bz >= 0) & (bx < gw) & (bz < gh)
            b_col = np.where(inside, bz * gw + bx, 0)
            hb_all = heights[b_col].astype(np.float64)
            can = ((hb_all > ha[:, None] + STEP) & (hb_all <= ha[:, None] + JUMP_UP) & ~np.isnan(hb_all) &
                   inside[:, None])
            has = can.any(axis=1)
            if not has.any():
                continue
            first = can.argmax(axis=1)
            hb = hb_all[np.arange(len(ha)), first]
            idx = np.nonzero(has)[0]
            e_i = len(edges)
            edges.append((has.copy(), b_col, first))
            foot = hb[idx] + 0.02
            for j in range(k):  # where it starts and the points between (the top's own point is free: it is a floor)
                c = (az[idx] + dz[d] * j) * gw + (ax[idx] + dx[d] * j)
                queries.append((e_i, idx, colx[c], foot, colz[c]))
    # Walking off the edge of a top onto a floor more than a step lower, 2 to 4 points out: the box keeps its height over
    # the points between (still on the edge, then falling) and comes straight down there. Beside a narrow top (a beam,
    # a stair over a crate) the next point has no floor the box fits on, so a drop to it alone was never found.
    for d in range(4):
        for k in range(2, 5):
            bx, bz = ax + dx[d] * k, az + dz[d] * k
            inside = (bx >= 0) & (bz >= 0) & (bx < gw) & (bz < gh)
            b_col = np.where(inside, bz * gw + bx, 0)
            hb_all = heights[b_col].astype(np.float64)
            can = (hb_all < ha[:, None] - STEP) & ~np.isnan(hb_all) & inside[:, None]
            has = can.any(axis=1)
            if not has.any():
                continue
            first = can.argmax(axis=1)
            hb = hb_all[np.arange(len(ha)), first]
            # Not through anything between that floor and the height it comes from (a ramp over it).
            sb = surf[b_col].astype(np.float64)
            between = (sb > hb[:, None] + 0.1) & (sb < ha[:, None] - 0.05)
            has &= ~between.any(axis=1)
            idx = np.nonzero(has)[0]
            if not len(idx):
                continue
            e_i = len(edges)
            edges.append((has.copy(), b_col, first))
            foot = ha[idx] + 0.02
            for j in range(1, k + 1):
                c = (az[idx] + dz[d] * j) * gw + (ax[idx] + dx[d] * j)
                queries.append((e_i, idx, colx[c], foot, colz[c]))
    qx = np.concatenate([q[2] for q in queries]); qf = np.concatenate([q[3] for q in queries])
    qz = np.concatenate([q[4] for q in queries])
    ok = solids.free(qx, qf, qz)
    at = 0
    for d, idx, _, _, _ in queries:
        edges[d][0][idx[~ok[at:at + len(idx)]]] = False
        at += len(idx)
    target = []
    for edge, b_col, first in edges:
        t = np.where(edge, b_col * K + first, -1)
        target.append(t)
    mark("ways")

    # ---------- Walking it from the spawns ----------
    node_id = a_col * K + a_k
    slot = np.full(cols * K, -1, dtype=np.int64)
    slot[node_id] = np.arange(len(node_id))
    nh = ha
    dead = np.zeros(len(node_id), dtype=bool)
    for e in entities:
        if e.get("type") != "killzone":
            continue
        v = volume(e)
        if v is None:
            continue
        x, y, z = colx[a_col], nh, colz[a_col]
        dead |= ((x >= v[0][0]) & (x <= v[1][0]) & (z >= v[0][2]) & (z <= v[1][2]) &
                 (y >= v[0][1] - 0.05) & (y <= v[1][1] + 0.05))
    ladders = []
    for e in entities:
        if e.get("type") != "ladder":
            continue
        v = volume(e)
        if v is None:
            continue
        g = np.array([HALF + CELL, STEP, HALF + CELL])
        l0, l1 = v[0] - g, v[1] + g
        x, y, z = colx[a_col], nh, colz[a_col]
        on = np.nonzero((x >= l0[0]) & (x <= l1[0]) & (z >= l0[2]) & (z <= l1[2]) & (y >= l0[1]) & (y <= l1[1]))[0]
        if len(on):
            ladders.append(on)
    return types.SimpleNamespace(**locals())


def flood(w, spawns):
    """The floor points reached from these spawns, each starting on the floor point under it: (reached, how many
    spawns started)."""
    gx0, gz0, gw, gh, heights, slot, dead, target, ladders = (w.gx0, w.gz0, w.gw, w.gh, w.heights, w.slot, w.dead,
                                                             w.target, w.ladders)
    node_id = w.node_id
    reached = np.zeros(len(node_id), dtype=bool)
    seeds = 0
    for sp in spawns:
        x = int(round((sp[0] - gx0) / CELL)); z = int(round((sp[2] - gz0) / CELL))
        best, best_gap = -1, 1e9
        for zz in range(max(0, z - 2), min(gh, z + 3)):
            for xx in range(max(0, x - 2), min(gw, x + 3)):
                c = zz * gw + xx
                for k in range(K):
                    h = heights[c, k]
                    if np.isnan(h):
                        break
                    if not (sp[1] - 2.5 <= h <= sp[1] + 0.5):
                        continue
                    gap = abs(sp[1] - h) + (abs(xx - x) + abs(zz - z)) * 0.01
                    if gap < best_gap:
                        best, best_gap = slot[c * K + k], gap
        if best >= 0 and not dead[best] and not reached[best]:
            reached[best] = True
            seeds += 1
    frontier = np.nonzero(reached)[0]
    while len(frontier):
        new = []
        for t in target:
            to = t[frontier]
            to = to[to >= 0]
            to = slot[to]
            to = to[(to >= 0)]
            to = to[~reached[to] & ~dead[to]]
            if len(to):
                to = np.unique(to)
                reached[to] = True
                new.append(to)
        for on in ladders:
            if reached[on].any() and not reached[on].all():
                more = on[~reached[on] & ~dead[on]]
                reached[more] = True
                new.append(more)
        frontier = np.unique(np.concatenate(new)) if new else np.zeros(0, dtype=np.int64)
    return reached, seeds


def low_places(w, reached, points, seen_bvh):
    """The low places of the map from above (a trench): floor lower than the floor around it by more than a jump, part
    of it under something (a bridge, a building's side over it). Each: the floor points walked from its lowest up to
    LOW_RISE higher, a step at a time — kept only if mostly open to the sky and overlooked from a floor a jump higher
    (a trench's banks; not a room by a higher street, under its roof; not a ground level with a balcony over a bit of it). Returns a list of arrays of floor point numbers."""
    rx, rz, rh, rl, rc, gw, gh = points
    n = len(rh)
    node_of = np.nonzero(reached)[0]
    point_of = np.full(len(reached), -1, dtype=np.int64)
    point_of[node_of] = np.arange(n)
    # Steps between floor points of the map from above, either way.
    a_l, b_l = [], []
    for t in w.target:
        to = t[node_of]
        ok = to >= 0
        to = np.where(ok, w.slot[np.maximum(to, 0)], -1)
        ok &= to >= 0
        b = np.where(ok, point_of[np.maximum(to, 0)], -1)
        ok &= b >= 0
        a, b = np.arange(n)[ok], b[ok]
        keep = (rl[a] == 0) & (rl[b] == 0) & (np.abs(rh[a] - rh[b]) <= STEP + 0.05)
        a_l.append(a[keep]); b_l.append(b[keep])
    a, b = np.concatenate(a_l + b_l), np.concatenate(b_l + a_l)
    order = np.argsort(a, kind="stable")
    a, b = a[order], b[order]
    start = np.searchsorted(a, np.arange(n + 1))
    # Overlooked: a floor a jump higher within LOW_OVERLOOK (a square, by doubling steps).
    mine = rl == 0
    hi = np.full(gw * gh, -np.inf, dtype=np.float32)
    np.fmax.at(hi, rc[mine], rh[mine].astype(np.float32))
    hi = hi.reshape(gh, gw)
    reach, done, k = int(round(LOW_OVERLOOK / CELL)), 0, 1
    while done < reach:
        k = min(k, reach - done)
        for sh in ((k, 0), (-k, 0), (0, k), (0, -k)):
            hi = np.maximum(hi, shifted(hi, sh[0], sh[1], -np.inf))
        done += k
        k *= 2
    overlooked = mine & (hi.reshape(-1)[rc] >= rh + JUMP_UP)
    # Under something: straight up meets a face.
    up = Vector((0.0, 1.0, 0.0))
    covered = np.zeros(n, dtype=bool)
    for i in np.nonzero(overlooked)[0]:
        covered[i] = seen_bvh.ray_cast(Vector((float(rx[i]), float(rh[i]) + 0.5, float(rz[i]))), up, 200.0)[0] is not None
    taken = np.zeros(n, dtype=bool)
    places = []
    for s in sorted(np.nonzero(overlooked & covered)[0], key=lambda i: rh[i]):
        if taken[s]:
            continue
        top = rh[s] + LOW_RISE
        comp = [s]
        taken[s] = True
        j = 0
        while j < len(comp):
            i = comp[j]
            j += 1
            for u in b[start[i]:start[i + 1]]:
                if not taken[u] and rh[u] <= top:
                    taken[u] = True
                    comp.append(u)
        comp = np.array(comp, dtype=np.int64)
        if (overlooked & ~covered)[comp].mean() >= LOW_SHARE and covered[comp].sum() * CELL * CELL >= 1.0:
            places.append(comp)
    return places


def generate(manifest, seen_triangles, folder, settings, log=print):
    """Makes the radar of a package's map; returns its manifest block (or None: no radar)."""
    clock = time.time()
    marks = []

    def mark(name):
        marks.append(f"{name} {time.time() - clock:.1f} s")

    resolution = int(settings.get("resolution", 1024))
    cover_max = float(settings.get("cover", 3.0))
    ao_on, ao_strength = bool(settings.get("ao", True)), float(settings.get("ao_strength", 0.45))
    shadow_on, tints_on = bool(settings.get("shadow", True)), bool(settings.get("tints", True))

    # ---------- What the map is made of ----------
    hull = None
    if manifest.get("hull") and os.path.exists(os.path.join(folder, manifest["hull"])):
        hull = Hull(os.path.join(folder, manifest["hull"]))
    blocks, block_tris = [], []
    for group in manifest.get("collision", []):
        if group.get("kind") not in (None, "solid"):  # players stand on these (a model's box too)
            continue  # grenade and bullet clips: players walk through them
        for b in group.get("blocks", []):
            p = np.array(b["p"], dtype=np.float64).reshape(-1, 3)
            t = np.array(b["t"], dtype=np.int64).reshape(-1, 3)
            if not len(p) or not len(t):
                continue
            p[:, 0] = -p[:, 0]
            t = t[:, ::-1]  # x turned over: the winding turns too
            blocks.append((p, t, not b.get("c")))
            block_tris.append(p[t])
    solids = Solids([] if hull else blocks, hull)
    seen = seen_triangles if len(seen_triangles) else np.zeros((0, 3, 3))
    walk_tris = np.concatenate([seen] + ([] if hull else block_tris)) if (len(seen) or block_tris) else np.zeros((0, 3, 3))
    walk_bvh = make_bvh(walk_tris)
    seen_bvh = make_bvh(seen)
    seen_planes = planes_of(seen)
    if walk_bvh is None:
        raise ValueError("nothing on the map to draw")

    entities = manifest.get("entities", [])


    spawns = [unity(e["position"]) for e in entities if e.get("type") == "spawn" and e.get("position")]
    if not spawns:
        raise ValueError("no spawns: nothing to walk the map from")

    w = walk_map(solids, walk_bvh, walk_tris, entities, mark)
    reached, seeds = flood(w, spawns)
    if seeds == 0:
        raise ValueError("no spawn stands on a floor: nothing to walk the map from")
    reached_count = int(reached.sum())
    mark("walk")
    surf, top, depth, colx, colz = w.surf, w.top, w.depth, w.colx, w.colz
    gw, gh, gx0, gz0, cols = w.gw, w.gh, w.gx0, w.gz0, w.cols
    a_col, nh, nodes = w.a_col, w.nh, w.nodes

    rc = a_col[reached]
    rh = nh[reached]
    if settings.get("debug"):
        values, counts = np.unique(np.round(rh, 1), return_counts=True)
        log("Radar heights reached: " + ", ".join(f"{v:.1f}:{c}" for v, c in zip(values, counts)))
    rx, rz = colx[rc], colz[rc]
    # ---------- The square ----------
    margin = HALF + 2.0
    minx, maxx, minz, maxz = rx.min() - margin, rx.max() + margin, rz.min() - margin, rz.max() + margin
    size = max(maxx - minx, maxz - minz)
    mx, mz = (minx + maxx - size) * 0.5, (minz + maxz - size) * 0.5

    # ---------- Layers ----------
    # The author's: radar layer boxes, each the place of its layer (ps_layer, 1 and up; several boxes make one layer's
    # place). Whoever stands in one sees its picture; everyone else the first (the map from above). Not a height alone,
    # as CS2's vertical sections: a tunnel lies as high as the banks of the trench beside it.
    regions = []
    for e in entities:
        if e.get("type") == "radarlayer":
            v = volume(e)
            if v is not None:
                regions.append((v[0], v[1], max(1, int(e.get("layer", 1)))))
    bottoms = []
    if not regions:  # none given: one split by height where floors lie over floors widely enough (CS2's way)
        order = np.argsort(rc, kind="stable")
        gaps_l, gaps_u = [], []
        floored = len(np.unique(rc))
        cs, hs = rc[order], rh[order]
        starts = np.r_[0, np.nonzero(np.diff(cs))[0] + 1, len(cs)]
        for i in range(len(starts) - 1):
            hh = np.sort(hs[starts[i]:starts[i + 1]])
            for j in range(len(hh) - 1):
                gaps_l.append(hh[j]); gaps_u.append(hh[j + 1])
        if len(gaps_l) * CELL * CELL >= LAYER_MIN_AREA and len(gaps_l) >= floored * 0.1:
            ev = sorted([(l + 0.5, 1) for l in gaps_l] + [(u - 0.1, -1) for u in gaps_u], key=lambda e: (e[0], e[1]))
            open_, best, split = 0, 0, 0.0
            for i in range(len(ev)):
                open_ += ev[i][1]
                if open_ > best and i + 1 < len(ev):
                    best, split = open_, (ev[i][0] + ev[i + 1][0]) * 0.5
            if best * CELL * CELL >= LAYER_MIN_AREA:
                bottoms = [split]
    if regions:
        layers = 1 + max(r[2] for r in regions)
        rl = np.zeros(len(rh), dtype=np.int64)
        for lo, hi, L in regions:
            rl[(rx >= lo[0]) & (rx <= hi[0]) & (rz >= lo[2]) & (rz <= hi[2]) & (rh >= lo[1] - 0.1) & (rh <= hi[1])] = L
    else:
        layers = len(bottoms) + 1
        rl = np.zeros(len(rh), dtype=np.int64)
        for i, b in enumerate(bottoms):
            rl = np.where(rh >= b - 0.1, i + 1, rl)
    # The low places of the map from above (a trench under bridges): each drawn as a layer of its own after the others —
    # the map from above shows it where nothing is over it; whoever stands down there sees the map with what is over it
    # see-through.
    main_layers = layers
    zones = []
    if settings.get("low_places", True):
        for pts in low_places(w, reached, (rx, rz, rh, rl, rc, gw, gh), seen_bvh):
            rl[pts] = layers
            zones.append((layers, pts))
            layers += 1
        if zones:
            log("Radar low places: " + ", ".join(f"{len(p) * CELL * CELL:.0f} m² at {rh[p].min():.1f}…{rh[p].max():.1f} m"
                                                for _, p in zones))
    zone_of = {L: pts for L, pts in zones}

    # ---------- Colours: one gradient for the map ----------
    low = [unity(e["position"])[1] for e in entities if e.get("type") == "radarmin" and e.get("position")]
    high = [unity(e["position"])[1] for e in entities if e.get("type") == "radarmax" and e.get("position")]
    stops = [(unity(e["position"])[1], tuple(float(c) for c in e.get("color", (0.5, 0.5, 0.5))[:3]))
             for e in entities if e.get("type") == "radarcolor" and e.get("position")]
    gradient = Gradient(min(low) if low else float(rh.min()), max(high) if high else float(rh.max()), stops)

    # ---------- Per column: the reached floors near it (whoever stands within a box's half of it) ----------
    KR = 6
    reach_h = np.full((cols, KR), np.nan, dtype=np.float32)
    reach_l = np.full((cols, KR), -1, dtype=np.int8)
    cand_h, cand_l, cand_c = [], [], []
    for oz in range(-2, 3):
        for ox in range(-2, 3):
            x = (rc % gw) + ox; z = (rc // gw) + oz
            ok = (x >= 0) & (z >= 0) & (x < gw) & (z < gh)
            cand_c.append((z * gw + x)[ok]); cand_h.append(rh[ok]); cand_l.append(rl[ok])
    cand_c, cand_h, cand_l = np.concatenate(cand_c), np.concatenate(cand_h), np.concatenate(cand_l)
    order = np.lexsort((-cand_h, cand_c))
    cand_c, cand_h, cand_l = cand_c[order], cand_h[order], cand_l[order]
    keepc = np.ones(len(cand_c), dtype=bool)
    keepc[1:] = ~((cand_c[1:] == cand_c[:-1]) & (np.abs(cand_h[1:] - cand_h[:-1]) < 0.05) & (cand_l[1:] == cand_l[:-1]))
    cand_c, cand_h, cand_l = cand_c[keepc], cand_h[keepc], cand_l[keepc]
    first = np.r_[0, np.nonzero(np.diff(cand_c))[0] + 1]
    rank = np.arange(len(cand_c)) - np.repeat(first, np.diff(np.r_[first, len(cand_c)]))
    fit = rank < KR
    reach_h[cand_c[fit], rank[fit]] = cand_h[fit]
    reach_l[cand_c[fit], rank[fit]] = cand_l[fit]

    # The nearest reached floor of each layer, carried up to NEAR metres out (cover is looked for there).
    near_h = []
    steps = int(math.ceil(NEAR / CELL))
    for L in range(layers):
        grid = np.full((gh, gw), np.nan, dtype=np.float32)
        sel = rl == L
        cc = rc[sel]
        hh = rh[sel].astype(np.float32)
        flat = grid.reshape(-1)
        np.fmax.at(flat, cc, hh)
        # Straight and diagonal steps by turns: an octagon, near enough a circle (straight ones alone made a diamond,
        # its corner cutting a room into a triangle).
        for _ in range(steps):
            g = grid.copy()
            sides = ((1, 0), (-1, 0), (0, 1), (0, -1)) + (((1, 1), (1, -1), (-1, 1), (-1, -1)) if _ % 2 else ())
            for sh in sides:
                moved = shifted(grid, sh[0], sh[1], np.nan)
                fill = np.isnan(g) & ~np.isnan(moved)
                g[fill] = moved[fill]
            grid = g
        near_h.append(grid.reshape(-1))
    # The highest reached floor of each layer within OVER_NEAR: a thing standing on it (a crate on a roof too tall to get
    # onto) is drawn as itself, not as the floor under that roof seen through it.
    over_h = []
    for L in range(layers):
        grid = np.full((gh, gw), np.nan, dtype=np.float32)
        sel = rl == L
        np.fmax.at(grid.reshape(-1), rc[sel], rh[sel].astype(np.float32))
        for _ in range(int(math.ceil(OVER_NEAR / CELL))):
            g = grid.copy()
            for sh in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                g = np.fmax(g, shifted(grid, sh[0], sh[1], np.nan))
            grid = g
        over_h.append(grid.reshape(-1))
    mark("layers")

    # ---------- The pixels: computed at SUPER times the size, then shrunk (smooth edges at any angle) ----------
    R = resolution * SUPER
    p = size / R
    pc = np.arange(R)
    pxx = mx + (pc + 0.5) * p                       # x of each column of pixels
    pzz = mz + (pc + 0.5) * p                       # z of each row (row 0 the lowest z)
    gx = np.clip(np.round((pxx - gx0) / CELL).astype(np.int64), 0, gw - 1)
    gz = np.clip(np.round((pzz - gz0) / CELL).astype(np.int64), 0, gh - 1)
    inx = (pxx >= gx0 - CELL) & (pxx <= gx0 + gw * CELL)
    inz = (pzz >= gz0 - CELL) & (pzz <= gz0 + gh * CELL)
    col_grid = (gz[:, None] * gw + gx[None, :])     # (R, R) the column under each pixel
    inside = inz[:, None] & inx[None, :]
    near_any = np.zeros(cols, dtype=bool)
    for L in range(layers):
        near_any |= ~np.isnan(near_h[L])
    want = inside & near_any[col_grid]
    method = settings.get("method", "faces")
    if method == "faces":
        floor, cover, topmost = draw_faces(seen, seen_bvh, seen_planes, (rx, rz, rh, rl, rc), (gw, gh, gx0, gz0), near_h,
                                           layers, col_grid, (R, mx, mz, p), cover_max, log)
        nothing = np.zeros((R, R), dtype=bool)
        # A floor goes on where the top seen is at its own height — or a slope's, on along its fall — up to EDGE_REACH (a
        # sliver of the same floor's faces too thin to be drawn left a gap at its edge, drawn as a wall: a white line along
        # de_new2's bank, under the pipe's roof).
        for L in range(layers):
            fl = floor[L]
            for _ in range(int(round(EDGE_REACH / p))):
                more = np.zeros((R, R), dtype=bool)
                for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    n1 = shifted(fl, dy, dx, np.nan)
                    n2 = shifted(fl, 2 * dy, 2 * dx, np.nan)
                    on = np.where(np.isnan(n2), n1, 2.0 * n1 - n2)
                    with np.errstate(invalid="ignore"):
                        more |= np.abs(topmost - on) < 0.03
                more &= np.isnan(fl) & np.isnan(cover[L])
                if not more.any():
                    break
                fl[more] = topmost[more]
    else:
        wy, wx = np.nonzero(want)
        psurf, pface = surfaces(seen_bvh, pxx[wx], pzz[wy], top, depth, 0.3, KP, faces=True)
        # Each surface's plane (the floor's own: what the floor is drawn out to, to its real edges).
        pplane = np.where(pface >= 0, seen_planes[np.maximum(pface, 0)], -1).astype(np.int32)
        del pface
        mark(f"pixel surfaces ({len(wy)})")

        topmost = np.full((R, R), np.nan, dtype=np.float32)
        topmost[wy, wx] = psurf[:, 0]
        nothing = np.isnan(topmost) & want                # seen nothing at all (an invisible floor of clip)
        floor = np.full((layers, R, R), np.nan, dtype=np.float32)
        cover = np.full((layers, R, R), np.nan, dtype=np.float32)
        colw = col_grid[wy, wx]
        for L in range(layers):
            best = np.full(len(wy), np.nan, dtype=np.float32)
            for j in range(KR):
                h = reach_h[colw, j]
                use = (reach_l[colw, j] == L) & ~np.isnan(h)
                if not use.any():
                    continue
                diff = np.abs(psurf - h[:, None])
                match = np.where(diff <= 0.5, psurf, np.nan)
                drawn = np.nanmax(np.where(np.isnan(match), -np.inf, match), axis=1)
                drawn = np.where(np.isinf(drawn), np.nan, drawn)
                drawn = np.where(np.isnan(psurf[:, 0]), h, drawn)
                drawn = np.where(use, drawn, np.nan)
                best = np.fmax(best, drawn)
            # Something solid on a higher floor nearby over the floor drawn here (a crate on a roof over a room): the top seen
            # from above is that thing, not the room's floor — drawn as cover on that floor.
            top_s = psurf[:, 0]
            up = over_h[L][colw]
            # It stands on that floor: the floor's own surface is there under it. Without it, it is the ceiling of the room
            # drawn here (a room's ceiling a little over a step up beside it, drawn as a diamond of cover).
            with np.errstate(invalid="ignore"):
                stands = np.any(np.abs(psurf[:, 1:] - up[:, None]) <= 0.3, axis=1)
            on_upper = (~np.isnan(best) & ~np.isnan(top_s) & ~np.isnan(up) & (up >= best + STEP) &
                        (top_s > best + 0.5) & (top_s >= up - 0.1) & (top_s <= up + cover_max) & stands)
            best = np.where(on_upper, np.nan, best)
            floor[L, wy, wx] = best
            # Cover: no floor of this layer here, but a surface not too high over the floor nearby.
            H = np.where(on_upper, up, near_h[L][colw])
            # The top seen from above, not the highest surface under the limit: a building taller than that (a closed room)
            # is a wall, and its own floor inside is not cover seen through its roof.
            s_top = np.where(psurf[:, 0] <= H + cover_max, psurf[:, 0], -np.inf)
            is_cover = np.isnan(best) & ~np.isnan(H) & np.isfinite(s_top) & (s_top > H + 0.25)
            cover[L, wy[is_cover], wx[is_cover]] = s_top[is_cover]
        # Slopes too steep to stand on (a canal's sides, slid down): not cover, not holes — ground going down, drawn as floor
        # by its height, where it joins a floor drawn. A slope's top changes smoothly from pixel to pixel and steeply (a
        # wall's jumps, a crate's top is flat).
        top_h = np.where(want, topmost, np.nan)
        with np.errstate(invalid="ignore"):
            gx_ = (shifted(top_h, 0, -1, np.nan) - shifted(top_h, 0, 1, np.nan)) / (2 * p)
            gz_ = (shifted(top_h, -1, 0, np.nan) - shifted(top_h, 1, 0, np.nan)) / (2 * p)
            steep = np.hypot(gx_, gz_)
            smooth = np.ones((R, R), dtype=bool)
            for dy_, dx_ in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                smooth &= np.abs(shifted(top_h, dy_, dx_, np.nan) - top_h) <= SLOPE_MAX * p * 1.5
            slope = smooth & (steep >= SLOPE_MIN) & (steep <= SLOPE_MAX)
        for L in range(layers):
            fl_l = floor[L]
            drawn = ~np.isnan(fl_l)
            sl = slope & ~drawn & ~np.isnan(near_h[L][col_grid])
            if not sl.any():
                continue
            # Only slope reaching out from a floor drawn nearby (then step by step through the slope itself).
            joined = sl & grow(drawn, max(1, int(round(0.5 / p))))  # (a lip or an edge between them: half a metre)
            for _ in range(int(SLOPE_REACH / p)):
                more = sl & grow(joined, 1) & ~joined
                if not more.any():
                    break
                joined |= more
            floor[L][joined] = top_h[joined]
            cover[L][joined] = np.nan
        # Floors out to their real edges: the walk's grid (20 cm) draws an edge at any angle but its own as steps; a floor is
        # drawn on along its own planes (the surfaces it was found on), up to EDGE_REACH, where nothing else is drawn — so its
        # edge is the edge of its faces, whatever their angle.
        widx = np.full((R, R), -1, dtype=np.int32)
        widx[wy, wx] = np.arange(len(wy), dtype=np.int32)
        for L in range(layers):
            fl_l, cv_l = floor[L], cover[L]
            has = ~np.isnan(fl_l)
            if not has.any():
                continue
            # The planes this layer's floor is drawn on.
            yy, xx = np.nonzero(has)
            ii = widx[yy, xx]
            okw = ii >= 0
            yy, xx, ii = yy[okw], xx[okw], ii[okw]
            k_of = np.argmin(np.abs(np.nan_to_num(psurf[ii], nan=1e9) - fl_l[yy, xx][:, None]), axis=1)
            own = np.unique(pplane[ii, k_of])
            own = own[own >= 0]
            if not len(own):
                continue
            for _ in range(int(math.ceil(EDGE_REACH / p))):
                grown = False
                for dy_, dx_ in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    nb = shifted(fl_l, dy_, dx_, np.nan)
                    cy, cx = np.nonzero(np.isnan(fl_l) & np.isnan(cv_l) & ~np.isnan(nb) & (widx >= 0))
                    if not len(cy):
                        continue
                    ci = widx[cy, cx]
                    h_nb = nb[cy, cx]
                    s, pl = psurf[ci], pplane[ci]
                    with np.errstate(invalid="ignore"):
                        fits = np.isin(pl, own) & (np.abs(s - h_nb[:, None]) <= max(0.05, SLOPE_MAX * p * 1.5))
                    k = np.argmax(fits, axis=1)
                    ok = fits[np.arange(len(ci)), k]
                    if ok.any():
                        fl_l[cy[ok], cx[ok]] = s[np.nonzero(ok)[0], k[ok]]
                        grown = True
                if not grown:
                    break
    # No floor under a wall: a floor slab goes on under the walls standing on it, and the face players stood on was drawn
    # through them (a room's wall beside its window was gone). What is solid right over the floor, or right over the
    # highest floor within WALL_ON of it (a wall on a room's floor over a slope going on under the room), is a wall;
    # the gap left is drawn as one below.
    if solids.hull is None:
        for L in range(layers):
            fl = floor[L]
            high = np.where(np.isnan(fl), -np.inf, fl)
            reach, done, k = int(round(WALL_ON / p)), 0, 1
            while done < reach:  # the highest within a square `reach` across, by doubling steps
                k = min(k, reach - done)
                for sh in ((k, 0), (-k, 0), (0, k), (0, -k)):
                    high = np.maximum(high, shifted(high, sh[0], sh[1], -np.inf))
                done += k
                k *= 2
            for near_floor, h in ((False, fl), (True, np.where(high > fl + 0.1, high, np.nan))):
                fy, fx = np.nonzero(~np.isnan(h) & ~np.isnan(fl))
                if not len(fy):
                    continue
                x_, z_, h_ = pxx[fx], pzz[fy], h[fy, fx].astype(np.float64)
                wall = ~solids.free(x_, h_ + 0.05, z_, height=0.02, half=p * 0.25)
                if near_floor:
                    # Only a wall standing on that floor, its slab going on under it, over a floor nobody walks here
                    # (a slope going on under a room); a trench walked under a building's side stays (it was walled off).
                    walked = (np.abs(reach_h[col_grid[fy, fx]] - fl[fy, fx][:, None]) < 0.3).any(axis=1)
                    wall &= ~walked & ~solids.free(x_, h_ - 0.07, z_, height=0.02, half=p * 0.25)
                fl[fy[wall], fx[wall]] = np.nan
    mark("floors and cover")
    if settings.get("dump"):
        # For finding out why (a file of what each pixel got): the floors, cover, the top seen, the reached floor points.
        np.savez_compressed(settings["dump"], floor=floor, cover=cover, topmost=topmost, nothing=nothing,
                            frame=np.array([mx, mz, size]), rx=rx, rz=rz, rh=rh, bottoms=np.array(bottoms))
    probes = settings.get("probe") if method == "rays" else None  # (x, z) in the game's space, or a list of them: what is drawn there, for finding out why
    if probes is not None and not isinstance(probes[0], (list, tuple)):
        probes = [probes]
    for probe in probes or []:
        qy, qx = int((probe[1] - mz) / p), int((probe[0] - mx) / p)
        if 0 <= qy < R and 0 <= qx < R:
            i = np.nonzero((wy == qy) & (wx == qx))[0]
            log(f"Radar probe {probe}: floor {floor[:, qy, qx].tolist()}, cover {cover[:, qy, qx].tolist()}, "
                f"surfaces {psurf[i[0]].tolist() if len(i) else None}, near {[float(n[col_grid[qy, qx]]) for n in near_h]}, "
                f"over {[float(n[col_grid[qy, qx]]) for n in over_h]}, reach {reach_h[col_grid[qy, qx]].tolist()}, "
                f"slope {float(steep[qy, qx]):.2f} smooth {bool(smooth[qy, qx])}, top around {top_h[qy-2:qy+3, qx-2:qx+3].round(2).tolist()}")

    # ---------- Drawing each layer ----------
    sites = [volume(e) for e in entities if e.get("type") == "bombsite"]
    buys = [volume(e) for e in entities if e.get("type") == "buyzone"]
    xs_px = np.broadcast_to(pxx[None, :], (R, R))
    zs_px = np.broadcast_to(pzz[:, None], (R, R))
    scale = R / 2048.0  # the blur and lines are given for 2048 (1024 shown)
    images = []
    stale = []
    roofs = np.zeros((R, R), dtype=bool)  # low roofs shown on the map from above (closed, from a low place too)
    for L in range(layers):
        fl, cv = floor[L], cover[L]
        if (regions or zones) and L == 0:
            # The map from above: the boxes' layers too where nothing is over them (a trench open to the sky, not where
            # a building or a bridge is over it; a pipe's roof, not the inside of it).
            fl, cv = fl.copy(), cv.copy()
            near0 = near_h[0][col_grid]
            for O in range(1, layers):
                for mine, theirs in ((fl, floor[O]), (cv, cover[O])):
                    seen_top = ~np.isnan(theirs) & ~(topmost > theirs + 0.15)
                    mine[seen_top] = np.fmax(mine[seen_top], theirs[seen_top])
            for O in range(1, layers):  # (once all are in: a roof does not go on over a trench's side seen beside it)
                # A low roof over it, one gets onto from the floor beside (a pipe's, landed on from the bank), is shown as
                # cover: closed, no way in seen; a building or a roof over stairs down is not (dark, as buildings are).
                with np.errstate(invalid="ignore"):
                    roof = (~np.isnan(floor[O]) & (topmost > floor[O] + 0.15) & np.isnan(fl) & np.isnan(cv) &
                            (topmost <= near0 + JUMP_UP))
                # The whole roof: the faces seen there, all of each seen from above (its edges its own: a trench's side
                # drawn up to it is under it) — each if mostly over this layer's floor (a pipe's top; not a bank's long
                # edge going on over a bit of the pipe under it), and not this layer's own floor.
                ys, xs = np.nonzero(roof)
                faces = set()
                for i in range(0, len(ys), 4):
                    hit = seen_bvh.ray_cast(Vector((float(pxx[xs[i]]), float(topmost[ys[i], xs[i]]) + 0.05,
                                                    float(pzz[ys[i]]))), Vector((0.0, -1.0, 0.0)), 0.2)
                    if hit[2] is not None:
                        faces.add(hit[2])
                for t in faces:
                    got = triangle_pixels(seen[t], R, mx, mz, p)
                    if got is None:
                        continue
                    (z0, z1, x0, x1), inside, h = got
                    top = topmost[z0:z1, x0:x1]
                    with np.errstate(invalid="ignore"):
                        shown = (inside & (np.abs(top - h) < 0.03) & np.isnan(floor[0][z0:z1, x0:x1]) &
                                 np.isnan(cover[0][z0:z1, x0:x1]))
                    if not shown.any() or (shown & ~np.isnan(floor[O][z0:z1, x0:x1])).sum() < 0.5 * shown.sum():
                        continue
                    cv[z0:z1, x0:x1][shown] = top[shown]
                    fl[z0:z1, x0:x1][shown] = np.nan
                    roofs[z0:z1, x0:x1] |= shown
        has_f, has_c = ~np.isnan(fl), ~np.isnan(cv)
        M = has_f | has_c
        rgb = np.zeros((R, R, 3)); a = np.zeros((R, R))
        # Other layers' floors, faint, under everything (the map from above has none: it shows what is seen from there).
        for O in range(layers):
            if O == L or L in zone_of or (L == 0 and O in zone_of):
                continue
            of = floor[O]
            show = ~np.isnan(of) & ~M & (a == 0)
            if show.any():
                rgb[show] = gradient(of[show]); a[show] = OTHER_LAYER_ALPHA
        if shadow_on:
            blur = box_blur(box_blur(M.astype(np.float64), max(1, int(round(16 * scale)))), max(1, int(round(16 * scale))))
            sh = np.where(M, 0.0, 0.6 * blur)
            over(rgb, a, np.zeros((R, R, 3)), sh)
        ring = grow(M, max(1, int(round(3 * scale)))) & ~M
        over(rgb, a, np.broadcast_to(np.array(OUTLINE), (R, R, 3)), np.where(ring, 0.6, 0.0))
        # Walls inside the map: gaps between floors narrower than WALL_FILL (a wall whose top is not seen, under a roof,
        # or no cover by the rules) are a wall's colour, not holes the HUD shows through.
        reach = max(1, int(round(WALL_FILL * 0.5 / p)))
        grown = box_blur(M.astype(np.float32), reach) > 1e-4               # within `reach` of a floor (a square)
        wall = (box_blur(grown.astype(np.float32), reach) > 1.0 - 1e-4) & ~M  # and every pixel that near is too: closed
        over(rgb, a, np.broadcast_to(np.array(OUTLINE), (R, R, 3)), np.where(wall, 1.0, 0.0))
        col = np.zeros((R, R, 3))
        col[has_f] = gradient(fl[has_f])
        col[has_c] = gradient(cv[has_c])
        # The edge of cover, inside it.
        cover_edge = has_c & grow(~has_c, max(1, int(round(2 * scale))))
        col[cover_edge] = col[cover_edge] * 0.4 + np.array(OUTLINE) * 0.6
        # Ledges: the floor next to it is more than a step higher.
        flz = np.where(has_f, fl, -np.inf)
        ledge = np.zeros((R, R), dtype=bool)
        for dy_, dx_ in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nb = shifted(flz, dy_, dx_, -np.inf)
            ledge |= has_f & (nb - fl > STEP * 1.2)
        col[ledge] = col[ledge] * 0.45 + np.array(LEDGE) * 0.55
        if ao_on:
            ao = np.zeros((R, R)); weight = 0.0
            solid_h = np.where(has_f, fl, np.where(has_c, cv, np.nan))
            wall_top = np.where(np.isnan(topmost), np.inf, topmost)
            for i in range(16):
                ang = i * math.pi / 8.0
                for rad, w in ((0.25, 1.0), (0.5, 0.66), (0.75, 0.33)):
                    ox_ = int(round(math.cos(ang) * rad / p)); oy_ = int(round(math.sin(ang) * rad / p))
                    sh_h = shifted(solid_h, oy_, ox_, np.nan)
                    sh_m = shifted(M, oy_, ox_, False)
                    sh_t = shifted(wall_top, oy_, ox_, np.inf)
                    closed = np.where(sh_m, sh_h > fl + 0.3, sh_t > fl + 0.3)
                    ao += w * (closed & has_f)
                    weight += w
            ao /= weight
            col[has_f] *= (1.0 - ao_strength * ao[has_f])[:, None]
        if tints_on:
            for vols, tint, strength in ((sites, SITE_TINT, 0.35), (buys, BUY_TINT, 0.25)):
                for v in vols:
                    if v is None:
                        continue
                    inz_ = (xs_px >= v[0][0]) & (xs_px <= v[1][0]) & (zs_px >= v[0][2]) & (zs_px <= v[1][2])
                    # The floor within the volume's heights (a thin volume a little over the floor, as CS maps' triggers
                    # often are, still counts).
                    t = has_f & inz_ & (fl >= v[0][1] - 1.0) & (fl <= v[1][1] + 0.1)
                    col[t] = col[t] * (1.0 - strength) + np.array(tint) * strength
        over(rgb, a, col, np.where(M, 1.0, 0.0))
        if L == 0:
            top_rgb, top_a, top_m = rgb, a, M
        elif L in zone_of:
            # From down there: the map from above, with this place's floor under what is over it (a bridge, a building's
            # side) and that thing still seen over it, a little; its edge outlined. A low roof (a pipe's) stays closed.
            with np.errstate(invalid="ignore"):
                under = has_f & (topmost > fl + 0.15) & ~roofs
            near_px = max(1, int(round(WALL_FILL * 0.5 / p)))
            see = (under | (grow(under, near_px) & ~top_m)) & (a > 0)
            rgb_u, a_u = top_rgb.copy(), top_a.copy()
            rgb_u[see] = rgb[see] * (1.0 - SEE_THROUGH) + top_rgb[see] * top_a[see][:, None] * SEE_THROUGH
            a_u[see] = np.maximum(a[see], top_a[see])
            edge = under & grow(~under, max(1, int(round(3 * scale))))
            rgb_u[edge] = rgb_u[edge] * 0.3 + np.array(OUTLINE) * 0.7
            rgb, a = rgb_u, a_u
        # Halved, the colours weighed by their cover (premultiplied).
        pm = rgb * a[..., None]
        pm = pm.reshape(resolution, SUPER, resolution, SUPER, 3).mean(axis=(1, 3))
        aa = a.reshape(resolution, SUPER, resolution, SUPER).mean(axis=(1, 3))
        out = np.where(aa[..., None] > 1e-6, pm / np.maximum(aa, 1e-6)[..., None], 0.0)
        img = np.concatenate([out, aa[..., None]], axis=-1)
        img = (np.clip(img, 0.0, 1.0) * 255.0 + 0.5).astype(np.uint8)
        img = img[::-1]  # the file's first row is the highest z
        auto = os.path.join(folder, f"radar_auto_{L}.png")
        mine = os.path.join(folder, f"radar_{L}.png")
        # The author's own picture: given in the map tools, or a radar_<i>.png left in the package that is not the last
        # one made here.
        given = settings.get("images", {}).get(L)
        made_before = open(auto, "rb").read() if os.path.exists(auto) else None
        own_here = os.path.exists(mine) and (made_before is None or open(mine, "rb").read() != made_before)
        write_png(auto, img)
        if given and os.path.exists(given):
            with open(given, "rb") as f, open(mine, "wb") as g:
                g.write(f.read())
        elif not own_here:
            with open(auto, "rb") as f, open(mine, "wb") as g:
                g.write(f.read())
        images.append(f"radar_{L}.png")
    # Pictures of layers the map no longer has.
    L = layers
    while os.path.exists(os.path.join(folder, f"radar_auto_{L}.png")):
        os.remove(os.path.join(folder, f"radar_auto_{L}.png"))
        if os.path.exists(os.path.join(folder, f"radar_{L}.png")):
            os.remove(os.path.join(folder, f"radar_{L}.png"))
        L += 1
    mark("pictures")
    log(f"Radar: {size:.0f} m across, {layers} layer(s)" +
        (f" from {', '.join(f'{b:.1f}' for b in bottoms)} m" if bottoms else "") +
        f", {reached_count} of {nodes} floor points reached from {seeds} spawns; {', '.join(marks)}")
    if regions:
        layers_json = [{"image": images[0]}] + [
            {"image": images[L], "boxes": [round(float(c), 4) for lo, hi, k in regions if k == L for c in (*lo, *hi)]}
            for L in range(1, main_layers)]
    else:
        layers_json = [{"image": images[0]}] + [{"image": images[i + 1], "bottom": round(float(b), 4)}
                                                for i, b in enumerate(bottoms)]
    block = {"format": 1, "min": [round(float(mx), 4), round(float(mz), 4)], "size": round(float(size), 4),
             "layers": layers_json}
    if zones:
        # Where each low place is (its number in the red of a picture the radar's size, its floor points carried out a
        # box's half) and how high: whoever stands there, at those heights, sees its picture.
        ps = size / resolution
        where = np.zeros((resolution, resolution, 4), dtype=np.uint8)
        g = int(math.ceil(HALF / ps))
        for i, (L, pts) in enumerate(zones):
            ix = np.clip(((rx[pts] - mx) / ps).astype(np.int64), 0, resolution - 1)
            iz = np.clip(((rz[pts] - mz) / ps).astype(np.int64), 0, resolution - 1)
            m = np.zeros((resolution, resolution), dtype=bool)
            m[iz, ix] = True
            m = grow(m, g)
            where[m, 0] = i + 1
            where[m, 3] = 255
        write_png(os.path.join(folder, "radar_low.png"), where[::-1])
        block["low"] = {"image": "radar_low.png", "places": [
            {"image": images[L], "bottom": round(float(rh[pts].min()), 4), "top": round(float(rh[pts].max()), 4)}
            for L, pts in zones]}
    elif os.path.exists(os.path.join(folder, "radar_low.png")):
        os.remove(os.path.join(folder, "radar_low.png"))
    return block


def seen_triangles(objects):
    """The seen meshes' triangles in the game's space, (N, 3, 3), winding turned with the axes."""
    import bpy
    depsgraph = bpy.context.evaluated_depsgraph_get()
    out = []
    for o in objects:
        if o.type != "MESH" or o.get("ps_entity") == "water":
            continue
        ev = o.evaluated_get(depsgraph)
        me = ev.to_mesh()
        try:
            me.calc_loop_triangles()
            n = len(me.loop_triangles)
            if not n:
                continue
            co = np.empty(len(me.vertices) * 3, dtype=np.float64)
            me.vertices.foreach_get("co", co)
            co = co.reshape(-1, 3)
            mw = np.array(o.matrix_world)
            co = co @ mw[:3, :3].T + mw[:3, 3]
            co = np.stack([-co[:, 0], co[:, 2], -co[:, 1]], axis=1)
            tri = np.empty(n * 3, dtype=np.int64)
            me.loop_triangles.foreach_get("vertices", tri)
            tri = tri.reshape(-1, 3)[:, ::-1]
            out.append(co[tri])
        finally:
            ev.to_mesh_clear()
    return np.concatenate(out) if out else np.zeros((0, 3, 3))
