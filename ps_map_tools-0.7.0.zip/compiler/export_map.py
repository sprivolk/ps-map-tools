"""
A map made in Blender, out as a map package: what the game's map compiler takes in.

    blender -b <map.blend> --python export_map.py -- <package folder>   (the map tools' compiler/ folder)

The package (format 1):
- <name>.glb   what is seen: every visible mesh of the map (glTF 2.0, its materials and textures in it).
- map.json     the rest, in our words: the entities (spawns, bomb sites, buy zones, ladders, water, the sun) and the
               collision as convex blocks (their corner points). Nothing in it depends on Blender.
- radar_<i>.png  the radar's pictures, one per layer (radar_gen.py; its "radar" block in map.json), with the made ones
               beside them as radar_auto_<i>.png to draw over.

A collection with the custom property ps_export = 0 is left out, with every collection in it (references, examples).
The objects say what they are with the custom property "ps_entity" (and their ps_* settings), set by our addon or by
the CS 1.6 importer:
  world, solid, detail, breakable, water    seen (in the .glb); "breakable" and "water" are entities too. ps_surface
                                            (concrete, wood, metal, glass... the game's Surfaces.json) is what bullets
                                            go through and what hits and steps sound like (default when not set)
  collision                                 its loose parts are the convex blocks a player stands on and walks against;
                                            with ps_concave, the whole mesh is one block as it is (terrain, models)
  grenadeclip, blockbullets                 like collision, but for thrown grenades only / for bullets only (CS tools)
  (shotclip)                                made by the export: stairs' steps for bullets and grenades (kind "shots"),
                                            players walking on the stairs' clip ramp
  spawn (ps_team T / CT)                    an empty on the floor; it faces its +X
  bombsite (ps_site A / B), buyzone (ps_team T / CT / ""), ladder, water    volumes: a closed mesh, convex
  radarlayer (ps_layer 1, 2…)               a volume: whoever stands in it sees that radar layer (several make one)
  radarmin, radarmax, radarcolor (ps_color) empties: the radar gradient's bottom, top and own colours by height
  killzone                                  a volume: whoever enters it dies (CS trigger_hurt)
  nobots                                    a volume: Training's bots never appear or run in it
  spraytarget (ps_distance metres), spraypattern, aimscreen, aimboard   Training's stands: boxes on a wall the game
                                            draws on (their face toward the nearest players' spawn, ps_flip the other)
  sun (ps_color, ps_brightness)             an empty; the light shines along its +X
  light (ps_color, ps_brightness, ps_range metres, ps_cone degrees for a spot)   an empty: a lamp the bake lights the
                                            map with (a spot shines along its +X)
Space: glTF's — metres, Y up, right-handed (Blender x, y, z is x, z, -y). Unity's is this with x turned over, as
glTFast imports the .glb.
"""
import json
import struct
import math
import os
import shutil
import sys

import bmesh
import bpy
import numpy as np
from mathutils import Matrix, Vector

FORMAT = 1
UNIT = 0.025  # metres a Hammer unit
GENERATOR = "PlaceholderShooter export_map 0.1"
PREVIEW = "preview.png"  # the Workshop card's picture (the map tools take it: <map>_preview.png beside the .blend)
SEEN = {"world", "solid", "detail", "breakable", "water"}
VOLUMES = {"bombsite", "buyzone", "ladder", "water", "radarlayer", "killzone", "ambient", "rulepanel", "nobots",
           "spraytarget", "spraypattern", "aimscreen", "aimboard"}
# Invisible blocks, and whom they stop: players (collision), thrown grenades, bullets.
CLIPS = {"collision": "player", "grenadeclip": "grenade", "blockbullets": "bullets", "solidclip": "solid",
         "shotclip": "shots", "invisibleclip": "player"}  # invisible: players (this block) and grenades (a copy)


def gltf(v):
    return [round(v.x, 4), round(v.z, 4), round(-v.y, 4)]


def convex_parts(obj):
    """Each loose part of a mesh object, as its corner points in world space."""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.transform(obj.matrix_world)
    bm.verts.ensure_lookup_table()
    seen, parts = set(), []
    for start in bm.verts:
        if start.index in seen:
            continue
        stack, part = [start], []
        seen.add(start.index)
        while stack:
            v = stack.pop()
            part.append(v.co.copy())
            for e in v.link_edges:
                o = e.other_vert(v)
                if o.index not in seen:
                    seen.add(o.index)
                    stack.append(o)
        if len(part) >= 4:
            parts.append(part)
    bm.free()
    return parts


def convex_meshes(obj):
    """Each loose part of a mesh object as its own little mesh: corners (world space) and triangles (fans of its faces)."""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.transform(obj.matrix_world)
    # In triangles as Blender cuts them (a fan from one corner of an L-shaped face ran outside it).
    bmesh.ops.triangulate(bm, faces=bm.faces[:])
    bm.verts.ensure_lookup_table()
    parts, seen = [], set()
    for face in bm.faces:
        if face.index in seen:
            continue
        stack, faces = [face], []
        seen.add(face.index)
        while stack:
            f = stack.pop()
            faces.append(f)
            for e in f.edges:
                for o in e.link_faces:
                    if o.index not in seen:
                        seen.add(o.index)
                        stack.append(o)
        index, points, tris = {}, [], []
        edges = {e for f in faces for e in f.edges}
        inside = set(faces)
        closed = all(sum(1 for g in e.link_faces if g in inside) == 2 for e in edges)
        for f in faces:
            ring = []
            for v in f.verts:
                if v.index not in index:
                    index[v.index] = len(points)
                    points.append(v.co.copy())
                ring.append(index[v.index])
            for i in range(1, len(ring) - 1):
                tris += [ring[0], ring[i], ring[i + 1]]
        if len(points) >= 4:
            parts.append((points, tris, closed))
    bm.free()
    return parts


def _hull(points):
    """The convex hull of points: (corners, triangles, volume), or None when they are flat."""
    bm = bmesh.new()
    for p in points:
        bm.verts.new(p)
    try:
        bmesh.ops.convex_hull(bm, input=bm.verts[:], use_existing_faces=False)
    except (ValueError, RuntimeError):
        bm.free()
        return None
    for v in [v for v in bm.verts if not v.link_faces]:
        bm.verts.remove(v)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    vol = bm.calc_volume(signed=False)
    if vol < 1e-7 or not bm.faces:
        bm.free()
        return None
    bm.verts.index_update()
    pts = [v.co.copy() for v in bm.verts]
    tris = []
    for f in bm.faces:
        ring = [v.index for v in f.verts]
        for i in range(1, len(ring) - 1):
            tris += [ring[0], ring[i], ring[i + 1]]
    bm.free()
    return pts, tris, vol


def convex_pieces(points, tris, tolerance=1e-4):
    """A closed solid that is not convex (a brush made an L by hand, a step on it) as convex pieces that fill it, as VBSP
    needs its brushes: space cut by the planes of its own faces, the cells inside it kept, those that make one convex
    piece together joined again. A player stands on these (a mesh as it is is only a shell: one-sided to the game's
    physics, and one turned inside out let players through). Its faces turned outward first. None: it cannot be done."""
    from mathutils.bvhtree import BVHTree
    faces = [tris[i:i + 3] for i in range(0, len(tris), 3)]
    tree = BVHTree.FromPolygons(points, faces)
    planes = []
    for a, b, c in faces:
        n = (points[b] - points[a]).cross(points[c] - points[a])
        if n.length < 1e-9:
            continue
        n.normalize()
        d = n.dot(points[a])
        if not any(abs(n.dot(m)) > 1 - 1e-6 and abs(d - e * n.dot(m)) < tolerance for m, e in planes):
            planes.append((n, d))
    if len(planes) > 64:
        return None
    lo = Vector(map(min, *points))
    hi = Vector(map(max, *points))
    cells = [[Vector((x, y, z)) for x in (lo.x, hi.x) for y in (lo.y, hi.y) for z in (lo.z, hi.z)]]
    for n, d in planes:
        out = []
        for cell in cells:
            side = [n.dot(p) - d for p in cell]
            if max(side) <= tolerance or min(side) >= -tolerance:
                out.append(cell)
                continue
            cut = [p.lerp(q, sp / (sp - sq)) for p, sp in zip(cell, side) for q, sq in zip(cell, side) if sp < -tolerance < tolerance < sq]
            below = [p for p, sp in zip(cell, side) if sp <= tolerance] + cut
            above = [p for p, sp in zip(cell, side) if sp >= -tolerance] + cut
            for part in (below, above):
                h = _hull(part)
                if h is not None:
                    out.append(h[0])
        cells = out
        if len(cells) > 512:
            return None

    def inside(cell):
        c = sum(cell, Vector()) / len(cell)
        # Inside: the solid's faces seen from its middle cover the whole sphere round it (their solid angles add up to
        # 4π; outside, to 0). The faces' own way only flips the sign: one turned inside out is still found. (Rays from
        # the middle were fooled by those running along an edge: a piece of a step went missing.)
        total = 0.0
        for a, b, cc in faces:
            ra, rb, rc = points[a] - c, points[b] - c, points[cc] - c
            la, lb, lc = ra.length, rb.length, rc.length
            num = ra.dot(rb.cross(rc))
            den = la * lb * lc + ra.dot(rb) * lc + ra.dot(rc) * lb + rb.dot(rc) * la
            total += 2.0 * math.atan2(num, den)
        return abs(total) > 2.0 * math.pi
    kept = [h for h in (_hull(c) for c in cells if inside(c)) if h is not None]
    if not kept:
        return None
    # Joined back where two make one convex piece (the hull of both no bigger than the two).
    pieces = [(h[0], h[2]) for h in kept]
    merged = True
    while merged and len(pieces) > 1:
        merged = False
        for i in range(len(pieces)):
            for j in range(i + 1, len(pieces)):
                h = _hull(pieces[i][0] + pieces[j][0])
                if h is not None and h[2] <= (pieces[i][1] + pieces[j][1]) * (1 + 1e-5) + 1e-9:
                    pieces[i] = (h[0], h[2])
                    del pieces[j]
                    merged = True
                    break
            if merged:
                break
    out = []
    for pts, _ in pieces:
        h = _hull(pts)
        if h is not None:
            out.append((h[0], h[1]))
    return out


def is_convex(points, tris, tolerance=1e-3):
    """Every corner lies behind (or on) the plane of every triangle."""
    for i in range(0, len(tris), 3):
        a, b, c = points[tris[i]], points[tris[i + 1]], points[tris[i + 2]]
        n = (b - a).cross(c - a)
        if n.length < 1e-9:
            continue
        n.normalize()
        if any((p - a).dot(n) > tolerance for p in points):
            return False
    return True


def whole_mesh(obj):
    """A mesh object's corners (world space) and triangles (fans of its faces), all of it."""
    mesh = obj.data
    points = [obj.matrix_world @ v.co for v in mesh.vertices]
    tris = []
    for f in mesh.polygons:
        ring = list(f.vertices)
        for i in range(1, len(ring) - 1):
            tris += [ring[0], ring[i], ring[i + 1]]
    return points, tris


def sun_way(obj):
    """Where the sun's light goes (Blender space, a unit vector): its arrow (ps_arrow: the empty's +Z, the map tools'
    sun), or, a CS map's light_environment, the empty's yaw and its "pitch" key (how far down; negative: down)."""
    if obj.get("ps_arrow"):
        return (obj.matrix_world.to_3x3() @ Vector((0.0, 0.0, 1.0))).normalized()
    pitch = math.radians(float(obj.get("cs_pitch", "-45") or -45))
    yaw = obj.rotation_euler.z
    return Vector((math.cos(pitch) * math.cos(yaw), math.cos(pitch) * math.sin(yaw), math.sin(pitch)))


def door_frame(obj):
    """A door (the map tools' Make door) for the game, glTF space: its node; its hinge point (at its foot), up, across
    (hinge → far edge), front (its normal); its width, height, thickness (metres); how far it opens (°), how fast (°/s),
    which ways (both / front / back), closing by itself after (s, 0 never), starting open; its surface (bullets); whether
    an HE knocks it out and from how far (m)."""
    corners = [Vector(c) for c in obj.bound_box]
    lo = Vector([min(c[k] for c in corners) for k in range(3)])
    hi = Vector([max(c[k] for c in corners) for k in range(3)])
    ext = hi - lo
    t = 0 if ext.x <= ext.y else 1
    w = 1 - t
    mw = obj.matrix_world
    axes = [mw.to_3x3() @ Vector(v) for v in ((1, 0, 0), (0, 1, 0), (0, 0, 1))]
    high = int(obj.get("ps_door_hinge", 0)) == 1
    local = Vector((0.0, 0.0, lo.z))
    local[w] = hi[w] if high else lo[w]
    local[t] = (lo[t] + hi[t]) / 2
    hinge = mw @ local
    up = axes[2].normalized()
    across = axes[w].normalized() * (-1 if high else 1)
    front = axes[t].normalized()

    def way(v):
        return [round(v.x, 5), round(v.z, 5), round(-v.y, 5)]  # a direction in glTF space
    surface = str(obj.get("ps_surface", "") or "")
    if not surface:
        surface = next((str(m.get("ps_surface")) for m in obj.data.materials if m and m.get("ps_surface")), "")
    return {
        "node": obj.name, "hinge": gltf(hinge), "up": way(up), "across": way(across), "front": way(front),
        "size": [round(ext[w] * axes[w].length, 4), round(ext.z * axes[2].length, 4), round(ext[t] * axes[t].length, 4)],
        "angle": float(obj.get("ps_door_angle", 90.0)), "speed": float(obj.get("ps_door_speed", 180.0)),
        "open": str(obj.get("ps_door_open", "both")), "autoclose": float(obj.get("ps_door_autoclose", 0.0)),
        "startsopen": bool(obj.get("ps_door_startsopen", 0)), "surface": surface or "wood",
        "breakable": bool(obj.get("ps_door_breakable", 1)), "breakradius": float(obj.get("ps_door_breakradius", 8.75)),
    }


def forward(obj):
    return (obj.matrix_world.to_3x3() @ Vector((1, 0, 0))).normalized()


def entity_of(obj):
    kind = obj.get("ps_entity")
    e = {"type": kind, "name": obj.name}
    for key in obj.keys():
        if key.startswith("ps_") and key != "ps_entity":
            value = obj[key]
            e[key[3:]] = list(value) if hasattr(value, "__len__") and not isinstance(value, str) else value
    if obj.type == "EMPTY":
        e["position"] = gltf(obj.matrix_world.translation)
        e["forward"] = gltf(forward(obj))
        # Its Y arrow (a rectangle lamp's first side lies along it).
        e["side"] = gltf((obj.matrix_world.to_3x3() @ Vector((0, 1, 0))).normalized())
    elif kind in VOLUMES and obj.type == "MESH":
        parts = convex_parts(obj)
        e["points"] = [c for p in parts[0] for c in gltf(p)] if parts else []
    if kind == "sun":
        e["direction"] = gltf(sun_way(obj))
    if kind == "door" and obj.type == "MESH":
        e.update(door_frame(obj))
    # Training: a spawn for bots only; a rule panel's switches as true/false (the game reads them so); a mover: its node,
    # its box where it stands (8 corners), its rule.
    if kind == "spawn":
        e["bot"] = bool(obj.get("ps_bot", 0))
    if kind in ("rulepanel", "spraytarget", "spraypattern", "aimscreen", "aimboard"):
        e["flip"] = bool(obj.get("ps_flip", 0))
        e["label"] = str(obj.get("ps_label", ""))
    if kind == "mover" and obj.type == "MESH":
        corners = [obj.matrix_world @ Vector(c) for c in obj.bound_box]
        e["points"] = [c for p in corners for c in gltf(p)]
        e["node"] = obj.name
        e["rule"] = str(obj.get("ps_rule", "training.cover"))
        e["value"] = int(obj.get("ps_value", 1))
        e["invert"] = bool(obj.get("ps_invert", 0))
        e["drop"] = float(obj.get("ps_drop", 0.0))
        e["seconds"] = float(obj.get("ps_seconds", 0.6))
    return e


# ---------- A CS 1.6 map's own player collision (its clip hulls), when the scene came from one ----------
# hull.bin: "PSH1"; planes (count, then normal xyz + distance, glTF space, metres); clip nodes (count, then plane, front,
# back as int32: below 0 is contents, -1 empty, -2 solid); models (count, then name, kind byte 0 world / 1 wall /
# 2 breakable, standing hull's head node, ducked hull's head node). The game moves players against it exactly as CS 1.6.
HULL_KINDS = {"func_wall": 1, "func_wall_toggle": 1, "func_door": 1, "func_door_rotating": 1, "func_breakable": 2}


def write_hull(bsp_path, out_path):
    import importlib.util
    # The CS 1.6 importer: in the project's ArtSource/Export (an imported CS map is only ever exported there).
    here = os.path.dirname(os.path.abspath(__file__))
    path = next((p for p in (os.path.join(here, "import_goldsrc_bsp.py"),
                             os.path.join(here, "..", "..", "..", "Export", "import_goldsrc_bsp.py")) if os.path.exists(p)), None)
    if path is None:
        raise RuntimeError("the CS 1.6 importer (import_goldsrc_bsp.py) is not here: its collision is left out")
    spec = importlib.util.spec_from_file_location("import_goldsrc_bsp", path)
    imp = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(imp)
    lumps = imp.read_bsp(bsp_path)
    unit = imp.UNIT
    planes = lumps["planes"]
    count = len(planes) // 20
    out = bytearray(b"PSH1")
    out += struct.pack("<i", count)
    for i in range(count):
        nx, ny, nz, dist = struct.unpack_from("<4f", planes, i * 20)
        out += struct.pack("<4f", nx, nz, -ny, dist * unit)
    nodes = lumps["clipnodes"]
    n = len(nodes) // 8
    out += struct.pack("<i", n)
    for i in range(n):
        plane, front, back = struct.unpack_from("<ihh", nodes, i * 8)
        out += struct.pack("<3i", plane, front, back)
    models = [("world", 0, 0)]
    for e in imp.parse_entities(lumps["entities"].decode("ascii", "replace")):
        kind = HULL_KINDS.get(e.get("classname", ""))
        model = e.get("model", "")
        if kind and model.startswith("*"):
            models.append((f"{e['classname']} {model}", kind, int(model[1:])))
    out += struct.pack("<i", len(models))
    for name, kind, m in models:
        heads = struct.unpack_from("<4i", lumps["models"], m * 64 + 36)
        encoded = name.encode("utf-8")
        out += struct.pack("<i", len(encoded)) + encoded + struct.pack("<Bii", kind, heads[1], heads[3])
    with open(out_path, "wb") as f:
        f.write(out)
    return len(models)


# ---------- Brushes (the map tools add-on): a box object that is seen and collides, its kind given by tool materials ----------
TILE = 64 * 0.025  # one tile of the Dev grid textures, metres
# A brush whose every face has one of these tool materials (material["ps_tool"]) is that, not seen.
WHOLE_TOOLS = {"clip": "collision", "grenadeclip": "grenadeclip", "blockbullets": "blockbullets", "killzone": "killzone",
               "ladder": "ladder", "collide": "solidclip", "invisible": "invisibleclip"}  # collide: a model's box, players and bullets


def tool_of(mat):
    return str(mat.get("ps_tool", "")) if mat is not None else ""


def world_uvs(obj):
    """Texture lock: UVs from the faces' places in the world (box mapped), one Dev grid tile per 64 units."""
    import numpy as np
    me = obj.data
    if not len(me.polygons):
        return
    layer = me.uv_layers.active or me.uv_layers.new(name="UVMap")
    mw = np.array(obj.matrix_world)
    co = np.empty(len(me.vertices) * 3, dtype=np.float32)
    me.vertices.foreach_get("co", co)
    co = co.reshape(-1, 3) @ mw[:3, :3].T + mw[:3, 3]
    nrm = np.empty(len(me.polygons) * 3, dtype=np.float32)
    me.polygons.foreach_get("normal", nrm)
    nrm = nrm.reshape(-1, 3) @ np.linalg.inv(mw[:3, :3])
    axis = np.abs(nrm).argmax(axis=1)
    starts = np.empty(len(me.polygons), dtype=np.int32)
    totals = np.empty(len(me.polygons), dtype=np.int32)
    me.polygons.foreach_get("loop_start", starts)
    me.polygons.foreach_get("loop_total", totals)
    loop_poly = np.repeat(np.arange(len(me.polygons)), totals)
    verts = np.empty(len(me.loops), dtype=np.int32)
    me.loops.foreach_get("vertex_index", verts)
    p = co[verts]
    a = axis[loop_poly]
    u = np.where(a == 0, p[:, 1], p[:, 0])
    v = np.where(a == 2, p[:, 1], p[:, 2])
    layer.data.foreach_set("uv", (np.stack([u, v], axis=1) / TILE).ravel())


def convex_planes(obj):
    """A convex brush's faces as (normal, distance) in world space, or None when it is not convex."""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.transform(obj.matrix_world)
    bm.normal_update()
    planes = [(f.normal.copy(), f.normal.dot(f.verts[0].co)) for f in bm.faces if f.normal.length > 0.5]
    points = [v.co.copy() for v in bm.verts]
    # Only a closed solid hides and cuts (a lone face, a sheet, a mesh with holes is no solid: taken for one, a stray
    # face of a brush stood for all the space behind it, and roofs beside it went missing).
    closed = bool(bm.edges) and all(len(e.link_faces) == 2 for e in bm.edges)
    bm.free()
    if not closed or len(planes) < 4 or any(n.dot(p) - d > 1e-3 for n, d in planes for p in points):
        return None
    return planes


KEEP = "ps_keep"  # a face attribute of a brush (the add-on's "Always draw"): 1 is never left out as hidden
SEE_THROUGH = {"glass", "chainlink", "metalgrate"}  # surfaces seen through: they hide nothing behind them


def face_surfaces(o):
    """The surface of each face (as Hammer's $surfaceprop: the material's own, material["ps_surface"]); the object's
    ps_surface, when set, stands for all of them. "" is the default."""
    own = str(o.get("ps_surface", "") or "")
    if own:
        return [own] * len(o.data.polygons)
    by_mat = [str(m.get("ps_surface", "") or "") if m else "" for m in o.data.materials]
    return [by_mat[f.material_index] if f.material_index < len(by_mat) else "" for f in o.data.polygons]


def split_by_surface(o, collection):
    """A seen object whose faces are of more than one surface (a wood door's faces on a concrete wall) as one object per
    surface, each with its ps_surface: the game knows a surface per object. One surface: it is set on the object."""
    per_face = face_surfaces(o)
    used = sorted(set(per_face))
    if len(used) <= 1:
        if used and used[0]:
            o["ps_surface"] = used[0]
        return [o]
    parts = []
    for s in used:
        c = o.copy()
        c.data = o.data.copy()
        collection.objects.link(c)
        bm = bmesh.new()
        bm.from_mesh(c.data)
        bm.faces.ensure_lookup_table()
        bmesh.ops.delete(bm, geom=[f for f in bm.faces if per_face[f.index] != s], context="FACES")
        bm.to_mesh(c.data)
        bm.free()
        c.name = f"{o.name} {s or 'default'}"
        if s:
            c["ps_surface"] = s
        else:
            c.pop("ps_surface", None)
        parts.append(c)
    bpy.data.objects.remove(o, do_unlink=True)
    return parts


def brush_roles(brushes):
    """The brushes that are seen (not wholly a tool) and, of those, the convex opaque ones with their planes: what hides
    faces (colliding or not: a face inside a step is not seen either). Shared by the export and the add-on's preview."""
    seen, solid = [], []
    for o in brushes:
        tools = {tool_of(o.data.materials[f.material_index]) if f.material_index < len(o.data.materials) else ""
                 for f in o.data.polygons}
        if len(tools) == 1 and next(iter(tools)) in WHOLE_TOOLS:
            continue
        seen.append(o)
        if not set(face_surfaces(o)) & SEE_THROUGH:
            planes = convex_planes(o)
            if planes:
                solid.append((o, planes))
    return seen, solid


def face_samples(points, centre, spacing):
    """Points all over a polygon (world space): a fan of triangles, each sampled on a grid finer than spacing, pulled a
    hair toward the middle (so a corner on another brush's edge is not taken for outside it)."""
    out = [centre]
    for i in range(1, len(points) - 1):
        a, b, c = points[0], points[i], points[i + 1]
        n = max(1, min(24, int(math.ceil(max((b - a).length, (c - a).length, (c - b).length) / spacing))))
        for u in range(n + 1):
            for v in range(n + 1 - u):
                p = (a * (n - u - v) + b * u + c * v) / n
                out.append(centre + (p - centre) * 0.98)
    return out


PART_KEYS = ("ps_brush", "ps_entity", "ps_surface", "ps_nocollide", "ps_col_players", "ps_col_grenades", "ps_edge_clip")
# The convex pieces closing the map (sealed.py), and the faces not seen that still stop the bake's light (world space:
# Nodraw ones, those left out as nobody sees them), filled by prepare_brushes and leave_out_unseen.
SEAL = []
CLEAR = []  # the player clips: closing the map, seen through
BLOCKERS = []


def loose_parts(mesh):
    """The face indices of each separate piece of a mesh (faces joined by shared corners)."""
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.faces.ensure_lookup_table()
    done, parts = set(), []
    for f in bm.faces:
        if f.index in done:
            continue
        done.add(f.index)
        stack, part = [f], []
        while stack:
            g = stack.pop()
            part.append(g.index)
            for v in g.verts:
                for h in v.link_faces:
                    if h.index not in done:
                        done.add(h.index)
                        stack.append(h)
        parts.append(part)
    bm.free()
    return parts


def split_parts(o, link=None):
    """A brush made of separate convex pieces (ps_parts: the add-on's stairs, steps and clip ramp in one object, to move
    as one) as one brush per piece, each with the brush's settings: a piece all of a tool material (the clip ramp) is
    then that tool, the others are seen. The pieces are linked to `link` when given; the brush itself is left alone."""
    pieces = []
    for i, part in enumerate(loose_parts(o.data)):
        bm = bmesh.new()
        bm.from_mesh(o.data)
        bm.faces.ensure_lookup_table()
        keep = set(part)
        bmesh.ops.delete(bm, geom=[f for f in bm.faces if f.index not in keep], context="FACES")
        # The other pieces' corners too (FACES leaves them): the piece is only itself.
        loose = [v for v in bm.verts if not v.link_faces]
        if loose:
            bmesh.ops.delete(bm, geom=loose, context="VERTS")
        mesh = bpy.data.meshes.new(f"{o.data.name} part {i}")
        bm.to_mesh(mesh)
        bm.free()
        for m in o.data.materials:
            mesh.materials.append(m)
        piece = bpy.data.objects.new(f"{o.name} part {i}", mesh)
        piece.matrix_world = o.matrix_world.copy()
        for key in PART_KEYS:
            if key in o:
                piece[key] = o[key]
        if o.get("ps_stairs"):
            piece["ps_seals"] = 1  # a stair's step: no collision, but it closes the map (prepare_brushes)
        if link is not None:
            link.objects.link(piece)
        pieces.append(piece)
    return pieces


def _box(points, grow=0.0):
    g = Vector((grow, grow, grow))
    return Vector(map(min, *points)) - g, Vector(map(max, *points)) + g


def _overlap(a, b):
    return all(a[0][k] <= b[1][k] and b[0][k] <= a[1][k] for k in range(3))


def clip_brush(o, solid_planes, spacing=8 * 0.025, boxes=None):
    """A seen brush as a bmesh in world space, its faces cut where other solid brushes reach into them (as VBSP does: a
    wall's side half inside another wall is split at that wall's faces), and the faces of it no player can see: tool faces
    (nodraw), and pieces covered all over by other solid brushes, each point inside one of them (one brush or several
    together), unless marked always drawn. The add-on shows the same before export."""
    eps = 0.5 * 0.025
    # How near a brush a face must be to count as covered by it: touching (0.5 mm), not half a unit (12.5 mm) — a crate
    # off the grid a few millimetres over the floor lost both the floor under it and its own bottom, a slit through which
    # the outside of the map showed.
    touch = 0.0005
    bm = bmesh.new()
    bm.from_mesh(o.data)
    bm.transform(o.matrix_world)
    if bm.edges and all(e.is_manifold for e in bm.edges):
        # Its normals for where it is now first: recalc_face_normals goes by them, and those of before the transform (a
        # brush turned 180°: the other way) made it turn a right brush inside out (stairs seen from inside in the game).
        bm.normal_update()
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])  # a closed brush faces outward (it is one-sided in the game)
    bm.normal_update()
    keep = bm.faces.layers.int.get(KEEP)
    mats = o.data.materials

    def is_tool(f):
        return bool(tool_of(mats[f.material_index] if f.material_index < len(mats) else None))

    def cuttable(f):
        return not is_tool(f) and not (keep is not None and f[keep])

    near = []
    if bm.verts:
        own = _box([v.co for v in bm.verts], eps)
        for other, planes in solid_planes:
            if other is o:
                continue
            # Its box as it was before any brush was cut (`boxes`): one cut away whole (inside another wall) still hides.
            if boxes is not None and other.name in boxes:
                box = boxes[other.name]
            elif other.data.vertices:
                box = _box([other.matrix_world @ v.co for v in other.data.vertices], eps)  # (bound_box: not for pieces)
            else:
                continue
            if _overlap(own, box):
                near.append((planes, box, other.name))
    # Cut: each face reaching into a brush is split along that brush's planes, one after another, only the part still
    # inside it going on to the next plane (the cuts stay within the brush, not across the whole face).
    for planes, box, _ in near:
        inside = [f for f in bm.faces if cuttable(f) and _overlap(_box([v.co for v in f.verts]), box)]
        for pn, pd in planes:
            if not inside:
                break
            nxt = []
            for f in inside:
                side = [pn.dot(v.co) - pd for v in f.verts]
                if max(side) <= 1e-4:
                    nxt.append(f)
                    continue
                if min(side) >= -1e-4:
                    continue  # wholly in front of this plane: outside the brush
                cut = bmesh.ops.bisect_plane(bm, geom=[f, *f.edges, *f.verts], plane_co=pn * pd, plane_no=pn,
                                             dist=1e-5)["geom_cut"]
                pieces = {lf for e in cut if isinstance(e, bmesh.types.BMEdge) for lf in e.link_faces}
                for piece in pieces or {f}:
                    if pn.dot(piece.calc_center_median()) - pd <= 0:
                        nxt.append(piece)
            inside = nxt
    bm.normal_update()
    hidden = []
    for f in bm.faces:
        if is_tool(f):
            hidden.append(f)
            continue
        if not cuttable(f):
            continue
        if f.calc_area() < 1e-6:
            hidden.append(f)  # a sliver of a cut (brushes a hair off each other): nothing to see
            continue
        pts = [v.co.copy() for v in f.verts]
        fbox = _box(pts)
        covering = [(planes, name) for planes, box, name in near if _overlap(fbox, box)]
        if not covering:
            continue
        n = f.normal

        def covered(p, planes, name):
            # On a brush's side counts as covered: two brushes side by side leave no gap at their seam.
            if all(pn.dot(p + n * touch) - pd <= 1e-4 for pn, pd in planes):
                return True
            # Two faces one on the other, looking the same way (brushes overlapping, their sides in one plane): one
            # is enough — the other flickered in the game and baked black (each in the other's shadow). The brush of
            # the name first in order keeps its face.
            return (name < o.name and all(pn.dot(p) - pd <= 1e-4 for pn, pd in planes)
                    and any(pn.dot(n) > 0.9999 and abs(pn.dot(p) - pd) < 1e-4 for pn, pd in planes))
        if all(any(covered(p, planes, name) for planes, name in covering)
               for p in face_samples(pts, f.calc_center_median(), spacing)):
            hidden.append(f)
    return bm, hidden


TWO_SIDED = "ps_two_sided"  # a face attribute of the export's copy: of a piece that is not closed


def mark_open_faces(o):
    """The faces of the brush's pieces that are not closed (a roof made of a plane, a mesh with holes, a lone face)
    marked (TWO_SIDED): the game shows them from both sides (both_sides)."""
    bm = bmesh.new()
    bm.from_mesh(o.data)
    flags, done = [0] * len(bm.faces), set()
    bm.faces.ensure_lookup_table()
    for f in bm.faces:
        if f.index in done:
            continue
        stack, part = [f], []
        done.add(f.index)
        while stack:
            g = stack.pop()
            part.append(g)
            for e in g.edges:
                for h in e.link_faces:
                    if h.index not in done:
                        done.add(h.index)
                        stack.append(h)
        inside = set(part)
        if any(sum(1 for h in e.link_faces if h in inside) != 2 for g in part for e in g.edges):
            for g in part:
                flags[g.index] = 1
    bm.free()
    if any(flags):
        attr = o.data.attributes.get(TWO_SIDED) or o.data.attributes.new(TWO_SIDED, "INT", "FACE")
        attr.data.foreach_set("value", flags)


LIGHTMAP_DENSITY = "ps_lightmap_density"


def with_density(o):
    """The brush's lightmap density (the map tools' Lightmap density) on each of its faces: a face's own where some were
    set apart, else the brush's (1: the map's) — so the brushes joined into one object below keep theirs for the bake."""
    me = o.data
    own = float(o.get(LIGHTMAP_DENSITY) or 1.0)
    attr = me.attributes.get(LIGHTMAP_DENSITY)
    if attr is not None and (attr.domain != "FACE" or attr.data_type != "FLOAT"):
        me.attributes.remove(attr)
        attr = None
    values = [0.0] * len(me.polygons)
    if attr is None:
        if own == 1.0:
            return
        attr = me.attributes.new(LIGHTMAP_DENSITY, "FLOAT", "FACE")
    else:
        attr.data.foreach_get("value", values)
    attr.data.foreach_set("value", [v if v > 0.0 else own for v in values])


def both_sides(bm):
    """Each marked face (mark_open_faces) given its back: the same face the other way round (a brush is one-sided in the
    game: a plane was seen from one side only, and went missing from the other)."""
    layer = bm.faces.layers.int.get(TWO_SIDED)
    if layer is None:
        return
    dense = bm.faces.layers.float.get(LIGHTMAP_DENSITY)
    for f in [f for f in bm.faces if f[layer]]:
        verts = [bm.verts.new(v.co) for v in reversed(f.verts)]
        back = bm.faces.new(verts)
        back.material_index = f.material_index
        back[layer] = 0
        if dense is not None:
            back[dense] = f[dense]
    bm.normal_update()


def prepare_brushes(taken):
    """Turns the add-on's brushes into what the rest of the export knows: tool brushes into their entities, seen brushes into
    seen objects (their tool faces, such as nodraw, left out) and collision (the whole brush, unless it is a detail or set
    not to collide). The seen ones are made light: a face lying inside another solid brush is never seen and goes, and the
    brushes are joined into one object per kind and surface. Works on the exported copy only (the file is not saved)."""
    for o in [o for o in taken if o.type == "MESH" and o.get("ps_brush") and o.get("ps_parts")]:
        pieces = split_parts(o, bpy.context.scene.collection)
        if o.get("ps_nocollide") and o.get("ps_stairs"):
            # Stairs walk on their clip ramp, the steps not colliding. One without a ramp (edited by hand, its ramp gone
            # or no longer of the clip material) let players through it: its steps collide then.
            def all_clip(p):
                mats = p.data.materials
                return all(tool_of(mats[f.material_index] if f.material_index < len(mats) else None) == "clip"
                           for f in p.data.polygons)
            if not any(all_clip(p) for p in pieces):
                print(f"{o.name}: stairs without their clip ramp: its steps collide instead (players walked through it)")
                for p in pieces:
                    p.pop("ps_nocollide", None)
        taken = [t for t in taken if t is not o] + pieces
        bpy.data.objects.remove(o, do_unlink=True)
    brushes = [o for o in taken if o.type == "MESH" and o.get("ps_brush")]
    if not brushes:
        return taken
    made, seen = [], []
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    try:
        import sealed
    finally:
        sys.path.pop(0)
    SEAL.clear()
    CLEAR.clear()
    BLOCKERS.clear()
    for o in brushes:
        o.data = o.data.copy()  # linked copies (Alt+D) share a mesh; each gets its own UVs and faces
        tools = {tool_of(o.data.materials[f.material_index]) if f.material_index < len(o.data.materials) else ""
                 for f in o.data.polygons}
        if len(tools) == 1 and next(iter(tools)) in WHOLE_TOOLS:
            o["ps_entity"] = WHOLE_TOOLS[next(iter(tools))]
            if next(iter(tools)) == "clip":
                CLEAR.extend(sealed.convex_pieces(o, convex_pieces))  # a player clip closes the map too (the edge's up to the ceiling)
            continue
        # What closes the map (sealed.py): its walls, Nodraw ones too; not details nor what is seen through (Source's
        # func_detail and glass). Stairs' steps too: not colliding (players walk on their clip ramp), but solid — the
        # air went through them, under the floors and out of the map.
        if (o.get("ps_entity") in (None, "world", "solid")
                and (not o.get("ps_nocollide") or o.get("ps_seals") or o.get("ps_stairs"))
                and not set(face_surfaces(o)) & SEE_THROUGH):
            SEAL.extend(sealed.convex_pieces(o, convex_pieces))
        kind = o.get("ps_entity") if o.get("ps_entity") in ("world", "solid", "detail") else "world"
        o["ps_entity"] = kind
        if o.get("ps_stairs") and o.get("ps_nocollide") and "clip" not in tools:
            # Stairs in one piece with no clip ramp (see above): the steps collide.
            print(f"{o.name}: stairs without their clip ramp: its steps collide instead (players walked through it)")
            o.pop("ps_nocollide", None)
        if kind == "detail":
            # A detail stops nothing, but for what its Collision ticks give it: an unseen block of its shape for players,
            # one for grenades (bullets go through: what stops them is not a detail).
            for key, entity, tail in (("ps_col_players", "collision", " players"), ("ps_col_grenades", "grenadeclip", " grenades")):
                if o.get(key):
                    extra = o.copy()
                    extra.data = o.data.copy()
                    extra.name = o.name + tail
                    extra["ps_entity"] = entity
                    del extra["ps_brush"]
                    bpy.context.scene.collection.objects.link(extra)
                    made.append(extra)
        if kind != "detail":
            # A stair's step (players on the clip ramp) still stops bullets and grenades (smoke too), as in CS: its own
            # block of kind "shots", its surface the step's (they went through the stairs).
            step = bool(o.get("ps_nocollide"))
            col = o.copy()
            col.data = o.data.copy()
            col.name = o.name + (" shots" if step else " collision")
            col["ps_entity"] = "shotclip" if step else "collision"
            nodraw = [m for m in o.data.materials if m is not None and tool_of(m) == "nodraw"]
            if not step and nodraw and all(tool_of(o.data.materials[f.material_index] if f.material_index < len(o.data.materials)
                                                  else None) == "nodraw" for f in o.data.polygons):
                # All of Nodraw: nothing seen to take the surface from (the game finds a wall's by its seen brush), so a
                # block that stops all with its own: a Nodraw of a surface (wood…) sounds of it.
                surf = next((str(m["ps_surface"]) for m in nodraw if m.get("ps_surface")), "")
                if surf:
                    col["ps_entity"] = "solidclip"
                    col["ps_surface"] = surf
            del col["ps_brush"]
            bpy.context.scene.collection.objects.link(col)
            made.append(col)
        seen.append(o)
    # A brush is a closed solid, its faces seen from outside only (as in Source): one-sided in the game, else the inside of
    # a wall shows from within it (glTF writes a material without backface culling as double-sided).
    for o in seen:
        for m in o.data.materials:
            if m is not None:
                m.use_backface_culling = True
    # Faces a player never sees: tool faces (nodraw), and faces (or their parts) covered all over by other solid brushes.
    _, solid_planes = brush_roles(seen)
    # Every solid brush's box now, before any is cut: one whose faces all go (a wall inside another) is still there.
    boxes = {other.name: _box([other.matrix_world @ v.co for v in other.data.vertices], 0.5 * 0.025)
             for other, _ in solid_planes if other.data.vertices}
    for o in seen:
        mark_open_faces(o)
        with_density(o)
        bm, hidden = clip_brush(o, solid_planes, boxes=boxes)
        # Nodraw faces are not seen, but they are walls: the bake's light stops at them (else it shone through the map's
        # edge, a lamp's out onto the roofs).
        mats = o.data.materials
        for f in hidden:
            if tool_of(mats[f.material_index] if f.material_index < len(mats) else None) == "nodraw":
                BLOCKERS.append([v.co.copy() for v in f.verts])
        bmesh.ops.delete(bm, geom=hidden, context="FACES")
        # The pieces left of one face back into one (fewer triangles).
        bmesh.ops.dissolve_limit(bm, angle_limit=0.005, verts=bm.verts[:], edges=bm.edges[:], delimit={"MATERIAL"})
        both_sides(bm)
        bm.transform(o.matrix_world.inverted())
        bm.to_mesh(o.data)
        bm.free()
        world_uvs(o)  # after the cuts: the pieces tile on as before
    # One object per kind and surface: fewer pieces to draw.
    groups = {}
    for o in seen:
        if len(o.data.polygons):
            groups.setdefault((o["ps_entity"], str(o.get("ps_surface", ""))), []).append(o)
    for (kind, surface), objs in groups.items():
        mats, bm = [], bmesh.new()
        for o in objs:
            first = len(bm.faces)
            part = o.data.copy()
            part.transform(o.matrix_world)
            bm.from_mesh(part)
            bm.faces.ensure_lookup_table()
            for f in bm.faces[first:]:
                m = o.data.materials[f.material_index] if f.material_index < len(o.data.materials) else None
                if m not in mats:
                    mats.append(m)
                f.material_index = mats.index(m)
            bpy.data.meshes.remove(part)
        mesh = bpy.data.meshes.new(f"Brushes {kind} {surface}".strip())
        bm.to_mesh(mesh)
        bm.free()
        for m in mats:
            mesh.materials.append(m)
        joined = bpy.data.objects.new(mesh.name, mesh)
        bpy.context.scene.collection.objects.link(joined)
        joined["ps_entity"] = kind
        if surface:
            joined["ps_surface"] = surface
        made.append(joined)
    gone = set(seen)
    kept = [o for o in taken if o not in gone]
    for o in seen:
        bpy.data.objects.remove(o, do_unlink=True)
    return kept + made


def open_everything():
    """What the file holds goes out as it is, however it was left in the views: a collection unticked (excluded), an object
    made unselectable or turned off in the viewports cannot be selected for the .glb (nor joined, nor baked), and would
    be missing from it while still listed. Only this export's copy of the file is changed (it is not saved)."""
    def walk(layer):
        if layer.collection.get("ps_export", 1) in (0, False):
            return  # references, examples (left out of the map): left as they are, often big
        layer.exclude = False
        layer.hide_viewport = False
        layer.collection.hide_viewport = False
        layer.collection.hide_select = False
        for o in layer.collection.objects:
            o.hide_viewport = False
            o.hide_select = False
        for child in layer.children:
            walk(child)
    for child in bpy.context.view_layer.layer_collection.children:
        walk(child)
    for o in bpy.context.scene.collection.objects:
        o.hide_viewport = False
        o.hide_select = False


def cut_brushes(scene):
    """The brushes the add-on's cutters cut (its "PS cut" Boolean modifiers: a tunnel through a slanted wall) as cut: the
    cut put into a mesh of their own, before anything else reads them. Their other modifiers are left out, as ever."""
    cut = [o for o in scene.objects if o.type == "MESH"
           and any(m.type == "BOOLEAN" and m.name.startswith("PS cut") and m.object for m in o.modifiers)]
    if not cut:
        return
    off = []
    for o in cut:
        for m in o.modifiers:
            if not (m.type == "BOOLEAN" and m.name.startswith("PS cut")) and m.show_viewport:
                m.show_viewport = False
                off.append(m)
    depsgraph = bpy.context.evaluated_depsgraph_get()
    for o in cut:
        mesh = bpy.data.meshes.new_from_object(o.evaluated_get(depsgraph), preserve_all_data_layers=True,
                                               depsgraph=depsgraph)
        mesh.name = o.data.name + " cut"
        print(f"{o.name}: cut ({len(o.data.polygons)} faces, {len(mesh.polygons)} cut)")
        for m in [m for m in o.modifiers if m.type == "BOOLEAN" and m.name.startswith("PS cut")]:
            o.modifiers.remove(m)
        o.data = mesh
    for m in off:
        m.show_viewport = True


def left_out():
    """Objects of collections marked ps_export = 0 (and of the collections inside them): references, examples, helpers."""
    out = set()

    def walk(col, skipped):
        skipped = skipped or col.get("ps_export", 1) in (0, False)
        if skipped:
            out.update(col.objects)
        for child in col.children:
            walk(child, skipped)
    walk(bpy.context.scene.collection, False)
    return out


def radar(manifest, seen, folder, scene, tris=None):
    """The radar pictures (radar_gen.py, Docs/radar-generator.md), when the map tools' Radar is on: the floor players can
    get to, walked from the spawns. A map it cannot be made for still exports, without a radar."""
    if not getattr(scene, "ps_radar", True):
        print("Radar: off in the map tools")
        return
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    try:
        import radar_gen
        settings = {
            "resolution": int(getattr(scene, "ps_radar_resolution", "1024") or 1024),
            "cover": float(getattr(scene, "ps_radar_cover", 3.0)),
            "ao": bool(getattr(scene, "ps_radar_ao", True)),
            "ao_strength": float(getattr(scene, "ps_radar_ao_strength", 0.45)),
            "shadow": bool(getattr(scene, "ps_radar_shadow", True)),
            "tints": bool(getattr(scene, "ps_radar_tints", True)),
            "debug": bool(os.environ.get("PS_RADAR_DEBUG")),
            "images": {i: bpy.path.abspath(path) for i in range(4)
                       for path in [str(getattr(scene, f"ps_radar_image_{i}", "") or "")] if path},
        }
        block = radar_gen.generate(manifest, radar_gen.seen_triangles(seen) if tris is None else tris, folder, settings)
        if block:
            manifest["radar"] = block
    except Exception as e:  # the map is still worth playing without it
        import traceback
        traceback.print_exc()
        print(f"Radar: not made: {e}")
    finally:
        sys.path.pop(0)


def map_ceiling(scene, brushes):
    """The map's ceiling (metres): its own (the map tools' Map ceiling, units), else 128 units over its highest brush."""
    own = float(getattr(scene, "ps_map_ceiling", 0) or 0)
    if own > 0:
        return own * UNIT
    tops = [max((o.matrix_world @ v.co).z for v in o.data.vertices) for o in brushes
            if o.type == "MESH" and o.data.vertices and not o.get("ps_edge_clip")]
    return (max(tops) if tops else 0.0) + 128 * UNIT


def sealed_air(scene, taken):
    """The air reached from the spawns (sealed.py), or None (no spawns, nothing closing). A leak is told, the air still
    returned (its `leak` set): the faces are then not left out by it."""
    import sealed
    spawns = [o.matrix_world.translation + Vector((0, 0, 32 * UNIT)) for o in taken if o.get("ps_entity") == "spawn"]
    ceiling = map_ceiling(scene, [o for o in taken if o.get("ps_entity") in ("world", "solid", "detail")])
    air = sealed.flood(SEAL, [tuple(p) for p in spawns], ceiling, CLEAR)
    if air is None:
        print("Sealed: no spawns or no walls, the air not flooded")
    elif air.leak is not None:
        p = air.centre(air.leak)
        print(f"Sealed: LEAK, the air from the spawns gets out of the map near ({p.x:.1f}, {p.y:.1f}, {p.z:.1f}) m "
              "(Check map shows the way): the outside is kept")
    else:
        print(f"Sealed: closed ({int(air.reached.sum())} cells of air, {air.cell / UNIT:.0f} units each)")
    return air


def models_or_doors(taken):
    """The meshes of the export still there (a bake splits and removes some of the seen ones)."""
    out = []
    for o in taken:
        try:
            if o.type == "MESH":
                out.append(o)
        except ReferenceError:
            pass
    return out


def prepare_models(taken):
    """The models (ps_entity "model"): what their particles and instances scatter (a plant's leaves) made real objects,
    models too; their modifiers the glTF export applies. Returns them all."""
    def alive(o):
        try:
            return bool(o.name)
        except ReferenceError:  # split by the bake (big objects go into its atlases in halves): gone
            return False
    # Not an original a card stands for (Leaves as pictures: kept, hidden, left out).
    models = [o for o in taken if alive(o) and o.type == "MESH" and o.get("ps_entity") == "model"
              and not o.get("ps_card_hidden")]
    made = []
    for o in models:
        if not o.particle_systems and o.instance_type == "NONE":
            continue
        bpy.ops.object.select_all(action="DESELECT")
        o.hide_set(False)
        o.select_set(True)
        bpy.context.view_layer.objects.active = o
        before = set(bpy.context.scene.objects)
        try:
            bpy.ops.object.duplicates_make_real(use_base_parent=False, use_hierarchy=False)
        except RuntimeError as e:
            print(f"{o.name}: its particles not made real ({e})")
            continue
        # Each a copy of its mesh (the .glb keeps the mesh once: joined, 2 356 leaves made it 365 MB).
        for i, extra in enumerate(x for x in bpy.context.scene.objects if x not in before and x.type == "MESH"):
            extra.name = f"{o.name} part {i}"
            extra["ps_entity"] = "model"
            made.append(extra)
        for p in list(o.modifiers):
            if p.type == "PARTICLE_SYSTEM":
                p.show_render = p.show_viewport = False  # (the export would apply them again)
    models += made
    if models:
        print(f"Models: {len(models)} ({len(made)} made from particles and instances)")
    return models


CARD_FLAT = 0.05      # thinner than this share of its size: a flat model (a leaf), drawn as a card
CARD_FACES = 16       # fewer faces than this: not worth a card


def flat_axis(mesh):
    """The axis (0..2) a mesh is flat along (a leaf), its box (lo, hi); None when it is not flat or is light already."""
    if len(mesh.polygons) < CARD_FACES or not mesh.vertices:
        return None
    co = [v.co for v in mesh.vertices]
    lo = Vector([min(c[k] for c in co) for k in range(3)])
    hi = Vector([max(c[k] for c in co) for k in range(3)])
    ext = hi - lo
    k = min(range(3), key=lambda i: ext[i])
    if max(ext) <= 0 or ext[k] > CARD_FLAT * max(ext):
        return None
    return k, lo, hi


def card_picture(mesh, k, lo, hi, size, path):
    """The flat mesh seen from above (along its flat axis), unlit, its outside transparent: a picture `size` square at
    `path` (one there already is used as it is: made once), and the square it covers (its middle, its side, its two
    axes) in the mesh's own space."""
    a, b = (k + 1) % 3, (k + 2) % 3
    centre = (lo + hi) / 2
    side = max(hi[a] - lo[a], hi[b] - lo[b]) * 1.02
    if not os.path.exists(path):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        scene = bpy.data.scenes.new("PS card")
        obj = cam = None
        try:
            obj = bpy.data.objects.new("PS card", mesh)
            scene.collection.objects.link(obj)
            cam = bpy.data.objects.new("PS card camera", bpy.data.cameras.new("PS card camera"))
            scene.collection.objects.link(cam)
            cam.data.type = "ORTHO"
            cam.data.ortho_scale = side
            axes = [Vector((1, 0, 0)), Vector((0, 1, 0)), Vector((0, 0, 1))]
            basis = Matrix((axes[a], axes[b], axes[k])).transposed()  # its x across, y up, looking down -k
            cam.matrix_world = Matrix.Translation(centre + axes[k] * (hi[k] - lo[k] + 1.0)) @ basis.to_4x4()
            cam.data.clip_end = (hi[k] - lo[k]) + 2.0
            scene.camera = cam
            scene.render.engine = "BLENDER_WORKBENCH"
            scene.display.shading.light = "FLAT"
            scene.display.shading.color_type = "TEXTURE"
            scene.render.film_transparent = True
            scene.view_settings.view_transform = "Standard"
            scene.render.resolution_x = scene.render.resolution_y = size
            scene.render.resolution_percentage = 100
            scene.render.image_settings.file_format = "PNG"
            scene.render.image_settings.color_mode = "RGBA"
            scene.render.filepath = path
            bpy.ops.render.render(write_still=True, scene=scene.name)
            # Its outside the leaf's own colour (still transparent): rendered black there, the game's smaller copies of
            # the picture (mips) and its filtering drew a dark rim round each leaf.
            import numpy as np
            shot = bpy.data.images.load(path, check_existing=False)
            px = np.empty(len(shot.pixels), dtype=np.float32)
            shot.pixels.foreach_get(px)
            px = px.reshape(-1, 4)
            solid = px[:, 3] > 0.5
            if solid.any():
                px[~solid, :3] = px[solid, :3].mean(axis=0)
                shot.pixels.foreach_set(px.ravel())
                shot.filepath_raw = path
                shot.file_format = "PNG"
                shot.save()
            bpy.data.images.remove(shot)
        finally:
            for x in (obj, cam):
                if x is not None:
                    data = x.data if x is cam else None
                    bpy.data.objects.remove(x, do_unlink=True)
                    if data is not None:
                        bpy.data.cameras.remove(data)
            bpy.data.scenes.remove(scene)
    image = bpy.data.images.load(path, check_existing=True)
    return image, centre, side, a, b


def card_mesh(mesh, size, path):
    """A card for a flat mesh (a leaf: a modelled heart of 948 faces): a square of two triangles with its picture seen
    from above, its outside transparent, seen from both sides — the same look, a few hundredth of the triangles. None
    when the mesh is not flat (or is light already)."""
    found = flat_axis(mesh)
    if found is None:
        return None
    k, lo, hi = found
    image, centre, side, a, b = card_picture(mesh, k, lo, hi, size, path)
    h = side / 2
    corners = []
    for u, v in ((0, 0), (1, 0), (1, 1), (0, 1)):
        p = centre.copy()
        p[a] += (u * 2 - 1) * h
        p[b] += (v * 2 - 1) * h
        corners.append(p)
    card = bpy.data.meshes.new(f"{mesh.name} card")
    card.from_pydata(corners, [], [(0, 1, 2, 3)])
    uv = card.uv_layers.new(name="UVMap")
    for loop, (u, v) in zip(card.loops, ((0, 0), (1, 0), (1, 1), (0, 1))):
        uv.data[loop.index].uv = (u, v)
    mat = bpy.data.materials.new(f"{mesh.name} card")
    mat.use_nodes = True
    tree = mat.node_tree
    bsdf = next(n for n in tree.nodes if n.type == "BSDF_PRINCIPLED")
    tex = tree.nodes.new("ShaderNodeTexImage")
    tex.image = image
    tree.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    tree.links.new(tex.outputs["Alpha"], bsdf.inputs["Alpha"])
    mat.use_backface_culling = False  # seen from both sides, as the leaf was
    if hasattr(mat, "surface_render_method"):
        mat.surface_render_method = "DITHERED"  # the views show its outside see-through
    card.materials.append(mat)
    return card


def texture_uvs_first(objects):
    """Each object's UVs its textures are drawn with (the UV map Blender renders with) first, the lightmap's after it, the
    rest gone: the game reads its textures through the first (a brush whose material used another UV map, "automap",
    was textured by the wrong one)."""
    for o in objects:
        me = o.data
        layers = list(me.uv_layers)
        if len(layers) < 2:
            continue
        render = next((u for u in layers if u.active_render and u.name != "Lightmap"), None) \
            or next((u for u in layers if u.name != "Lightmap"), None)
        if me.users > 1:
            o.data = me = me.copy()
        for u in [u for u in list(me.uv_layers) if u.name not in (render.name, "Lightmap")]:
            me.uv_layers.remove(u)


def base_colour_of(material):
    """What a material's colour comes from: (its image node or None, its colour, its alpha linked to that image)."""
    tree = material.node_tree if material.use_nodes else None
    colour = tuple(material.diffuse_color)
    if tree is None:
        return None, colour, False
    bsdf = next((n for n in tree.nodes if n.type == "BSDF_PRINCIPLED"), None)
    if bsdf is None:
        image = next((n for n in tree.nodes if n.type == "TEX_IMAGE" and n.image), None)
        return image, colour, False
    socket = bsdf.inputs["Base Color"]
    colour = tuple(socket.default_value)

    def image_behind(s, depth=0):
        # Through what lies between (a mix, a hue, a colour ramp): the first image found.
        if not s.is_linked or depth > 6:
            return None
        node = s.links[0].from_node
        if node.type == "TEX_IMAGE":
            return node if node.image else None
        for i in node.inputs:
            found = image_behind(i, depth + 1)
            if found is not None:
                return found
        return None
    image = image_behind(socket)
    alpha = bsdf.inputs["Alpha"]
    cutout = alpha.is_linked and image is not None and alpha.links[0].from_node == image
    return image, colour, cutout


def simple_materials(objects, size, styles=None):
    """Each material as the game draws it: its colour (a picture, at most `size` across, or a colour), and how its
    picture lies (a Mapping node: its scale and offset, kept for the game). The normal, roughness, height pictures and the
    rest go: the game does not draw them, and they made the map's file many times bigger (55 pictures, 120 MB).
    A material with a second look (its ps_basecolor_stylized: the picture's path, the same UVs) puts it in `styles`
    {the game's material name: path}, for style_pictures."""
    done, shrunk = {}, 0
    for o in objects:
        for slot in o.material_slots:
            m = slot.material
            if m is None:
                continue
            if m.name in done:
                slot.material = done[m.name]
                continue
            image_node, colour, cutout = base_colour_of(m)
            new = bpy.data.materials.new(m.name)
            new.use_nodes = True
            for key in ("ps_surface", "ps_tool"):
                if key in m:
                    new[key] = m[key]
            if styles is not None and m.get("ps_basecolor_stylized"):
                styles[new.name] = bpy.path.abspath(str(m["ps_basecolor_stylized"]))
            new.use_backface_culling = m.use_backface_culling
            tree = new.node_tree
            tree.nodes.clear()
            out = tree.nodes.new("ShaderNodeOutputMaterial")
            bsdf = tree.nodes.new("ShaderNodeBsdfPrincipled")
            tree.links.new(bsdf.outputs[0], out.inputs["Surface"])
            bsdf.inputs["Base Color"].default_value = colour
            bsdf.inputs["Roughness"].default_value = 0.9
            # Its own light (a lamp's glass): the emission's colour and strength go too (the game draws it glowing).
            old = next((n for n in m.node_tree.nodes if n.type == "BSDF_PRINCIPLED"), None) \
                if m.use_nodes and m.node_tree else None
            if old is not None and old.inputs["Emission Strength"].default_value > 0 \
                    and max(tuple(old.inputs["Emission Color"].default_value)[:3]) > 0:
                bsdf.inputs["Emission Color"].default_value = old.inputs["Emission Color"].default_value
                bsdf.inputs["Emission Strength"].default_value = old.inputs["Emission Strength"].default_value
            if image_node is not None and image_node.image is not None:
                image = image_node.image
                if image.size[0] == 0:
                    try:
                        image.reload()
                    except RuntimeError:
                        pass
                w, h = image.size
                if w and h and max(w, h) > size:
                    k = size / max(w, h)
                    image = image.copy()
                    image.scale(max(1, int(w * k)), max(1, int(h * k)))
                    image.file_format = "PNG" if cutout else "JPEG"
                    shrunk += 1
                tex = tree.nodes.new("ShaderNodeTexImage")
                tex.image = image
                tex.interpolation = image_node.interpolation
                tex.extension = image_node.extension
                tree.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
                if cutout:
                    # A leaf's picture: its alpha rounded (the glTF export's sign of a cut-out, alphaMode MASK).
                    cut = tree.nodes.new("ShaderNodeMath")
                    cut.operation = "ROUND"
                    tree.links.new(tex.outputs["Alpha"], cut.inputs[0])
                    tree.links.new(cut.outputs[0], bsdf.inputs["Alpha"])
                # How the picture lies: the Mapping node before it (UV coordinates), as glTF's texture transform.
                vector = image_node.inputs["Vector"]
                mapping = vector.links[0].from_node if vector.is_linked else None
                if mapping is not None and mapping.type == "MAPPING":
                    copy = tree.nodes.new("ShaderNodeMapping")
                    copy.vector_type = mapping.vector_type
                    for name in ("Location", "Rotation", "Scale"):
                        if name in mapping.inputs and name in copy.inputs:
                            copy.inputs[name].default_value = mapping.inputs[name].default_value
                    coords = tree.nodes.new("ShaderNodeTexCoord")
                    tree.links.new(coords.outputs["UV"], copy.inputs["Vector"])
                    tree.links.new(copy.outputs["Vector"], tex.inputs["Vector"])
            done[m.name] = new
            done[new.name] = new  # a mesh shared by objects: the next of them already has it
            slot.material = new
    if done:
        print(f"Materials: {len({id(v) for v in done.values()})} as the game draws them (colour only), {shrunk} picture(s) "
              f"shrunk to {size}")


def style_pictures(styles, folder, size):
    """The second look's pictures (cartoon: style_stylized_<n>.jpg, at most `size` across) beside the .glb; the manifest's
    "styles" list [{look, material, picture}]: the game swaps each material's picture for its own when a player asks for
    that look (Graphics → Experimental). A picture missing is left out (that material keeps one look)."""
    out = {}
    for i, (name, path) in enumerate(sorted(styles.items())):
        if not os.path.isfile(path):
            print(f"Styles: no picture {path} for {name}, left out")
            continue
        image = bpy.data.images.load(path, check_existing=False)
        w, h = image.size
        if w and h and max(w, h) > size:
            k = size / max(w, h)
            image.scale(max(1, int(w * k)), max(1, int(h * k)))
        file = f"style_stylized_{i}.jpg"
        image.filepath_raw = os.path.join(folder, file)
        image.file_format = "JPEG"
        image.save()
        bpy.data.images.remove(image)
        out[name] = file
    for f in os.listdir(folder):
        if f.startswith("style_stylized_") and f not in out.values():
            os.remove(os.path.join(folder, f))
    if out:
        print(f"Styles: {len(out)} material(s) with a cartoon look")
    return [{"look": "stylized", "material": m, "picture": f} for m, f in sorted(out.items())] or None


def sky_picture(scene, folder):
    """The map's sky (the Light panel's Sky, an Image — packed in the file or not —, else the scene's ps_sky path: a 360°
    picture, equirectangular, its middle the map's north, +Y) beside the .glb as sky.jpg, at most 4096 across, and in a
    cube (sky_cube); its file's name for the manifest, or None (the game's plain sky colour)."""
    out = os.path.join(folder, "sky.jpg")
    source = getattr(scene, "ps_sky_image", None) or scene.get("ps_sky_image")
    if not isinstance(source, bpy.types.Image) or source.size[0] == 0:
        path = bpy.path.abspath(str(scene.get("ps_sky") or ""))
        source = bpy.data.images.load(path, check_existing=True) if path and os.path.isfile(path) else None
    if source is None:
        for file in ("sky.jpg", "sky_cube.jpg", "sky_small.jpg"):
            if os.path.exists(os.path.join(folder, file)):
                os.remove(os.path.join(folder, file))
        return None
    # A copy of its pixels (the picture itself, maybe packed or the file it came from, stays as it is).
    w, h = source.size
    image = bpy.data.images.new("PS sky out", w, h, alpha=False, float_buffer=source.is_float)
    image.pixels[:] = source.pixels[:] if source.channels == 4 else \
        [c for i in range(w * h) for c in (*source.pixels[i * source.channels:i * source.channels + 3], 1.0)]
    if w > 4096:
        image.scale(4096, max(1, h * 4096 // w))
    image.filepath_raw = out
    image.file_format = "JPEG"
    image.save()
    w, h = image.size
    px = np.empty(w * h * 4, dtype=np.float32)
    image.pixels.foreach_get(px)
    bpy.data.images.remove(image)
    sky_cube(px.reshape(h, w, 4)[..., :3], folder)
    print(f"Sky: {source.name}")
    return "sky.jpg"


SKY_TURN = 90.0  # the game's panorama turn (MapSky.NorthTurn: Skybox/Panoramic's _Rotation)


def sky_cube(pano, folder):
    """The sky as the game shows it, already in a cube (sky_cube.jpg: six faces side by side, +X −X +Y −Y +Z −Z, as the
    game's own cube made from the panorama has them, each a quarter of the panorama wide, 256…1024) and small
    (sky_small.jpg, 512 across: what the first person's metal reflects). The game takes them as they are: no panorama
    drawn into a cube at load, nor kept. `pano`: (h, w, 3), rows bottom first (Blender's)."""
    h, w = pano.shape[:2]
    face = int(min(1024, max(256, 2 ** math.ceil(math.log2(max(w // 4, 1))))))

    def sample(u, v):  # bilinear, u round (wraps), v up (clamped)
        x, y = u * w - 0.5, v * h - 0.5
        x0, y0 = np.floor(x).astype(np.int64), np.floor(y).astype(np.int64)
        fx, fy = (x - x0)[..., None], (y - y0)[..., None]

        def at(yy, xx):
            return pano[np.clip(yy, 0, h - 1), xx % w]
        return (at(y0, x0) * (1 - fx) * (1 - fy) + at(y0, x0 + 1) * fx * (1 - fy) +
                at(y0 + 1, x0) * (1 - fx) * fy + at(y0 + 1, x0 + 1) * fx * fy)

    s = (np.arange(face, dtype=np.float32) + 0.5) / face * 2.0 - 1.0
    sx, ty = np.meshgrid(s, s)  # across, down
    one = np.ones_like(sx)
    # Each face's directions (the cube map's own: +X −X +Y −Y +Z −Z), its first row first.
    dirs = [(one, -ty, -sx), (-one, -ty, sx), (sx, one, ty), (sx, -one, -ty), (sx, -ty, one), (-sx, -ty, -one)]
    a = math.radians(-SKY_TURN)
    c, sn = math.cos(a), math.sin(a)
    faces = []
    for x, y, z in dirs:
        # Turned back as Skybox/Panoramic turns its sphere, then its picture's longitude and latitude.
        vx, vz = c * x - sn * z, sn * x + c * z
        n = np.sqrt(vx * vx + y * y + vz * vz)
        lon, lat = np.arctan2(vz / n, vx / n), np.arccos(np.clip(y / n, -1.0, 1.0))
        faces.append(sample(0.5 - lon / (2.0 * math.pi), 1.0 - lat / math.pi))
    # Blender's rows bottom first: a face's first row at the bottom of the file (the game copies it as it lies).
    save_jpeg(np.concatenate(faces, axis=1), os.path.join(folder, "sky_cube.jpg"))
    small = 512
    if w > small:
        k = w // small
        pano = pano[: h - h % k, : small * k].reshape(h // k, k, small, k, 3).mean(axis=(1, 3))
    save_jpeg(pano, os.path.join(folder, "sky_small.jpg"))


def save_jpeg(rgb, path):
    """A picture (h, w, 3, rows bottom first, as Blender's pixels) to a JPEG."""
    h, w = rgb.shape[:2]
    image = bpy.data.images.new("PS sky part", w, h, alpha=False)
    image.pixels.foreach_set(np.concatenate([rgb, np.ones((h, w, 1), np.float32)], axis=2).astype(np.float32).ravel())
    image.filepath_raw = path
    image.file_format = "JPEG"
    image.save()
    bpy.data.images.remove(image)


def baked_light(manifest, seen, folder, mode, tris=None):
    """With a bake mode (fast / final): the light baked into lightmaps and probes, the manifest's "baked" block; the seen
    objects as they now are (split to fit their atlases). Without one, the last bake's pictures go (they would not fit
    this export's surfaces): the map shows its test light."""
    if not mode:
        for kind in ("lightmap", "sun"):
            i = 0
            while os.path.exists(os.path.join(folder, f"{kind}_{i}.png")):
                os.remove(os.path.join(folder, f"{kind}_{i}.png"))
                i += 1
        return seen
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    try:
        import bake_light
        import radar_gen
        block, seen = bake_light.bake(seen, manifest, radar_gen.seen_triangles(seen) if tris is None else tris, folder, mode,
                                      blockers=BLOCKERS)
        manifest["baked"] = block
        manifest["light"] = "baked"  # whoever plays it sees the baked light (not the test light chosen)
    finally:
        sys.path.pop(0)
    return seen


def map_name(scene):
    """The map's name in the game (map.json "name": the Workshop's card, servers, players, the .psmap's file): the one
    written in the Workshop card, else the .blend's own; whatever cannot be in a file name taken out."""
    name = str(getattr(scene, "ps_map_name", "") or "").strip()
    name = "".join(ch for ch in name if ch not in r'\/:*?"<>|' and ord(ch) >= 32).strip()
    return name or os.path.splitext(os.path.basename(bpy.data.filepath))[0] or "map"


def real_prefabs(scene):
    """Prefab copies (the map tools' Art tab: a group placed as linked copies, empties instancing its collection) made
    real objects where they stand, each mesh its own, before anything is taken."""
    copies = [o for o in scene.objects if o.get("ps_prefab") and o.instance_type == "COLLECTION" and o.instance_collection]
    for e in copies:
        bpy.ops.object.select_all(action="DESELECT")
        e.hide_set(False)
        e.select_set(True)
        bpy.context.view_layer.objects.active = e
        before = set(scene.objects)
        bpy.ops.object.duplicates_make_real(use_base_parent=False, use_hierarchy=True)
        for o in scene.objects:
            if o not in before:
                if o.type == "MESH" and o.data.users > 1:
                    o.data = o.data.copy()
                for k in ("ps_mirror_pair", "ps_mirror_role", "ps_mirror_linked", "ps_mirror_name"):
                    if k in o:
                        del o[k]
        bpy.data.objects.remove(e, do_unlink=True)
    if copies:
        print(f"Prefabs: {len(copies)} copies made real")


def main(folder, bake=None):
    os.makedirs(folder, exist_ok=True)
    scene = bpy.context.scene
    name = map_name(scene)
    # A file saved in Edit Mode: its edits are in the meshes once out of it.
    if bpy.context.object is not None and bpy.context.object.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")
    open_everything()
    real_prefabs(scene)
    skipped = left_out()
    cut_brushes(scene)
    skipped |= {o for o in scene.objects if o.get("ps_entity") == "cutter"}
    # The collision boxes of an original a card stands for (Leaves as pictures): a leaf collides with nothing.
    skipped |= {o for o in scene.objects if o.get("ps_model_box") and o.parent is not None and o.parent.get("ps_card_hidden")}
    taken = prepare_brushes([o for o in scene.objects if o not in skipped])
    # Surfaces from the materials, face by face (Hammer's $surfaceprop): the seen objects as one object per surface.
    split = []
    for o in taken:
        if o.type == "MESH" and o.get("ps_entity") in ("world", "solid", "detail") and o.display_type != "WIRE":
            split.extend(split_by_surface(o, scene.collection))
        else:
            split.append(o)
    taken = split
    seen = [o for o in taken if o.type == "MESH" and o.get("ps_entity") in SEEN and o.display_type != "WIRE"]
    entities, collision = [], []
    # A breakable's (or any entity's) own collision goes with it: the object it shares its "ps_owner" (or CS model) with.
    owners = {}
    for o in taken:
        if o.get("ps_entity") is not None and o.get("ps_entity") not in CLIPS:
            key = o.get("ps_owner") or o.get("cs_model")
            if key:
                owners[key] = o.name
    for obj in taken:
        kind = obj.get("ps_entity")
        if not kind or kind in ("world", "solid", "detail", "model"):
            continue
        if kind in CLIPS:
            # Each block: "p" its corners (x, y, z, ...), "t" its triangles (counter-clockwise from outside, in Blender's
            # winding; glTF space keeps it, as its turn of axes is not a mirror).
            if obj.get("ps_concave"):
                # Not convex (terrain, models' own shapes): the whole mesh is one block, its triangles as they are.
                points, tris = whole_mesh(obj)
                blocks = [{"p": [c for p in points for c in gltf(p)], "t": tris, "c": True}] if tris else []
            else:
                # A part that is not convex (an L, a U, one turned inside out) is cut into convex pieces that fill it
                # (convex_pieces); only when that cannot be done does it go as it is (a shell: one-sided to players).
                blocks = []
                for points, tris, closed in convex_meshes(obj):
                    if not closed:
                        # A sheet or a mesh with holes (a roof made of a plane): a shell, its triangles both ways round
                        # (the game's physics meets a triangle from its front only: players went through from behind).
                        back = [tris[i + k] for i in range(0, len(tris), 3) for k in (0, 2, 1)]
                        blocks.append({"p": [c for p in points for c in gltf(p)], "t": tris + back, "c": True})
                        print(f"{obj.name}: not closed (a plane, or holes in it): seen and colliding from both sides, "
                              "thin; Make solid in the map tools gives it a thickness")
                        continue
                    if is_convex(points, tris):
                        blocks.append({"p": [c for p in points for c in gltf(p)], "t": tris})
                        continue
                    pieces = convex_pieces(points, tris)
                    if pieces:
                        blocks += [{"p": [c for p in pts for c in gltf(p)], "t": t} for pts, t in pieces]
                        print(f"{obj.name}: not convex, cut into {len(pieces)} convex piece(s) for collision")
                    else:
                        blocks.append({"p": [c for p in points for c in gltf(p)], "t": tris, "c": True})
                        print(f"{obj.name}: not convex and could not be cut into convex pieces: collides as a shell")
            entry = {"name": obj.name, "blocks": blocks}
            if kind not in ("collision", "invisibleclip"):
                entry["kind"] = CLIPS[kind]
            if kind == "invisibleclip":
                collision.append({"name": obj.name + " grenades", "kind": "grenade", "blocks": blocks})
            if kind in ("solidclip", "shotclip") and obj.get("ps_surface"):
                entry["surface"] = str(obj["ps_surface"])  # what bullets meet (a wooden box: wood)
            owner = owners.get(obj.get("ps_owner") or obj.get("cs_model"))
            if owner:
                entry["entity"] = owner
            collision.append(entry)
            continue
        entities.append(entity_of(obj))

    glb = os.path.join(folder, name + ".glb")
    # A .glb of another name is the map's before it was renamed (the Workshop card's Name): not part of it any more.
    for file in os.listdir(folder):
        if file.lower().endswith(".glb") and file != os.path.basename(glb):
            os.remove(os.path.join(folder, file))
    manifest = {
        "format": FORMAT,
        "generator": GENERATOR,
        "name": name,
        "space": "gltf",
        "unitMetres": float(scene.get("cs_unit_metres", 0.025)),
        "visual": os.path.basename(glb),
        "nodes": [],
        "entities": entities,
        "collision": collision,
    }
    # The Workshop's card: who made it, what it is, its version (the map tools' fields), and its picture.
    for key in ("author", "description", "version"):
        # The add-on's own properties (Blender 5 keeps them apart from the scene's custom properties).
        value = str(getattr(scene, "ps_" + key, "") or scene.get("ps_" + key, "") or "").strip()
        if value:
            manifest[key] = value
    # How the map is lit while its light is not baked (the test light chosen in the map tools): everyone who plays this
    # package, players who download it from the server too, sees it the same way.
    light = str(getattr(scene, "ps_test_light", "") or "").strip().lower()
    if light in ("faces", "flat", "sun"):
        manifest["light"] = light
    # The mode chosen in the map tools: a game that has the map (a phone's Workshop) plays it so when it can.
    mode = str(getattr(scene, "ps_ruleset", "") or "").strip()
    if mode:
        manifest["mode"] = mode
    preview = os.path.splitext(bpy.data.filepath)[0] + "_preview.png"
    if os.path.exists(preview):
        shutil.copyfile(preview, os.path.join(folder, PREVIEW))
    elif os.path.exists(os.path.join(folder, PREVIEW)):
        os.remove(os.path.join(folder, PREVIEW))
    source = scene.get("cs_source")
    if source:
        manifest["source"] = source
        bsp = os.path.join(os.path.dirname(bpy.data.filepath), source)
        if os.path.exists(bsp):
            models = write_hull(bsp, os.path.join(folder, "hull.bin"))
            manifest["hull"] = "hull.bin"
            print(f"Hull: {models} models from {source}")
    # The light baked (bake_light.py): the seen objects get their lightmap UVs before they go into the .glb.
    # What the radar and the probes walk on: the map whole (before the faces nobody sees go: a roof's top, say).
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    try:
        import radar_gen
        import visibility
        whole = radar_gen.seen_triangles(seen)
        if getattr(scene, "ps_cull_unseen", True):
            try:
                air = sealed_air(scene, taken)
                visibility.leave_out_unseen(seen, manifest, whole, folder, KEEP, SEE_THROUGH, air=air,
                                            blockers=BLOCKERS)
            except Exception as e:  # noqa: BLE001  (the map is still right with them)
                import traceback
                traceback.print_exc()
                print(f"Unseen faces: kept ({e})")
    finally:
        sys.path.pop(0)
    seen = baked_light(manifest, seen, folder, bake, whole)

    # The models (the map tools' Make model: plants, pots, a staircase made elsewhere): as they are, their own UVs and
    # materials, lit by the probes as players are (not baked), colliding through their boxes only.
    models = prepare_models(taken)
    # The doors (Make door): each a node of its own, moved by the game (lit by the probes, as the models).
    doors = [o for o in models_or_doors(taken) if o.get("ps_entity") == "door"]
    # Training's movers (Make mover): each a node of its own too, moved by the game.
    movers = [o for o in models_or_doors(taken) if o.get("ps_entity") == "mover"]
    shown = seen + models + doors + movers
    texture_uvs_first(shown)
    size = int(getattr(scene, "ps_texture_size", "1024") or 1024)
    styles = {}
    simple_materials(shown, size, styles)

    # What is seen: one .glb, each object a node of its name.
    bpy.ops.object.select_all(action="DESELECT")
    for o in shown:
        o.hide_set(False)
        o.select_set(True)
    bpy.ops.export_scene.gltf(filepath=glb, export_format="GLB", use_selection=True, export_apply=True,
                              export_yup=True, export_extras=True, export_cameras=False, export_lights=False,
                              export_animations=False)
    manifest["nodes"] = [dict({"name": o.name, "type": o.get("ps_entity")},
                              **({"surface": str(o["ps_surface"])} if o.get("ps_surface") else {})) for o in seen]
    manifest["nodes"] += [{"name": o.name, "type": "model"} for o in models]
    manifest["nodes"] += [{"name": o.name, "type": "door"} for o in doors]
    manifest["nodes"] += [{"name": o.name, "type": "mover"} for o in movers]
    radar(manifest, seen, folder, scene, whole)
    looks = style_pictures(styles, folder, size)
    if looks:
        manifest["styles"] = looks
    sky = sky_picture(scene, folder)
    if sky:
        manifest["sky"] = sky
        # The same sky in a cube and small (sky_cube): a game that knows them takes them instead of the panorama.
        manifest["skyCube"], manifest["skySmall"] = "sky_cube.jpg", "sky_small.jpg"
        # Where the picture's north is (degrees round, the map tools' Sky turn): the game turns its sky as much.
        turn = float(getattr(scene, "ps_sky_rotation", None) or scene.get("ps_sky_rotation") or 0.0)
        if turn:
            manifest["skyRotation"] = round(turn, 2)
    with open(os.path.join(folder, "map.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, separators=(",", ":"))
    counts = {}
    for e in entities:
        counts[e["type"]] = counts.get(e["type"], 0) + 1
    blocks = sum(len(c["blocks"]) for c in collision)
    print(f"Exported {name}: {len(seen)} seen objects, {blocks} collision blocks, entities {counts}")


if __name__ == "__main__":
    args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    if not args:
        raise SystemExit("usage: blender -b <map.blend> --python export_map.py -- <package folder> [--bake fast|final|release]")
    mode = args[args.index("--bake") + 1] if "--bake" in args and args.index("--bake") + 1 < len(args) else None
    main(args[0], mode)
