"""Brushes that keep how they were made: stairs, an arch, a wall with its doors and windows, a room, a cylinder. Each is
one object (its convex pieces apart in one mesh, as the stairs always were: the export takes each piece as a brush), its
settings on it (Object.ps_maker): changed in the map tools' panel, it is built again where it stands. Moved or turned
(G, R) it keeps them; edited by hand in Edit Mode, or scaled, it becomes a plain brush of what it is then.

Built in the object's own space (its origin, its turn about the vertical), sizes in units."""
import math

import bmesh
import bpy
from mathutils import Matrix, Vector

from . import UNIT, world_uvs, make_brush, child_collection

KINDS = {"stairs": "Stairs", "arch": "Arch", "wall": "Wall", "room": "Room", "cylinder": "Cylinder", "slab": "Floor"}
_building = [False]


# ---------- What each is made of: its pieces, (corners, faces, material slot or None: by the way the face looks) ----------
def stairs_pieces(p):
    from .brush_tools import prism
    r, t = p.rise * UNIT, p.thickness * UNIT
    bm = bmesh.new()
    if p.shape == "straight":
        d, w, n = p.run * UNIT, p.width * UNIT, p.steps
        side = (-w / 2, w / 2)

        def under(x):  # the slab's underside along the flight
            return max(0.0, x * r / d - t) if not p.solid else 0.0
        for i in range(n):
            x0, x1 = i * d, (i + 1) * d
            plan = [(x0, side[0]), (x1, side[0]), (x1, side[1]), (x0, side[1])]
            prism(bm, plan, [under(x0), under(x1), under(x1), under(x0)], [(i + 1) * r] * 4, 0)
        # The ramp players walk on: from the foot of the first step to the top of the last.
        plan = [(0, side[0]), (n * d, side[0]), (n * d, side[1]), (0, side[1])]
        top = [0, n * r, n * r, 0]
        prism(bm, plan, [max(0.0, z - t) if not p.solid else 0.0 for z in top], top, 1)
    else:
        n = max(1, round(p.angle / (2 * math.pi) * p.per_turn))
        da = (2 * math.pi / p.per_turn) * (-1 if p.clockwise else 1)
        ri, ro = p.inner * UNIT, p.outer * UNIT

        def at(radius, a):
            return radius * math.cos(a), radius * math.sin(a)
        for i in range(n):
            a0, a1 = i * da, (i + 1) * da
            plan = [at(ri, a0), at(ro, a0), at(ro, a1), at(ri, a1)]
            if p.clockwise:
                plan.reverse()
            ramp0, ramp1 = i * r, (i + 1) * r
            ends = [ramp0, ramp0, ramp1, ramp1] if not p.clockwise else [ramp1, ramp1, ramp0, ramp0]
            bottom = [0.0] * 4 if p.solid else [max(0.0, z - t) for z in ends]
            prism(bm, plan, bottom, [(i + 1) * r] * 4, 0)
            prism(bm, plan, bottom, ends, 1)
    bm.verts.index_update()
    verts = [v.co.copy() for v in bm.verts]
    faces = [([v.index for v in f.verts], f.material_index) for f in bm.faces]
    bm.free()
    return [(verts, faces)]


DIRECTIONS_UP = {"+X": (0, 1, 0.0), "-X": (0, -1, math.pi), "+Y": (1, 1, math.pi / 2), "-Y": (1, -1, -math.pi / 2)}
ARROWS = {"+X": "TRIA_RIGHT", "-X": "TRIA_LEFT", "+Y": "TRIA_UP", "-Y": "TRIA_DOWN"}  # as seen from the top view


def stairs_fill(lo, hi, direction, rise):
    """A straight flight filling the box lo..hi, climbing toward `direction` (+X, -X, +Y, -Y): as many steps as its height
    takes near the step height `rise` (metres; never over 18 units: a jump), each as deep as the length shared out.
    Returns (steps, step height, step depth, width, where it starts, its turn), metres."""
    along, up, turn = DIRECTIONS_UP[direction]
    height, length, w = hi.z - lo.z, hi[along] - lo[along], hi[1 - along] - lo[1 - along]
    n = max(1, round(height / rise))
    if height / n > 18 * UNIT + 1e-6:
        n = math.ceil(height / (18 * UNIT) - 1e-6)
    origin = Vector((0.0, 0.0, lo.z))
    origin[along] = lo[along] if up > 0 else hi[along]
    origin[1 - along] = (lo[1 - along] + hi[1 - along]) / 2
    return n, height / n, length / n, w, origin, turn


def direction_row(layout, owner, prop):
    """The four arrows (which way the stairs climb), one pressed."""
    row = layout.row(align=True)
    row.label(text="Up toward")
    for key in ("-X", "+Y", "-Y", "+X"):
        row.prop_enum(owner, prop, key, text="", icon=ARROWS[key])


def headroom(p):
    """Units between a turn of a spiral and the one above it (None: it does not come round over itself)."""
    if p.shape != "turning" or p.angle <= 2 * math.pi + 1e-4:
        return None
    return 0 if p.solid else round(p.per_turn * p.rise - p.thickness)


def box_outline(x0, x1, z0, z1):
    from .brush_tools import on_units
    return on_units([(x0, z0), (x1, z0), (x1, z1), (x0, z1)]) if x1 - x0 > 1e-4 and z1 - z0 > 1e-4 else []


def across(outlines, y0, y1):
    """Outlines in the x, z plane made prisms from y0 to y1."""
    from .brush_tools import extruded
    out = []
    for outline in outlines:
        if outline:
            verts, faces = extruded(outline, lambda x, z, y: Vector((x, y, z)), y0, y1)
            out.append((verts, [(f, None) for f in faces]))
    return out


def arch_pieces(p):
    """An arch or a tunnel: across x (the opening's middle at 0), y from 0 to its depth, standing on z = 0."""
    from .brush_tools import arch_fill, arch_curve
    t = p.arch_thickness * UNIT
    w, h = p.opening_width * UNIT, p.opening_height * UNIT
    a0, a1, z0, z1 = -w / 2, w / 2, 0.0, h
    outlines = arch_fill(a0, a1, z0, z1, p.segments, outer=t if p.outside == "round" else None)
    if p.outside == "round":
        spring = arch_curve(a0, a1, z0, z1, p.segments)[1]
        sides = [(a0 - t, a0, z0, spring), (a1, a1 + t, z0, spring)]
    else:
        sides = [(a0 - t, a0, z0, z1 + t), (a1, a1 + t, z0, z1 + t), (a0, a1, z1, z1 + t)]
    return across([box_outline(*s) for s in sides] + outlines, 0.0, p.depth * UNIT)


def wall_outlines(length, height, openings):
    """A wall's outline (along it from 0 to its length, up from 0 to its height) in pieces round its openings, each from
    its offset along the wall; one running into the one before it is left out."""
    from .brush_tools import arch_fill
    outlines, x = [], 0.0
    for o in sorted(openings, key=lambda o: o.offset):
        o0 = max(0.0, o.offset * UNIT)
        o1 = min(length, o0 + o.width * UNIT)
        z0 = max(0.0, o.sill * UNIT)
        z1 = min(height, z0 + o.height * UNIT)
        if o0 < x - 1e-6 or o1 - o0 < UNIT or z1 - z0 < UNIT:
            continue
        outlines.append(box_outline(x, o0, 0.0, height))
        outlines.append(box_outline(o0, o1, 0.0, z0))
        outlines.append(box_outline(o0, o1, z1, height))
        if o.top == "arch":
            outlines += arch_fill(o0, o1, z0, z1, o.segments)
        x = o1
    outlines.append(box_outline(x, length, 0.0, height))
    return [o for o in outlines if o]


def wall_size(p, side):
    """A room's wall: its length and height (units)."""
    sx, sy, sz = p.room_size
    t = p.room_thickness
    return (sy if side < 2 else sx - 2 * t), (sz - (2 * t if p.ceiling else t))


def nearest_wall(obj, point):
    """Which of a room's walls is nearest the point (world), and how far along that wall the point is (units)."""
    p = obj.ps_maker
    local = obj.matrix_world.inverted() @ point
    sx, sy, sz = (v * UNIT for v in p.room_size)
    t = p.room_thickness * UNIT
    def to_wall(x, y, x0, x1, y0, y1):
        # How far the point is from a wall's middle line (seen from above): along it as well as across, so a point past
        # the end of one wall is not taken for on it (the cursor outside the room by the +X wall went to the +Y one).
        dx = max(x0 - x, 0.0, x - x1)
        dy = max(y0 - y, 0.0, y - y1)
        return math.hypot(dx, dy)
    dist = [to_wall(local.x, local.y, t / 2, t / 2, 0.0, sy), to_wall(local.x, local.y, sx - t / 2, sx - t / 2, 0.0, sy),
            to_wall(local.x, local.y, t, sx - t, t / 2, t / 2), to_wall(local.x, local.y, t, sx - t, sy - t / 2, sy - t / 2)]
    side = min(range(4), key=lambda k: dist[k])
    along = local.y if side < 2 else local.x - t
    return side, along / UNIT


def resizable(obj):
    """A room or a wall made with the map tools that Resize can size as a box: turned only by quarter turns about the
    vertical (its sides along the world's axes), not scaled."""
    p = obj.ps_maker
    kinds = ("room", "wall", "slab") if p.shape != "straight" else ("room", "wall", "slab", "stairs")
    return p.kind in kinds and kept_turn(obj) and abs(math.sin(2 * obj.rotation_euler.z)) < 1e-4


def wall_frame(obj, side):
    """A wall of a room (or a wall made with the map tools) as Resize sees it: its length and height (metres) and a
    function putting a point on it (along it, up from its floor, across its thickness; metres) in the world."""
    p = obj.ps_maker
    mw = obj.matrix_world.copy()
    if p.kind == "room":
        sz, t = p.room_size[2] * UNIT, p.room_thickness * UNIT
        length, place = room_walls(p)[side]
        top = sz - t if p.ceiling else sz
        return length, top - t, (lambda s, z, d: mw @ place(s, z, d)), t
    return p.wall_length * UNIT, p.wall_height * UNIT, (lambda s, z, d: mw @ Vector((s, d, z))), p.wall_thickness * UNIT


def opening_length(obj, o):
    """The length and height (units) of the wall an opening is in."""
    p = obj.ps_maker
    if p.kind == "room":
        return wall_size(p, int(o.side))
    return p.wall_length, p.wall_height


def keep_opening_in(obj, o):
    """An opening moved or sized by hand kept within its wall (along it, and between the floor and the top)."""
    length, height = opening_length(obj, o)
    o.width = min(max(o.width, 1.0), length)
    o.height = min(max(o.height, 1.0), height)
    o.offset = min(max(o.offset, 0.0), length - o.width)
    o.sill = min(max(o.sill, 0.0), height - o.height)


def box_start(obj):
    """What Resize keeps of a room or a wall as a drag starts: its place, its size and where its openings are."""
    p = obj.ps_maker
    if p.kind == "stairs":
        # Stairs: the way they climb and the step height wanted (the steps are shared out again in the new box).
        return {"location": obj.location.copy(), "turn": obj.matrix_world.to_3x3().normalized(), "direction": p.direction,
                "rise": p.rise}
    size = tuple(p.room_size) if p.kind == "room" else (p.slab_x, p.slab_y, p.slab_thickness) if p.kind == "slab"         else (p.wall_length, p.wall_thickness, p.wall_height)
    return {"location": obj.location.copy(), "size": size, "turn": obj.matrix_world.to_3x3().normalized(),
            "openings": [(o.offset, o.width) for o in p.openings], "holes": [(h.x, h.y) for h in p.holes]}


def fill_box(obj, lo, hi, start):
    """A room or a wall made to fill the world box lo..hi (metres), its openings left where they are in the world (those
    in a wall moved at its start go back along it by as much), each kept within its wall."""
    p = obj.ps_maker
    if p.kind == "stairs":
        # As many steps as the height takes near the step height it had (18 units at most), the length shared out.
        n, r, d, w, origin, turn = stairs_fill(Vector(lo), Vector(hi), start["direction"], start["rise"] * UNIT)
        _building[0] = True
        try:
            p.steps, p.rise, p.run, p.width = n, r / UNIT, d / UNIT, w / UNIT
            obj.location = origin
            obj.rotation_euler = (0.0, 0.0, turn)
        finally:
            _building[0] = False
        rebuild(obj)
        return
    turn = start["turn"]
    size_local = turn.transposed() @ (hi - lo)
    size_local = Vector([abs(v) for v in size_local])
    # Its origin: the corner its own (0, 0, 0) is at, the box's low or high side by how each of its axes is turned.
    location = Vector(lo)
    for k in range(3):
        j = max(range(3), key=lambda j: abs(turn[k][j]))
        if turn[k][j] < 0:
            location[k] = hi[k]
    shift = turn.transposed() @ (location - start["location"])  # the origin moved, in its own axes (metres)
    _building[0] = True
    try:
        if p.kind == "room":
            p.room_size = [round(v / UNIT, 3) for v in size_local]
        elif p.kind == "slab":
            p.slab_x, p.slab_y, p.slab_thickness = (round(v / UNIT, 3) for v in size_local)
        else:
            p.wall_length, p.wall_thickness, p.wall_height = (round(size_local[0] / UNIT, 3), round(size_local[1] / UNIT, 3),
                                                              round(size_local[2] / UNIT, 3))
        obj.location = location
        for o, (offset, width) in zip(p.openings, start["openings"]):
            along = shift.y if p.kind == "room" and int(o.side) < 2 else shift.x
            o.offset, o.width = offset - along / UNIT, width
            keep_opening_in(obj, o)
        sx, sy = (p.room_size[0], p.room_size[1]) if p.kind == "room" else (p.slab_x, p.slab_y)
        for h, (x, y) in zip(p.holes, start["holes"]):
            # A hole in a floor or a ceiling stays where it is too, within it.
            h.x = min(max(x - shift.x / UNIT, 0.0), max(0.0, sx - h.size_x))
            h.y = min(max(y - shift.y / UNIT, 0.0), max(0.0, sy - h.size_y))
    finally:
        _building[0] = False
    rebuild(obj)


def placed_prisms(outlines, place, d0, d1):
    from .brush_tools import extruded
    out = []
    for outline in outlines:
        verts, faces = extruded(outline, place, d0, d1)
        out.append((verts, [(f, None) for f in faces]))
    return out


def wall_pieces(p):
    """A wall along x from 0 to its length, y from 0 to its thickness, z from 0 to its height, its openings cut through."""
    outlines = wall_outlines(p.wall_length * UNIT, p.wall_height * UNIT, p.openings)
    return placed_prisms(outlines, lambda x, z, y: Vector((x, y, z)), 0.0, p.wall_thickness * UNIT)


ROOM_SIDES = ["Wall -X", "Wall +X", "Wall -Y", "Wall +Y"]


def room_walls(p):
    """The room's four walls: (length along it, a function putting (along, up, across) in the room's space)."""
    sx, sy, sz = (v * UNIT for v in p.room_size)
    t = p.room_thickness * UNIT
    return [
        (sy, lambda s, z, d: Vector((d, s, t + z))),
        (sy, lambda s, z, d: Vector((sx - t + d, s, t + z))),
        (sx - 2 * t, lambda s, z, d: Vector((t + s, d, t + z))),
        (sx - 2 * t, lambda s, z, d: Vector((t + s, sy - t + d, t + z))),
    ]


def room_pieces(p):
    """Hammer's Hollow: a floor, four walls (with their openings, the sill from the floor's top) and a ceiling of the
    room's box (from 0 to its size), this thick."""
    from .brush_tools import box_corners
    sx, sy, sz = (v * UNIT for v in p.room_size)
    t = p.room_thickness * UNIT
    top = sz - t if p.ceiling else sz
    out = slab_boxes(sx, sy, 0.0, t, [h for h in p.holes if h.level == "floor"])
    if p.ceiling:
        out += slab_boxes(sx, sy, sz - t, sz, [h for h in p.holes if h.level == "ceiling"])
    if top - t > 1e-4 and min(sx, sy) > 2 * t:
        for k, (length, place) in enumerate(room_walls(p)):
            openings = [o for o in p.openings if int(o.side) == k]
            out += placed_prisms(wall_outlines(length, top - t, openings), place, 0.0, t)
    return out


def cylinder_pieces(p):
    """A round brush standing on its origin."""
    rad, h, n = p.radius * UNIT, p.cylinder_height * UNIT, p.sides
    ring = [(rad * math.cos(2 * math.pi * i / n), rad * math.sin(2 * math.pi * i / n)) for i in range(n)]
    verts = [Vector((x, y, 0.0)) for x, y in ring] + [Vector((x, y, h)) for x, y in ring]
    faces = [list(range(n))[::-1], list(range(n, 2 * n))] + [(i, (i + 1) % n, n + (i + 1) % n, n + i) for i in range(n)]
    return [(verts, [(f, None) for f in faces])]


def slab_pieces(p):
    """A floor or a ceiling (from 0 to its size along x and y, its thickness up) with its holes."""
    return slab_boxes(p.slab_x * UNIT, p.slab_y * UNIT, 0.0, p.slab_thickness * UNIT, p.holes)


def slab_boxes(sx, sy, z0, z1, hole_list):
    """A slab from 0 to sx, sy (metres), z0 to z1, with holes (x, y, size_x, size_y in units): cut into boxes round them —
    the cells between the holes' sides, joined along x, then the same spans along y (few, all convex)."""
    from .brush_tools import box_corners
    holes = []
    for h in hole_list:
        x0, y0 = max(0.0, h.x * UNIT), max(0.0, h.y * UNIT)
        x1, y1 = min(sx, x0 + h.size_x * UNIT), min(sy, y0 + h.size_y * UNIT)
        if x1 - x0 > 1e-4 and y1 - y0 > 1e-4:
            holes.append((x0, y0, x1, y1))
    xs = sorted({0.0, sx, *[v for h in holes for v in (h[0], h[2])]})
    ys = sorted({0.0, sy, *[v for h in holes for v in (h[1], h[3])]})

    def solid(x0, x1, y0, y1):
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        return not any(h[0] < cx < h[2] and h[1] < cy < h[3] for h in holes)
    rows = []  # per band of y: the x spans that are solid
    for j in range(len(ys) - 1):
        spans, start = [], None
        for i in range(len(xs) - 1):
            if solid(xs[i], xs[i + 1], ys[j], ys[j + 1]):
                start = xs[i] if start is None else start
                end = xs[i + 1]
            elif start is not None:
                spans.append((start, end))
                start = None
        if start is not None:
            spans.append((start, end))
        rows.append((ys[j], ys[j + 1], spans))
    boxes, open_ = [], {}
    for y0, y1, spans in rows:
        now = {}
        for span in spans:
            now[span] = (open_.pop(span)[0] if span in open_ else y0, y1)
        for span, (a, b) in open_.items():
            boxes.append((span, a, b))
        open_ = now
    for span, (a, b) in open_.items():
        boxes.append((span, a, b))
    out = []
    for (x0, x1), y0, y1 in boxes:
        verts, faces = box_corners((x0, y0, z0), (x1, y1, z1))
        out.append((verts, [(f, None) for f in faces]))
    return out


BUILD = {"stairs": stairs_pieces, "arch": arch_pieces, "wall": wall_pieces, "room": room_pieces, "cylinder": cylinder_pieces,
         "slab": slab_pieces}
DIRECTIONS = [Vector((1, 0, 0)), Vector((-1, 0, 0)), Vector((0, 1, 0)), Vector((0, -1, 0)), Vector((0, 0, 1)), Vector((0, 0, -1))]


def stamp(mesh):
    """What the mesh is now, briefly: an edit by hand shows as another stamp."""
    co = [0.0] * (len(mesh.vertices) * 3)
    mesh.vertices.foreach_get("co", co)
    return f"{len(mesh.vertices)}:{len(mesh.polygons)}:{round(sum(abs(c) for c in co), 4)}"


def rebuild(obj):
    """The object's mesh made again from its settings, in its own space; its materials kept (each face the slot set for
    the way it looks, or the piece's own: a stair's clip ramp)."""
    p = obj.ps_maker
    if not p.kind or _building[0]:
        return
    if p.stamp and p.stamp != stamp(obj.data):
        # Edited by hand since it was built (Edit Mode, its mesh moved): never built again over that (it went back round
        # its origin, a house moved off into the bomb site), a plain brush of what it is now instead.
        plain(obj, "edited by hand")
        return
    _building[0] = True
    try:
        pieces = BUILD[p.kind](p)
        bm = bmesh.new()
        by_side = []  # faces taking the material set for the way they look
        for verts, faces in pieces:
            vs = [bm.verts.new(v) for v in verts]
            for f, slot in faces:
                try:
                    face = bm.faces.new([vs[i] for i in f])
                except ValueError:
                    continue  # a doubled face of a squeezed piece
                if slot is None:
                    by_side.append(face)
                else:
                    face.material_index = slot
        bm.normal_update()  # (recalc_face_normals goes by the normals there are)
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
        bm.normal_update()
        slots = max(1, len(obj.data.materials))
        for face in by_side:
            k = max(range(6), key=lambda i: face.normal.dot(DIRECTIONS[i]))
            face.material_index = max(0, min(p.dir_mats[k], slots - 1))
        bm.to_mesh(obj.data)
        bm.free()
        obj.data.update()
        if p.kind == "stairs":
            room = headroom(p)
            if room is None:
                obj.pop("ps_headroom", None)
            else:
                obj["ps_headroom"] = room
        world_uvs(obj)
        p.stamp = stamp(obj.data)
    finally:
        _building[0] = False


# The settings put on the grid when changed (Sizes on the grid): sizes at least a step (a thinner one is left as it is),
# offsets any number of steps.
ON_GRID_SIZES = ("width", "height", "opening_width", "opening_height", "arch_thickness", "depth", "wall_length",
                 "wall_height", "wall_thickness", "room_thickness", "radius", "cylinder_height", "slab_x", "slab_y",
                 "slab_thickness", "size_x", "size_y")
ON_GRID_OFFSETS = ("offset", "sill", "x", "y")


def onto_grid(owner, step):
    """The owner's (a maker's, an opening's, a hole's) lengths in whole grid steps (units)."""
    for name in ON_GRID_SIZES + ON_GRID_OFFSETS:
        if not hasattr(owner, name) or name in ("width",) and isinstance(owner, PSMaker) and owner.kind == "stairs":
            continue  # (the stairs' width: from the box they fill)
        v = getattr(owner, name)
        if not isinstance(v, float):
            continue
        q = round(v / step) * step
        if name in ON_GRID_SIZES:
            if v < step:
                continue
            q = max(step, q)
        if abs(q - v) > 1e-6:
            setattr(owner, name, q)
    if isinstance(owner, PSMaker) and owner.kind == "room":
        size = [max(step, round(v / step) * step) if v >= step else v for v in owner.room_size]
        if any(abs(a - b) > 1e-6 for a, b in zip(size, owner.room_size)):
            owner.room_size = size


def changed(self, context):
    obj = self.id_data
    if not isinstance(obj, bpy.types.Object) or obj.type != "MESH" or _building[0]:
        return
    scene = context.scene if context is not None else bpy.context.scene
    if getattr(scene, "ps_snap_sizes", False):
        _building[0] = True
        try:
            onto_grid(self, scene.ps_grid_units)
        finally:
            _building[0] = False
    rebuild(obj)


def show_settings_soon(context):
    """The new object's settings at the mouse a moment after the tool (instead of the tool's panel, F9: changes there are
    one undo step all together, here each its own — Ctrl+Z takes back the last change, not the whole door)."""
    window = context.window

    def later():
        try:
            for area in window.screen.areas:
                if area.type == "VIEW_3D":
                    region = next(r for r in area.regions if r.type == "WINDOW")
                    with bpy.context.temp_override(window=window, area=area, region=region):
                        bpy.ops.psmap.selected_popup("INVOKE_DEFAULT")
                    break
        except (RuntimeError, ReferenceError, StopIteration, TypeError):
            pass
        return None
    if window is not None and not bpy.app.background:
        bpy.app.timers.register(later, first_interval=0.05)


def make(context, kind, settings, location, turn, materials, collection=None, like=None, name=None):
    """A new object of this kind with these settings (a dict), placed at `location` turned by `turn` about the vertical,
    built. `like`: a Likeness (brush_tools) to take the settings and the materials of each side from."""
    mesh = bpy.data.meshes.new(name or KINDS[kind])
    obj = bpy.data.objects.new(name or KINDS[kind], mesh)
    (collection or child_collection(context.scene, "Seen")).objects.link(obj)
    for m in materials:
        mesh.materials.append(m)
    obj.location = location
    obj.rotation_euler = (0.0, 0.0, turn)
    p = obj.ps_maker
    _building[0] = True
    try:
        p.kind = kind
        for key, value in settings.items():
            if key == "openings":
                for o in value:
                    item = p.openings.add()
                    for k, v in o.items():
                        setattr(item, k, v)
            else:
                setattr(p, key, value)
        if like is not None:
            rot = Matrix.Rotation(turn, 3, "Z")
            for i, d in enumerate(DIRECTIONS):
                world = rot @ d
                if like.faces:
                    p.dir_mats[i] = max(like.faces, key=lambda t: t[0].dot(world))[1]
    finally:
        _building[0] = False
    obj["ps_parts"] = 1  # its pieces apart in one mesh: one brush each in the export
    if like is not None:
        for k, v in like.settings.items():
            obj[k] = v
    if kind == "stairs":
        obj["ps_nocollide"] = 1  # the steps: players walk on the ramp
        obj["ps_stairs"] = 1
    make_brush(obj)
    rebuild(obj)
    return obj


def clip_material():
    from . import ensure_materials
    ensure_materials()
    return next(m for m in bpy.data.materials if m.get("ps_tool") == "clip")


def restore_ramp(obj):
    """Stairs (made with the map tools) whose clip ramp lost its material (a material put on the whole stairs): the ramp's
    slot (1) the player clip again, built again. True when it was so."""
    p = obj.ps_maker
    if p.kind != "stairs":
        return False
    mats = obj.data.materials
    clip = clip_material()
    if len(mats) >= 2 and mats[1] == clip:
        return False
    if len(mats) < 2:
        if not len(mats):
            mats.append(clip)  # (nothing seen set: the clip stands for it until a material is put on)
        mats.append(clip)
    else:
        mats[1] = clip
    _building[0] = True
    try:
        p.dir_mats = [0 if v == 1 else v for v in p.dir_mats]
    finally:
        _building[0] = False
    rebuild(obj)
    return True


def put_material(obj, mat):
    """A material on the whole of a brush, but for its tool faces (a stair's clip ramp, the map edge's Nodraw): those
    stay what they are. Made with the map tools: every side of it this material, built again."""
    p = obj.ps_maker
    if p.kind:
        mats = obj.data.materials
        keep = mats[1] if p.kind == "stairs" and len(mats) > 1 else None
        mats.clear()
        mats.append(mat)
        if p.kind == "stairs":
            mats.append(keep if keep is not None and keep.get("ps_tool") else clip_material())  # the ramp's slot
        _building[0] = True
        try:
            p.dir_mats = [0] * 6
        finally:
            _building[0] = False
        rebuild(obj)
        return
    me = obj.data
    old = list(me.materials)
    tools = []
    for f in me.polygons:
        m = old[f.material_index] if f.material_index < len(old) else None
        if m is not None and m.get("ps_tool") and m not in tools:
            tools.append(m)
    index = [(1 + tools.index(m)) if m in tools else 0 for m in old]
    faces = [index[f.material_index] if f.material_index < len(index) else 0 for f in me.polygons]
    me.materials.clear()
    me.materials.append(mat)
    for m in tools:
        me.materials.append(m)
    me.polygons.foreach_set("material_index", faces)
    me.update()


def plain(obj, why=""):
    """No longer one of these: a plain brush of what it is now (its pieces stay apart, as brushes)."""
    obj.ps_maker.kind = ""
    obj.ps_maker.stamp = why


def edited(obj):
    """Changed by hand since it was built (Edit Mode)."""
    p = obj.ps_maker
    return bool(p.kind) and p.stamp != stamp(obj.data)


def kept_turn(obj):
    """Turned only about the vertical, not scaled: still what its settings say."""
    s = obj.scale
    r = obj.rotation_euler
    return obj.rotation_mode == "XYZ" and abs(r.x) < 1e-6 and abs(r.y) < 1e-6 and all(abs(v - 1) < 1e-6 for v in s)


# ---------- Its settings ----------
def _stairs_direction_get(self):
    obj = self.id_data
    z = obj.rotation_euler.z % (2 * math.pi)
    turns = {"+X": 0.0, "+Y": math.pi / 2, "-X": math.pi, "-Y": 3 * math.pi / 2}
    best = min(turns, key=lambda k: min(abs(z - turns[k]), 2 * math.pi - abs(z - turns[k])))
    return ["+X", "-X", "+Y", "-Y"].index(best)


def _stairs_direction_set(self, value):
    """The flight turned to climb the other way, in the same place (the box it takes up), its steps shared out again."""
    obj = self.id_data
    key = ["+X", "-X", "+Y", "-Y"][value]
    mw = obj.matrix_basis if obj.parent is None else obj.matrix_world  # matrix_world: not yet updated after a turn
    pts = [mw @ v.co for v in obj.data.vertices]
    if not pts:
        return
    lo = Vector([min(p[k] for p in pts) for k in range(3)])
    hi = Vector([max(p[k] for p in pts) for k in range(3)])
    n, r, d, w, origin, turn = stairs_fill(lo, hi, key, self.rise * UNIT)
    _building[0] = True
    try:
        self.steps, self.rise, self.run, self.width = n, r / UNIT, d / UNIT, w / UNIT
    finally:
        _building[0] = False
    obj.location = origin
    obj.rotation_euler = (0.0, 0.0, turn)
    rebuild(obj)


class PSOpening(bpy.types.PropertyGroup):
    offset: bpy.props.FloatProperty(name="From the wall's start (units)", default=0.0, min=0.0, step=100, precision=0,
                                    update=changed)
    width: bpy.props.FloatProperty(name="Width", default=64.0, min=8.0, step=100, precision=0, update=changed)
    height: bpy.props.FloatProperty(name="Height", default=112.0, min=8.0, step=100, precision=0, update=changed)
    sill: bpy.props.FloatProperty(name="From the floor", default=0.0, min=0.0, step=100, precision=0, update=changed)
    top: bpy.props.EnumProperty(name="Top", items=[("flat", "Flat", ""), ("arch", "Arch", "")], update=changed)
    segments: bpy.props.IntProperty(name="Arch segments", default=8, min=2, max=32, update=changed)
    side: bpy.props.EnumProperty(name="In", items=[(str(i), n, "") for i, n in enumerate(ROOM_SIDES)],
                                 update=changed)  # a room's: which of its walls


def units(name, default, least=1.0, desc=""):
    return bpy.props.FloatProperty(name=name, default=default, min=least, step=100, precision=0, description=desc,
                                   update=changed)


class PSHole(bpy.types.PropertyGroup):
    x: bpy.props.FloatProperty(name="From the side -X (units)", default=0.0, min=0.0, step=100, precision=0, update=changed)
    y: bpy.props.FloatProperty(name="From the side -Y (units)", default=0.0, min=0.0, step=100, precision=0, update=changed)
    size_x: bpy.props.FloatProperty(name="Size X", default=64.0, min=4.0, step=100, precision=0, update=changed)
    size_y: bpy.props.FloatProperty(name="Size Y", default=64.0, min=4.0, step=100, precision=0, update=changed)
    level: bpy.props.EnumProperty(name="In", items=[("floor", "Floor", ""), ("ceiling", "Ceiling", "")],
                                  update=changed)  # a room's: in its floor or its ceiling


class PSMaker(bpy.types.PropertyGroup):
    kind: bpy.props.StringProperty()
    stamp: bpy.props.StringProperty()
    dir_mats: bpy.props.IntVectorProperty(size=6, default=(0, 0, 0, 0, 0, 0))
    # Stairs
    shape: bpy.props.EnumProperty(name="Shape", items=[("straight", "Straight", ""), ("turning", "Turning", "")],
                                  update=changed)
    steps: bpy.props.IntProperty(name="Steps", default=8, min=1, max=128, update=changed)
    rise: units("Step height", 16.0, 2.0, "18 at most: higher than that is a jump, not a step")
    run: units("Step depth", 16.0, 4.0)
    width: units("Width", 96.0, 16.0)
    solid: bpy.props.BoolProperty(name="Solid below", default=True, update=changed)
    thickness: units("Slab thickness", 16.0, 2.0)
    angle: bpy.props.FloatProperty(name="Turns by", subtype="ANGLE", default=math.pi / 2, min=math.radians(15),
                                   max=math.radians(1440), update=changed)
    per_turn: bpy.props.IntProperty(name="Steps a full turn", default=16, min=4, max=96, update=changed)
    inner: units("Inner radius", 48.0, 0.0)
    outer: units("Outer radius", 144.0, 16.0)
    clockwise: bpy.props.BoolProperty(name="Clockwise", default=False, update=changed)
    direction: bpy.props.EnumProperty(name="Up toward", items=[(k, k, f"Climbing toward {k}") for k in ("+X", "-X", "+Y", "-Y")],
                                      get=_stairs_direction_get, set=_stairs_direction_set)
    # Arch
    opening_width: units("Opening width", 64.0, 8.0)
    opening_height: units("Opening height", 112.0, 8.0)
    segments: bpy.props.IntProperty(name="Segments", default=8, min=2, max=32, update=changed)
    arch_thickness: units("Thickness", 16.0)
    depth: units("Depth", 16.0, desc="A tunnel: its length")
    outside: bpy.props.EnumProperty(name="Outside", items=[("square", "Square", ""), ("round", "Round", "")],
                                    update=changed)
    # Wall
    wall_length: units("Length", 256.0, 2.0)
    wall_height: units("Height", 128.0, 2.0)
    wall_thickness: units("Thickness", 16.0)
    openings: bpy.props.CollectionProperty(type=PSOpening)
    # Room
    room_size: bpy.props.FloatVectorProperty(name="Size", size=3, default=(256.0, 256.0, 128.0), min=2.0, step=100,
                                             precision=0, update=changed)
    room_thickness: units("Thickness", 16.0)
    ceiling: bpy.props.BoolProperty(name="Ceiling", default=True, update=changed)
    # Cylinder
    sides: bpy.props.IntProperty(name="Sides", default=12, min=3, max=64, update=changed)
    radius: units("Radius", 32.0, 2.0)
    cylinder_height: units("Height", 128.0)
    # Floor (a slab with holes)
    slab_x: units("Size X", 256.0, 2.0)
    slab_y: units("Size Y", 256.0, 2.0)
    slab_thickness: units("Thickness", 16.0)
    holes: bpy.props.CollectionProperty(type=PSHole)


FIELDS = {
    "arch": ("opening_width", "opening_height", "segments", "arch_thickness", "depth"),
    "room": ("room_size", "room_thickness", "ceiling"),
    "cylinder": ("sides", "radius", "cylinder_height"),
    "wall": ("wall_length", "wall_height", "wall_thickness"),
    "slab": ("slab_x", "slab_y", "slab_thickness"),
}


class MAP_OT_hole_remove(bpy.types.Operator):
    bl_idname = "psmap.hole_remove"
    bl_label = "Remove the hole"
    bl_description = "The floor closed where this hole was"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}
    index: bpy.props.IntProperty()

    def execute(self, context):
        obj = context.active_object
        if obj is None or obj.ps_maker.kind not in ("slab", "room") or not 0 <= self.index < len(obj.ps_maker.holes):
            return {"CANCELLED"}
        obj.ps_maker.holes.remove(self.index)
        rebuild(obj)
        return {"FINISHED"}


class MAP_OT_opening_remove(bpy.types.Operator):
    bl_idname = "psmap.opening_remove"
    bl_label = "Remove the opening"
    bl_description = "The wall closed where this opening was"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}
    index: bpy.props.IntProperty()

    def execute(self, context):
        obj = context.active_object
        if obj is None or obj.ps_maker.kind not in ("wall", "room") or not 0 <= self.index < len(obj.ps_maker.openings):
            return {"CANCELLED"}
        obj.ps_maker.openings.remove(self.index)
        rebuild(obj)
        return {"FINISHED"}


class MAP_OT_opening_add(bpy.types.Operator):
    bl_idname = "psmap.opening_add"
    bl_label = "Add an opening"
    bl_description = ("One more door in this wall (a room: in its wall nearest the 3D cursor), in the middle of where it "
                      "is still whole (change it below)")
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}

    def execute(self, context):
        obj = context.active_object
        if obj is None or obj.ps_maker.kind not in ("wall", "room"):
            return {"CANCELLED"}
        p = obj.ps_maker
        side, length, height = 0, p.wall_length, p.wall_height
        if p.kind == "room":
            # The wall nearest the 3D cursor.
            side = nearest_wall(obj, context.scene.cursor.location)[0]
            length, height = wall_size(p, side)
        # The widest stretch left whole.
        x, gaps = 0.0, []
        for o in sorted([o for o in p.openings if p.kind == "wall" or int(o.side) == side], key=lambda o: o.offset):
            gaps.append((x, o.offset))
            x = o.offset + o.width
        gaps.append((x, length))
        g0, g1 = max(gaps, key=lambda g: g[1] - g[0])
        item = p.openings.add()
        _building[0] = True
        try:
            item.side = str(side)
            item.width = min(64.0, max(8.0, g1 - g0 - 16))
            item.height = min(112.0, height - 16) if height > 24 else height
            item.offset = round(((g0 + g1) / 2 - item.width / 2) / 16) * 16
        finally:
            _building[0] = False
        rebuild(obj)
        return {"FINISHED"}


def room_hole_at(obj, point):
    """A room's floor or ceiling the point (world) is on, rather than one of its walls: "floor", "ceiling" or None; and
    where it is over the room (x, y in units from its -X, -Y side)."""
    p = obj.ps_maker
    local = obj.matrix_world.inverted() @ point
    sx, sy, sz = (v * UNIT for v in p.room_size)
    t = p.room_thickness * UNIT
    if not (-1e-4 <= local.x <= sx + 1e-4 and -1e-4 <= local.y <= sy + 1e-4):
        return None, None
    wall = nearest_wall(obj, point)
    to_wall = min(abs(local.x - t), abs(local.x - (sx - t)), abs(local.y - t), abs(local.y - (sy - t)))
    to_floor = abs(local.z - t)
    to_ceiling = abs(local.z - (sz - t)) if p.ceiling else float("inf")
    level = "floor" if to_floor <= to_ceiling else "ceiling"
    if min(to_floor, to_ceiling) > to_wall + 1e-4 and wall is not None:
        return None, None  # nearer a wall: a door or a window there
    return level, (local.x / UNIT, local.y / UNIT)


class MAP_OT_split_room(bpy.types.Operator):
    bl_idname = "psmap.split_room"
    bl_label = "Split into brushes"
    bl_description = ("The room as its floor, its ceiling and its four walls, each one object of its own (the walls with their "
                      "doors and windows, the floor and the ceiling with their holes): to move or resize each apart")
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        from .brush_tools import Likeness, select_only
        made = []
        for obj in [o for o in context.selected_objects if o.type == "MESH" and o.ps_maker.kind == "room"]:
            made += split_room(context, obj, Likeness(obj))
        if not made:
            self.report({"WARNING"}, "Select a room (made with Hollow)")
            return {"CANCELLED"}
        select_only(context, made)
        return {"FINISHED"}


def split_room(context, obj, like):
    """A room made into its six parts (see MAP_OT_split_room); the room itself goes."""
    p = obj.ps_maker
    sx, sy, sz = p.room_size
    t = p.room_thickness
    top = sz - t if p.ceiling else sz
    mw = obj.matrix_world.copy()
    turn = obj.rotation_euler.z
    mats = list(obj.data.materials)
    col = obj.users_collection[0]
    name = obj.name
    U = UNIT

    def at(x, y, z):
        return mw @ Vector((x * U, y * U, z * U))
    made = []
    for level, z0, holes in [("floor", 0.0, [h for h in p.holes if h.level == "floor"])] + \
            ([("ceiling", sz - t, [h for h in p.holes if h.level == "ceiling"])] if p.ceiling else []):
        slab = make(context, "slab", {"slab_x": sx, "slab_y": sy, "slab_thickness": t}, at(0, 0, z0), turn, mats, col, like,
                    name=f"{name} {level}")
        _building[0] = True
        try:
            for h in holes:
                n = slab.ps_maker.holes.add()
                n.x, n.y, n.size_x, n.size_y = h.x, h.y, h.size_x, h.size_y
        finally:
            _building[0] = False
        rebuild(slab)
        made.append(slab)
    # The walls as the room has them (room_walls): -X and +X along y (their own x along the world's y), -Y and +Y along x.
    walls = [(0, (t, 0, t), math.pi / 2, sy), (1, (sx, 0, t), math.pi / 2, sy),
             (2, (t, 0, t), 0.0, sx - 2 * t), (3, (t, sy - t, t), 0.0, sx - 2 * t)]
    for side, origin, extra, length in walls:
        if length <= 0 or top - t <= 0:
            continue
        openings = [{"offset": o.offset, "width": o.width, "height": o.height, "sill": o.sill, "top": o.top,
                     "segments": o.segments} for o in p.openings if int(o.side) == side]
        wall = make(context, "wall", {"wall_length": length, "wall_height": top - t, "wall_thickness": t,
                                      "openings": openings}, at(*origin), turn + extra, mats, col, like,
                    name=f"{name} {ROOM_SIDES[side].split()[-1]}")
        made.append(wall)
    bpy.data.objects.remove(obj, do_unlink=True)
    return made


def wall_from_pieces(objs):
    """Brushes of pieces that are together a wall with holes through it (a wall made with the map tools then edited by
    hand, or an old wall of three brushes round its door) read as a wall: (lo, hi, along axis, [(offset, width, sill,
    height)] in units), or None when they are not one (not upright, pieces not across its whole thickness, no hole)."""
    import bmesh
    bm = bmesh.new()
    for obj in objs:
        part = obj.data.copy()
        part.transform(obj.matrix_world)
        bm.from_mesh(part)
        bpy.data.meshes.remove(part)
    boxes, done = [], set()
    bm.faces.index_update()
    for f in bm.faces:
        if f.index in done:
            continue
        stack, verts = [f], set()
        done.add(f.index)
        while stack:
            g = stack.pop()
            verts.update(g.verts)
            for e in g.edges:
                for h in e.link_faces:
                    if h.index not in done:
                        done.add(h.index)
                        stack.append(h)
        pts = [v.co for v in verts]
        boxes.append((Vector([min(p[k] for p in pts) for k in range(3)]), Vector([max(p[k] for p in pts) for k in range(3)])))
    bm.free()
    if not boxes:
        return None
    lo = Vector([min(b[0][k] for b in boxes) for k in range(3)])
    hi = Vector([max(b[1][k] for b in boxes) for k in range(3)])
    size = hi - lo
    thin = 0 if size.x < size.y else 1
    along = 1 - thin
    eps = 1e-4
    if size[thin] <= eps or size[thin] * 2 > size[along]:
        return None
    for b0, b1 in boxes:
        if abs(b0[thin] - lo[thin]) > eps or abs(b1[thin] - hi[thin]) > eps:
            return None  # a piece not across the whole thickness: not a plain wall
    a_cuts = sorted({lo[along], hi[along], *[b[0][along] for b in boxes], *[b[1][along] for b in boxes]})
    z_cuts = sorted({lo.z, hi.z, *[b[0].z for b in boxes], *[b[1].z for b in boxes]})

    def covered(a, z):
        return any(b0[along] - eps <= a <= b1[along] + eps and b0.z - eps <= z <= b1.z + eps for b0, b1 in boxes)
    # Each column between the pieces' sides: its open runs up it; next columns with the same runs make one opening.
    columns = []
    for i in range(len(a_cuts) - 1):
        a = (a_cuts[i] + a_cuts[i + 1]) / 2
        runs, start = [], None
        for j in range(len(z_cuts) - 1):
            open_ = not covered(a, (z_cuts[j] + z_cuts[j + 1]) / 2)
            if open_ and start is None:
                start = z_cuts[j]
            if not open_ and start is not None:
                runs.append((start, z_cuts[j]))
                start = None
        if start is not None:
            runs.append((start, z_cuts[-1]))
        columns.append((a_cuts[i], a_cuts[i + 1], runs))
    openings, current = [], {}
    for a0, a1, runs in columns + [(None, None, [])]:
        for run in list(current):
            if run not in runs:
                s0 = current.pop(run)
                openings.append(((s0 - lo[along]) / UNIT, (prev - s0) / UNIT, (run[0] - lo.z) / UNIT, (run[1] - run[0]) / UNIT))
        for run in runs:
            current.setdefault(run, a0)
        prev = a1
    if not openings:
        return None
    return lo, hi, along, [tuple(round(v, 3) for v in o) for o in openings]


def wall_again(context, group):
    """Brushes of pieces round holes (a wall with openings edited by hand, joined, or an old wall of brushes) made one wall
    with openings again (its holes its openings); the pieces go. None when they are not a wall with holes through it."""
    from .brush_tools import Likeness
    found = wall_from_pieces(group)
    if found is None:
        return None
    obj = group[0]
    lo, hi, along, holes = found
    size = hi - lo
    thin = 1 - along
    location, turn = (lo.copy(), 0.0) if along == 0 else (Vector((hi.x, lo.y, lo.z)), math.pi / 2)
    openings = [{"offset": o, "width": w, "sill": s, "height": h} for o, w, s, h in holes]
    like, col, name = Likeness(obj), obj.users_collection[0], obj.name
    mats = []
    for o in group:
        mats += [m for m in o.data.materials if m not in mats]
    wall = make(context, "wall", {"wall_length": round(size[along] / UNIT, 3), "wall_height": round(size.z / UNIT, 3),
                                  "wall_thickness": round(size[thin] / UNIT, 3), "openings": openings},
                location, turn, mats, col, like, name=name)
    for o in group:
        bpy.data.objects.remove(o, do_unlink=True)
    wall.name = name
    return wall


class MAP_OT_wall_again(bpy.types.Operator):
    bl_idname = "psmap.wall_again"
    bl_label = "Wall with openings again"
    bl_description = ("A wall of pieces round its doors and windows (a wall with openings edited by hand, now a plain brush) "
                      "made a wall with openings again: its holes found between the pieces become its openings (flat at the "
                      "top: set an arch again in its settings), and Resize sizes it and its openings")
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        from .brush_tools import Likeness, select_only
        made, skipped = [], []
        plain = [o for o in context.selected_objects if o.type == "MESH" and o.get("ps_brush") and not o.ps_maker.kind]
        # Several selected: one wall of them all (an old wall of brushes round its door); else each on its own.
        groups = [plain] if len(plain) > 1 and wall_from_pieces(plain) is not None else [[o] for o in plain]
        for group in groups:
            wall = wall_again(context, group)
            if wall is None:
                skipped.append(group[0].name)
                continue
            made.append(wall)
        if skipped:
            self.report({"WARNING"}, f"Not a wall with holes through it (left as it is): {', '.join(skipped)}")
        if not made:
            return {"CANCELLED"}
        select_only(context, made)
        self.report({"INFO"}, f"{len(made)} wall(s) with openings again")
        return {"FINISHED"}


class MAP_OT_make_plain(bpy.types.Operator):
    bl_idname = "psmap.make_plain"
    bl_label = "Make plain"
    bl_description = "No longer rebuilt from its settings: a plain brush (its pieces apart), to edit by hand"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}

    def execute(self, context):
        obj = context.active_object
        if obj is not None and obj.type == "MESH":
            plain(obj, "made plain")
        return {"FINISHED"}


def draw(layout, obj):
    """Its settings in the panel, changed live."""
    p = obj.ps_maker
    box = layout.box()
    if not p.kind:
        if obj.type == "MESH" and obj.get("ps_parts"):
            # Pieces: maybe a wall with openings once, edited by hand since.
            box.operator("psmap.wall_again", icon="MOD_BUILD")
        return
    row = box.row()
    row.label(text=f"{KINDS[p.kind]}: its settings (changed, it is built again)", icon="MODIFIER")
    row.operator("psmap.make_plain", text="", icon="X")
    scene = bpy.context.scene
    box.prop(scene, "ps_snap_sizes", text=f"Sizes on the grid ({scene.ps_grid_units} u)", icon="SNAP_GRID")
    col = box.column(align=True)
    if p.kind == "stairs":
        col.row(align=True).prop(p, "shape", expand=True)
        if p.shape == "straight":
            direction_row(col, p, "direction")
        col.prop(p, "rise")
        names = ("steps", "run", "width") if p.shape == "straight" else ("angle", "per_turn", "inner", "outer", "clockwise")
        for name in names:
            col.prop(p, name)
        col.prop(p, "solid")
        if not p.solid:
            col.prop(p, "thickness")
        room = headroom(p)
        if room is not None and room < 72:
            col.label(text=f"{room} units between turns: " + ("no way through" if room < 54 else "crouched only"),
                      icon="ERROR")
    else:
        for name in FIELDS[p.kind]:
            col.prop(p, name)
        if p.kind == "arch":
            col.row(align=True).prop(p, "outside", expand=True)
    if p.kind in ("slab", "room"):
        for i, h in enumerate(p.holes):
            sub = box.box().column(align=True)
            row = sub.row(align=True)
            row.label(text=f"Hole {i + 1}")
            if p.kind == "room":
                row.prop(h, "level", text="")
            row.operator("psmap.hole_remove", text="", icon="TRASH").index = i
            for name in ("x", "y", "size_x", "size_y"):
                sub.prop(h, name)
    if p.kind in ("wall", "room"):
        for i, o in enumerate(p.openings):
            sub = box.box().column(align=True)
            row = sub.row(align=True)
            row.label(text=f"Opening {i + 1}")
            if p.kind == "room":
                row.prop(o, "side", text="")
            row.operator("psmap.opening_remove", text="", icon="TRASH").index = i
            for name in ("offset", "width", "height", "sill"):
                sub.prop(o, name)
            sub.row(align=True).prop(o, "top", expand=True)
            if o.top == "arch":
                sub.prop(o, "segments")
        box.operator("psmap.opening_add", icon="ADD")
    if p.kind == "room":
        box.operator("psmap.split_room", icon="MOD_EXPLODE")
    box.label(text="Edited by hand (Edit Mode) or scaled: a plain brush", icon="INFO")


CLASSES = [PSOpening, PSHole, PSMaker, MAP_OT_opening_remove, MAP_OT_opening_add, MAP_OT_hole_remove, MAP_OT_make_plain,
           MAP_OT_split_room, MAP_OT_wall_again]


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    bpy.types.Object.ps_maker = bpy.props.PointerProperty(type=PSMaker)
    bpy.types.Scene.ps_map_ceiling = bpy.props.IntProperty(
        name="Map ceiling (units)", default=0, min=0, max=65536,
        description="How high the player clips over the map's edge go (Map edge); 0: the highest brush and 128 over it")
    bpy.types.Scene.ps_cull_unseen = bpy.props.BoolProperty(
        name="Leave out faces nobody sees", default=True,
        description="At export, faces no player can see from anywhere they get to (the back of the map's edge walls, "
                    "roof tops) are left out, as Hammer's compiler leaves out the outside. A face marked Always draw stays")
    bpy.types.Scene.ps_texture_size = bpy.props.EnumProperty(
        name="Pictures", default="1024", items=[("512", "512", "Light: phones with little memory"),
                                                 ("1024", "1024", "Most maps"), ("2048", "2048", "Sharp, heavy")],
        description="At export, each material's colour picture made at most this big (and only it: the game draws no "
                    "normal or roughness pictures)")
    bpy.types.Scene.ps_snap_sizes = bpy.props.BoolProperty(
        name="Sizes on the grid", default=True,
        description="The settings of stairs, arches, walls, rooms, floors changed: their sizes and offsets in whole grid steps")


def unregister():
    del bpy.types.Scene.ps_snap_sizes
    del bpy.types.Scene.ps_texture_size
    del bpy.types.Scene.ps_cull_unseen
    del bpy.types.Scene.ps_map_ceiling
    del bpy.types.Object.ps_maker
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
