"""
The map's light baked in Blender (Cycles): everything seen gets a second UV set (its "Lightmap") packed into atlases of
2048 × 2048, and the sun, the lamps and the sky are baked into them, direct and bounced (the surfaces' own colours left
out: the game multiplies its textures by it, as with any lightmap). Players and weapons, which move, take their light from
probes: little cubes where players can go (the radar's walk), baked the same way, each face the light coming from that side
(Source's ambient cubes).

What comes out (in the game's space, as the rest of the package): lightmap_<i>.png (RGBM, the range RGBM_RANGE: 8 bits a
channel, light up to that many times white) and the manifest's "baked" block:
    {"format": 1, "mode": "fast" | "final", "encoding": "rgbm8", "lightmaps": ["lightmap_0.png", ...],
     "nodes": [{"node": "<seen object>", "lightmap": <atlas>}, ...], "probes": {"p": [x, y, z, ...], "c": [r, g, b × 6 a probe: +x -x +y -y +z -z]}}
"""
import math
import os
import time

import bmesh
import bpy
import numpy as np
from mathutils import Vector

UNIT = 0.025
ATLAS = 2048
FILL = 0.35           # how much of an atlas the packed islands take, about (measured: a third on a blockout map)
PAD = 8.0             # pixels between islands: the denoiser and the game's smaller copies (mips) do not mix them
# Never smaller (fast, final): a step or a thin wall must get pixels of its own (else it reads black); Final at least
# twice as sharp as Fast on a small map, which its density alone would not make bigger than the smallest atlas.
RGBM_RANGE = 8.0
MODES = {
    # units a lightmap pixel, Cycles samples, the smallest atlas
    "fast": (32, 64, 512),
    # 4 units (10 cm): a 16-unit wall 4 pixels thick (at 8 its light ran under walls and round door frames).
    "final": (4, 512, 1024),
}
PROBE_STEP = 1.6      # metres between probes over the floor players reach
PROBE_HEIGHT = 1.0    # over the floor (a player's chest)
PROBE_CELL = 4        # pixels a probe face takes in the probe picture
SKY = (0.62, 0.75, 0.9)
SKY_STRENGTH = 0.6    # the sky's light (Cycles world): shade outdoors, what comes in at the doors
SUN_ENERGY = 3.0      # W/m² of a brightness-1 sun: a lit white floor a little over white


def blender(u):
    """A point in the game's space back in Blender's (x over, y up there)."""
    return Vector((-u[0], -u[2], u[1]))


def gltf_dir(v):
    """A glTF direction in Blender's space."""
    return Vector((v[0], -v[2], v[1]))


def setup_cycles(scene, samples):
    scene.render.engine = "CYCLES"
    cy = scene.cycles
    cy.samples = samples
    cy.use_denoising = False
    cy.max_bounces = 6
    cy.diffuse_bounces = 4
    cy.glossy_bounces = 0
    cy.transmission_bounces = 2
    try:
        prefs = bpy.context.preferences.addons["cycles"].preferences
        for kind in ("OPTIX", "CUDA", "HIP", "ONEAPI", "METAL"):
            try:
                prefs.compute_device_type = kind
            except TypeError:
                continue
            prefs.get_devices()
            gpus = [d for d in prefs.devices if d.type == kind]
            if gpus:
                for d in prefs.devices:
                    d.use = d.type == kind
                cy.device = "GPU"
                return kind
    except Exception as e:  # noqa: BLE001  (no card it can use, or its drivers: the processor)
        print(f"Bake: graphics cards not used ({e})")
    cy.device = "CPU"
    return "CPU"


def setup_lights(scene, entities):
    """The map's sun and lamps as Blender lights (whatever lights the file had are left out), the sky as the world."""
    for o in [o for o in scene.objects if o.type == "LIGHT"]:
        bpy.data.objects.remove(o, do_unlink=True)
    world = bpy.data.worlds.new("Bake sky")
    world.use_nodes = True
    # By its kind, not its name: a Blender in Russian (new data's names translated) names it "Фон" — the bake failed.
    nodes = world.node_tree.nodes
    bg = next((n for n in nodes if n.type == "BACKGROUND"), None)
    if bg is None:
        bg = nodes.new("ShaderNodeBackground")
        out = next((n for n in nodes if n.type == "OUTPUT_WORLD"), None) or nodes.new("ShaderNodeOutputWorld")
        world.node_tree.links.new(bg.outputs[0], out.inputs[0])
    bg.inputs[0].default_value = (*SKY, 1.0)
    bg.inputs[1].default_value = SKY_STRENGTH
    scene.world = world
    made = 0
    # No sun of its own: the one the game's test light has (the sandbox scene's), as the Sun test light shows it.
    if not any(e.get("type") == "sun" for e in entities):
        entities = list(entities) + [{"type": "sun", "brightness": 1.0, "color": [1.0, 0.96, 0.88],
                                      "direction": [0.35, -0.8, 0.48]}]
    for e in entities:
        kind = e.get("type")
        if kind not in ("sun", "light"):
            continue
        colour = tuple(e.get("color") or (1.0, 0.95, 0.85))[:3]
        bright = float(e.get("brightness") or (1.0 if kind == "sun" else 2.0))
        if kind == "sun":
            # A CS map's light_environment says its brightness on its own scale (200 a plain sun): over 10 is that.
            if bright > 10.0:
                bright /= 200.0
            data = bpy.data.lights.new("Bake sun", "SUN")
            data.energy = SUN_ENERGY * bright
            data.angle = math.radians(1.5)
            d = gltf_dir(e.get("direction") or (0.3, -1.0, 0.2)).normalized()
            obj = bpy.data.objects.new("Bake sun", data)
            obj.rotation_euler = d.to_track_quat("-Z", "Y").to_euler()
        else:
            cone = float(e.get("cone") or 0.0)
            reach = float(e.get("range") or 9.0)
            data = bpy.data.lights.new("Bake lamp", "SPOT" if cone > 0 else "POINT")
            # Bright enough to light its reach as the game's lamp of that range does.
            data.energy = 60.0 * bright * (reach / 8.0) ** 2
            data.shadow_soft_size = 0.1
            if cone > 0:
                data.spot_size = math.radians(min(179.0, cone))
            fade_at(data, reach)
            obj = bpy.data.objects.new("Bake lamp", data)
            p = e.get("position") or (0, 0, 0)
            obj.location = Vector((p[0], -p[2], p[1]))
            f = e.get("forward")
            if f:
                obj.rotation_euler = gltf_dir(f).normalized().to_track_quat("-Z", "Y").to_euler()
        data.color = colour
        scene.collection.objects.link(obj)
        made += 1
    return made


def fade_at(light, reach):
    """A lamp's light gone at its range, as the game's lamps (Unity's: (1 - (d/r)^4)^2 on the light of its distance):
    Cycles' own goes on for ever, a lamp in a room lit what is past it."""
    light.use_nodes = True
    nodes = light.node_tree.nodes
    emit = next((n for n in nodes if n.type == "EMISSION"), None)
    if emit is None:
        return
    path = nodes.new("ShaderNodeLightPath")
    ratio = nodes.new("ShaderNodeMath")
    ratio.operation = "DIVIDE"
    ratio.inputs[1].default_value = max(reach, 0.01)
    quart = nodes.new("ShaderNodeMath")
    quart.operation = "POWER"
    quart.inputs[1].default_value = 4.0
    left = nodes.new("ShaderNodeMath")
    left.operation = "SUBTRACT"
    left.use_clamp = True
    left.inputs[0].default_value = 1.0
    square = nodes.new("ShaderNodeMath")
    square.operation = "POWER"
    square.inputs[1].default_value = 2.0
    links = light.node_tree.links
    links.new(path.outputs["Ray Length"], ratio.inputs[0])
    links.new(ratio.outputs[0], quart.inputs[0])
    links.new(quart.outputs[0], left.inputs[1])
    links.new(left.outputs[0], square.inputs[0])
    links.new(square.outputs[0], emit.inputs["Strength"])


def add_blockers(polygons):
    """The faces not seen that are still walls (Nodraw, those left out as nobody sees them) as one object the bake's light
    stops at: black, so no light comes off them either (as Source's Nodraw). None when there are none."""
    if not polygons:
        return None
    verts, faces = [], []
    for poly in polygons:
        first = len(verts)
        verts += [tuple(v) for v in poly]
        faces.append(list(range(first, first + len(poly))))
    mesh = bpy.data.meshes.new("PS bake blockers")
    mesh.from_pydata(verts, [], faces)
    mat = bpy.data.materials.new("PS bake blocker")
    if mat.node_tree is None:
        mat.use_nodes = True
    bsdf = next((n for n in mat.node_tree.nodes if n.type == "BSDF_PRINCIPLED"), None)
    if bsdf is not None:
        bsdf.inputs["Base Color"].default_value = (0, 0, 0, 1)
        bsdf.inputs["Roughness"].default_value = 1.0
    mesh.materials.append(mat)
    obj = bpy.data.objects.new("PS bake blockers", mesh)
    bpy.context.scene.collection.objects.link(obj)
    obj.hide_render = False
    return obj


def area_of(o):
    me = o.data
    a = np.empty(len(me.polygons), dtype=np.float64)
    me.polygons.foreach_get("area", a)
    s = o.matrix_world.to_scale()
    return float(a.sum()) * abs(s.x * s.y * s.z) ** (2.0 / 3.0)


def split_half(o):
    """A mesh too big for one atlas in two, by where its faces are (the longer side of its box halved)."""
    me = o.data
    cs = np.array([p.center for p in me.polygons])
    axis = int(np.argmax(cs.max(axis=0) - cs.min(axis=0)))
    cut = float(np.median(cs[:, axis]))
    keep_a = set(np.nonzero(cs[:, axis] <= cut)[0].tolist())
    if not keep_a or len(keep_a) == len(me.polygons):
        return [o]
    halves = []
    for side in (True, False):
        bm = bmesh.new()
        bm.from_mesh(me)
        bm.faces.ensure_lookup_table()
        gone = [f for f in bm.faces if (f.index in keep_a) != side]
        bmesh.ops.delete(bm, geom=gone, context="FACES")
        mesh = bpy.data.meshes.new(o.data.name + (" a" if side else " b"))
        bm.to_mesh(mesh)
        bm.free()
        for m in me.materials:
            mesh.materials.append(m)
        piece = o.copy()
        piece.data = mesh
        piece.name = o.name + (" a" if side else " b")
        for c in o.users_collection:
            c.objects.link(piece)
        halves.append(piece)
    bpy.data.objects.remove(o, do_unlink=True)
    return halves


def atlases(objects, texel):
    """The seen objects in groups, each fitting one atlas at the density (objects too big split)."""
    capacity = ATLAS * ATLAS * FILL * texel * texel  # m² an atlas holds
    todo = [o for o in objects if o.type == "MESH" and len(o.data.polygons)]
    fitted = []
    while todo:
        o = todo.pop()
        if area_of(o) > capacity and len(o.data.polygons) > 1:
            parts = split_half(o)
            if len(parts) > 1:
                todo += parts
                continue
        fitted.append(o)
    fitted.sort(key=area_of, reverse=True)
    groups, sizes = [], []
    for o in fitted:
        a = area_of(o)
        for i in range(len(groups)):
            if sizes[i] + a <= capacity:
                groups[i].append(o)
                sizes[i] += a
                break
        else:
            groups.append([o])
            sizes.append(a)
    return groups, sizes


def unwrap(group, size=ATLAS):
    """A "Lightmap" UV set on each object of the group, all packed together into one square (multi-object Edit Mode),
    the islands 4 pixels of a `size` picture apart."""
    bpy.ops.object.select_all(action="DESELECT")
    for o in group:
        # The brushes' faces joined where they meet (their corners welded): faces side by side in one plane are one
        # island (smart_project keeps what is joined and flat enough together), not one each with a gap round it.
        bm = bmesh.new()
        bm.from_mesh(o.data)
        bmesh.ops.remove_doubles(bm, verts=bm.verts[:], dist=0.001)
        bm.to_mesh(o.data)
        bm.free()
        for f in o.data.polygons:
            f.use_smooth = False  # (welded, a face still flat: its own normal)
        o.data.update()
        o.select_set(True)
        layer = o.data.uv_layers.get("Lightmap") or o.data.uv_layers.new(name="Lightmap")
        o.data.uv_layers.active = layer
    bpy.context.view_layer.objects.active = group[0]
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action="SELECT")
    bpy.ops.uv.smart_project(angle_limit=math.radians(66), island_margin=0.0, area_weight=0.0, correct_aspect=True,
                             scale_to_bounds=False)
    # One density for all: smart_project fits each object's islands to the square on its own (a small brush as big as
    # the floor), the floor then blurred and its shadows lost.
    bpy.ops.uv.average_islands_scale()
    # Turned a quarter at most: a brush's edges stay along the pixels (turned by any angle, a straight shadow edge across
    # an island laid at 45° came out in steps).
    bpy.ops.uv.pack_islands(rotate=True, rotate_method="CARDINAL", margin_method="FRACTION", margin=PAD / size)
    bpy.ops.object.mode_set(mode="OBJECT")
    for o in group:
        # The texture's own UVs stay first (TEXCOORD_0), the lightmap's second (TEXCOORD_1).
        o.data.uv_layers.active = o.data.uv_layers[0]


def repack(group, size):
    """The group's lightmap islands packed again for a picture of `size` (its gaps PAD of its pixels)."""
    bpy.ops.object.select_all(action="DESELECT")
    for o in group:
        o.select_set(True)
        o.data.uv_layers.active = o.data.uv_layers["Lightmap"]
    bpy.context.view_layer.objects.active = group[0]
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action="SELECT")
    bpy.ops.uv.pack_islands(rotate=True, rotate_method="CARDINAL", margin_method="FRACTION", margin=PAD / size)
    bpy.ops.object.mode_set(mode="OBJECT")
    for o in group:
        o.data.uv_layers.active = o.data.uv_layers[0]


def density(group, size):
    """Metres a lightmap pixel the packed group has: its faces' area against the share of the picture they take."""
    area, share = 0.0, 0.0
    for o in group:
        me = o.data
        uv = me.uv_layers["Lightmap"].data
        s = o.matrix_world.to_scale()
        k = abs(s.x * s.y * s.z) ** (2.0 / 3.0)
        for f in me.polygons:
            area += f.area * k
            idx = list(f.loop_indices)
            a = 0.0
            for j in range(1, len(idx) - 1):
                p0, p1, p2 = uv[idx[0]].uv, uv[idx[j]].uv, uv[idx[j + 1]].uv
                a += abs((p1.x - p0.x) * (p2.y - p0.y) - (p2.x - p0.x) * (p1.y - p0.y)) / 2
            share += a
    return math.sqrt(area / max(share * size * size, 1e-9))


def bake_target(objects, image, uv="Lightmap"):
    """Every material of these objects bakes into `image` through the UV set `uv` (its own image node, active)."""
    done = set()
    for o in objects:
        if not o.data.materials:
            o.data.materials.append(white_material())
        for m in o.data.materials:
            if m is None or m.name in done:
                continue
            done.add(m.name)
            if m.node_tree is None:
                m.use_nodes = True
            nodes = m.node_tree.nodes
            node = nodes.get("PS bake") or nodes.new("ShaderNodeTexImage")
            node.name = "PS bake"
            node.image = image
            mapping = nodes.get("PS bake uv") or nodes.new("ShaderNodeUVMap")
            mapping.name = "PS bake uv"
            mapping.uv_map = uv
            if not node.inputs[0].is_linked:
                m.node_tree.links.new(mapping.outputs[0], node.inputs[0])
            nodes.active = node
    for o in objects:
        for i, slot in enumerate(o.material_slots):
            if slot.material is None:
                slot.material = white_material()


_white = []


def white_material():
    if not _white:
        m = bpy.data.materials.new("PS bake white")
        if m.node_tree is None:
            m.use_nodes = True
        _white.append(m)
    return _white[0]


def clear_targets():
    for m in bpy.data.materials:
        if m.node_tree:
            for name in ("PS bake", "PS bake uv"):
                n = m.node_tree.nodes.get(name)
                if n is not None:
                    m.node_tree.nodes.remove(n)


def run_bake(objects, margin):
    bpy.ops.object.select_all(action="DESELECT")
    for o in objects:
        o.select_set(True)
    bpy.context.view_layer.objects.active = objects[0]
    # Through the lightmap's own UVs (left to itself, the bake takes the active ones: the texture's, tiled, the light
    # landing on other faces' pixels).
    cycles_bake(type="DIFFUSE", pass_filter={"DIRECT", "INDIRECT"}, margin=margin, margin_type="EXTEND",
                use_clear=True, target="IMAGE_TEXTURES", uv_layer="Lightmap")


def cycles_bake(**settings):
    """Cycles' bake; failing on the graphics card (a card too new for this Blender's OptiX or CUDA: an RTX 5000 one
    failed at once), again on the processor, slower, for the rest of the bake."""
    try:
        bpy.ops.object.bake(**settings)
    except RuntimeError as e:
        cy = bpy.context.scene.cycles
        if cy.device != "GPU":
            raise
        print(f"Bake: the graphics card failed ({e}): on the processor instead (slower)")
        cy.device = "CPU"
        bpy.ops.object.bake(**settings)


def denoise(light):
    """The baked light (h, w, 3, linear) through Blender's own denoiser (OIDN, the compositor's Denoise, HDR): the speckles
    of a bake's samples go, shadow edges stay. Rendered as a composite (Workbench, nothing of the scene drawn) to an EXR."""
    sc = bpy.context.scene
    h, w = light.shape[:2]
    src = bpy.data.images.new("PS denoise in", w, h, float_buffer=True)
    rgba = np.concatenate([light, np.ones((h, w, 1), np.float32)], axis=2).astype(np.float32)
    src.pixels.foreach_set(rgba.ravel())
    tree = bpy.data.node_groups.get("PS denoise") or bpy.data.node_groups.new("PS denoise", "CompositorNodeTree")
    tree.nodes.clear()
    if not tree.interface.items_tree:
        tree.interface.new_socket("Image", in_out="OUTPUT", socket_type="NodeSocketColor")
    n_img = tree.nodes.new("CompositorNodeImage")
    n_img.image = src
    n_dn = tree.nodes.new("CompositorNodeDenoise")
    n_dn.inputs["HDR"].default_value = True
    out = tree.nodes.new("NodeGroupOutput")
    tree.links.new(n_img.outputs[0], n_dn.inputs[0])
    tree.links.new(n_dn.outputs[0], out.inputs[0])
    kept = (sc.compositing_node_group, sc.render.engine, sc.render.resolution_x, sc.render.resolution_y,
            sc.render.resolution_percentage, sc.render.use_compositing, sc.render.filepath, sc.camera,
            sc.render.image_settings.file_format, sc.render.image_settings.color_depth)
    cam = bpy.data.objects.get("PS denoise camera")
    if cam is None:
        cam = bpy.data.objects.new("PS denoise camera", bpy.data.cameras.new("PS denoise camera"))
        sc.collection.objects.link(cam)
    path = os.path.join(bpy.app.tempdir, "ps_denoise.exr")
    try:
        sc.compositing_node_group = tree
        sc.render.engine = "BLENDER_WORKBENCH"
        sc.render.resolution_x, sc.render.resolution_y, sc.render.resolution_percentage = w, h, 100
        sc.render.use_compositing = True
        sc.camera = cam
        sc.render.image_settings.file_format = "OPEN_EXR"
        sc.render.image_settings.color_depth = "32"
        sc.render.filepath = path
        bpy.ops.render.render(write_still=True)
        done = bpy.data.images.load(path, check_existing=False)
        result = pixels(done)[..., :3].copy()
        bpy.data.images.remove(done)
    except Exception as e:  # no denoiser here (an old CPU): the light as baked
        print(f"Bake: not denoised ({e})")
        result = light
    finally:
        (sc.compositing_node_group, sc.render.engine, sc.render.resolution_x, sc.render.resolution_y,
         sc.render.resolution_percentage, sc.render.use_compositing, sc.render.filepath, sc.camera,
         sc.render.image_settings.file_format, sc.render.image_settings.color_depth) = kept
        bpy.data.images.remove(src)
    return np.maximum(result, 0.0)


def pixels(image):
    w, h = image.size
    px = np.empty(w * h * 4, dtype=np.float32)
    image.pixels.foreach_get(px)
    return px.reshape(h, w, 4)


def rgbm(light):
    """Linear light (h, w, 3) as RGBM 8-bit: rgb × m × RGBM_RANGE, m in the alpha. Rows top first for the file."""
    m = np.clip(light.max(axis=2) / RGBM_RANGE, 1.0 / 255.0, 1.0)
    m = np.ceil(m * 255.0) / 255.0
    rgb = np.clip(light / (m[..., None] * RGBM_RANGE), 0.0, 1.0)
    out = np.concatenate([rgb, m[..., None]], axis=2)
    return (out * 255.0 + 0.5).astype(np.uint8)[::-1]


# ---------- Probes ----------
def probe_points(manifest, seen_tris, folder):
    """Where the probes go: over the floor players reach (the radar's walk), one in every PROBE_STEP square a floor height."""
    import radar_gen as rg
    hull = None
    if manifest.get("hull") and os.path.exists(os.path.join(folder, manifest["hull"])):
        hull = rg.Hull(os.path.join(folder, manifest["hull"]))
    blocks, block_tris = [], []
    for group in manifest.get("collision", []):
        if group.get("kind") not in (None, "solid"):  # players stand on these (a model's box too)
            continue
        for b in group.get("blocks", []):
            p = np.array(b["p"], dtype=np.float64).reshape(-1, 3)
            t = np.array(b["t"], dtype=np.int64).reshape(-1, 3)
            if not len(p) or not len(t):
                continue
            p[:, 0] = -p[:, 0]
            t = t[:, ::-1]
            blocks.append((p, t, not b.get("c")))
            block_tris.append(p[t])
    solids = rg.Solids([] if hull else blocks, hull)
    walk_tris = np.concatenate([seen_tris] + ([] if hull else block_tris)) if (len(seen_tris) or block_tris) else seen_tris
    w = rg.walk_map(solids, rg.make_bvh(walk_tris), walk_tris, manifest.get("entities", []))
    spawns = [rg.unity(e["position"]) for e in manifest.get("entities", []) if e.get("type") == "spawn" and e.get("position")]
    reached, seeds = rg.flood(w, spawns)
    if not seeds:
        return np.zeros((0, 3))
    x, y, z = w.colx[w.a_col][reached], w.nh[reached], w.colz[w.a_col][reached]
    key = np.stack([np.floor(x / PROBE_STEP), np.floor(z / PROBE_STEP), np.floor(y / 1.5)], axis=1)
    _, first = np.unique(key, axis=0, return_index=True)
    return np.stack([x[first], y[first] + PROBE_HEIGHT, z[first]], axis=1)


def bake_probes(points, margin_scene_objects):
    """Probe cubes at the points (game space) baked; returns (n, 6, 3) light: game +x -x +y -y +z -z."""
    n = len(points)
    if not n:
        return np.zeros((0, 6, 3))
    faces_total = n * 6
    per_row = int(math.ceil(math.sqrt(faces_total)))
    size = per_row * PROBE_CELL
    image = bpy.data.images.new("PS probes", size, size, float_buffer=True)
    me = bpy.data.meshes.new("PS probes")
    bm = bmesh.new()
    uv = bm.loops.layers.uv.new("Lightmap")
    h = 0.04
    # Blender directions of the game's +x -x +y -y +z -z (game x is Blender -x, game y is Blender z, game z is Blender -y).
    dirs = [Vector((-1, 0, 0)), Vector((1, 0, 0)), Vector((0, 0, 1)), Vector((0, 0, -1)), Vector((0, -1, 0)), Vector((0, 1, 0))]
    cells = []
    for i, u in enumerate(points):
        c = blender(u)
        for k, d in enumerate(dirs):
            # A square facing d, a little out from the probe's middle.
            a = Vector((d.y, d.z, d.x)) if abs(d.x) < 0.5 else Vector((0, 1, 0))
            a = a - d * a.dot(d)
            a.normalize()
            b = d.cross(a)
            centre = c + d * h
            vs = [bm.verts.new(centre + (a * sx + b * sy) * h) for sx, sy in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
            f = bm.faces.new(vs)
            if f.normal.dot(d) < 0:
                f.normal_flip()
            cell = i * 6 + k
            cx, cy = cell % per_row, cell // per_row
            u0, v0 = (cx * PROBE_CELL + 1) / size, (cy * PROBE_CELL + 1) / size
            u1, v1 = (cx * PROBE_CELL + PROBE_CELL - 1) / size, (cy * PROBE_CELL + PROBE_CELL - 1) / size
            for loop, (uu, vv) in zip(f.loops, ((u0, v0), (u1, v0), (u1, v1), (u0, v1))):
                loop[uv].uv = (uu, vv)
            cells.append((cx, cy))
    bm.to_mesh(me)
    bm.free()
    obj = bpy.data.objects.new("PS probes", me)
    bpy.context.scene.collection.objects.link(obj)
    # Seen by nothing else: the probes neither shade the map nor each other.
    for attr in ("visible_shadow", "visible_diffuse", "visible_glossy", "visible_transmission", "visible_volume_scatter"):
        setattr(obj, attr, False)
    me.materials.append(white_material())
    bake_target([obj], image)
    run_bake([obj], 1)
    px = pixels(image)
    out = np.zeros((n, 6, 3), dtype=np.float32)
    for idx, (cx, cy) in enumerate(cells):
        y0, x0 = cy * PROBE_CELL + PROBE_CELL // 2, cx * PROBE_CELL + PROBE_CELL // 2
        out[idx // 6, idx % 6] = px[y0 - 1:y0 + 1, x0 - 1:x0 + 1, :3].mean(axis=(0, 1))
    bpy.data.objects.remove(obj, do_unlink=True)
    return out


# ---------- Ambient zones ----------
AMBIENT_FADE = 48 * UNIT  # past a zone's sides its lift fades out over this (its own: ps_fade, units), smoothly
AMBIENT_REACH = 0.8    # metres its occlusion looks round (corners, under ledges keep a little darker)
AMBIENT_SAMPLES = 32   # Cycles samples of the zones' passes (where each pixel is, how open it is)
LUMA = np.array([0.2126, 0.7152, 0.0722], dtype=np.float32)


def ambient_zones(entities):
    """The map's ambient zones (entities "ambient": a volume of corners, glTF space): (planes (k, 3) normals out and (k,)
    distances, Blender space; its colour, luminance 1; its strength)."""
    zones = []
    for e in entities:
        if e.get("type") != "ambient" or not e.get("points"):
            continue
        p = e["points"]
        pts = [gltf_dir(p[i:i + 3]) for i in range(0, len(p) - 2, 3)]
        bm = bmesh.new()
        for v in pts:
            bm.verts.new(v)
        try:
            bmesh.ops.convex_hull(bm, input=bm.verts[:])
        except (ValueError, RuntimeError):
            bm.free()
            continue
        bm.normal_update()
        centre = sum(pts, Vector()) / len(pts)
        normals, dists = [], []
        for f in bm.faces:
            n = f.normal.copy()
            if n.length < 0.5:
                continue
            d = n.dot(f.verts[0].co)
            if n.dot(centre) > d:
                n, d = -n, -d
            normals.append(tuple(n))
            dists.append(d)
        bm.free()
        if len(normals) < 4:
            continue
        colour = np.array(tuple(e.get("color") or (1.0, 1.0, 1.0))[:3], dtype=np.float32)
        colour = colour / max(float(colour @ LUMA), 1e-3)
        strength = float(e.get("brightness") if e.get("brightness") is not None else 0.06)
        fade = float(e.get("fade") or 0.0) * UNIT or AMBIENT_FADE
        zones.append((np.array(normals, dtype=np.float32), np.array(dists, dtype=np.float32), colour, max(0.0, strength),
                      max(fade, 1e-3)))
    return zones


def lift(light, where, zones, openness=None):
    """The light (n, 3) at points `where` (n, 3, Blender space) lifted inside the ambient zones: in its dark places only
    (where it is already as light as the zone's strength, by half; lighter, hardly), toward the zone's colour, up to its
    strength at most; fading in from the zone's sides; a little less in corners (`openness` 0..1, the pixel's ambient
    occlusion). Where zones overlap, the strongest."""
    gain = np.zeros(len(light), dtype=np.float32)
    tint = np.zeros((len(light), 3), dtype=np.float32)
    for normals, dists, colour, strength, fade in zones:
        inside = (dists[None, :] - where @ normals.T).min(axis=1)
        # Whole within the zone, fading out over `fade` past its sides: a zone drawn to a room lights its walls as much
        # as the players in it (fading in from its sides, the walls on them got next to nothing).
        t = np.clip((inside + fade) / fade, 0.0, 1.0)
        s = strength * t * t * (3.0 - 2.0 * t)  # smoothstep: no edge where it begins nor where it is whole
        better = s > gain
        # Overlapping zones: the strongest, its colour blended in by how much stronger (no edge where one takes over).
        mix = np.where(better, 1.0 - gain / np.maximum(s, 1e-6), 0.0)[:, None]
        tint = tint * (1.0 - mix) + colour[None, :] * mix
        gain = np.maximum(gain, s)
    if not gain.any():
        return light
    lum = np.maximum(light @ LUMA, 0.0)
    amount = gain / (1.0 + (lum / np.maximum(gain, 1e-6)) ** 2)
    if openness is not None:
        amount *= 0.8 + 0.2 * np.clip(openness, 0.0, 1.0)  # corners a little darker only: walls as lit as players
    return light + tint * amount[:, None]


def zone_passes(group, size, margin):
    """Where each lightmap pixel of the group is (Blender space) and how open it is (ambient occlusion, 0..1): (h, w, 3),
    (h, w), for the ambient zones."""
    scene = bpy.context.scene
    kept = scene.cycles.samples
    scene.cycles.samples = AMBIENT_SAMPLES
    if scene.world is not None:
        scene.world.light_settings.distance = AMBIENT_REACH
    out = []
    # Where: each object's materials swapped for one glowing its own position (Cycles' POSITION bake came out bent: a
    # plane at x 5 read 20, the zones lit nothing on the walls), baked as its emission (exact).
    glow = bpy.data.materials.new("PS position")
    glow.use_nodes = True
    tree = glow.node_tree
    tree.nodes.clear()
    geo = tree.nodes.new("ShaderNodeNewGeometry")
    emit = tree.nodes.new("ShaderNodeEmission")
    end = tree.nodes.new("ShaderNodeOutputMaterial")
    tree.links.new(geo.outputs["Position"], emit.inputs["Color"])
    tree.links.new(emit.outputs[0], end.inputs["Surface"])
    meshes = {o.data.name: o.data for o in group}
    own = {name: list(me.materials) for name, me in meshes.items()}
    try:
        for kind in ("EMIT", "AO"):
            if kind == "EMIT":
                for me in meshes.values():
                    for i in range(len(me.materials)):
                        me.materials[i] = glow
            else:
                for name, me in meshes.items():
                    for i, m in enumerate(own[name]):
                        me.materials[i] = m
            image = bpy.data.images.new(f"PS {kind.lower()}", size, size, float_buffer=True)
            bake_target(group, image)
            bpy.ops.object.select_all(action="DESELECT")
            for o in group:
                o.select_set(True)
            bpy.context.view_layer.objects.active = group[0]
            cycles_bake(type=kind, margin=margin, margin_type="EXTEND", use_clear=True,
                        target="IMAGE_TEXTURES", uv_layer="Lightmap")
            px = pixels(image)
            out.append(px[..., :3].copy() if kind == "EMIT" else px[..., 0].copy())
            bpy.data.images.remove(image)
    finally:
        for name, me in meshes.items():
            for i, m in enumerate(own[name]):
                if i < len(me.materials):
                    me.materials[i] = m
        bpy.data.materials.remove(glow)
        scene.cycles.samples = kept
    return out[0], out[1]


# ---------- All of it ----------
def bake(seen, manifest, seen_tris, folder, mode, log=print, blockers=None):
    """Bakes the map's light; returns the manifest's "baked" block. `seen`: the objects going into the .glb (they get
    their Lightmap UVs here, before the export)."""
    clock = time.time()
    units, samples, least = MODES[mode]
    texel = units * UNIT
    scene = bpy.context.scene
    # Only what the game shows takes part (casts and catches light): the collision copies of brushes (where the seen ones
    # are), clips (a stair's ramp over its steps), tool brushes, volumes and references would shade what is seen black.
    shown = {o.name for o in seen}
    for o in scene.objects:
        if o.type in ("MESH", "CURVE", "SURFACE", "META", "FONT") and o.name not in shown:
            o.hide_render = True
    walls = add_blockers(blockers or [])
    device = setup_cycles(scene, samples)
    lamps = setup_lights(scene, manifest.get("entities", []))
    groups, sizes = atlases(seen, texel)
    zones = ambient_zones(manifest.get("entities", []))
    log(f"Bake {mode}: {len(groups)} atlas(es) for {sum(sizes):.0f} m², {lamps} lights, {samples} samples on {device}, "
        f"{len(blockers or [])} faces not seen stopping the light" + (f", {len(zones)} ambient zone(s)" if zones else ""))
    names = []
    files = []
    for i, group in enumerate(groups):
        # As big as the density asks (a power of two, up to an atlas): a small map at Fast is a small picture.
        side = math.sqrt(sizes[i] / FILL) / texel
        size = int(min(ATLAS, max(least, 2 ** math.ceil(math.log2(max(side, 1.0))))))
        unwrap(group, size)
        # As dense as asked, by what the packing really gave (not by the guess above): coarser by more than a seventh,
        # the picture twice as big (up to an atlas).
        got = density(group, size)
        while got > texel * 1.15 and size < ATLAS:
            size *= 2
            repack(group, size)
            got = density(group, size)
        log(f"  atlas {i}: {size}×{size}, {got / UNIT:.1f} units a pixel (asked {units})")
        image = bpy.data.images.new(f"PS lightmap {i}", size, size, float_buffer=True)
        bake_target(group, image)
        # The gaps between islands filled from their edges, half a gap each (the denoiser then draws no black into them).
        # No wider: a margin wider than the gaps (it was a 32nd of the picture, 64 pixels at 2048) ran over other islands,
        # whole roofs taking the light of faces beside them in the picture (shadows where none fall).
        run_bake(group, int(PAD // 2))
        light = denoise(pixels(image)[..., :3].copy())
        if zones:
            where, openness = zone_passes(group, size, int(PAD // 2))
            h, w = light.shape[:2]
            light = lift(light.reshape(-1, 3), where.reshape(-1, 3), zones, openness.reshape(-1)).reshape(h, w, 3)
        name = f"lightmap_{i}.png"
        import radar_gen
        radar_gen.write_png(os.path.join(folder, name), rgbm(light))
        files.append(name)
        for o in group:
            names.append({"node": o.name, "lightmap": i})
        log(f"  atlas {i}: {size}×{size}, {len(group)} objects, {sizes[i]:.0f} m², {time.time() - clock:.0f} s")
    # Old atlases of a bigger bake.
    i = len(files)
    while os.path.exists(os.path.join(folder, f"lightmap_{i}.png")):
        os.remove(os.path.join(folder, f"lightmap_{i}.png"))
        i += 1
    points = probe_points(manifest, seen_tris, folder)
    probes = bake_probes(points, seen)
    if zones and len(points):
        # The probes too (players, weapons): the same lift at each probe, on each of its sides.
        where = np.array([tuple(blender(u)) for u in points], dtype=np.float32)
        n = len(points)
        probes = lift(probes.reshape(-1, 3), np.repeat(where, 6, axis=0), zones).reshape(n, 6, 3)
    clear_targets()
    if walls is not None:
        bpy.data.objects.remove(walls, do_unlink=True)
    log(f"  {len(points)} probes; all {time.time() - clock:.0f} s")
    block = {
        "format": 1, "mode": mode, "encoding": "rgbm8", "range": RGBM_RANGE, "lightmaps": files, "nodes": names,
        "probes": {"p": [round(float(v), 3) for v in points.reshape(-1)],
                   "c": [round(float(v), 4) for v in probes.reshape(-1)]},
    }
    # The objects now seen (big ones were split to fit their atlases).
    kept = [o for g in groups for o in g]
    for o in seen:
        try:
            if o.type != "MESH":
                kept.append(o)
        except ReferenceError:  # split: its halves are in the groups
            pass
    return block, kept
