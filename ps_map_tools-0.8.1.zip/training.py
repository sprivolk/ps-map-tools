"""Training (aim_botz): what a training map needs besides a map's usual things.
- Bot spawn: a spawn with "For bots" — the game's Training bots appear on these, players never do.
- Rule panel: a box on a wall that is one server rule; shot in the game it changes the rule for everyone. The game draws
  it (its title on top, under it a switch, − value + or a button per choice) on its side facing the players' spawns
  ("Flip" turns it the other way).
- Mover (Make mover): a brush or a model that comes out by a rule — cover rising from the floor, a floor plate sinking to
  open a pit. Shown while the rule has the value (or, inverted, while it has not); hidden it has gone down into the floor
  by "Drop" (0: its own height). It moves with its collision; lit by the probes, as doors are.
- No bots zone: a volume bots never appear or run in (the players' place by the rule panels).
- Spray target and Spray pattern (the spray range), Aim screen and Aim board (the aim trainer): boxes on a wall the game
  draws on, facing the players' spawn like the panels."""
import bpy

from . import BRUSH_KEYS, child_collection, object_mode

# The rules a panel or a mover can be (the game's ids); any other id can still be typed in the Object tab.
RULES = [
    ("training.bots", "Bots (number)", ""),
    ("training.botMode", "Bot mode (Static / Strafe / Shuffle / Rush / Peek)", ""),
    ("training.jumps", "Bots jump", ""),
    ("training.crouch", "Bots crouch", ""),
    ("training.cover", "Cover", ""),
    ("training.armor", "Bot armor", ""),
    ("combat.headshotOnly", "Headshots only", ""),
    ("cheats.infiniteMagazine", "Infinite magazine", ""),
    ("cheats.fastReload", "Fast reload", ""),
    ("server.infiniteReserveAmmo", "Infinite reserve ammo", ""),
    ("cheats.showImpacts", "Show impacts", ""),
    ("cheats.showHitboxes", "Show hitboxes", ""),
    ("effects.decals", "Marks and stains", ""),
    ("effects.blood", "Blood", ""),
    ("training.lock", "Lock (the other panels take no shots while on)", ""),
    ("training.aimMode", "Aim trainer (Gridshot / Spidershot / Microshot / Tracking)", ""),
    ("training.aimSize", "Aim target size (cm)", ""),
    ("training.aimCount", "Aim targets at once", ""),
    ("training.aimStep", "Microshot step (cm)", ""),
    ("training.aimTrack", "Tracking difficulty (Easy / Medium / Hard)", ""),
    ("training.high", "Bots on the back platform (Back)", ""),
    ("training.left", "Bots on the left ledges (Left)", ""),
    ("training.right", "Bots on the right ledges (Right)", ""),
    ("training.botSpeed", "Bot speed (Walk / Rifle / Knife / Mix)", ""),
    ("training.botLook", "Bot look (Auto / At you / Own way / Away)", ""),
    ("training.peekTime", "Peek time (Short / Medium / Long)", ""),
]
MOVER_KEYS = {"ps_rule": "training.cover", "ps_value": 1, "ps_invert": 0, "ps_drop": 0.0, "ps_seconds": 0.6}


def is_panel(obj):
    return obj is not None and obj.get("ps_entity") == "rulepanel" and obj.type == "MESH"


def is_mover(obj):
    return obj is not None and obj.get("ps_entity") == "mover" and obj.type == "MESH"


STANDS = {"spraytarget": "Spray target: the game draws the held gun's pattern turned over (a path to drag the crosshair "
                          "along from the black dot) and the player's last spray, coloured bullet by bullet",
          "spraypattern": "Spray pattern: the game draws the held gun's pattern, its bullets numbered",
          "aimscreen": "Aim screen: the aim trainer's balls appear in front of it, each player's own",
          "aimboard": "Aim board: the aim trainer's counters; its bottom is RESET (shot, it clears them)"}


def is_stand(obj):
    return obj is not None and obj.get("ps_entity") in STANDS and obj.type == "MESH"


def is_bot_spawn(obj):
    return obj is not None and obj.get("ps_entity") == "spawn" and bool(obj.get("ps_bot", 0))


def mover_ui(obj):
    ui = obj.id_properties_ui
    ui("ps_value").update(min=0, max=20, description="The rule's value it is out for (a switch: 1 on, 0 off; a choice: "
                                                      "its number from 0)")
    ui("ps_drop").update(min=0.0, soft_max=10.0, description="Metres it goes down when hidden (0: its own height, "
                                                             "just under the floor)")
    ui("ps_seconds").update(min=0.05, max=10.0, description="Seconds it takes to come out or go down")


class MAP_OT_make_mover(bpy.types.Operator):
    bl_idname = "psmap.make_mover"
    bl_label = "Make mover"
    bl_description = ("The selected brushes or models come out by a rule in the game (Training's cover): shown while the "
                      "rule has the value, else down in the floor. A floor plate over a pit: Inverted (in place while the "
                      "cover is off). Rule, value, drop and speed: the Object tab")
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return any(o.type == "MESH" and o.get("ps_entity") in (None, "world", "solid", "detail", "model")
                   for o in context.selected_objects)

    def execute(self, context):
        object_mode(context)
        col = child_collection(context.scene, "Entities")
        made = []
        for o in [o for o in context.selected_objects if o.type == "MESH"
                  and o.get("ps_entity") in (None, "world", "solid", "detail", "model")]:
            for c in list(o.children):
                if c.get("ps_model_box"):
                    bpy.data.objects.remove(c, do_unlink=True)  # it collides as its own box now
            for c in list(o.users_collection):
                c.objects.unlink(o)
            col.objects.link(o)
            for key in BRUSH_KEYS + ("ps_entity", "ps_edge", "ps_edge_clip", "ps_keep"):
                if key in o:
                    del o[key]
            o["ps_entity"] = "mover"
            for key, value in MOVER_KEYS.items():
                if key not in o:
                    o[key] = value
            mover_ui(o)
            o.display_type = "TEXTURED"
            made.append(o)
        self.report({"INFO"}, f"{len(made)} mover(s): out while {MOVER_KEYS['ps_rule']} is 1; the Object tab sets them")
        return {"FINISHED"} if made else {"CANCELLED"}


class MAP_OT_mover_back(bpy.types.Operator):
    bl_idname = "psmap.mover_back"
    bl_label = "Not a mover"
    bl_description = "The selected mover a brush again (into Seen)"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        from . import make_brush
        seen = child_collection(context.scene, "Seen")
        for o in [o for o in context.selected_objects if is_mover(o)]:
            for key in list(MOVER_KEYS) + ["ps_entity"]:
                if key in o:
                    del o[key]
            for c in list(o.users_collection):
                c.objects.unlink(o)
            seen.objects.link(o)
            make_brush(o)
        return {"FINISHED"}


class MAP_OT_training_set(bpy.types.Operator):
    bl_idname = "psmap.training_set"
    bl_label = "Set"
    bl_description = "Set this on the selected objects"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}
    key: bpy.props.StringProperty()
    value: bpy.props.StringProperty()

    def execute(self, context):
        for o in context.selected_objects:
            if self.key in ("ps_bot", "ps_flip", "ps_invert"):
                o[self.key] = int(self.value)
            else:
                o[self.key] = self.value
        return {"FINISHED"}


class MAP_OT_training_rule(bpy.types.Operator):
    bl_idname = "psmap.training_rule"
    bl_label = "Rule"
    bl_description = "Which server rule it is"
    bl_options = {"REGISTER", "UNDO", "INTERNAL"}
    rule: bpy.props.EnumProperty(items=RULES)

    def execute(self, context):
        for o in context.selected_objects:
            if is_panel(o) or is_mover(o):
                o["ps_rule"] = self.rule
        return {"FINISHED"}


def rule_name(rule_id):
    return next((name for r, name, _ in RULES if r == rule_id), rule_id)


def draw(layout, obj):
    """A rule panel's, a mover's or a bot spawn's settings (the Object tab)."""
    box = layout.box()
    if is_panel(obj):
        box.label(text="Rule panel: shot in the game, it changes its rule", icon="RESTRICT_SELECT_OFF")
        box.operator_menu_enum("psmap.training_rule", "rule", text=f"Rule: {rule_name(str(obj.get('ps_rule', '')))}")
        box.prop(obj, '["ps_rule"]', text="Rule id")
        if "ps_label" in obj:
            box.prop(obj, '["ps_label"]', text="Title (empty: the rule's own)")
        flip = bool(obj.get("ps_flip", 0))
        op = box.operator("psmap.training_set", text="Faces away from the spawns" if flip else "Faces the players' spawns",
                          depress=flip, icon="ARROW_LEFTRIGHT")
        op.key, op.value = "ps_flip", "0" if flip else "1"
        box.label(text="Drawn by the game on its thin side; about 1.6 × 0.9 m reads well from the spawn")
    elif is_stand(obj):
        box.label(text=STANDS[obj["ps_entity"]], icon="SHADING_TEXTURE")
        if "ps_distance" in obj:
            box.prop(obj, '["ps_distance"]', text="Firing line (m)")
        flip = bool(obj.get("ps_flip", 0))
        op = box.operator("psmap.training_set", text="Faces away from the spawns" if flip else "Faces the players' spawn",
                          depress=flip, icon="ARROW_LEFTRIGHT")
        op.key, op.value = "ps_flip", "0" if flip else "1"
    elif is_mover(obj):
        box.label(text="Mover: comes out by a rule (cover), with its collision", icon="TRIA_UP_BAR")
        box.operator_menu_enum("psmap.training_rule", "rule", text=f"Rule: {rule_name(str(obj.get('ps_rule', '')))}")
        col = box.column(align=True)
        for key, text in (("ps_value", "Out while the rule is"), ("ps_drop", "Drop when hidden (m, 0: its height)"),
                          ("ps_seconds", "Moves in (s)")):
            if key in obj:
                col.prop(obj, f'["{key}"]', text=text)
        inverted = bool(obj.get("ps_invert", 0))
        op = col.operator("psmap.training_set", text="Inverted: out while it is NOT (a pit's lid)" if inverted
                          else "Out while it is", depress=inverted, icon="CHECKBOX_HLT" if inverted else "CHECKBOX_DEHLT")
        op.key, op.value = "ps_invert", "0" if inverted else "1"
        box.operator("psmap.mover_back", icon="LOOP_BACK")


def draw_spawn(col, obj):
    """The spawn's "For bots" switch (Training)."""
    bot = bool(obj.get("ps_bot", 0))
    op = col.operator("psmap.training_set", text="For bots (Training): on" if bot else "For bots (Training): off",
                      depress=bot, icon="CHECKBOX_HLT" if bot else "CHECKBOX_DEHLT")
    op.key, op.value = "ps_bot", "0" if bot else "1"


CLASSES = [MAP_OT_make_mover, MAP_OT_mover_back, MAP_OT_training_set, MAP_OT_training_rule]
