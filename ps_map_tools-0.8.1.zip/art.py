"""Art materials and groups: dressing a map once its brushes play well.

- Art materials: a shared library of pictures (ArtSource/Materials/<name>/, or the add-on's preference): each folder one
  material — its colour picture and material.json {"surface": "plaster", "size": 2.0} (what bullets and steps meet, and how
  many metres the picture covers). Put on a brush, it lies by the world like the Dev textures (texture lock), at its own
  size; the export keeps its picture and size (a Mapping node), so the game draws it as it is. The library is what counts:
  a material put on again takes the library's picture, surface and size.
- Groups: a name on objects (ps_group: the house, the bridge) to select them all, or see only them while dressing them.
  The objects stay in their own collections: the export and the mirror do not know of groups.
"""
import json
import os
import re
import shutil
import time

import bpy
from .translations import tr
import bpy.utils.previews
import numpy as np

from . import ART, TILE, SURFACES, in_seen

META = "material.json"
PICTURES = (".png", ".jpg", ".jpeg", ".tga", ".tif", ".tiff", ".webp", ".bmp")
# Not a colour picture (a downloaded set: ambientCG, Poly Haven).
NOT_COLOUR = ("normal", "nrm", "rough", "gloss", "_ao", "ambientocclusion", "height", "disp", "bump", "mask", "metal",
              "spec", "opacity", "_alpha")
DEFAULT_SIZE = 2.0
GROUP = "ps_group"
UP = "_Vertical"  # a grain pair's upright half: <name>_Vertical, the picture turned 90 degrees

_lib = {"time": 0.0, "path": "", "items": []}
_previews = [None]
_quiet = [False]


# ---------- The library ----------
def library():
    """The library's folder: the add-on's preference, else ArtSource/Materials beside the add-on."""
    try:
        own = bpy.context.preferences.addons[__package__].preferences.materials_path
    except (KeyError, AttributeError):
        own = ""
    return os.path.normpath(bpy.path.abspath(own)) if own else os.path.join(ART, "Materials")


def colour_picture(folder, name):
    files = sorted(f for f in os.listdir(folder) if f.lower().endswith(PICTURES))

    def stem(f):
        return os.path.splitext(f)[0].lower()
    for f in files:
        if stem(f) == name.lower():
            return os.path.join(folder, f)
    for f in files:
        if any(k in stem(f) for k in ("color", "colour", "albedo", "basecolor", "diff")):
            return os.path.join(folder, f)
    for f in files:
        if not any(k in stem(f) for k in NOT_COLOUR):
            return os.path.join(folder, f)
    return None


def read_meta(folder):
    try:
        with open(os.path.join(folder, META), encoding="utf-8") as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def write_meta(name, **changes):
    folder = os.path.join(library(), name)
    if not os.path.isdir(folder):
        return
    data = read_meta(folder)
    data.update(changes)
    with open(os.path.join(folder, META), "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    _lib["time"] = 0.0


def items(force=False):
    """The library's materials: [{name, picture, surface, size}], looked through again every few seconds."""
    path = library()
    if not force and path == _lib["path"] and time.time() - _lib["time"] < 3.0:
        return _lib["items"]
    found = []
    if os.path.isdir(path):
        for name in sorted(os.listdir(path), key=str.lower):
            folder = os.path.join(path, name)
            if not os.path.isdir(folder):
                continue
            picture = colour_picture(folder, name)
            if picture is None:
                continue
            meta = read_meta(folder)
            surface = str(meta.get("surface", "default"))
            raw = meta.get("size", DEFAULT_SIZE)
            try:
                # one size (a square picture), or [width, height]: a picture taller than wide on the walls (a sheet wall
                # with moss at its foot, the moss not repeated up the wall)
                if isinstance(raw, (list, tuple)) and len(raw) >= 2:
                    size = (max(0.05, float(raw[0])), max(0.05, float(raw[1])))
                else:
                    size = max(0.05, float(raw))
            except (TypeError, ValueError):
                size = DEFAULT_SIZE
            found.append({"name": name, "picture": picture, "surface": surface if surface in SURFACES else "default",
                          "size": size})
    _lib.update(time=time.time(), path=path, items=found)
    return found


def find(name):
    return next((i for i in items() if i["name"] == name), None)


def icon(item):
    pcoll = _previews[0]
    if pcoll is None:
        return 0
    key = item["picture"]
    if key not in pcoll:
        try:
            pcoll.load(key, key, "IMAGE")
        except (RuntimeError, KeyError):
            return 0
    return pcoll[key].icon_id


# ---------- The material in the .blend ----------
def material_name(name):
    return "Art " + name


def scale_of(size):
    # The brushes' UVs: one per Dev tile (TILE metres); the picture covers `size` metres.
    return TILE / max(size, 0.05)


def mapping_of(mat):
    if mat.node_tree is None:
        return None
    return next((n for n in mat.node_tree.nodes if n.type == "MAPPING"), None)


def set_size(mat, size):
    m = mapping_of(mat)
    if m is not None:
        if isinstance(size, (list, tuple)):
            m.inputs["Scale"].default_value = (scale_of(size[0]), scale_of(size[1]), 1.0)
        else:
            k = scale_of(size)
            m.inputs["Scale"].default_value = (k, k, 1.0)


def average_colour(image):
    try:
        w, h = image.size
        if not w or not h:
            return (0.6, 0.6, 0.6)
        px = np.empty(w * h * image.channels, dtype=np.float32)
        image.pixels.foreach_get(px)
        rgb = px.reshape(-1, image.channels)[::max(1, (w * h) // 4096), :3].mean(axis=0)
        return tuple(float(c) for c in rgb)
    except (RuntimeError, ValueError):
        return (0.6, 0.6, 0.6)


def load_picture(path):
    image = bpy.data.images.load(path, check_existing=True)
    if bpy.data.filepath:
        try:
            image.filepath = bpy.path.relpath(path)
        except ValueError:  # another drive
            pass
    return image


def same_file(a, b):
    return os.path.normcase(os.path.abspath(bpy.path.abspath(a))) == os.path.normcase(os.path.abspath(b))


def art_material(item):
    """The library's material in this file, made or brought up to the library (picture, surface, size)."""
    name = material_name(item["name"])
    mat = bpy.data.materials.get(name)
    if mat is None or mapping_of(mat) is None:
        if mat is None:
            mat = bpy.data.materials.new(name)
        if mat.node_tree is None:
            mat.use_nodes = True
        tree = mat.node_tree
        tree.nodes.clear()
        out = tree.nodes.new("ShaderNodeOutputMaterial")
        out.location = (600, 0)
        bsdf = tree.nodes.new("ShaderNodeBsdfPrincipled")
        bsdf.location = (300, 0)
        bsdf.inputs["Roughness"].default_value = 0.9
        tex = tree.nodes.new("ShaderNodeTexImage")
        tex.location = (0, 0)
        mapping = tree.nodes.new("ShaderNodeMapping")
        mapping.location = (-200, 0)
        coords = tree.nodes.new("ShaderNodeTexCoord")
        coords.location = (-400, 0)
        tree.links.new(coords.outputs["UV"], mapping.inputs["Vector"])
        tree.links.new(mapping.outputs["Vector"], tex.inputs["Vector"])
        tree.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
        tree.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
        mat.use_fake_user = True
    tex = next((n for n in mat.node_tree.nodes if n.type == "TEX_IMAGE"), None)
    if tex is not None and (tex.image is None or not same_file(tex.image.filepath, item["picture"])):
        tex.image = load_picture(item["picture"])
        mat.diffuse_color = (*average_colour(tex.image), 1.0)
    mat["ps_art"] = item["name"]
    if item["surface"] == "default":
        mat.pop("ps_surface", None)
    else:
        mat["ps_surface"] = item["surface"]
    _quiet[0] = True
    try:
        mat.ps_art_size = item["size"][0] if isinstance(item["size"], tuple) else item["size"]
    finally:
        _quiet[0] = False
    set_size(mat, item["size"])  # (after: the property's own update sets a square size)
    mat["ps_art_tall"] = isinstance(item["size"], tuple)
    return mat


def on_size(mat, context):
    set_size(mat, mat.ps_art_size)
    if not _quiet[0] and mat.get("ps_art"):
        write_meta(str(mat["ps_art"]), size=round(mat.ps_art_size, 3))


def active_art(context):
    obj = context.active_object
    mat = obj.active_material if obj is not None else None
    return mat if mat is not None and mat.get("ps_art") else None


# ---------- Operators: art materials ----------
class MAP_OT_art_apply(bpy.types.Operator):
    bl_idname = "psmap.art_apply"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Art material"
    bl_description = "Put this library material on the selected brushes (in Edit Mode: on the selected faces)"
    name: bpy.props.StringProperty()

    def execute(self, context):
        item = find(self.name)
        if item is None:
            self.report({"WARNING"}, tr(f"{self.name}: not in the library", "reports"))
            return {"CANCELLED"}
        mat = art_material(item)
        set_current(context.scene, self.name)
        up = find(self.name + UP)
        if up is not None:
            return grain_apply(context, mat, art_material(up))
        return bpy.ops.psmap.material(name=mat.name)


# ---------- Grain pairs: the grain along the brush ----------
def long_axis(o):
    pts = [o.matrix_world @ v.co for v in o.data.vertices]
    if not pts:
        return 0
    size = [max(p[i] for p in pts) - min(p[i] for p in pts) for i in range(3)]
    return max(range(3), key=lambda i: size[i])


def along(normal_axis, axis):
    """Does a face's world-mapped texture run its grain (across the picture) along `axis`? The brushes' UVs: a face
    looking along X takes (y, z), along Y (x, z), along Z (x, y)."""
    return axis == {0: 1, 1: 0, 2: 0}[normal_axis] or axis == normal_axis


def slot(me, mat):
    i = me.materials.find(mat.name)
    if i < 0:
        me.materials.append(mat)
        i = len(me.materials) - 1
    return i


def grain_apply(context, mat, mat_up):
    """The pair on the selected brushes (in Edit Mode: their selected faces): each face the half whose grain runs along
    the brush's longest side; tool faces (a clip) kept."""
    import bmesh
    from . import make_brush, is_brush
    obj = context.active_object
    if obj is not None and obj.mode == "EDIT":
        for o in [o for o in context.objects_in_mode if o.type == "MESH"]:
            axis = long_axis(o)
            a, b = slot(o.data, mat), slot(o.data, mat_up)
            rot = o.matrix_world.to_3x3()
            bm = bmesh.from_edit_mesh(o.data)
            for f in bm.faces:
                if f.select:
                    n = rot @ f.normal
                    f.material_index = a if along(max(range(3), key=lambda i: abs(n[i])), axis) else b
            bmesh.update_edit_mesh(o.data)
        return {"FINISHED"}
    for o in [o for o in context.selected_objects if o.type == "MESH"]:
        me = o.data
        old = list(me.materials)
        tools = []
        for m in old:
            if m is not None and m.get("ps_tool") and m not in tools:
                tools.append(m)
        axis = long_axis(o)
        rot = o.matrix_world.to_3x3()
        index = []
        for f in me.polygons:
            m = old[f.material_index] if f.material_index < len(old) else None
            if m is not None and m in tools:
                index.append(2 + tools.index(m))
                continue
            n = rot @ f.normal
            index.append(0 if along(max(range(3), key=lambda i: abs(n[i])), axis) else 1)
        me.materials.clear()
        for m in [mat, mat_up] + tools:
            me.materials.append(m)
        me.polygons.foreach_set("material_index", index)
        me.update()
        if not is_brush(o) and in_seen(o):
            make_brush(o)
    return {"FINISHED"}


class MAP_OT_art_replace(bpy.types.Operator):
    bl_idname = "psmap.art_replace"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Replace"
    bl_description = ("Instead of the active object's active material: this one, wherever that material is on the selected "
                      "objects (a group selected: Dev Plaster → the house's plaster on every wall at once)")
    name: bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.active_material is not None and obj.mode == "OBJECT"

    def execute(self, context):
        item = find(self.name)
        if item is None:
            return {"CANCELLED"}
        old = context.active_object.active_material
        new = art_material(item)
        done = 0
        for o in context.selected_objects:
            if o.type != "MESH":
                continue
            for slot in o.material_slots:
                if slot.material == old:
                    slot.material = new
                    done += 1
        self.report({"INFO"}, tr(f"{old.name} → {new.name}: {done} slot(s)", "reports"))
        return {"FINISHED"}


def safe_name(text):
    text = re.sub(r"[^\w\- ]+", "", text.strip()).strip().replace(" ", "_")
    return text[:48]


class MAP_OT_art_new(bpy.types.Operator):
    bl_idname = "psmap.art_new"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "New from picture"
    bl_description = ("A colour picture into the library (copied into a folder of its own) as a material: its name, surface "
                      "and how many metres it covers are set on the right of the file window")
    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    filter_image: bpy.props.BoolProperty(default=True, options={"HIDDEN"})
    filter_folder: bpy.props.BoolProperty(default=True, options={"HIDDEN"})
    name: bpy.props.StringProperty(name="Name", description="Empty: the picture's name")
    surface: bpy.props.EnumProperty(name="Surface", items=[(s, s, "") for s in SURFACES], default="default",
                                    description="What bullets go through, what steps and hits sound like")
    size: bpy.props.FloatProperty(name="Picture covers", default=DEFAULT_SIZE, min=0.05, max=64.0, unit="LENGTH",
                                  description="How many metres of a wall the picture covers before it repeats")

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        src = bpy.path.abspath(self.filepath)
        if not os.path.isfile(src) or not src.lower().endswith(PICTURES):
            self.report({"WARNING"}, tr("Choose a picture", "reports"))
            return {"CANCELLED"}
        stem = os.path.splitext(os.path.basename(src))[0]
        bare = re.sub(r"(?i)[_\- ]*(color|colour|albedo|basecolor|diffuse|diff)$", "", stem) or stem
        name = safe_name(self.name or bare)
        if not name:
            self.report({"WARNING"}, tr("Give it a name", "reports"))
            return {"CANCELLED"}
        folder = os.path.join(library(), name)
        os.makedirs(folder, exist_ok=True)
        dst = os.path.join(folder, name + os.path.splitext(src)[1].lower())
        if os.path.normcase(os.path.abspath(src)) != os.path.normcase(os.path.abspath(dst)):
            shutil.copyfile(src, dst)
        write_meta(name, surface=self.surface, size=round(self.size, 3))
        items(force=True)
        item = find(name)
        if item is None:
            return {"CANCELLED"}
        art_material(item)
        self.report({"INFO"}, tr(f"{name}: in the library ({folder})", "reports"))
        return {"FINISHED"}


class MAP_OT_art_surface(bpy.types.Operator):
    bl_idname = "psmap.art_surface"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Surface"
    bl_description = "The active art material's surface (what bullets go through, steps and hits), kept in the library"
    surface: bpy.props.EnumProperty(name="Surface", items=[(s, s, "") for s in SURFACES])

    def execute(self, context):
        mat = active_art(context)
        if mat is None:
            return {"CANCELLED"}
        if self.surface == "default":
            mat.pop("ps_surface", None)
        else:
            mat["ps_surface"] = self.surface
        write_meta(str(mat["ps_art"]), surface=self.surface)
        return {"FINISHED"}


class MAP_OT_art_refresh(bpy.types.Operator):
    bl_idname = "psmap.art_refresh"
    bl_label = "Look again"
    bl_description = ("Read the library again, and bring this file's art materials up to it (a picture painted over, a "
                      "size or surface changed in material.json)")

    def execute(self, context):
        if _previews[0] is not None:
            _previews[0].clear()
        lib = {i["name"]: i for i in items(force=True)}
        for mat in [m for m in bpy.data.materials if m.get("ps_art") in lib]:
            art_material(lib[mat["ps_art"]])
            tex = next((n for n in mat.node_tree.nodes if n.type == "TEX_IMAGE"), None)
            if tex is not None and tex.image is not None:
                tex.image.reload()
                mat.diffuse_color = (*average_colour(tex.image), 1.0)
        return {"FINISHED"}


class MAP_OT_art_open(bpy.types.Operator):
    bl_idname = "psmap.art_open"
    bl_label = "Open the library's folder"
    bl_description = "The library's folder in Explorer"

    def execute(self, context):
        os.makedirs(library(), exist_ok=True)
        bpy.ops.wm.path_open(filepath=library())
        return {"FINISHED"}


# ---------- Groups ----------
def group_of(obj):
    return str(obj.get(GROUP, "") or "")


def groups(scene):
    counts = {}
    for o in scene.objects:
        g = group_of(o)
        if g:
            counts[g] = counts.get(g, 0) + 1
    return sorted(counts.items(), key=lambda kv: kv[0].lower())


def only_group(scene):
    return str(scene.get("ps_only_group", "") or "")


def show_all(scene, view_layer):
    for name in list(scene.get("ps_only_hidden", []) or []):
        o = scene.objects.get(name)
        if o is not None:
            try:
                o.hide_set(False, view_layer=view_layer)
            except RuntimeError:
                pass
    for key in ("ps_only_hidden", "ps_only_group"):
        if key in scene:
            del scene[key]


class MAP_OT_group_set(bpy.types.Operator):
    bl_idname = "psmap.group_set"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Into a group"
    bl_description = "The selected objects into a group (a name: the house), to select them all or see only them"
    name: bpy.props.StringProperty(name="Group", default="House")

    @classmethod
    def poll(cls, context):
        return bool(context.selected_objects)

    def invoke(self, context, event):
        obj = context.active_object
        if obj is not None and group_of(obj):
            self.name = group_of(obj)
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        name = self.name.strip()
        if not name:
            return {"CANCELLED"}
        for o in context.selected_objects:
            o[GROUP] = name
        self.report({"INFO"}, tr(f"{len(context.selected_objects)} object(s) in {name}", "reports"))
        return {"FINISHED"}


class MAP_OT_group_clear(bpy.types.Operator):
    bl_idname = "psmap.group_clear"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Out of the group"
    bl_description = "The selected objects in no group"

    @classmethod
    def poll(cls, context):
        return any(group_of(o) for o in context.selected_objects)

    def execute(self, context):
        for o in context.selected_objects:
            if GROUP in o:
                del o[GROUP]
        return {"FINISHED"}


class MAP_OT_group_rename(bpy.types.Operator):
    bl_idname = "psmap.group_rename"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Rename"
    bl_description = "A new name for this group"
    group: bpy.props.StringProperty()
    name: bpy.props.StringProperty(name="Name")

    def invoke(self, context, event):
        self.name = self.group
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        name = self.name.strip()
        if not name:
            return {"CANCELLED"}
        for o in context.scene.objects:
            if group_of(o) == self.group:
                o[GROUP] = name
        if only_group(context.scene) == self.group:
            context.scene["ps_only_group"] = name
        return {"FINISHED"}


class MAP_OT_group_select(bpy.types.Operator):
    bl_idname = "psmap.group_select"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Select"
    bl_description = "Select the group's objects (Shift: added to what is selected)"
    group: bpy.props.StringProperty()
    extend: bpy.props.BoolProperty(default=False, options={"SKIP_SAVE"})

    def invoke(self, context, event):
        self.extend = event.shift
        return self.execute(context)

    def execute(self, context):
        obj = context.active_object
        if obj is not None and obj.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        layer = context.view_layer
        if not self.extend:
            for o in list(layer.objects.selected):
                if o is not None:
                    o.select_set(False)
        first = None
        for o in context.scene.objects:
            if group_of(o) == self.group and o.visible_get(view_layer=layer):
                o.select_set(True)
                first = first or o
        if first is not None and (layer.objects.active is None or group_of(layer.objects.active) != self.group):
            layer.objects.active = first
        return {"FINISHED"}


class MAP_OT_group_only(bpy.types.Operator):
    bl_idname = "psmap.group_only"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Only this group"
    bl_description = "See only this group's objects in every view (the rest hidden); pressed again: everything back"
    group: bpy.props.StringProperty()

    def execute(self, context):
        scene, layer = context.scene, context.view_layer
        was = only_group(scene)
        show_all(scene, layer)
        if was == self.group or not self.group:
            return {"FINISHED"}
        hidden = []
        for o in scene.objects:
            if group_of(o) == self.group or not o.visible_get(view_layer=layer):
                continue
            try:
                o.hide_set(True, view_layer=layer)
                hidden.append(o.name)
            except RuntimeError:
                pass
        scene["ps_only_hidden"] = hidden
        scene["ps_only_group"] = self.group
        return {"FINISHED"}


# ---------- The Art tab: the current material, the eyedropper, working in a group ----------
def current(scene):
    return str(scene.get("ps_art_current", "") or "")


def set_current(scene, name):
    scene["ps_art_current"] = name


class MAP_OT_art_put(bpy.types.Operator):
    bl_idname = "psmap.art_put"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Put"
    bl_description = "Put the current material (picked or last put) on the selected brushes (in Edit Mode: the selected faces)"

    @classmethod
    def poll(cls, context):
        return bool(current(context.scene))

    def execute(self, context):
        name = current(context.scene)
        if find(name) is not None:
            return bpy.ops.psmap.art_apply(name=name)
        if bpy.data.materials.get(name) is not None:
            return bpy.ops.psmap.material(name=name)
        return {"CANCELLED"}


class MAP_OT_art_pick(bpy.types.Operator):
    bl_idname = "psmap.art_pick"
    bl_label = "Pick"
    bl_description = "Eyedropper: click a face in the view, its material becomes the current one (Esc: stop)"

    def modal(self, context, event):
        context.area.header_text_set("Pick a material: click a face · Esc / right click: stop")
        if event.type in {"ESC", "RIGHTMOUSE"} and event.value == "PRESS":
            context.area.header_text_set(None)
            return {"CANCELLED"}
        if event.type == "LEFTMOUSE" and event.value == "PRESS":
            from bpy_extras import view3d_utils
            region, rv3d = context.region, context.region_data
            co = (event.mouse_region_x, event.mouse_region_y)
            origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, co)
            ray = view3d_utils.region_2d_to_vector_3d(region, rv3d, co)
            dg = context.evaluated_depsgraph_get()
            hit, _, _, index, obj, _ = context.scene.ray_cast(dg, origin, ray)
            context.area.header_text_set(None)
            if not hit or obj is None or obj.type != "MESH":
                self.report({"WARNING"}, tr("Nothing there", "reports"))
                return {"CANCELLED"}
            src = obj.original
            me = src.data
            if index >= len(me.polygons) or not me.materials:
                return {"CANCELLED"}
            mat = me.materials[me.polygons[index].material_index]
            if mat is None:
                return {"CANCELLED"}
            name = str(mat["ps_art"]) if mat.get("ps_art") else mat.name
            if name.endswith(UP) and find(name[:-len(UP)]) is not None:
                name = name[:-len(UP)]
            set_current(context.scene, name)
            self.report({"INFO"}, tr(f"Current: {name}", "reports"))
            for a in context.screen.areas:
                a.tag_redraw()
            return {"FINISHED"}
        return {"RUNNING_MODAL"} if event.type not in {"MIDDLEMOUSE", "WHEELUPMOUSE", "WHEELDOWNMOUSE",
                                                       "TRACKPADPAN", "TRACKPADZOOM"} else {"PASS_THROUGH"}

    def invoke(self, context, event):
        if context.area is None or context.area.type != "VIEW_3D":
            self.report({"WARNING"}, tr("In the 3D view", "reports"))
            return {"CANCELLED"}
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}


class MAP_OT_group_work(bpy.types.Operator):
    bl_idname = "psmap.group_work"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Work in this group"
    bl_description = ("Only this group in the views, selected and in sight, to dress it like a prop; pressed again "
                      "(or Stop): everything back")
    group: bpy.props.StringProperty()

    def execute(self, context):
        scene = context.scene
        if only_group(scene) == self.group or not self.group:
            show_all(scene, context.view_layer)
            return {"FINISHED"}
        bpy.ops.psmap.group_only(group=self.group)
        bpy.ops.psmap.group_select(group=self.group)
        for area in context.screen.areas:
            if area.type == "VIEW_3D":
                region = next((r for r in area.regions if r.type == "WINDOW"), None)
                if region is not None:
                    with context.temp_override(area=area, region=region):
                        bpy.ops.view3d.view_selected()
        return {"FINISHED"}


CLASSES = [MAP_OT_art_put, MAP_OT_art_pick, MAP_OT_group_work, MAP_OT_art_apply, MAP_OT_art_replace, MAP_OT_art_new, MAP_OT_art_surface, MAP_OT_art_refresh, MAP_OT_art_open,
           MAP_OT_group_set, MAP_OT_group_clear, MAP_OT_group_rename, MAP_OT_group_select, MAP_OT_group_only]


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    bpy.types.Scene.ps_art_columns = bpy.props.IntProperty(name="Columns", default=2, min=1, max=6,
                                                          description="Material tiles side by side")
    bpy.types.Scene.ps_art_tile = bpy.props.FloatProperty(name="Tile size", default=5.0, min=2.0, max=12.0,
                                                         description="How big the material pictures are drawn")
    bpy.types.Material.ps_art_size = bpy.props.FloatProperty(
        name="Picture covers", default=DEFAULT_SIZE, min=0.05, max=64.0, unit="LENGTH", update=on_size,
        description="How many metres the picture covers before it repeats (kept in the library)")
    _previews[0] = bpy.utils.previews.new()


def unregister():
    if _previews[0] is not None:
        bpy.utils.previews.remove(_previews[0])
        _previews[0] = None
    del bpy.types.Material.ps_art_size
    del bpy.types.Scene.ps_art_columns
    del bpy.types.Scene.ps_art_tile
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
