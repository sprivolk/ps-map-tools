"""Who is editing which part (a map in parts, connected to GitHub).

- Changing something in a part marks it as yours on GitHub («sprivolk is editing A site»); while you keep changing it
  the mark is kept fresh (every 10 minutes); Send frees the parts it sent; 30 minutes without a change and the mark
  counts as gone (Blender closed, forgotten).
- A part someone else is editing: its objects here can't be selected (grey in the list, a lock and their name);
  «Edit anyway» lets you in; changing it anyway warns once; Send over it asks first.
- Everyone's marks are asked for every minute.

The marks live in .psmap-team/editing.json on a branch of their own (psmap-team), so the map's history keeps only the
map's changes."""
import base64
import json
import threading
import time

import bpy

from . import parts as P

BRANCH = "psmap-team"
FILE = ".psmap-team/editing.json"
STALE = 30 * 60
BEAT = 10 * 60
POLL = 60
KEPT = "_psmap_lock"  # an object's own hide_select while someone else's part holds it

_s = {"locks": {}, "for": "", "edited": {}, "warned": set(), "unlocked": set(), "worker": None, "polled": 0.0,
      "beat": {}, "error": ""}


def fresh(entry, now=None):
    return bool(entry) and (now or time.time()) - entry.get("seen", entry.get("since", 0)) < STALE


def holder(part, me):
    """Who else is editing the part now (None: nobody, or you)."""
    e = _s["locks"].get(part)
    if fresh(e) and e.get("user") != me:
        return e.get("user")
    return None


def mine(part, me):
    e = _s["locks"].get(part)
    return fresh(e) and e.get("user") == me


# ---------- GitHub (worker thread) ----------
def _path(repo):
    from .github import q
    return q(repo.prefix + FILE)


def _ensure_branch(repo):
    try:
        repo.call("GET", f"/git/ref/heads/{BRANCH}")
    except Exception as e:
        if getattr(e, "args", (0,))[0] not in (404, 409):
            raise
        repo.call("POST", "/git/refs", {"ref": f"refs/heads/{BRANCH}", "sha": repo.head(create=True)})


def read(repo):
    try:
        got = repo.call("GET", f"/contents/{_path(repo)}?ref={BRANCH}")
        return json.loads(base64.b64decode(got["content"]).decode("utf-8") or "{}"), got["sha"]
    except Exception as e:
        if getattr(e, "args", (0,))[0] == 404:
            return {}, None
        raise


def change(repo, me, take=(), release=(), beat=()):
    """One write of the marks: parts taken, freed, kept fresh (stale ones of anyone dropped)."""
    _ensure_branch(repo)
    for _ in range(4):
        locks, sha = read(repo)
        now = int(time.time())
        locks = {k: v for k, v in locks.items() if fresh(v, now)}
        for p in take:
            if not fresh(locks.get(p)) or locks[p].get("user") == me:
                locks[p] = {"user": me, "since": locks.get(p, {}).get("since", now) if locks.get(p, {}).get("user") == me
                            else now, "seen": now}
        for p in beat:
            if locks.get(p, {}).get("user") == me:
                locks[p]["seen"] = now
        for p in release:
            if locks.get(p, {}).get("user") == me:
                del locks[p]
        body = {"message": f"editing: {me}", "branch": BRANCH,
                "content": base64.b64encode(json.dumps(locks, indent=1, sort_keys=True).encode()).decode("ascii")}
        if sha:
            body["sha"] = sha
        try:
            repo.call("PUT", f"/contents/{_path(repo)}", body)
            return locks
        except Exception as e:
            if getattr(e, "args", (0,))[0] not in (409, 422):
                raise
    return read(repo)[0]


def _work(token, full, branch, folder, me, take, release, beat):
    from .github import Repo
    try:
        repo = Repo(token, full, branch, folder)
        locks = change(repo, me, take, release, beat) if (take or release or beat) else read(repo)[0]
        _s["locks"], _s["for"], _s["error"] = locks, full, ""
        now = time.time()
        for p in list(take) + list(beat):
            _s["beat"][p] = now
        for p in release:
            _s["beat"].pop(p, None)
    except Exception as e:
        _s["error"] = str(e)[:120]


# ---------- here (main thread) ----------
def _context():
    """(account, state, scene) when the open map is in parts, connected, signed in and online; else None."""
    from .github import account, read_state
    if not bpy.app.online_access or not bpy.data.filepath:
        return None
    acc = account()
    if not acc["token"]:
        return None
    state = read_state(bpy.data.filepath)
    scene = bpy.context.scene
    if not state or not P.is_split(scene):
        return None
    return acc, state, scene


def apply_locks(scene, me):
    """Someone else's parts: their objects can't be selected here (each object's own setting kept and given back)."""
    pm = P.part_map(scene)
    with P.quiet():
        for name, part in pm.items():
            o = bpy.data.objects.get(name)
            if o is None:
                continue
            closed = holder(part, me) is not None and part not in _s["unlocked"]
            if closed and KEPT not in o:
                o[KEPT] = int(o.hide_select)
                o.hide_select = True
            elif not closed and KEPT in o:
                o.hide_select = bool(o[KEPT])
                del o[KEPT]


def free_all():
    with P.quiet():
        for o in bpy.data.objects:
            if KEPT in o:
                o.hide_select = bool(o[KEPT])
                del o[KEPT]


def _tick():
    try:
        ctx = _context()
    except Exception:
        ctx = None
    if ctx is None:
        if any(KEPT in o for o in bpy.data.objects):
            free_all()
        return 2.0
    acc, state, scene = ctx
    me, now = acc["login"], time.time()
    if _s["for"] != state["repo"]:
        _s["locks"], _s["for"], _s["unlocked"], _s["warned"] = {}, state["repo"], set(), set()
    apply_locks(scene, me)
    if _s["worker"] is not None and _s["worker"].is_alive():
        return 2.0
    take = [p for p, t in _s["edited"].items() if now - t < STALE and not mine(p, me) and holder(p, me) is None]
    beat = [p for p, t in _s["edited"].items() if now - t < STALE and mine(p, me) and now - _s["beat"].get(p, 0) > BEAT]
    # Freed for idling only what this session marked: a mark from before (Blender reopened) runs out by itself.
    idle = [p for p, e in _s["locks"].items() if e.get("user") == me and fresh(e)
            and p in _s["edited"] and now - _s["edited"][p] > STALE]
    if take or beat or idle or now - _s["polled"] > POLL:
        _s["polled"] = now
        _s["worker"] = threading.Thread(target=_work, daemon=True, args=(
            acc["token"], state["repo"], state.get("branch", ""), state.get("folder", ""), me, take, idle, beat))
        _s["worker"].start()
    return 2.0


@bpy.app.handlers.persistent
def on_depsgraph(scene, depsgraph):
    """A change in a part: it is yours (taken on the next tick); in someone else's part: warned once."""
    if P.is_quiet() or not _s["for"]:
        return
    changed = set()
    for u in depsgraph.updates:
        if isinstance(u.id, bpy.types.Object) and (u.is_updated_transform or u.is_updated_geometry):
            changed.add(u.id.original.name)
    if not changed:
        return
    pm = P.part_map(scene)
    from .github import account
    me = account()["login"]
    now = time.time()
    for name in changed:
        part = pm.get(name)
        if part is None:
            continue
        _s["edited"][part] = now
        who = holder(part, me)
        if who and part not in _s["warned"]:
            _s["warned"].add(part)
            text = f"{who} is editing {part} now: if you go on, one of you will choose whose version stays"
            bpy.app.timers.register(lambda: _warn(text), first_interval=0.05)


def _warn(text):
    def draw(menu, context):
        menu.layout.label(text=text, icon="ERROR")
    bpy.context.window_manager.popup_menu(draw, title="Someone is editing this part", icon="LOCKED")
    return None


def sent(token, full, branch, folder, me, parts_sent):
    """After a Send (its thread): the parts sent are free again."""
    from .github import Repo
    mine_now = [p for p in parts_sent if _s["locks"].get(p, {}).get("user") == me]
    for p in parts_sent:
        _s["edited"].pop(p, None)
    if mine_now:
        try:
            _s["locks"] = change(Repo(token, full, branch, folder), me, release=mine_now)
        except Exception:
            pass


def editing_others(parts_list, me):
    """{part: who} of the parts someone else is editing now."""
    return {p: holder(p, me) for p in parts_list if holder(p, me)}


class MAP_OT_parts_unlock(bpy.types.Operator):
    bl_idname = "psmap.parts_unlock"
    bl_label = "Edit anyway"
    bl_description = ("Lets you select and change this part here although someone is editing it: then one of you will "
                      "choose whose version stays")
    part: bpy.props.StringProperty()

    def execute(self, context):
        _s["unlocked"].add(self.part)
        from .github import account
        apply_locks(context.scene, account()["login"])
        return {"FINISHED"}


def row_badge(row, part, me):
    """In the parts' tree: who edits the part."""
    who = holder(part, me)
    if who:
        row.label(text=who, icon="LOCKED")
        if part not in _s["unlocked"]:
            row.operator("psmap.parts_unlock", text="", icon="UNLOCKED").part = part
    elif mine(part, me):
        row.label(text="you", icon="GREASEPENCIL")


@bpy.app.handlers.persistent
def on_load(_):
    _s.update(locks={}, edited={}, warned=set(), unlocked=set(), beat={}, polled=0.0)
    _s["for"] = ""
    for o in bpy.data.objects:  # saved while someone's part was closed: the own setting back
        if KEPT in o:
            o.hide_select = bool(o[KEPT])
            del o[KEPT]


CLASSES = [MAP_OT_parts_unlock]


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    bpy.app.handlers.depsgraph_update_post.append(on_depsgraph)
    bpy.app.handlers.load_post.append(on_load)
    bpy.app.timers.register(_tick, first_interval=2.0, persistent=True)


def unregister():
    if bpy.app.timers.is_registered(_tick):
        bpy.app.timers.unregister(_tick)
    for lst, fn in ((bpy.app.handlers.depsgraph_update_post, on_depsgraph), (bpy.app.handlers.load_post, on_load)):
        if fn in lst:
            lst.remove(fn)
    free_all()
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
