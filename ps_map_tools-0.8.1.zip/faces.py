"""Faces (Art tab): a texture moved, turned, scaled or fitted on a face, like Hammer's face edit, and patchwork — faces
cut into sheets, materials mixed over them, sheets shuffled.

A brush's UVs come from the world (texture lock, world_uvs); each face may carry its own shift, turn and scale, kept in
face attributes the UVs are made through every time:
  ps_tex_off (u, v, - : in Dev tiles of 64 units), ps_tex_scale (u, v, - : the picture that many times bigger;
  0 = 1), both 3-float vectors (what bmesh makes),
  ps_tex_rot (radians). uv = turn(world uv / scale) + shift.
A mirror copy takes them with its mesh. A brush made by a maker (stairs, arches) is built again from its settings: its
face settings go then."""
import math
import random

import bmesh
import bpy
from .translations import tr
import numpy as np

from . import TILE, UNIT, is_brush

OFF, SCALE, ROT = "ps_tex_off", "ps_tex_scale", "ps_tex_rot"


def face_transform(me, n):
    """(offsets (n, 2), scales (n, 2), turns (n)) of the mesh's faces, or None when it has none."""
    a_off, a_sc, a_rot = (me.attributes.get(k) for k in (OFF, SCALE, ROT))
    if a_off is None and a_sc is None and a_rot is None:
        return None
    def vec(a):
        out = np.zeros((n, 2), np.float32)
        if a is not None and a.domain == "FACE" and a.data_type in ("FLOAT_VECTOR", "FLOAT2"):
            w = 3 if a.data_type == "FLOAT_VECTOR" else 2
            buf = np.empty(n * w, np.float32)
            a.data.foreach_get("vector", buf)
            out = buf.reshape(-1, w)[:, :2].copy()
        return out
    off, sc = vec(a_off), vec(a_sc)
    rot = np.zeros(n, np.float32)
    if a_rot is not None and a_rot.domain == "FACE" and a_rot.data_type == "FLOAT":
        a_rot.data.foreach_get("value", rot)
    sc[np.abs(sc) < 1e-6] = 1.0
    return off, sc, rot


def apply_transform(uv, loop_poly, tr):
    """The world UVs (n loops, 2) through each face's shift, turn and scale."""
    off, sc, rot = tr
    uv = uv / sc[loop_poly]
    c, s = np.cos(rot)[loop_poly], np.sin(rot)[loop_poly]
    u = uv[:, 0] * c - uv[:, 1] * s
    v = uv[:, 0] * s + uv[:, 1] * c
    return np.stack([u, v], axis=1) + off[loop_poly]


# ---------- Working on the selected faces ----------
def selected_faces(context):
    """[(object, bmesh, [faces])] of the meshes in Edit Mode with faces selected; in Object Mode every face of the
    selected brushes (a temporary bmesh each, written back by done())."""
    out = []
    obj = context.active_object
    if obj is not None and obj.mode == "EDIT":
        for o in [o for o in context.objects_in_mode if o.type == "MESH"]:
            bm = bmesh.from_edit_mesh(o.data)
            Layers(bm)  # made first: a new layer leaves the faces taken before it dead
            faces = [f for f in bm.faces if f.select]
            if faces:
                out.append((o, bm, faces))
    else:
        for o in [o for o in context.selected_objects if o.type == "MESH" and is_brush(o)]:
            bm = bmesh.new()
            bm.from_mesh(o.data)
            Layers(bm)
            out.append((o, bm, list(bm.faces)))
    return out


def done(context, items):
    from . import world_uvs
    edit = context.active_object is not None and context.active_object.mode == "EDIT"
    for o, bm, _ in items:
        if edit:
            bmesh.update_edit_mesh(o.data)
        else:
            bm.to_mesh(o.data)
            bm.free()
            o.data.update()
            world_uvs(o)
    if edit:
        # The UVs are made in Object Mode: there and back (the selection stays).
        bpy.ops.object.mode_set(mode="OBJECT")
        for o, _, _ in items:
            world_uvs(o)
        bpy.ops.object.mode_set(mode="EDIT")


class Layers:
    """The face layers of a bmesh (made when missing): off, scale (float2 as float vectors), rot."""

    def __init__(self, bm):
        self.off = bm.faces.layers.float_vector.get(OFF) or bm.faces.layers.float_vector.new(OFF)
        self.sc = bm.faces.layers.float_vector.get(SCALE) or bm.faces.layers.float_vector.new(SCALE)
        self.rot = bm.faces.layers.float.get(ROT) or bm.faces.layers.float.new(ROT)

    def get(self, f):
        o, s = f[self.off], f[self.sc]
        return [o[0], o[1]], [s[0] if abs(s[0]) > 1e-6 else 1.0, s[1] if abs(s[1]) > 1e-6 else 1.0], f[self.rot]

    def set(self, f, off, sc, rot):
        f[self.off] = (off[0], off[1], 0.0)
        f[self.sc] = (sc[0], sc[1], 0.0)
        f[self.rot] = rot


def world_uv0(o, f):
    """The face's world UVs before its own shift and scale: [(u, v)] of its corners, in Dev tiles."""
    mw = o.matrix_world
    n = mw.to_3x3() @ f.normal
    axis = max(range(3), key=lambda i: abs(n[i]))
    out = []
    for v in f.verts:
        p = mw @ v.co
        out.append(((p.y if axis == 0 else p.x) / TILE, (p.y if axis == 2 else p.z) / TILE))
    return out


def picture_repeat(o, f):
    """How many times the face's material repeats in one UV unit (its Mapping node's scale; 1 without)."""
    mats = o.data.materials
    m = mats[f.material_index] if f.material_index < len(mats) else None
    if m is not None and m.node_tree is not None:
        node = next((n for n in m.node_tree.nodes if n.type == "MAPPING"), None)
        if node is not None:
            return float(node.inputs["Scale"].default_value[0]) or 1.0
    return 1.0


class MAP_OT_face_tex(bpy.types.Operator):
    bl_idname = "psmap.face_tex"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Texture on faces"
    bl_description = "The texture on the selected faces (Object Mode: on all faces of the selected brushes)"
    action: bpy.props.EnumProperty(items=[
        ("left", "←", "Move the texture left by the grid step"), ("right", "→", "Move it right by the grid step"),
        ("up", "↑", "Move it up by the grid step"), ("down", "↓", "Move it down by the grid step"),
        ("ccw", "⟲", "Turn it 90° to the left"), ("cw", "⟳", "Turn it 90° to the right"),
        ("bigger", "×2", "Twice as big"), ("smaller", "÷2", "Half as big"),
        ("fit", "Fit", "The picture once over the whole face"), ("fit_u", "Fit ↔", "The picture once across the face"),
        ("reset", "Reset", "Back to the world's: no shift, turn or scale"),
        ("copy", "Copy active", "The active face's shift, turn and scale on the selected faces")],
        options={"SKIP_SAVE"})

    def execute(self, context):
        items = selected_faces(context)
        if not items:
            self.report({"WARNING"}, tr("Select faces (Edit Mode) or brushes", "reports"))
            return {"CANCELLED"}
        step = context.scene.ps_grid_units * UNIT / TILE
        src = None
        if self.action == "copy":
            for o, bm, _ in items:
                if bm.faces.active is not None and bm.faces.active.select:
                    src = Layers(bm).get(bm.faces.active)
                    break
            if src is None:
                self.report({"WARNING"}, tr("No active face (click one last)", "reports"))
                return {"CANCELLED"}
        for o, bm, faces in items:
            L = Layers(bm)
            for f in faces:
                off, sc, rot = L.get(f)
                a = self.action
                if a in ("left", "right", "up", "down"):
                    d = step / (sc[0] if a in ("left", "right") else sc[1])
                    if a == "left":
                        off[0] += d
                    elif a == "right":
                        off[0] -= d
                    elif a == "up":
                        off[1] -= d
                    else:
                        off[1] += d
                elif a in ("ccw", "cw"):
                    rot = (rot + (math.pi / 2 if a == "ccw" else -math.pi / 2)) % (2 * math.pi)
                elif a == "bigger":
                    sc = [sc[0] * 2, sc[1] * 2]
                elif a == "smaller":
                    sc = [sc[0] / 2, sc[1] / 2]
                elif a in ("fit", "fit_u"):
                    uv = world_uv0(o, f)
                    k = picture_repeat(o, f)
                    us, vs = [p[0] for p in uv], [p[1] for p in uv]
                    du, dv = max(us) - min(us), max(vs) - min(vs)
                    rot = 0.0
                    su = max(du * k, 1e-4)
                    sv = max(dv * k, 1e-4) if a == "fit" else su
                    sc = [su, sv]
                    off = [-min(us) / su, -min(vs) / sv]
                elif a == "reset":
                    off, sc, rot = [0.0, 0.0], [1.0, 1.0], 0.0
                elif a == "copy":
                    off, sc, rot = list(src[0]), list(src[1]), src[2]
                L.set(f, off, sc, rot)
        done(context, items)
        return {"FINISHED"}


# ---------- Patchwork ----------
def mix_list(scene):
    return [n for n in str(scene.get("ps_mix", "") or "").split("|") if n]


def set_mix(scene, names):
    scene["ps_mix"] = "|".join(names)


class MAP_OT_cut_panels(bpy.types.Operator):
    bl_idname = "psmap.cut_panels"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Cut into sheets"
    bl_description = ("The selected faces cut on a world grid of sheets (as the panels on the textures): each sheet a "
                      "face of its own, for Mix and Shuffle. The brush stays the same shape")
    width: bpy.props.FloatProperty(name="Sheet width", default=1.2, min=0.1, max=20, unit="LENGTH")
    height: bpy.props.FloatProperty(name="Sheet height", default=2.4, min=0.1, max=20, unit="LENGTH")

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.mode == "EDIT"

    def execute(self, context):
        from mathutils import Vector
        cut = 0
        for o in [o for o in context.objects_in_mode if o.type == "MESH"]:
            bm = bmesh.from_edit_mesh(o.data)
            mw, inv = o.matrix_world, o.matrix_world.inverted()
            sel = [f for f in bm.faces if f.select]
            if not sel:
                continue
            pts = [mw @ v.co for f in sel for v in f.verts]
            # Planes across X and Y every sheet width, across Z every sheet height (on the world's grid: the
            # textures' seams lie there too); a face parallel to a plane is not cut by it.
            for d, size in ((0, self.width), (1, self.width), (2, self.height)):
                lo, hi = min(p[d] for p in pts), max(p[d] for p in pts)
                k = math.floor(lo / size + 1e-6) + 1
                while k * size < hi - 1e-4:
                    co, no = Vector((0.0, 0.0, 0.0)), Vector((0.0, 0.0, 0.0))
                    co[d], no[d] = k * size, 1.0
                    live = [f for f in bm.faces if f.select]
                    geom = live + list({e for f in live for e in f.edges}) + list({v for f in live for v in f.verts})
                    res = bmesh.ops.bisect_plane(bm, geom=geom, plane_co=inv @ co,
                                                 plane_no=(inv.to_3x3().transposed() @ no).normalized(), dist=1e-5)
                    for g in res["geom"]:  # the cut faces' pieces stay selected for the next cuts
                        if isinstance(g, bmesh.types.BMFace):
                            g.select = True
                    cut += 1
                    k += 1
            bmesh.update_edit_mesh(o.data)
        self.report({"INFO"}, tr(f"{cut} cuts", "reports"))
        return {"FINISHED"}


class MAP_OT_mix(bpy.types.Operator):
    bl_idname = "psmap.mix"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Mix"
    bl_description = "The mix's materials over the selected faces at random (Cut into sheets first for patchwork)"
    seed: bpy.props.IntProperty(name="Seed", default=1, description="Another seed: another patchwork")
    first: bpy.props.IntProperty(name="First one, %", default=60, min=0, max=100,
                                 description="How many of the faces keep the mix's first material (the main one)")

    @classmethod
    def poll(cls, context):
        return bool(mix_list(context.scene))

    def execute(self, context):
        from . import art
        mats = []
        for name in mix_list(context.scene):
            item = art.find(name)
            if item is not None:
                mats.append(art.art_material(item))
            elif bpy.data.materials.get(name) is not None:
                mats.append(bpy.data.materials[name])
        if not mats:
            return {"CANCELLED"}
        rng = random.Random(self.seed)
        items = selected_faces(context)
        for o, bm, faces in items:
            me = o.data
            slots = []
            for m in mats:
                i = me.materials.find(m.name)
                if i < 0:
                    me.materials.append(m)
                    i = len(me.materials) - 1
                slots.append(i)
            for f in faces:
                cur = me.materials[f.material_index] if f.material_index < len(me.materials) else None
                if cur is not None and cur.get("ps_tool"):
                    continue
                if len(slots) == 1 or rng.random() * 100 < self.first:
                    f.material_index = slots[0]
                else:
                    f.material_index = rng.choice(slots[1:])
        done(context, items)
        return {"FINISHED"}


class MAP_OT_shuffle(bpy.types.Operator):
    bl_idname = "psmap.shuffle"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Shuffle sheets"
    bl_description = ("Each selected face's texture shifted by whole sheets and turned round at random: the same "
                      "picture, not the same sheet side by side")
    step: bpy.props.FloatProperty(name="Sheet width", default=1.2, min=0.05, max=20, unit="LENGTH")
    seed: bpy.props.IntProperty(name="Seed", default=1)

    def execute(self, context):
        rng = random.Random(self.seed)
        items = selected_faces(context)
        for o, bm, faces in items:
            L = Layers(bm)
            for f in faces:
                off, sc, rot = L.get(f)
                off = [rng.randint(0, 7) * self.step / TILE / sc[0], rng.randint(0, 3) * self.step / TILE / sc[1]]
                rot = math.pi if rng.random() < 0.5 else 0.0
                L.set(f, off, sc, rot)
        done(context, items)
        return {"FINISHED"}


class MAP_OT_mix_edit(bpy.types.Operator):
    bl_idname = "psmap.mix_edit"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Mix list"
    bl_description = "Add the current material to the mix, or take one out"
    name: bpy.props.StringProperty(options={"SKIP_SAVE"})
    remove: bpy.props.BoolProperty(options={"SKIP_SAVE"})

    def execute(self, context):
        from . import art
        names = mix_list(context.scene)
        if self.remove:
            names = [n for n in names if n != self.name]
        else:
            name = self.name or art.current(context.scene)
            if name and name not in names:
                names.append(name)
        set_mix(context.scene, names)
        return {"FINISHED"}


CLASSES = [MAP_OT_face_tex, MAP_OT_cut_panels, MAP_OT_mix, MAP_OT_shuffle, MAP_OT_mix_edit]
