"""Dressing (Art tab): props and decals put on the map with a click, props scattered over faces, and prefabs — a group
made once and placed as linked copies.

- Props: a library of .blend files (ArtSource/Props/<name>.blend, the first mesh in each; a picture <name>.png beside
  it shows in the list). Put on the map they are models (models.py: their own UVs, lit as players are), copies sharing
  one mesh. Add to library writes the active mesh there.
- Decals: a library of pictures with transparency (ArtSource/Decals/<name>/<name>.png + decal.json {"size": [w, h]} in
  metres): a flat Detail brush on the face, a hair off it, its picture cut out by its alpha, lit by the bake as the walls.
- Placing (Place): the thing follows the mouse over the surfaces, standing on them (its up along the face's);
  R / Shift+R turn it, + / − size it, Ctrl snaps to the grid, click puts it and goes on, right click / Esc stops.
- Prefabs: a group made a prefab (a collection of its objects, which stay where they are: the first copy); Place copy
  puts a linked copy at the 3D cursor (an instance: changing the group changes every copy); Make real turns a copy into
  objects of its own. The export makes the copies real objects first.
"""
import json
import math
import os
import random
import re
import shutil

import bmesh
import bpy
from .translations import tr
import bpy.utils.previews
from mathutils import Matrix, Quaternion, Vector

from . import ART, UNIT, child_collection

PROPS = os.path.join(ART, "Props")
DECALS = os.path.join(ART, "Decals")
_previews = [None]
_cache = {"props": None, "decals": None}


def safe(text):
    return re.sub(r"[^\w\- ]+", "", text.strip()).strip().replace(" ", "_")[:48]


def icon_for(path):
    pc = _previews[0]
    if pc is None or not path or not os.path.isfile(path):
        return 0
    if path not in pc:
        try:
            pc.load(path, path, "IMAGE")
        except (RuntimeError, KeyError):
            return 0
    return pc[path].icon_id


# ---------- Libraries ----------
def props(force=False):
    if _cache["props"] is None or force:
        out = []
        if os.path.isdir(PROPS):
            for f in sorted(os.listdir(PROPS), key=str.lower):
                if f.lower().endswith(".blend"):
                    name = f[:-6]
                    pic = os.path.join(PROPS, name + ".png")
                    out.append({"name": name, "path": os.path.join(PROPS, f), "picture": pic if os.path.isfile(pic) else ""})
        _cache["props"] = out
    return _cache["props"]


def decals(force=False):
    if _cache["decals"] is None or force:
        out = []
        if os.path.isdir(DECALS):
            for name in sorted(os.listdir(DECALS), key=str.lower):
                folder = os.path.join(DECALS, name)
                pic = os.path.join(folder, name + ".png")
                if not os.path.isfile(pic):
                    continue
                size = [1.0, 1.0]
                try:
                    with open(os.path.join(folder, "decal.json"), encoding="utf-8") as f:
                        size = [float(x) for x in json.load(f).get("size", size)][:2]
                except (OSError, ValueError, TypeError):
                    pass
                out.append({"name": name, "picture": pic, "size": size})
        _cache["decals"] = out
    return _cache["decals"]


def prop_source(name):
    """The prop's mesh object, loaded once from its .blend (kept out of the scene, by a fake user)."""
    key = "PS prop " + name
    src = bpy.data.objects.get(key)
    if src is not None:
        return src
    item = next((p for p in props() if p["name"] == name), None)
    if item is None:
        return None
    with bpy.data.libraries.load(item["path"], link=False) as (data_from, data_to):
        data_to.objects = list(data_from.objects)
    meshes = [o for o in data_to.objects if o is not None and o.type == "MESH"]
    for o in data_to.objects:
        if o is not None and o not in meshes[:1]:
            bpy.data.objects.remove(o)
    if not meshes:
        return None
    src = meshes[0]
    src.name = key
    src.use_fake_user = True
    src.matrix_world = Matrix.Identity(4)
    return src


def decal_material(item):
    name = "Decal " + item["name"]
    mat = bpy.data.materials.get(name)
    if mat is not None:
        return mat
    mat = bpy.data.materials.new(name)
    if mat.node_tree is None:
        mat.use_nodes = True
    tree = mat.node_tree
    tree.nodes.clear()
    out = tree.nodes.new("ShaderNodeOutputMaterial")
    bsdf = tree.nodes.new("ShaderNodeBsdfPrincipled")
    tex = tree.nodes.new("ShaderNodeTexImage")
    tex.image = bpy.data.images.load(item["picture"], check_existing=True)
    tree.links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
    tree.links.new(tex.outputs["Alpha"], bsdf.inputs["Alpha"])  # cut out by its alpha (the export's MASK)
    tree.links.new(bsdf.outputs["BSDF"], out.inputs["Surface"])
    bsdf.inputs["Roughness"].default_value = 0.9
    try:
        mat.surface_render_method = "DITHERED"
    except (AttributeError, TypeError):
        pass
    mat.use_backface_culling = True
    mat["ps_decal"] = item["name"]
    mat.use_fake_user = True
    return mat


def decal_object(context, item, like=None):
    w, h = item["size"]
    me = bpy.data.meshes.new("Decal " + item["name"])
    bm = bmesh.new()
    uv = bm.loops.layers.uv.new("UVMap")
    vs = [bm.verts.new((x * w / 2, y * h / 2, 0.0)) for x, y in ((-1, -1), (1, -1), (1, 1), (-1, 1))]
    f = bm.faces.new(vs)
    for loop, c in zip(f.loops, ((0, 0), (1, 0), (1, 1), (0, 1))):
        loop[uv].uv = c
    bm.to_mesh(me)
    bm.free()
    me.materials.append(decal_material(item))
    obj = bpy.data.objects.new("Decal " + item["name"], me)
    col = child_collection(context.scene, "Seen")
    col.objects.link(obj)
    obj["ps_brush"] = 1
    obj["ps_entity"] = "detail"
    obj["ps_own_uv"] = 1
    obj["ps_decal"] = item["name"]
    return obj


def prop_object(context, name, collide):
    from . import models
    src = prop_source(name)
    if src is None:
        return None
    obj = src.copy()  # the same mesh: copies share it
    obj.name = name
    obj.use_fake_user = False
    col = child_collection(context.scene, models.MODELS)
    col.objects.link(obj)
    obj["ps_entity"] = "model"
    obj["ps_prop"] = name
    obj.display_type = "TEXTURED"
    if collide:
        models.add_box(obj, col)
    return obj


# ---------- Placing by the mouse ----------
def surface_under(context, event, skip):
    from bpy_extras import view3d_utils
    region, rv3d = context.region, context.region_data
    co = (event.mouse_region_x, event.mouse_region_y)
    origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, co)
    ray = view3d_utils.region_2d_to_vector_3d(region, rv3d, co)
    dg = context.evaluated_depsgraph_get()
    for _ in range(8):
        hit, loc, normal, _, obj, _ = context.scene.ray_cast(dg, origin, ray)
        if not hit:
            return None
        if obj is not None and (obj.original in skip or obj.original.parent in skip):
            origin = loc + ray * 1e-3
            continue
        return loc, normal.normalized()
    return None


class MAP_OT_place(bpy.types.Operator):
    bl_idname = "psmap.place"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Place"
    bl_description = ("Put it on the surfaces with the mouse: R / Shift+R turn, + / − size, Ctrl snap to the grid, click "
                      "put (and go on), right click / Esc stop")
    kind: bpy.props.EnumProperty(items=[("prop", "Prop", ""), ("decal", "Decal", "")])
    name: bpy.props.StringProperty()
    collide: bpy.props.BoolProperty(name="Collision box", default=False)

    def new_one(self, context):
        if self.kind == "prop":
            self.obj = prop_object(context, self.name, False)
        else:
            item = next((d for d in decals() if d["name"] == self.name), None)
            self.obj = decal_object(context, item) if item else None
        if self.obj is not None:
            self.obj.scale = (self.size,) * 3

    def place(self, context, event):
        found = surface_under(context, event, {self.obj})
        if found is None:
            return
        loc, n = found
        if event.ctrl:
            step = context.scene.ps_grid_units * UNIT
            loc = Vector(round(c / step) * step for c in loc)
        q = Quaternion(n, self.spin) @ n.to_track_quat("Z", "Y")
        self.obj.rotation_mode = "QUATERNION"
        self.obj.rotation_quaternion = q
        self.obj.location = loc + n * (0.003 if self.kind == "decal" else 0.0)

    def modal(self, context, event):
        context.area.header_text_set("Click: put · R / Shift+R: turn · + / −: size · Ctrl: grid · Esc / right click: stop")
        if event.type in {"ESC", "RIGHTMOUSE"} and event.value == "PRESS":
            if self.obj is not None:
                me = self.obj.data
                bpy.data.objects.remove(self.obj, do_unlink=True)
                if me.users == 0:
                    bpy.data.meshes.remove(me)
            context.area.header_text_set(None)
            self.report({"INFO"}, tr(f"{self.count} put", "reports"))
            return {"FINISHED"} if self.count else {"CANCELLED"}
        if event.type == "MOUSEMOVE":
            self.place(context, event)
        elif event.type == "R" and event.value == "PRESS":
            self.spin += math.radians(-15 if event.shift else 15)
            self.place(context, event)
        elif event.type in {"NUMPAD_PLUS", "EQUAL", "PLUS"} and event.value == "PRESS":
            self.size *= 1.1
            self.obj.scale = (self.size,) * 3
        elif event.type in {"NUMPAD_MINUS", "MINUS"} and event.value == "PRESS":
            self.size /= 1.1
            self.obj.scale = (self.size,) * 3
        elif event.type == "LEFTMOUSE" and event.value == "PRESS":
            self.place(context, event)
            if self.kind == "prop" and self.collide:
                from . import models
                models.add_box(self.obj, self.obj.users_collection[0])
            self.count += 1
            self.new_one(context)
            self.place(context, event)
        elif event.type in {"MIDDLEMOUSE", "WHEELUPMOUSE", "WHEELDOWNMOUSE", "TRACKPADPAN", "TRACKPADZOOM"}:
            return {"PASS_THROUGH"}
        return {"RUNNING_MODAL"}

    def invoke(self, context, event):
        if context.area is None or context.area.type != "VIEW_3D":
            self.report({"WARNING"}, tr("In the 3D view", "reports"))
            return {"CANCELLED"}
        if context.active_object is not None and context.active_object.mode != "OBJECT":
            bpy.ops.object.mode_set(mode="OBJECT")
        self.spin, self.size, self.count = 0.0, 1.0, 0
        self.new_one(context)
        if self.obj is None:
            self.report({"WARNING"}, tr(f"{self.name}: not in the library", "reports"))
            return {"CANCELLED"}
        self.place(context, event)
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}


class MAP_OT_scatter(bpy.types.Operator):
    bl_idname = "psmap.scatter"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Scatter"
    bl_description = "The prop over the selected faces (Edit Mode) at random: standing on them, turned and sized at random"
    name: bpy.props.StringProperty()
    count: bpy.props.IntProperty(name="How many", default=10, min=1, max=2000)
    size_min: bpy.props.FloatProperty(name="Size from", default=0.8, min=0.05, max=10)
    size_max: bpy.props.FloatProperty(name="to", default=1.2, min=0.05, max=10)
    turn: bpy.props.BoolProperty(name="Turn at random", default=True)
    seed: bpy.props.IntProperty(name="Seed", default=1)

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.mode == "EDIT"

    def execute(self, context):
        rng = random.Random(self.seed)
        tris = []
        for o in [o for o in context.objects_in_mode if o.type == "MESH"]:
            bm = bmesh.from_edit_mesh(o.data)
            mw = o.matrix_world
            for f in bm.faces:
                if not f.select:
                    continue
                vs = [mw @ v.co for v in f.verts]
                n = (mw.to_3x3() @ f.normal).normalized()
                for i in range(1, len(vs) - 1):
                    a, b, c = vs[0], vs[i], vs[i + 1]
                    tris.append(((b - a).cross(c - a).length / 2, a, b, c, n))
        if not tris:
            self.report({"WARNING"}, tr("Select faces", "reports"))
            return {"CANCELLED"}
        bpy.ops.object.mode_set(mode="OBJECT")
        total = sum(t[0] for t in tris)
        made = 0
        for _ in range(self.count):
            r, acc = rng.random() * total, 0.0
            tri = tris[-1]
            for t in tris:
                acc += t[0]
                if acc >= r:
                    tri = t
                    break
            _, a, b, c, n = tri
            u, v = rng.random(), rng.random()
            if u + v > 1:
                u, v = 1 - u, 1 - v
            p = a + (b - a) * u + (c - a) * v
            obj = prop_object(context, self.name, False)
            if obj is None:
                return {"CANCELLED"}
            spin = rng.random() * 2 * math.pi if self.turn else 0.0
            obj.rotation_mode = "QUATERNION"
            obj.rotation_quaternion = Quaternion(n, spin) @ n.to_track_quat("Z", "Y")
            obj.location = p
            obj.scale = (rng.uniform(self.size_min, self.size_max),) * 3
            made += 1
        self.report({"INFO"}, tr(f"{made} {self.name}", "reports"))
        return {"FINISHED"}


class MAP_OT_prop_add(bpy.types.Operator):
    bl_idname = "psmap.prop_add"
    bl_options = {"REGISTER"}
    bl_label = "Add to library"
    bl_description = ("The active mesh into the props library (ArtSource/Props/<name>.blend), its origin the point it "
                      "stands on, its up the way it stands")
    name: bpy.props.StringProperty(name="Name")

    @classmethod
    def poll(cls, context):
        return context.active_object is not None and context.active_object.type == "MESH"

    def invoke(self, context, event):
        self.name = safe(context.active_object.name.split(".")[0])
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        name = safe(self.name)
        if not name:
            return {"CANCELLED"}
        os.makedirs(PROPS, exist_ok=True)
        src = context.active_object
        copy = src.copy()
        copy.data = src.data.copy()
        copy.matrix_world = Matrix.Identity(4)
        copy.name = name
        for k in list(copy.keys()):
            if k.startswith("ps_"):
                del copy[k]
        path = os.path.join(PROPS, name + ".blend")
        bpy.data.libraries.write(path, {copy}, path_remap="ABSOLUTE", fake_user=True)
        me = copy.data
        bpy.data.objects.remove(copy)
        bpy.data.meshes.remove(me)
        props(force=True)
        self.report({"INFO"}, tr(f"{name}: {path}", "reports"))
        return {"FINISHED"}


class MAP_OT_decal_new(bpy.types.Operator):
    bl_idname = "psmap.decal_new"
    bl_options = {"REGISTER"}
    bl_label = "New decal"
    bl_description = "A picture with transparency (PNG) into the decal library, with its size on the map"
    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    filter_image: bpy.props.BoolProperty(default=True, options={"HIDDEN"})
    filter_folder: bpy.props.BoolProperty(default=True, options={"HIDDEN"})
    name: bpy.props.StringProperty(name="Name", description="Empty: the picture's name")
    width: bpy.props.FloatProperty(name="Width", default=1.0, min=0.02, max=50, unit="LENGTH",
                                   description="Its width on the map; the height goes by the picture")

    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def execute(self, context):
        src = bpy.path.abspath(self.filepath)
        if not os.path.isfile(src) or not src.lower().endswith(".png"):
            self.report({"WARNING"}, tr("A PNG picture (with transparency)", "reports"))
            return {"CANCELLED"}
        name = safe(self.name or os.path.splitext(os.path.basename(src))[0])
        folder = os.path.join(DECALS, name)
        os.makedirs(folder, exist_ok=True)
        dst = os.path.join(folder, name + ".png")
        if os.path.normcase(os.path.abspath(src)) != os.path.normcase(os.path.abspath(dst)):
            shutil.copyfile(src, dst)
        img = bpy.data.images.load(dst, check_existing=True)
        w, h = img.size
        aspect = h / w if w else 1.0
        with open(os.path.join(folder, "decal.json"), "w", encoding="utf-8") as f:
            json.dump({"size": [round(self.width, 3), round(self.width * aspect, 3)]}, f, indent=2)
        decals(force=True)
        return {"FINISHED"}


class MAP_OT_dress_refresh(bpy.types.Operator):
    bl_idname = "psmap.dress_refresh"
    bl_label = "Look again"
    bl_description = "Read the props and decals libraries again"

    def execute(self, context):
        props(force=True)
        decals(force=True)
        if _previews[0] is not None:
            _previews[0].clear()
        return {"FINISHED"}


class MAP_OT_dress_open(bpy.types.Operator):
    bl_idname = "psmap.dress_open"
    bl_label = "Open the folder"
    bl_description = "Open the library's folder in the file manager (put your own files there, then Refresh)"
    kind: bpy.props.StringProperty()

    def execute(self, context):
        path = PROPS if self.kind == "prop" else DECALS
        os.makedirs(path, exist_ok=True)
        bpy.ops.wm.path_open(filepath=path)
        return {"FINISHED"}


# ---------- Prefabs ----------
PREFAB = "ps_prefab"


def prefab_collection(name):
    return next((c for c in bpy.data.collections if c.get(PREFAB) == name), None)


class MAP_OT_prefab_make(bpy.types.Operator):
    bl_idname = "psmap.prefab_make"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Make prefab"
    bl_description = ("The group as a prefab: its objects stay where they are (the first copy) and Place copy puts "
                      "linked copies of it; what changes in the group changes in every copy")
    group: bpy.props.StringProperty()

    def execute(self, context):
        from . import art
        objs = [o for o in context.scene.objects if art.group_of(o) == self.group]
        if not objs:
            return {"CANCELLED"}
        col = prefab_collection(self.group)
        if col is None:
            col = bpy.data.collections.new(f"Prefab {self.group}")
            col[PREFAB] = self.group
            context.scene.collection.children.link(col)
        for o in objs:
            if col not in o.users_collection:
                col.objects.link(o)
        pts = [o.matrix_world @ Vector(c) for o in objs if o.type == "MESH" for c in o.bound_box] or \
              [o.matrix_world.translation for o in objs]
        lo = Vector((min(p.x for p in pts), min(p.y for p in pts), min(p.z for p in pts)))
        hi = Vector((max(p.x for p in pts), max(p.y for p in pts), max(p.z for p in pts)))
        col.instance_offset = Vector(((lo.x + hi.x) / 2, (lo.y + hi.y) / 2, lo.z))  # copies stand on its bottom centre
        # Only the objects (the group's own collections show them): the prefab's collection itself not drawn twice.
        for layer in context.view_layer.layer_collection.children:
            if layer.collection == col:
                layer.exclude = True
        self.report({"INFO"}, tr(f"Prefab {self.group}: {len(objs)} objects", "reports"))
        return {"FINISHED"}


class MAP_OT_prefab_place(bpy.types.Operator):
    bl_idname = "psmap.prefab_place"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Place copy"
    bl_description = "A linked copy of the prefab at the 3D cursor (move it with G, turn it with R Z)"
    group: bpy.props.StringProperty()

    def execute(self, context):
        col = prefab_collection(self.group)
        if col is None:
            return {"CANCELLED"}
        e = bpy.data.objects.new(f"{self.group} copy", None)
        e.instance_type = "COLLECTION"
        e.instance_collection = col
        e.empty_display_size = 0.5
        e[PREFAB] = self.group
        child_collection(context.scene, "Prefabs").objects.link(e)
        e.location = context.scene.cursor.location
        for o in context.selected_objects:
            o.select_set(False)
        e.select_set(True)
        context.view_layer.objects.active = e
        return {"FINISHED"}


def make_real(context, empties):
    """Prefab copies as objects of their own (each mesh its own), where they stand."""
    made = []
    for e in empties:
        for o in context.selected_objects:
            o.select_set(False)
        e.select_set(True)
        context.view_layer.objects.active = e
        before = set(context.scene.objects)
        bpy.ops.object.duplicates_make_real(use_base_parent=False, use_hierarchy=True)
        for o in context.scene.objects:
            if o not in before:
                if o.type == "MESH" and o.data.users > 1:
                    o.data = o.data.copy()
                for k in ("ps_mirror_pair", "ps_mirror_role", "ps_mirror_linked", "ps_mirror_name", "ps_group"):
                    if k in o:
                        del o[k]
                made.append(o)
        bpy.data.objects.remove(e, do_unlink=True)
    return made


class MAP_OT_prefab_real(bpy.types.Operator):
    bl_idname = "psmap.prefab_real"
    bl_options = {"REGISTER", "UNDO"}
    bl_label = "Make real"
    bl_description = "The selected prefab copies as objects of their own, changed apart from the prefab from now on"

    @classmethod
    def poll(cls, context):
        return any(o.get(PREFAB) and o.instance_type == "COLLECTION" for o in context.selected_objects)

    def execute(self, context):
        made = make_real(context, [o for o in context.selected_objects if o.get(PREFAB) and o.instance_type == "COLLECTION"])
        self.report({"INFO"}, tr(f"{len(made)} objects", "reports"))
        return {"FINISHED"}


CLASSES = [MAP_OT_place, MAP_OT_scatter, MAP_OT_prop_add, MAP_OT_decal_new, MAP_OT_dress_refresh, MAP_OT_dress_open,
           MAP_OT_prefab_make, MAP_OT_prefab_place, MAP_OT_prefab_real]


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    _previews[0] = bpy.utils.previews.new()


def unregister():
    if _previews[0] is not None:
        bpy.utils.previews.remove(_previews[0])
        _previews[0] = None
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
