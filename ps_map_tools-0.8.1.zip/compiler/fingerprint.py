"""What a map package was made of: fingerprints of what its light and its radar come from, kept in the package
(build.json), so an export does again only what changed (Docs: the Play tab's Bake buttons).

- The light (the .glb, its lightmaps, probes, styles, sky): every mesh that is seen or cuts or stops the light (brushes,
  models, doors, movers, cutters; not a brush all of player clip), the map's lights and sun, Blender's lights, their
  materials and pictures, the world (sky), the scene's light settings, and the exporter's own code. One fingerprint an
  object, a material...: the add-on tells which changed since the last bake.
- The radar: everything but the lights (floors, walls, clips, spawns, zones...), its settings and its code.
What is neither (a spawn moved, the mode, the Workshop card) is made again at every export, in seconds.

Works on the scene as it is in the file (the add-on's live scene, or the export's before it changes anything)."""
import hashlib
import json
import os

import bpy
import numpy as np

FILE = "build.json"
VERSION = 1
HERE = os.path.dirname(os.path.abspath(__file__))
# The scene's settings the light (bake, sky, the glb's pictures, the faces left out) is made by.
LIGHT_SCENE = ("ps_sky", "ps_sky_image", "ps_sky_rotation", "ps_sky_ground", "ps_sky_ground_own", "ps_sky_own_sun",
               "ps_shadow_depth", "ps_sun_softness", "ps_sun_source", "ps_texture_size", "ps_cull_unseen",
               "ps_map_ceiling", "cs_unit_metres")
LIGHT_PREFIXES = ("ps_sky", "ps_sun", "ps_shadow", "ps_ambient", "ps_bake")
RADAR_SCENE = ("ps_radar", "ps_radar_resolution", "ps_radar_cover", "ps_radar_ao", "ps_radar_ao_strength",
               "ps_radar_shadow", "ps_radar_tints", "ps_map_ceiling", "cs_unit_metres",
               *(f"ps_radar_image_{i}" for i in range(4)))
LIGHT_CODE = ("export_map.py", "bake_light.py", "visibility.py", "sealed.py")
RADAR_CODE = ("export_map.py", "radar_gen.py")
SEEN_KINDS = (None, "world", "solid", "detail", "breakable", "water", "model", "door", "mover", "cutter")
LIGHT_KINDS = ("light", "sun")
QUALITY = {"fast": 1, "final": 2, "release": 3}


# ---------- values ----------
def _v(x):
    """A value made plain and steady (floats rounded: a hair of float noise is not a change)."""
    if isinstance(x, float):
        return round(x, 5)
    if isinstance(x, (bool, int, str)) or x is None:
        return x
    if isinstance(x, bpy.types.ID):
        return "ID:" + x.name_full
    if hasattr(x, "to_list"):
        x = x.to_list()
    elif hasattr(x, "to_dict"):
        x = x.to_dict()
    if isinstance(x, dict):
        return {str(k): _v(v) for k, v in sorted(x.items())}
    try:
        return [_v(i) for i in x]
    except TypeError:
        return repr(x)


# A data-block's own bookkeeping (users, session id, preview...): not what it is, and not the same in another session.
ID_KEYS = {p.identifier for p in bpy.types.ID.bl_rna.properties}


def _rna(struct, skip=()):
    """A struct's own settings (simple values, and the names of what it points to)."""
    out = {}
    own = ID_KEYS if isinstance(struct, bpy.types.ID) else ()
    for p in struct.bl_rna.properties:
        k = p.identifier
        if k in own:
            continue
        if k in ("rna_type", "name", "select", "show_expanded", "location", "width", "height", "dimensions",
                 "is_active_output", "hide", "mute_link", "use_nodes") or k in skip or p.type == "COLLECTION":
            continue
        try:
            value = getattr(struct, k)
        except Exception:  # noqa: BLE001
            continue
        if p.type == "POINTER":
            out[k] = getattr(value, "name_full", None) if value is not None else None
        else:
            out[k] = _v(value)
    return out


def _h(*parts):
    h = hashlib.sha1()
    for p in parts:
        h.update(p if isinstance(p, (bytes, bytearray)) else json.dumps(p, sort_keys=True, default=repr).encode())
    return h.hexdigest()[:16]


def _image(img):
    if img is None:
        return None
    if img.packed_file is not None:
        return [img.name_full, "packed", img.packed_file.size]
    path = bpy.path.abspath(img.filepath, library=img.library)
    try:
        st = os.stat(path)
        return [img.name_full, path, int(st.st_mtime), st.st_size]
    except OSError:
        return [img.name_full, path, None]


def _tree(tree, done=None):
    """A node tree: each node's kind and settings, its inputs' values, pictures, and how they are linked."""
    if tree is None:
        return None
    done = {} if done is None else done
    if tree.name_full in done:
        return done[tree.name_full]
    done[tree.name_full] = "…"
    nodes = []
    for n in sorted(tree.nodes, key=lambda n: n.name):
        entry = [n.bl_idname, n.name, _rna(n, skip=("label", "color", "use_custom_color", "parent"))]
        entry.append([(i.identifier, _v(getattr(i, "default_value", None))) for i in n.inputs if not i.is_linked])
        if getattr(n, "image", None) is not None:
            entry.append(_image(n.image))
        if getattr(n, "node_tree", None) is not None:
            entry.append(_tree(n.node_tree, done))
        nodes.append(entry)
    links = sorted((l.from_node.name, l.from_socket.identifier, l.to_node.name, l.to_socket.identifier)
                   for l in tree.links)
    done[tree.name_full] = _h(nodes, links)
    return done[tree.name_full]


def _material(m):
    return _h(_rna(m, skip=("preview_render_type", "pass_index", "paint_active_slot")),
              {k: _v(m[k]) for k in m.keys() if not k.startswith("_")}, _tree(m.node_tree))


def _mesh(me, cache):
    key = me.name_full
    if key in cache:
        return cache[key]
    co = np.empty(len(me.vertices) * 3, dtype=np.float32)
    me.vertices.foreach_get("co", co)
    loops = np.empty(len(me.loops), dtype=np.int32)
    me.loops.foreach_get("vertex_index", loops)
    totals = np.empty(len(me.polygons), dtype=np.int32)
    me.polygons.foreach_get("loop_total", totals)
    mats = np.empty(len(me.polygons), dtype=np.int32)
    me.polygons.foreach_get("material_index", mats)
    parts = [np.round(co, 5).tobytes(), loops.tobytes(), totals.tobytes(), mats.tobytes()]
    for uv in me.uv_layers:
        a = np.empty(len(me.loops) * 2, dtype=np.float32)
        uv.data.foreach_get("uv", a)
        parts += [uv.name.encode(), np.round(a, 5).tobytes()]
    for attr in me.attributes:
        if attr.name.startswith("ps_") and attr.data_type in ("FLOAT", "INT", "BOOLEAN") and len(attr.data):
            a = np.empty(len(attr.data), dtype=np.float64)
            attr.data.foreach_get("value", a)
            parts += [attr.name.encode(), attr.domain.encode(), np.round(a, 5).tobytes()]
    cache[key] = _h(*parts, [m.name_full if m else None for m in me.materials])
    return cache[key]


def _object(o, cache):
    """An object: what it is, where, its settings, its shape and materials, its modifiers, its light."""
    parts = [o.type, [round(x, 5) for row in o.matrix_world for x in row], o.display_type,
             {k: _v(o[k]) for k in sorted(o.keys()) if not k.startswith("_")},
             [(m.type, _rna(m)) for m in o.modifiers],
             [s.material.name_full if s.material else None for s in o.material_slots],
             o.instance_type, o.instance_collection.name_full if o.instance_collection else None]
    if o.type == "MESH" and o.data is not None:
        parts.append(_mesh(o.data, cache))
    elif o.type == "LIGHT" and o.data is not None:
        parts.append(_rna(o.data, skip=("node_tree",)))
    return _h(*parts)


# ---------- what goes where ----------
def _left_out(scene):
    """Objects of collections marked ps_export = 0 (and the collections inside them): the export leaves them out."""
    out = set()

    def walk(col, skipped):
        skipped = skipped or col.get("ps_export", 1) in (0, False)
        if skipped:
            out.update(col.objects)
        for c in col.children:
            walk(c, skipped)
    walk(scene.collection, False)
    return out


def _all_clip(o):
    mats = [s.material for s in o.material_slots]
    tools = {str(m.get("ps_tool", "")) if m is not None else "" for m in mats}
    return bool(mats) and "" not in tools and "nodraw" not in tools


def is_light(o):
    return o.type == "LIGHT" or o.get("ps_entity") in LIGHT_KINDS


def is_seen(o):
    """An object the light is made of: seen, or cutting what is seen, or stopping the light."""
    if is_light(o):
        return True
    if o.type == "EMPTY" and o.instance_type == "COLLECTION" and o.instance_collection is not None:
        return True  # a prefab copy (made real at export)
    if o.type != "MESH" or o.get("ps_entity") not in SEEN_KINDS:
        return False
    return not (o.get("ps_brush") and _all_clip(o))


def _scene(scene, names, prefixes=()):
    keys = set(names)
    for p in scene.bl_rna.properties:
        if p.identifier.startswith(prefixes):
            keys.add(p.identifier)
    keys |= {k for k in scene.keys() if k.startswith(prefixes) or k in names}
    out = {}
    for k in sorted(keys):
        value = getattr(scene, k, None) if k in scene.bl_rna.properties else scene.get(k)
        if value is None and k in scene.keys():
            value = scene.get(k)
        out[k] = _image(value) if isinstance(value, bpy.types.Image) else _v(value)
        if k.startswith("ps_radar_image_") and value:
            path = bpy.path.abspath(str(value))
            try:
                st = os.stat(path)
                out[k] = [path, int(st.st_mtime), st.st_size]
            except OSError:
                pass
    return out


def _code(names):
    h = hashlib.sha1()
    for n in names:
        try:
            with open(os.path.join(HERE, n), "rb") as f:
                h.update(f.read())
        except OSError:
            h.update(n.encode())
    return h.hexdigest()[:16]


def state(scene):
    """{"light": {"items": {what: fingerprint}, "total"}, "radar": {"total"}} of the scene now."""
    cache = {}
    out_objs = _left_out(scene)
    light, radar = {}, {}
    mats = set()
    for o in scene.objects:
        if o in out_objs or o.type == "CAMERA":
            continue
        fp = _object(o, cache)
        if is_seen(o):
            light["obj:" + o.name] = fp
            mats.update(s.material for s in o.material_slots if s.material is not None)
            if o.type == "EMPTY" and o.instance_collection is not None:
                for x in o.instance_collection.all_objects:
                    light["obj:" + o.name + "/" + x.name] = _object(x, cache)
                    mats.update(s.material for s in x.material_slots if s.material is not None)
        if not is_light(o):
            radar[o.name] = fp
    for m in mats:
        light["mat:" + m.name] = _material(m)
    light["world"] = _h(_tree(scene.world.node_tree) if scene.world else None,
                        _rna(scene.world) if scene.world else None)
    light["scene"] = _h(_scene(scene, LIGHT_SCENE, LIGHT_PREFIXES))
    light["code"] = _code(LIGHT_CODE)
    radar["scene"] = _h(_scene(scene, RADAR_SCENE))
    radar["code"] = _code(RADAR_CODE)
    return {"light": {"items": light, "total": _h(sorted(light.items()))},
            "radar": {"total": _h(sorted(radar.items()))}}


# ---------- the package's own ----------
def read(folder):
    try:
        with open(os.path.join(folder, FILE), encoding="utf-8") as f:
            data = json.load(f)
        return data if data.get("version") == VERSION else {}
    except (OSError, ValueError):
        return {}


def write(folder, data):
    data = dict(data, version=VERSION)
    with open(os.path.join(folder, FILE), "w", encoding="utf-8") as f:
        json.dump(data, f, separators=(",", ":"))


def light_ok(built, now, mode):
    """The package's baked light can stand for a bake of `mode` now: made of the same, and as good (Final stands for
    Fast; Fast does not for Final)."""
    light = (built or {}).get("light") or {}
    if not light.get("mode") or light.get("total") != now["light"]["total"]:
        return False
    if mode == "reuse":
        return True
    return QUALITY.get(light["mode"], 0) >= QUALITY.get(mode, 99)


def changed(built, now, most=3):
    """What changed since the package's light was made: (names to tell, how many more)."""
    old = ((built or {}).get("light") or {}).get("items") or {}
    new = now["light"]["items"]
    keys = sorted(k for k in set(old) | set(new) if old.get(k) != new.get(k))
    words = {"world": "the sky (world)", "scene": "light settings", "code": "map tools updated"}
    names = []
    for k in keys:
        name = words.get(k) or k.split(":", 1)[-1]
        if name not in names:
            names.append(name)
    return names[:most], max(0, len(names) - most)
