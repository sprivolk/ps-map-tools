"""Blender's own lights (Add → Light: Point, Spot, Area, Sun) made the map's (the add-on's empties: light, sun), asked when
the light is baked (Bake Fast / Bake Final). The bake lights the map by the add-on's lights only (it leaves Blender's
out), so a light set in Blender is converted first, or left out.

A converted Blender light is kept as it is, marked: what it was when converted (its fingerprint, PS_MARK) and the light
made of it (PS_MADE). Changed since (brighter, moved, another colour), the mark no longer fits and it is asked again;
converted again, the same light of the map is set anew (none doubled; one deleted is made again).

How each goes over:
  Point → light: colour (× its temperature's), brightness and range by its power (see `lamp_from_watts`), its light
          fading as in Blender (ps_natural: the bake does not cut it at the range).
  Spot  → light with a cone (spot_size); its soft edge (Spot Blend) is not kept.
  Area  → light of a shape (ps_shape "rect", ps_size, ps_spread); a disc or an ellipse as the rectangle round it.
  Sun   → sun: its way, colour, brightness; its disc (Angle) the map's sun softness. One sun for the map: when it has its
          own already, which one is asked.
Left out (told): lights hidden from the render, from another file (linked), with no power; a light's nodes, IES, shadow
off and light linking are not carried over (the light is, without them)."""
import hashlib
import math

import bpy
from mathutils import Vector

PS_MARK = "ps_converted"     # on a Blender light: its fingerprint when converted
PS_MADE = "ps_converted_to"  # on a Blender light: the name of the map's light made of it
FROM = "converted_from"      # on the map's light: the Blender light it was made of (not ps_: not exported)
ADDON_OWN = ("Sun preview (not exported)",)  # the add-on's own lights (__init__.PREVIEW_SUN): never converted

SUN_ENERGY = 3.0             # compiler/bake_light.SUN_ENERGY: W/m² of a brightness-1 sun
LAMP_WATTS = 60.0            # compiler/bake_light: a brightness-1 lamp of range 8 m is 60 W


def blackbody(kelvin):
    """The colour of a light of that temperature (K), its brightest channel 1 (Tanner Helland's fit of the curve)."""
    t = max(1000.0, min(40000.0, kelvin)) / 100.0
    r = 255.0 if t <= 66 else 329.698727446 * (t - 60) ** -0.1332047592
    g = 99.4708025861 * math.log(t) - 161.1195681661 if t <= 66 else 288.1221695283 * (t - 60) ** -0.0755148492
    b = 255.0 if t >= 66 else 0.0 if t <= 19 else 138.5177312231 * math.log(t - 10) - 305.0447927307
    c = [max(0.0, min(255.0, x)) / 255.0 for x in (r, g, b)]
    top = max(c) or 1.0
    return [x / top for x in c]


def colour_of(data):
    """The light's colour as the bake sees it: its colour times its temperature's (when it uses one)."""
    c = list(data.color)
    if getattr(data, "use_temperature", False):
        k = blackbody(float(data.temperature))
        c = [a * b for a, b in zip(c, k)]
    return [round(min(1.0, max(0.0, x)), 4) for x in c]


def watts(data):
    """Its power in watts (its Exposure counted)."""
    return float(data.energy) * 2.0 ** float(getattr(data, "exposure", 0.0) or 0.0)


def lamp_from_watts(w, custom=None):
    """(brightness, range m) of the map's lamp lighting as a Blender lamp of `w` watts. The bake makes a lamp
    60 × brightness × (range / 8)² W: with Blender's fading (ps_natural) the range only says how far the game's live lamp
    (unbaked test light) reaches, so brightness 1 and the range of that power — or its Custom Distance, the power kept."""
    if custom and custom > 0:
        return round(w / (LAMP_WATTS * (custom / 8.0) ** 2), 4), round(custom, 3)
    reach = 8.0 * math.sqrt(max(w, 1e-6) / LAMP_WATTS)
    return 1.0, round(max(0.5, reach), 3)


def fingerprint(obj):
    """What the light is now: kind, colour, power, size, cone, where and how turned (rounded: a hair moved is not a
    change)."""
    d = obj.data
    parts = [d.type, tuple(round(x, 4) for x in d.color), bool(getattr(d, "use_temperature", False)),
             round(float(getattr(d, "temperature", 0.0)), 1), round(watts(d), 4),
             bool(d.use_custom_distance), round(float(d.cutoff_distance), 3)]
    if d.type == "SPOT":
        parts += [round(d.spot_size, 4)]
    if d.type == "AREA":
        parts += [d.shape, round(d.size, 4), round(d.size_y, 4), round(d.spread, 4)]
    if d.type == "SUN":
        parts += [round(d.angle, 4)]
    mw = obj.matrix_world
    parts += [tuple(round(x, 3) for row in mw for x in row)]
    return hashlib.sha1(repr(parts).encode()).hexdigest()[:16]


def blender_lights(scene):
    """The scene's Blender lights the bake would leave out: (to convert, left out with why)."""
    todo, skipped = [], []
    for o in scene.objects:
        if o.type != "LIGHT" or o.name.startswith(ADDON_OWN):
            continue  # (the add-on's own: Preview sun shadows' light, not the map's)
        if o.library is not None or (o.data is not None and o.data.library is not None):
            skipped.append((o, "from another file"))
        elif o.hide_render:
            skipped.append((o, "off in renders"))
        elif watts(o.data) <= 0:
            skipped.append((o, "no power"))
        else:
            todo.append(o)
    return todo, skipped


def pending(scene):
    """The Blender lights not converted yet, or changed since: their mark does not fit them."""
    todo, _ = blender_lights(scene)
    out = []
    for o in todo:
        made = str(o.get(PS_MADE, ""))
        if o.get(PS_MARK) != fingerprint(o):
            out.append(o)
        elif made and bpy.data.objects.get(made) is None:
            out.append(o)  # the map's light made of it was deleted: made again
    return out


def map_suns(scene):
    return [o for o in scene.objects if o.get("ps_entity") == "sun" and not o.get(FROM)]


def blender_sun(scene):
    """The scene's Blender sun (the brightest, of those the bake would take), or None."""
    suns = [o for o in blender_lights(scene)[0] if o.data.type == "SUN"]
    return max(suns, key=lambda o: watts(o.data)) if suns else None


def sync_sun(scene, collection, source):
    """The Play panel's Sun choice, before each play and bake: "blender" - the Blender sun made (or set anew as) a sun
    of the map, beside the map's own (the export takes it, compiler/export_map: ps_sun_source); "game" - the Blender sun
    left as it is (marked answered: the bake's window does not ask about it). Returns its softness (degrees) or None."""
    sun = blender_sun(scene)
    if sun is None:
        return None
    if source != "blender":
        sun[PS_MARK] = fingerprint(sun)
        return None
    softness = []
    convert(scene, [sun], collection, "both", softness)
    return softness[0] if softness else None


def _empty(name, collection, display, size):
    obj = bpy.data.objects.new(name, None)
    obj.empty_display_type = display
    obj.empty_display_size = size
    collection.objects.link(obj)
    return obj


def _colour_ui(obj):
    obj.id_properties_ui("ps_color").update(subtype="COLOR", min=0.0, max=1.0, soft_min=0.0, soft_max=1.0)
    obj.id_properties_ui("ps_brightness").update(min=0.0, soft_max=20.0)


def convert(scene, lights, collection, sun_choice="ours", softness_out=None):
    """Each Blender light made (or set anew as) the map's. `sun_choice`: "ours" (the map's sun stays, a Blender sun is not
    converted), "blender" (the Blender sun becomes the map's sun), "both" (made a sun beside the map's own, which stays:
    the Play panel's Sun choice says which the export takes). Returns (made, updated, left out [(name, why)],
    notes [text])."""
    made = updated = 0
    left, notes = [], []
    suns = [o for o in lights if o.data.type == "SUN"]
    if len(suns) > 1:
        brightest = max(suns, key=lambda o: watts(o.data))
        for o in suns:
            if o is not brightest:
                left.append((o.name, "a second sun (one a map; the brightest taken)"))
        lights = [o for o in lights if o.data.type != "SUN" or o is brightest]
    for o in lights:
        d = o.data
        mw = o.matrix_world
        rot = mw.to_3x3().normalized()
        target = bpy.data.objects.get(str(o.get(PS_MADE, "")))
        if d.type == "SUN":
            ours = [s for s in map_suns(scene) if s is not target]
            if ours and sun_choice not in ("blender", "both"):
                left.append((o.name, "the map has its own sun (kept)"))
                o[PS_MADE] = ""  # answered: not asked again until it changes
                o[PS_MARK] = fingerprint(o)
                continue
            for s in (ours if sun_choice == "blender" else ()):  # the Blender one is the map's sun now: the old goes
                bpy.data.objects.remove(s, do_unlink=True)
            if target is None or target.get("ps_entity") != "sun":
                target = _empty(f"Sun ({o.name})", collection, "SINGLE_ARROW", 4.0)
                made += 1
            else:
                updated += 1
            way = -(rot @ Vector((0.0, 0.0, 1.0)))  # a Blender light shines down its −Z
            target.location = mw.translation
            target.rotation_mode = "XYZ"
            target.rotation_euler = way.to_track_quat("Z", "Y").to_euler()
            target["ps_entity"] = "sun"
            target["ps_arrow"] = 1
            target["ps_color"] = colour_of(d)
            bright = watts(d) / SUN_ENERGY
            if bright > 10.0:  # (the bake reads a sun over 10 as a CS map's, on a scale of 200)
                notes.append(f"{o.name}: strength {watts(d):.0f} is more than the map's sun takes: made 10 "
                             f"(= {10 * SUN_ENERGY:.0f} in Blender)")
                bright = 10.0
            target["ps_brightness"] = round(bright, 4)
            if softness_out is not None:
                softness_out.append(math.degrees(d.angle))
        else:
            if target is None or target.get("ps_entity") != "light":
                target = _empty(f"Light ({o.name})", collection, "SPHERE", 0.2)
                made += 1
            else:
                updated += 1
            target.location = mw.translation
            # The map's lamp shines along its +X, a rectangle's first side along its +Y; Blender's down its −Z, an area
            # light's first side along its X.
            fwd = (rot @ Vector((0.0, 0.0, -1.0))).normalized()
            side = (rot @ Vector((1.0, 0.0, 0.0))).normalized()
            up = fwd.cross(side).normalized()
            from mathutils import Matrix
            target.rotation_mode = "XYZ"
            target.rotation_euler = Matrix((fwd, side, up)).transposed().to_euler()
            target["ps_entity"] = "light"
            target["ps_color"] = colour_of(d)
            custom = float(d.cutoff_distance) if d.use_custom_distance else None
            bright, reach = lamp_from_watts(watts(d), custom)
            target["ps_brightness"] = bright
            target["ps_range"] = reach
            target["ps_natural"] = True
            for key in ("ps_cone", "ps_shape", "ps_size", "ps_spread"):
                if key in target:
                    del target[key]
            if d.type == "SPOT":
                target["ps_cone"] = round(math.degrees(d.spot_size), 2)
                if d.spot_blend > 0.05:
                    notes.append(f"{o.name}: its soft edge (Spot Blend) is not kept")
            elif d.type == "AREA":
                sx = float(d.size)
                sy = float(d.size_y) if d.shape in ("RECTANGLE", "ELLIPSE") else sx
                target["ps_shape"] = "rect"
                target["ps_size"] = [round(sx, 4), round(sy, 4)]
                target["ps_spread"] = round(min(180.0, math.degrees(d.spread)), 2)
                if d.shape in ("DISK", "ELLIPSE"):
                    notes.append(f"{o.name}: a {d.shape.lower()} light made a rectangle")
        _colour_ui(target)
        target[FROM] = o.name
        tree = getattr(d, "node_tree", None)
        if tree is not None and any(n.type not in ("EMISSION", "OUTPUT_LIGHT") for n in tree.nodes):
            notes.append(f"{o.name}: its nodes (texture, IES) are not carried over")
        if not getattr(d, "use_shadow", True):
            notes.append(f"{o.name}: it casts no shadow in Blender; the map's light does")
        o[PS_MADE] = target.name
        o[PS_MARK] = fingerprint(o)
    return made, updated, left, notes
