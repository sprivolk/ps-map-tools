"""
A map made in Blender, out as a map package: what the game's map compiler takes in.

    blender -b <map.blend> --python export_map.py -- <package folder>   (the map tools' compiler/ folder)

The package (format 1):
- <name>.glb   what is seen: every visible mesh of the map (glTF 2.0, its materials and textures in it).
- map.json     the rest, in our words: the entities (spawns, bomb sites, buy zones, ladders, water, the sun) and the
               collision as convex blocks (their corner points). Nothing in it depends on Blender.
- radar_<i>.png  the radar's pictures, one per layer (radar_gen.py; its "radar" block in map.json), with the made ones
               beside them as radar_auto_<i>.png to draw over.

A collection with the custom property ps_export = 0 is left out, with every collection in it (references, examples).
The objects say what they are with the custom property "ps_entity" (and their ps_* settings), set by our addon or by
the CS 1.6 importer:
  world, solid, detail, breakable, water    seen (in the .glb); "breakable" and "water" are entities too. ps_surface
                                            (concrete, wood, metal, glass... the game's Surfaces.json) is what bullets
                                            go through and what hits and steps sound like (default when not set)
  collision                                 its loose parts are the convex blocks a player stands on and walks against;
                                            with ps_concave, the whole mesh is one block as it is (terrain, models)
  grenadeclip, blockbullets                 like collision, but for thrown grenades only / for bullets only (CS tools)
  spawn (ps_team T / CT)                    an empty on the floor; it faces its +X
  bombsite (ps_site A / B), buyzone (ps_team T / CT / ""), ladder, water    volumes: a closed mesh, convex
  radarlayer                                a volume: the radar layer of what lies in its heights (CS2 vertical sections)
  radarmin, radarmax, radarcolor (ps_color) empties: the radar gradient's bottom, top and own colours by height
  killzone                                  a volume: whoever enters it dies (CS trigger_hurt)
  sun (ps_color, ps_brightness)             an empty; the light shines along its +X
  light (ps_color, ps_brightness, ps_range metres, ps_cone degrees for a spot)   an empty: a lamp the bake lights the
                                            map with (a spot shines along its +X)
Space: glTF's — metres, Y up, right-handed (Blender x, y, z is x, z, -y). Unity's is this with x turned over, as
glTFast imports the .glb.
"""
import json
import struct
import math
import os
import shutil
import sys

import bmesh
import bpy
from mathutils import Matrix, Vector

FORMAT = 1
UNIT = 0.025  # metres a Hammer unit
GENERATOR = "PlaceholderShooter export_map 0.1"
PREVIEW = "preview.png"  # the Workshop card's picture (the map tools take it: <map>_preview.png beside the .blend)
SEEN = {"world", "solid", "detail", "breakable", "water"}
VOLUMES = {"bombsite", "buyzone", "ladder", "water", "radarlayer", "killzone"}
# Invisible blocks, and whom they stop: players (collision), thrown grenades, bullets.
CLIPS = {"collision": "player", "grenadeclip": "grenade", "blockbullets": "bullets"}


def gltf(v):
    return [round(v.x, 4), round(v.z, 4), round(-v.y, 4)]


def convex_parts(obj):
    """Each loose part of a mesh object, as its corner points in world space."""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.transform(obj.matrix_world)
    bm.verts.ensure_lookup_table()
    seen, parts = set(), []
    for start in bm.verts:
        if start.index in seen:
            continue
        stack, part = [start], []
        seen.add(start.index)
        while stack:
            v = stack.pop()
            part.append(v.co.copy())
            for e in v.link_edges:
                o = e.other_vert(v)
                if o.index not in seen:
                    seen.add(o.index)
                    stack.append(o)
        if len(part) >= 4:
            parts.append(part)
    bm.free()
    return parts


def convex_meshes(obj):
    """Each loose part of a mesh object as its own little mesh: corners (world space) and triangles (fans of its faces)."""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.transform(obj.matrix_world)
    # In triangles as Blender cuts them (a fan from one corner of an L-shaped face ran outside it).
    bmesh.ops.triangulate(bm, faces=bm.faces[:])
    bm.verts.ensure_lookup_table()
    parts, seen = [], set()
    for face in bm.faces:
        if face.index in seen:
            continue
        stack, faces = [face], []
        seen.add(face.index)
        while stack:
            f = stack.pop()
            faces.append(f)
            for e in f.edges:
                for o in e.link_faces:
                    if o.index not in seen:
                        seen.add(o.index)
                        stack.append(o)
        index, points, tris = {}, [], []
        for f in faces:
            ring = []
            for v in f.verts:
                if v.index not in index:
                    index[v.index] = len(points)
                    points.append(v.co.copy())
                ring.append(index[v.index])
            for i in range(1, len(ring) - 1):
                tris += [ring[0], ring[i], ring[i + 1]]
        if len(points) >= 4:
            parts.append((points, tris))
    bm.free()
    return parts


def _hull(points):
    """The convex hull of points: (corners, triangles, volume), or None when they are flat."""
    bm = bmesh.new()
    for p in points:
        bm.verts.new(p)
    try:
        bmesh.ops.convex_hull(bm, input=bm.verts[:], use_existing_faces=False)
    except (ValueError, RuntimeError):
        bm.free()
        return None
    for v in [v for v in bm.verts if not v.link_faces]:
        bm.verts.remove(v)
    bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])
    vol = bm.calc_volume(signed=False)
    if vol < 1e-7 or not bm.faces:
        bm.free()
        return None
    bm.verts.index_update()
    pts = [v.co.copy() for v in bm.verts]
    tris = []
    for f in bm.faces:
        ring = [v.index for v in f.verts]
        for i in range(1, len(ring) - 1):
            tris += [ring[0], ring[i], ring[i + 1]]
    bm.free()
    return pts, tris, vol


def convex_pieces(points, tris, tolerance=1e-4):
    """A closed solid that is not convex (a brush made an L by hand, a step on it) as convex pieces that fill it, as VBSP
    needs its brushes: space cut by the planes of its own faces, the cells inside it kept, those that make one convex
    piece together joined again. A player stands on these (a mesh as it is is only a shell: one-sided to the game's
    physics, and one turned inside out let players through). Its faces turned outward first. None: it cannot be done."""
    from mathutils.bvhtree import BVHTree
    faces = [tris[i:i + 3] for i in range(0, len(tris), 3)]
    tree = BVHTree.FromPolygons(points, faces)
    planes = []
    for a, b, c in faces:
        n = (points[b] - points[a]).cross(points[c] - points[a])
        if n.length < 1e-9:
            continue
        n.normalize()
        d = n.dot(points[a])
        if not any(abs(n.dot(m)) > 1 - 1e-6 and abs(d - e * n.dot(m)) < tolerance for m, e in planes):
            planes.append((n, d))
    if len(planes) > 64:
        return None
    lo = Vector(map(min, *points))
    hi = Vector(map(max, *points))
    cells = [[Vector((x, y, z)) for x in (lo.x, hi.x) for y in (lo.y, hi.y) for z in (lo.z, hi.z)]]
    for n, d in planes:
        out = []
        for cell in cells:
            side = [n.dot(p) - d for p in cell]
            if max(side) <= tolerance or min(side) >= -tolerance:
                out.append(cell)
                continue
            cut = [p.lerp(q, sp / (sp - sq)) for p, sp in zip(cell, side) for q, sq in zip(cell, side) if sp < -tolerance < tolerance < sq]
            below = [p for p, sp in zip(cell, side) if sp <= tolerance] + cut
            above = [p for p, sp in zip(cell, side) if sp >= -tolerance] + cut
            for part in (below, above):
                h = _hull(part)
                if h is not None:
                    out.append(h[0])
        cells = out
        if len(cells) > 512:
            return None

    def inside(cell):
        c = sum(cell, Vector()) / len(cell)
        # Inside: the solid's faces seen from its middle cover the whole sphere round it (their solid angles add up to
        # 4π; outside, to 0). The faces' own way only flips the sign: one turned inside out is still found. (Rays from
        # the middle were fooled by those running along an edge: a piece of a step went missing.)
        total = 0.0
        for a, b, cc in faces:
            ra, rb, rc = points[a] - c, points[b] - c, points[cc] - c
            la, lb, lc = ra.length, rb.length, rc.length
            num = ra.dot(rb.cross(rc))
            den = la * lb * lc + ra.dot(rb) * lc + ra.dot(rc) * lb + rb.dot(rc) * la
            total += 2.0 * math.atan2(num, den)
        return abs(total) > 2.0 * math.pi
    kept = [h for h in (_hull(c) for c in cells if inside(c)) if h is not None]
    if not kept:
        return None
    # Joined back where two make one convex piece (the hull of both no bigger than the two).
    pieces = [(h[0], h[2]) for h in kept]
    merged = True
    while merged and len(pieces) > 1:
        merged = False
        for i in range(len(pieces)):
            for j in range(i + 1, len(pieces)):
                h = _hull(pieces[i][0] + pieces[j][0])
                if h is not None and h[2] <= (pieces[i][1] + pieces[j][1]) * (1 + 1e-5) + 1e-9:
                    pieces[i] = (h[0], h[2])
                    del pieces[j]
                    merged = True
                    break
            if merged:
                break
    out = []
    for pts, _ in pieces:
        h = _hull(pts)
        if h is not None:
            out.append((h[0], h[1]))
    return out


def is_convex(points, tris, tolerance=1e-3):
    """Every corner lies behind (or on) the plane of every triangle."""
    for i in range(0, len(tris), 3):
        a, b, c = points[tris[i]], points[tris[i + 1]], points[tris[i + 2]]
        n = (b - a).cross(c - a)
        if n.length < 1e-9:
            continue
        n.normalize()
        if any((p - a).dot(n) > tolerance for p in points):
            return False
    return True


def whole_mesh(obj):
    """A mesh object's corners (world space) and triangles (fans of its faces), all of it."""
    mesh = obj.data
    points = [obj.matrix_world @ v.co for v in mesh.vertices]
    tris = []
    for f in mesh.polygons:
        ring = list(f.vertices)
        for i in range(1, len(ring) - 1):
            tris += [ring[0], ring[i], ring[i + 1]]
    return points, tris


def forward(obj):
    return (obj.matrix_world.to_3x3() @ Vector((1, 0, 0))).normalized()


def entity_of(obj):
    kind = obj.get("ps_entity")
    e = {"type": kind, "name": obj.name}
    for key in obj.keys():
        if key.startswith("ps_") and key != "ps_entity":
            value = obj[key]
            e[key[3:]] = list(value) if hasattr(value, "__len__") and not isinstance(value, str) else value
    if obj.type == "EMPTY":
        e["position"] = gltf(obj.matrix_world.translation)
        e["forward"] = gltf(forward(obj))
    elif kind in VOLUMES and obj.type == "MESH":
        parts = convex_parts(obj)
        e["points"] = [c for p in parts[0] for c in gltf(p)] if parts else []
    if kind == "sun":
        # CS light_environment: its yaw is the empty's, its "pitch" key how far down it shines (negative: down).
        pitch = math.radians(float(obj.get("cs_pitch", "-45") or -45))
        yaw = obj.rotation_euler.z
        e["direction"] = gltf(Vector((math.cos(pitch) * math.cos(yaw), math.cos(pitch) * math.sin(yaw), math.sin(pitch))))
    return e


# ---------- A CS 1.6 map's own player collision (its clip hulls), when the scene came from one ----------
# hull.bin: "PSH1"; planes (count, then normal xyz + distance, glTF space, metres); clip nodes (count, then plane, front,
# back as int32: below 0 is contents, -1 empty, -2 solid); models (count, then name, kind byte 0 world / 1 wall /
# 2 breakable, standing hull's head node, ducked hull's head node). The game moves players against it exactly as CS 1.6.
HULL_KINDS = {"func_wall": 1, "func_wall_toggle": 1, "func_door": 1, "func_door_rotating": 1, "func_breakable": 2}


def write_hull(bsp_path, out_path):
    import importlib.util
    # The CS 1.6 importer: in the project's ArtSource/Export (an imported CS map is only ever exported there).
    here = os.path.dirname(os.path.abspath(__file__))
    path = next((p for p in (os.path.join(here, "import_goldsrc_bsp.py"),
                             os.path.join(here, "..", "..", "..", "Export", "import_goldsrc_bsp.py")) if os.path.exists(p)), None)
    if path is None:
        raise RuntimeError("the CS 1.6 importer (import_goldsrc_bsp.py) is not here: its collision is left out")
    spec = importlib.util.spec_from_file_location("import_goldsrc_bsp", path)
    imp = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(imp)
    lumps = imp.read_bsp(bsp_path)
    unit = imp.UNIT
    planes = lumps["planes"]
    count = len(planes) // 20
    out = bytearray(b"PSH1")
    out += struct.pack("<i", count)
    for i in range(count):
        nx, ny, nz, dist = struct.unpack_from("<4f", planes, i * 20)
        out += struct.pack("<4f", nx, nz, -ny, dist * unit)
    nodes = lumps["clipnodes"]
    n = len(nodes) // 8
    out += struct.pack("<i", n)
    for i in range(n):
        plane, front, back = struct.unpack_from("<ihh", nodes, i * 8)
        out += struct.pack("<3i", plane, front, back)
    models = [("world", 0, 0)]
    for e in imp.parse_entities(lumps["entities"].decode("ascii", "replace")):
        kind = HULL_KINDS.get(e.get("classname", ""))
        model = e.get("model", "")
        if kind and model.startswith("*"):
            models.append((f"{e['classname']} {model}", kind, int(model[1:])))
    out += struct.pack("<i", len(models))
    for name, kind, m in models:
        heads = struct.unpack_from("<4i", lumps["models"], m * 64 + 36)
        encoded = name.encode("utf-8")
        out += struct.pack("<i", len(encoded)) + encoded + struct.pack("<Bii", kind, heads[1], heads[3])
    with open(out_path, "wb") as f:
        f.write(out)
    return len(models)


# ---------- Brushes (the map tools add-on): a box object that is seen and collides, its kind given by tool materials ----------
TILE = 64 * 0.025  # one tile of the Dev grid textures, metres
# A brush whose every face has one of these tool materials (material["ps_tool"]) is that, not seen.
WHOLE_TOOLS = {"clip": "collision", "grenadeclip": "grenadeclip", "blockbullets": "blockbullets", "killzone": "killzone",
               "ladder": "ladder"}


def tool_of(mat):
    return str(mat.get("ps_tool", "")) if mat is not None else ""


def world_uvs(obj):
    """Texture lock: UVs from the faces' places in the world (box mapped), one Dev grid tile per 64 units."""
    import numpy as np
    me = obj.data
    if not len(me.polygons):
        return
    layer = me.uv_layers.active or me.uv_layers.new(name="UVMap")
    mw = np.array(obj.matrix_world)
    co = np.empty(len(me.vertices) * 3, dtype=np.float32)
    me.vertices.foreach_get("co", co)
    co = co.reshape(-1, 3) @ mw[:3, :3].T + mw[:3, 3]
    nrm = np.empty(len(me.polygons) * 3, dtype=np.float32)
    me.polygons.foreach_get("normal", nrm)
    nrm = nrm.reshape(-1, 3) @ np.linalg.inv(mw[:3, :3])
    axis = np.abs(nrm).argmax(axis=1)
    starts = np.empty(len(me.polygons), dtype=np.int32)
    totals = np.empty(len(me.polygons), dtype=np.int32)
    me.polygons.foreach_get("loop_start", starts)
    me.polygons.foreach_get("loop_total", totals)
    loop_poly = np.repeat(np.arange(len(me.polygons)), totals)
    verts = np.empty(len(me.loops), dtype=np.int32)
    me.loops.foreach_get("vertex_index", verts)
    p = co[verts]
    a = axis[loop_poly]
    u = np.where(a == 0, p[:, 1], p[:, 0])
    v = np.where(a == 2, p[:, 1], p[:, 2])
    layer.data.foreach_set("uv", (np.stack([u, v], axis=1) / TILE).ravel())


def convex_planes(obj):
    """A convex brush's faces as (normal, distance) in world space, or None when it is not convex."""
    bm = bmesh.new()
    bm.from_mesh(obj.data)
    bm.transform(obj.matrix_world)
    bm.normal_update()
    planes = [(f.normal.copy(), f.normal.dot(f.verts[0].co)) for f in bm.faces if f.normal.length > 0.5]
    points = [v.co.copy() for v in bm.verts]
    bm.free()
    if not planes or any(n.dot(p) - d > 1e-3 for n, d in planes for p in points):
        return None
    return planes


KEEP = "ps_keep"  # a face attribute of a brush (the add-on's "Always draw"): 1 is never left out as hidden
SEE_THROUGH = {"glass", "chainlink", "metalgrate"}  # surfaces seen through: they hide nothing behind them


def face_surfaces(o):
    """The surface of each face (as Hammer's $surfaceprop: the material's own, material["ps_surface"]); the object's
    ps_surface, when set, stands for all of them. "" is the default."""
    own = str(o.get("ps_surface", "") or "")
    if own:
        return [own] * len(o.data.polygons)
    by_mat = [str(m.get("ps_surface", "") or "") if m else "" for m in o.data.materials]
    return [by_mat[f.material_index] if f.material_index < len(by_mat) else "" for f in o.data.polygons]


def split_by_surface(o, collection):
    """A seen object whose faces are of more than one surface (a wood door's faces on a concrete wall) as one object per
    surface, each with its ps_surface: the game knows a surface per object. One surface: it is set on the object."""
    per_face = face_surfaces(o)
    used = sorted(set(per_face))
    if len(used) <= 1:
        if used and used[0]:
            o["ps_surface"] = used[0]
        return [o]
    parts = []
    for s in used:
        c = o.copy()
        c.data = o.data.copy()
        collection.objects.link(c)
        bm = bmesh.new()
        bm.from_mesh(c.data)
        bm.faces.ensure_lookup_table()
        bmesh.ops.delete(bm, geom=[f for f in bm.faces if per_face[f.index] != s], context="FACES")
        bm.to_mesh(c.data)
        bm.free()
        c.name = f"{o.name} {s or 'default'}"
        if s:
            c["ps_surface"] = s
        else:
            c.pop("ps_surface", None)
        parts.append(c)
    bpy.data.objects.remove(o, do_unlink=True)
    return parts


def brush_roles(brushes):
    """The brushes that are seen (not wholly a tool) and, of those, the convex opaque ones with their planes: what hides
    faces (colliding or not: a face inside a step is not seen either). Shared by the export and the add-on's preview."""
    seen, solid = [], []
    for o in brushes:
        tools = {tool_of(o.data.materials[f.material_index]) if f.material_index < len(o.data.materials) else ""
                 for f in o.data.polygons}
        if len(tools) == 1 and next(iter(tools)) in WHOLE_TOOLS:
            continue
        seen.append(o)
        if not set(face_surfaces(o)) & SEE_THROUGH:
            planes = convex_planes(o)
            if planes:
                solid.append((o, planes))
    return seen, solid


def face_samples(points, centre, spacing):
    """Points all over a polygon (world space): a fan of triangles, each sampled on a grid finer than spacing, pulled a
    hair toward the middle (so a corner on another brush's edge is not taken for outside it)."""
    out = [centre]
    for i in range(1, len(points) - 1):
        a, b, c = points[0], points[i], points[i + 1]
        n = max(1, min(24, int(math.ceil(max((b - a).length, (c - a).length, (c - b).length) / spacing))))
        for u in range(n + 1):
            for v in range(n + 1 - u):
                p = (a * (n - u - v) + b * u + c * v) / n
                out.append(centre + (p - centre) * 0.98)
    return out


PART_KEYS = ("ps_brush", "ps_entity", "ps_surface", "ps_nocollide", "ps_edge_clip")
# The convex pieces closing the map (sealed.py), and the faces not seen that still stop the bake's light (world space:
# Nodraw ones, those left out as nobody sees them), filled by prepare_brushes and leave_out_unseen.
SEAL = []
CLEAR = []  # the player clips: closing the map, seen through
BLOCKERS = []


def loose_parts(mesh):
    """The face indices of each separate piece of a mesh (faces joined by shared corners)."""
    bm = bmesh.new()
    bm.from_mesh(mesh)
    bm.faces.ensure_lookup_table()
    done, parts = set(), []
    for f in bm.faces:
        if f.index in done:
            continue
        done.add(f.index)
        stack, part = [f], []
        while stack:
            g = stack.pop()
            part.append(g.index)
            for v in g.verts:
                for h in v.link_faces:
                    if h.index not in done:
                        done.add(h.index)
                        stack.append(h)
        parts.append(part)
    bm.free()
    return parts


def split_parts(o, link=None):
    """A brush made of separate convex pieces (ps_parts: the add-on's stairs, steps and clip ramp in one object, to move
    as one) as one brush per piece, each with the brush's settings: a piece all of a tool material (the clip ramp) is
    then that tool, the others are seen. The pieces are linked to `link` when given; the brush itself is left alone."""
    pieces = []
    for i, part in enumerate(loose_parts(o.data)):
        bm = bmesh.new()
        bm.from_mesh(o.data)
        bm.faces.ensure_lookup_table()
        keep = set(part)
        bmesh.ops.delete(bm, geom=[f for f in bm.faces if f.index not in keep], context="FACES")
        # The other pieces' corners too (FACES leaves them): the piece is only itself.
        loose = [v for v in bm.verts if not v.link_faces]
        if loose:
            bmesh.ops.delete(bm, geom=loose, context="VERTS")
        mesh = bpy.data.meshes.new(f"{o.data.name} part {i}")
        bm.to_mesh(mesh)
        bm.free()
        for m in o.data.materials:
            mesh.materials.append(m)
        piece = bpy.data.objects.new(f"{o.name} part {i}", mesh)
        piece.matrix_world = o.matrix_world.copy()
        for key in PART_KEYS:
            if key in o:
                piece[key] = o[key]
        if link is not None:
            link.objects.link(piece)
        pieces.append(piece)
    return pieces


def _box(points, grow=0.0):
    g = Vector((grow, grow, grow))
    return Vector(map(min, *points)) - g, Vector(map(max, *points)) + g


def _overlap(a, b):
    return all(a[0][k] <= b[1][k] and b[0][k] <= a[1][k] for k in range(3))


def clip_brush(o, solid_planes, spacing=8 * 0.025, boxes=None):
    """A seen brush as a bmesh in world space, its faces cut where other solid brushes reach into them (as VBSP does: a
    wall's side half inside another wall is split at that wall's faces), and the faces of it no player can see: tool faces
    (nodraw), and pieces covered all over by other solid brushes, each point inside one of them (one brush or several
    together), unless marked always drawn. The add-on shows the same before export."""
    eps = 0.5 * 0.025
    bm = bmesh.new()
    bm.from_mesh(o.data)
    bm.transform(o.matrix_world)
    if bm.edges and all(e.is_manifold for e in bm.edges):
        # Its normals for where it is now first: recalc_face_normals goes by them, and those of before the transform (a
        # brush turned 180°: the other way) made it turn a right brush inside out (stairs seen from inside in the game).
        bm.normal_update()
        bmesh.ops.recalc_face_normals(bm, faces=bm.faces[:])  # a closed brush faces outward (it is one-sided in the game)
    bm.normal_update()
    keep = bm.faces.layers.int.get(KEEP)
    mats = o.data.materials

    def is_tool(f):
        return bool(tool_of(mats[f.material_index] if f.material_index < len(mats) else None))

    def cuttable(f):
        return not is_tool(f) and not (keep is not None and f[keep])

    near = []
    if bm.verts:
        own = _box([v.co for v in bm.verts], eps)
        for other, planes in solid_planes:
            if other is o:
                continue
            # Its box as it was before any brush was cut (`boxes`): one cut away whole (inside another wall) still hides.
            if boxes is not None and other.name in boxes:
                box = boxes[other.name]
            elif other.data.vertices:
                box = _box([other.matrix_world @ v.co for v in other.data.vertices], eps)  # (bound_box: not for pieces)
            else:
                continue
            if _overlap(own, box):
                near.append((planes, box, other.name))
    # Cut: each face reaching into a brush is split along that brush's planes, one after another, only the part still
    # inside it going on to the next plane (the cuts stay within the brush, not across the whole face).
    for planes, box, _ in near:
        inside = [f for f in bm.faces if cuttable(f) and _overlap(_box([v.co for v in f.verts]), box)]
        for pn, pd in planes:
            if not inside:
                break
            nxt = []
            for f in inside:
                side = [pn.dot(v.co) - pd for v in f.verts]
                if max(side) <= 1e-4:
                    nxt.append(f)
                    continue
                if min(side) >= -1e-4:
                    continue  # wholly in front of this plane: outside the brush
                cut = bmesh.ops.bisect_plane(bm, geom=[f, *f.edges, *f.verts], plane_co=pn * pd, plane_no=pn,
                                             dist=1e-5)["geom_cut"]
                pieces = {lf for e in cut if isinstance(e, bmesh.types.BMEdge) for lf in e.link_faces}
                for piece in pieces or {f}:
                    if pn.dot(piece.calc_center_median()) - pd <= 0:
                        nxt.append(piece)
            inside = nxt
    bm.normal_update()
    hidden = []
    for f in bm.faces:
        if is_tool(f):
            hidden.append(f)
            continue
        if not cuttable(f):
            continue
        if f.calc_area() < 1e-6:
            hidden.append(f)  # a sliver of a cut (brushes a hair off each other): nothing to see
            continue
        pts = [v.co.copy() for v in f.verts]
        fbox = _box(pts)
        covering = [(planes, name) for planes, box, name in near if _overlap(fbox, box)]
        if not covering:
            continue
        n = f.normal

        def covered(p, planes, name):
            # On a brush's side counts as covered: two brushes side by side leave no gap at their seam.
            if all(pn.dot(p + n * eps) - pd <= 1e-4 for pn, pd in planes):
                return True
            # Two faces one on the other, looking the same way (brushes overlapping, their sides in one plane): one
            # is enough — the other flickered in the game and baked black (each in the other's shadow). The brush of
            # the name first in order keeps its face.
            return (name < o.name and all(pn.dot(p) - pd <= 1e-4 for pn, pd in planes)
                    and any(pn.dot(n) > 0.9999 and abs(pn.dot(p) - pd) < 1e-4 for pn, pd in planes))
        if all(any(covered(p, planes, name) for planes, name in covering)
               for p in face_samples(pts, f.calc_center_median(), spacing)):
            hidden.append(f)
    return bm, hidden


def prepare_brushes(taken):
    """Turns the add-on's brushes into what the rest of the export knows: tool brushes into their entities, seen brushes into
    seen objects (their tool faces, such as nodraw, left out) and collision (the whole brush, unless it is a detail or set
    not to collide). The seen ones are made light: a face lying inside another solid brush is never seen and goes, and the
    brushes are joined into one object per kind and surface. Works on the exported copy only (the file is not saved)."""
    for o in [o for o in taken if o.type == "MESH" and o.get("ps_brush") and o.get("ps_parts")]:
        pieces = split_parts(o, bpy.context.scene.collection)
        if o.get("ps_nocollide") and o.get("ps_stairs"):
            # Stairs walk on their clip ramp, the steps not colliding. One without a ramp (edited by hand, its ramp gone
            # or no longer of the clip material) let players through it: its steps collide then.
            def all_clip(p):
                mats = p.data.materials
                return all(tool_of(mats[f.material_index] if f.material_index < len(mats) else None) == "clip"
                           for f in p.data.polygons)
            if not any(all_clip(p) for p in pieces):
                print(f"{o.name}: stairs without their clip ramp: its steps collide instead (players walked through it)")
                for p in pieces:
                    p.pop("ps_nocollide", None)
        taken = [t for t in taken if t is not o] + pieces
        bpy.data.objects.remove(o, do_unlink=True)
    brushes = [o for o in taken if o.type == "MESH" and o.get("ps_brush")]
    if not brushes:
        return taken
    made, seen = [], []
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    try:
        import sealed
    finally:
        sys.path.pop(0)
    SEAL.clear()
    CLEAR.clear()
    BLOCKERS.clear()
    for o in brushes:
        o.data = o.data.copy()  # linked copies (Alt+D) share a mesh; each gets its own UVs and faces
        tools = {tool_of(o.data.materials[f.material_index]) if f.material_index < len(o.data.materials) else ""
                 for f in o.data.polygons}
        if len(tools) == 1 and next(iter(tools)) in WHOLE_TOOLS:
            o["ps_entity"] = WHOLE_TOOLS[next(iter(tools))]
            if next(iter(tools)) == "clip":
                CLEAR.extend(sealed.convex_pieces(o))  # a player clip closes the map too (the edge's up to the ceiling)
            continue
        # What closes the map (sealed.py): its walls, Nodraw ones too; not details nor what is seen through (Source's
        # func_detail and glass).
        if (o.get("ps_entity") in (None, "world", "solid") and not o.get("ps_nocollide")
                and not set(face_surfaces(o)) & SEE_THROUGH):
            SEAL.extend(sealed.convex_pieces(o))
        kind = o.get("ps_entity") if o.get("ps_entity") in ("world", "solid", "detail") else "world"
        o["ps_entity"] = kind
        if o.get("ps_stairs") and o.get("ps_nocollide") and "clip" not in tools:
            # Stairs in one piece with no clip ramp (see above): the steps collide.
            print(f"{o.name}: stairs without their clip ramp: its steps collide instead (players walked through it)")
            o.pop("ps_nocollide", None)
        if kind != "detail" and not o.get("ps_nocollide"):
            col = o.copy()
            col.data = o.data.copy()
            col.name = o.name + " collision"
            col["ps_entity"] = "collision"
            del col["ps_brush"]
            bpy.context.scene.collection.objects.link(col)
            made.append(col)
        seen.append(o)
    # A brush is a closed solid, its faces seen from outside only (as in Source): one-sided in the game, else the inside of
    # a wall shows from within it (glTF writes a material without backface culling as double-sided).
    for o in seen:
        for m in o.data.materials:
            if m is not None:
                m.use_backface_culling = True
    # Faces a player never sees: tool faces (nodraw), and faces (or their parts) covered all over by other solid brushes.
    _, solid_planes = brush_roles(seen)
    # Every solid brush's box now, before any is cut: one whose faces all go (a wall inside another) is still there.
    boxes = {other.name: _box([other.matrix_world @ v.co for v in other.data.vertices], 0.5 * 0.025)
             for other, _ in solid_planes if other.data.vertices}
    for o in seen:
        bm, hidden = clip_brush(o, solid_planes, boxes=boxes)
        # Nodraw faces are not seen, but they are walls: the bake's light stops at them (else it shone through the map's
        # edge, a lamp's out onto the roofs).
        mats = o.data.materials
        for f in hidden:
            if tool_of(mats[f.material_index] if f.material_index < len(mats) else None) == "nodraw":
                BLOCKERS.append([v.co.copy() for v in f.verts])
        bmesh.ops.delete(bm, geom=hidden, context="FACES")
        # The pieces left of one face back into one (fewer triangles).
        bmesh.ops.dissolve_limit(bm, angle_limit=0.005, verts=bm.verts[:], edges=bm.edges[:], delimit={"MATERIAL"})
        bm.transform(o.matrix_world.inverted())
        bm.to_mesh(o.data)
        bm.free()
        world_uvs(o)  # after the cuts: the pieces tile on as before
    # One object per kind and surface: fewer pieces to draw.
    groups = {}
    for o in seen:
        if len(o.data.polygons):
            groups.setdefault((o["ps_entity"], str(o.get("ps_surface", ""))), []).append(o)
    for (kind, surface), objs in groups.items():
        mats, bm = [], bmesh.new()
        for o in objs:
            first = len(bm.faces)
            part = o.data.copy()
            part.transform(o.matrix_world)
            bm.from_mesh(part)
            bm.faces.ensure_lookup_table()
            for f in bm.faces[first:]:
                m = o.data.materials[f.material_index] if f.material_index < len(o.data.materials) else None
                if m not in mats:
                    mats.append(m)
                f.material_index = mats.index(m)
            bpy.data.meshes.remove(part)
        mesh = bpy.data.meshes.new(f"Brushes {kind} {surface}".strip())
        bm.to_mesh(mesh)
        bm.free()
        for m in mats:
            mesh.materials.append(m)
        joined = bpy.data.objects.new(mesh.name, mesh)
        bpy.context.scene.collection.objects.link(joined)
        joined["ps_entity"] = kind
        if surface:
            joined["ps_surface"] = surface
        made.append(joined)
    gone = set(seen)
    kept = [o for o in taken if o not in gone]
    for o in seen:
        bpy.data.objects.remove(o, do_unlink=True)
    return kept + made


def open_everything():
    """What the file holds goes out as it is, however it was left in the views: a collection unticked (excluded), an object
    made unselectable or turned off in the viewports cannot be selected for the .glb (nor joined, nor baked), and would
    be missing from it while still listed. Only this export's copy of the file is changed (it is not saved)."""
    def walk(layer):
        if layer.collection.get("ps_export", 1) in (0, False):
            return  # references, examples (left out of the map): left as they are, often big
        layer.exclude = False
        layer.hide_viewport = False
        layer.collection.hide_viewport = False
        layer.collection.hide_select = False
        for o in layer.collection.objects:
            o.hide_viewport = False
            o.hide_select = False
        for child in layer.children:
            walk(child)
    for child in bpy.context.view_layer.layer_collection.children:
        walk(child)
    for o in bpy.context.scene.collection.objects:
        o.hide_viewport = False
        o.hide_select = False


def left_out():
    """Objects of collections marked ps_export = 0 (and of the collections inside them): references, examples, helpers."""
    out = set()

    def walk(col, skipped):
        skipped = skipped or col.get("ps_export", 1) in (0, False)
        if skipped:
            out.update(col.objects)
        for child in col.children:
            walk(child, skipped)
    walk(bpy.context.scene.collection, False)
    return out


def radar(manifest, seen, folder, scene, tris=None):
    """The radar pictures (radar_gen.py, Docs/radar-generator.md), when the map tools' Radar is on: the floor players can
    get to, walked from the spawns. A map it cannot be made for still exports, without a radar."""
    if not getattr(scene, "ps_radar", True):
        print("Radar: off in the map tools")
        return
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    try:
        import radar_gen
        settings = {
            "resolution": int(getattr(scene, "ps_radar_resolution", "1024") or 1024),
            "cover": float(getattr(scene, "ps_radar_cover", 3.0)),
            "ao": bool(getattr(scene, "ps_radar_ao", True)),
            "ao_strength": float(getattr(scene, "ps_radar_ao_strength", 0.45)),
            "shadow": bool(getattr(scene, "ps_radar_shadow", True)),
            "tints": bool(getattr(scene, "ps_radar_tints", True)),
            "debug": bool(os.environ.get("PS_RADAR_DEBUG")),
            "images": {i: bpy.path.abspath(path) for i in range(4)
                       for path in [str(getattr(scene, f"ps_radar_image_{i}", "") or "")] if path},
        }
        block = radar_gen.generate(manifest, radar_gen.seen_triangles(seen) if tris is None else tris, folder, settings)
        if block:
            manifest["radar"] = block
    except Exception as e:  # the map is still worth playing without it
        import traceback
        traceback.print_exc()
        print(f"Radar: not made: {e}")
    finally:
        sys.path.pop(0)


def map_ceiling(scene, brushes):
    """The map's ceiling (metres): its own (the map tools' Map ceiling, units), else 128 units over its highest brush."""
    own = float(getattr(scene, "ps_map_ceiling", 0) or 0)
    if own > 0:
        return own * UNIT
    tops = [max((o.matrix_world @ v.co).z for v in o.data.vertices) for o in brushes
            if o.type == "MESH" and o.data.vertices and not o.get("ps_edge_clip")]
    return (max(tops) if tops else 0.0) + 128 * UNIT


def sealed_air(scene, taken):
    """The air reached from the spawns (sealed.py), or None (no spawns, nothing closing). A leak is told, the air still
    returned (its `leak` set): the faces are then not left out by it."""
    import sealed
    spawns = [o.matrix_world.translation + Vector((0, 0, 32 * UNIT)) for o in taken if o.get("ps_entity") == "spawn"]
    ceiling = map_ceiling(scene, [o for o in taken if o.get("ps_entity") in ("world", "solid", "detail")])
    air = sealed.flood(SEAL, [tuple(p) for p in spawns], ceiling, CLEAR)
    if air is None:
        print("Sealed: no spawns or no walls, the air not flooded")
    elif air.leak is not None:
        p = air.centre(air.leak)
        print(f"Sealed: LEAK, the air from the spawns gets out of the map near ({p.x:.1f}, {p.y:.1f}, {p.z:.1f}) m "
              "(Check map shows the way): the outside is kept")
    else:
        print(f"Sealed: closed ({int(air.reached.sum())} cells of air, {air.cell / UNIT:.0f} units each)")
    return air


def baked_light(manifest, seen, folder, mode, tris=None):
    """With a bake mode (fast / final): the light baked into lightmaps and probes, the manifest's "baked" block; the seen
    objects as they now are (split to fit their atlases). Without one, the last bake's pictures go (they would not fit
    this export's surfaces): the map shows its test light."""
    if not mode:
        i = 0
        while os.path.exists(os.path.join(folder, f"lightmap_{i}.png")):
            os.remove(os.path.join(folder, f"lightmap_{i}.png"))
            i += 1
        return seen
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    try:
        import bake_light
        import radar_gen
        block, seen = bake_light.bake(seen, manifest, radar_gen.seen_triangles(seen) if tris is None else tris, folder, mode,
                                      blockers=BLOCKERS)
        manifest["baked"] = block
        manifest["light"] = "baked"  # whoever plays it sees the baked light (not the test light chosen)
    finally:
        sys.path.pop(0)
    return seen


def main(folder, bake=None):
    os.makedirs(folder, exist_ok=True)
    name = os.path.splitext(os.path.basename(bpy.data.filepath))[0] or "map"
    scene = bpy.context.scene
    # A file saved in Edit Mode: its edits are in the meshes once out of it.
    if bpy.context.object is not None and bpy.context.object.mode != "OBJECT":
        bpy.ops.object.mode_set(mode="OBJECT")
    open_everything()
    skipped = left_out()
    taken = prepare_brushes([o for o in scene.objects if o not in skipped])
    # Surfaces from the materials, face by face (Hammer's $surfaceprop): the seen objects as one object per surface.
    split = []
    for o in taken:
        if o.type == "MESH" and o.get("ps_entity") in ("world", "solid", "detail") and o.display_type != "WIRE":
            split.extend(split_by_surface(o, scene.collection))
        else:
            split.append(o)
    taken = split
    seen = [o for o in taken if o.type == "MESH" and o.get("ps_entity") in SEEN and o.display_type != "WIRE"]
    entities, collision = [], []
    # A breakable's (or any entity's) own collision goes with it: the object it shares its "ps_owner" (or CS model) with.
    owners = {}
    for o in taken:
        if o.get("ps_entity") is not None and o.get("ps_entity") not in CLIPS:
            key = o.get("ps_owner") or o.get("cs_model")
            if key:
                owners[key] = o.name
    for obj in taken:
        kind = obj.get("ps_entity")
        if not kind or kind in ("world", "solid", "detail"):
            continue
        if kind in CLIPS:
            # Each block: "p" its corners (x, y, z, ...), "t" its triangles (counter-clockwise from outside, in Blender's
            # winding; glTF space keeps it, as its turn of axes is not a mirror).
            if obj.get("ps_concave"):
                # Not convex (terrain, models' own shapes): the whole mesh is one block, its triangles as they are.
                points, tris = whole_mesh(obj)
                blocks = [{"p": [c for p in points for c in gltf(p)], "t": tris, "c": True}] if tris else []
            else:
                # A part that is not convex (an L, a U, one turned inside out) is cut into convex pieces that fill it
                # (convex_pieces); only when that cannot be done does it go as it is (a shell: one-sided to players).
                blocks = []
                for points, tris in convex_meshes(obj):
                    if is_convex(points, tris):
                        blocks.append({"p": [c for p in points for c in gltf(p)], "t": tris})
                        continue
                    pieces = convex_pieces(points, tris)
                    if pieces:
                        blocks += [{"p": [c for p in pts for c in gltf(p)], "t": t} for pts, t in pieces]
                        print(f"{obj.name}: not convex, cut into {len(pieces)} convex piece(s) for collision")
                    else:
                        blocks.append({"p": [c for p in points for c in gltf(p)], "t": tris, "c": True})
                        print(f"{obj.name}: not convex and could not be cut into convex pieces: collides as a shell")
            entry = {"name": obj.name, "blocks": blocks}
            if kind != "collision":
                entry["kind"] = CLIPS[kind]
            owner = owners.get(obj.get("ps_owner") or obj.get("cs_model"))
            if owner:
                entry["entity"] = owner
            collision.append(entry)
            continue
        entities.append(entity_of(obj))

    glb = os.path.join(folder, name + ".glb")
    manifest = {
        "format": FORMAT,
        "generator": GENERATOR,
        "name": name,
        "space": "gltf",
        "unitMetres": float(scene.get("cs_unit_metres", 0.025)),
        "visual": os.path.basename(glb),
        "nodes": [],
        "entities": entities,
        "collision": collision,
    }
    # The Workshop's card: who made it, what it is, its version (the map tools' fields), and its picture.
    for key in ("author", "description", "version"):
        # The add-on's own properties (Blender 5 keeps them apart from the scene's custom properties).
        value = str(getattr(scene, "ps_" + key, "") or scene.get("ps_" + key, "") or "").strip()
        if value:
            manifest[key] = value
    # How the map is lit while its light is not baked (the test light chosen in the map tools): everyone who plays this
    # package, players who download it from the server too, sees it the same way.
    light = str(getattr(scene, "ps_test_light", "") or "").strip().lower()
    if light in ("faces", "flat", "sun"):
        manifest["light"] = light
    # The mode chosen in the map tools: a game that has the map (a phone's Workshop) plays it so when it can.
    mode = str(getattr(scene, "ps_ruleset", "") or "").strip()
    if mode:
        manifest["mode"] = mode
    preview = os.path.splitext(bpy.data.filepath)[0] + "_preview.png"
    if os.path.exists(preview):
        shutil.copyfile(preview, os.path.join(folder, PREVIEW))
    elif os.path.exists(os.path.join(folder, PREVIEW)):
        os.remove(os.path.join(folder, PREVIEW))
    source = scene.get("cs_source")
    if source:
        manifest["source"] = source
        bsp = os.path.join(os.path.dirname(bpy.data.filepath), source)
        if os.path.exists(bsp):
            models = write_hull(bsp, os.path.join(folder, "hull.bin"))
            manifest["hull"] = "hull.bin"
            print(f"Hull: {models} models from {source}")
    # The light baked (bake_light.py): the seen objects get their lightmap UVs before they go into the .glb.
    # What the radar and the probes walk on: the map whole (before the faces nobody sees go: a roof's top, say).
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    try:
        import radar_gen
        import visibility
        whole = radar_gen.seen_triangles(seen)
        if getattr(scene, "ps_cull_unseen", True):
            try:
                air = sealed_air(scene, taken)
                visibility.leave_out_unseen(seen, manifest, whole, folder, KEEP, SEE_THROUGH, air=air,
                                            blockers=BLOCKERS)
            except Exception as e:  # noqa: BLE001  (the map is still right with them)
                import traceback
                traceback.print_exc()
                print(f"Unseen faces: kept ({e})")
    finally:
        sys.path.pop(0)
    seen = baked_light(manifest, seen, folder, bake, whole)

    # What is seen: one .glb, each object a node of its name.
    bpy.ops.object.select_all(action="DESELECT")
    for o in seen:
        o.hide_set(False)
        o.select_set(True)
    bpy.ops.export_scene.gltf(filepath=glb, export_format="GLB", use_selection=True, export_apply=True,
                              export_yup=True, export_extras=True, export_cameras=False, export_lights=False,
                              export_animations=False)
    manifest["nodes"] = [dict({"name": o.name, "type": o.get("ps_entity")},
                              **({"surface": str(o["ps_surface"])} if o.get("ps_surface") else {})) for o in seen]
    radar(manifest, seen, folder, scene, whole)
    with open(os.path.join(folder, "map.json"), "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, separators=(",", ":"))
    counts = {}
    for e in entities:
        counts[e["type"]] = counts.get(e["type"], 0) + 1
    blocks = sum(len(c["blocks"]) for c in collision)
    print(f"Exported {name}: {len(seen)} seen objects, {blocks} collision blocks, entities {counts}")


if __name__ == "__main__":
    args = sys.argv[sys.argv.index("--") + 1:] if "--" in sys.argv else []
    if not args:
        raise SystemExit("usage: blender -b <map.blend> --python export_map.py -- <package folder> [--bake fast|final]")
    mode = args[args.index("--bake") + 1] if "--bake" in args and args.index("--bake") + 1 < len(args) else None
    main(args[0], mode)
