"""The map tools' interface: tabs of their own in the 3D view's sidebar (N) — Build, Object, Entities, View, Play — each
short, its parts folding; the selected object's settings in a popup at the mouse (F); the brush tools and the materials
in pie menus (Q, Shift+Q). Blender's own Properties editor is left as it is."""
import bpy

from . import (UNIT, DEV, DEV_SURFACES, TOOLS, ENTITIES, GROUPS, group_shown, busy, game_path, has_preview, is_brush,
               is_map_file, _export, HAS_UNITY, MAP_FORMAT, game_reads)
from . import brush_tools, makers, overlay, walk, cutters


class Tab:
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"


# ---------- Build ----------
class MAP_PT_build_grid(Tab, bpy.types.Panel):
    bl_category = "Build"
    bl_label = "Grid"

    def draw(self, context):
        scene = context.scene
        row = self.layout.row(align=True)
        row.operator("psmap.grid", text="[ smaller").step = -1
        row.label(text=f"{scene.ps_grid_units} u = {scene.ps_grid_units * UNIT:.2f} m")
        row.operator("psmap.grid", text="bigger ]").step = 1
        self.layout.operator("psmap.quad_view", icon="VIEW_ORTHO")


class MAP_PT_build_brushes(Tab, bpy.types.Panel):
    bl_category = "Build"
    bl_label = "Brushes"

    def draw(self, context):
        layout = self.layout
        row = layout.row()
        row.scale_y = 1.4
        row.operator("psmap.draw_brush", icon="ADD")
        row.operator("psmap.resize", text="Resize", icon="FULLSCREEN_ENTER")
        row = layout.row(align=True)
        row.operator("psmap.box", icon="MESH_CUBE")
        row.operator("psmap.snap_to_grid", text="Snap", icon="SNAP_GRID")
        row.operator("psmap.square", text="Square", icon="MESH_CUBE")
        row.operator("psmap.make_brushes", text="Split", icon="MOD_EXPLODE")
        layout.label(text="Q: tools round the mouse, Shift+Q: materials, F: the selected's settings", icon="INFO")


class MAP_PT_build_tools(Tab, bpy.types.Panel):
    bl_category = "Build"
    bl_label = "Brush tools"

    def draw(self, context):
        brush_tools.draw_buttons(self.layout)


def material_buttons(layout):
    col = layout.column(align=True)
    col.label(text="Colours:")
    grid = col.grid_flow(columns=3, align=True)
    for name, _ in DEV:
        grid.operator("psmap.material", text=name[4:]).name = name
    col.label(text="Surfaces (what bullets go through, steps):")
    grid = col.grid_flow(columns=3, align=True)
    for surface, name, _ in DEV_SURFACES:
        grid.operator("psmap.material", text=name[4:]).name = name
    col.label(text="Tools (Hammer's tool textures):")
    grid = col.grid_flow(columns=2, align=True)
    for tool, name, _, tip in TOOLS:
        grid.operator("psmap.material", text=name[5:]).name = name


class MAP_PT_build_materials(Tab, bpy.types.Panel):
    bl_category = "Build"
    bl_label = "Materials"

    def draw(self, context):
        material_buttons(self.layout)


# ---------- Object: what is selected ----------
def draw_selected(layout, context):
    """The selected brush's or entity's settings (the Object tab, and the popup at the mouse)."""
    obj = context.active_object
    if obj is None or not obj.select_get():
        layout.label(text="Nothing selected: select a brush or an entity", icon="INFO")
        return
    layout.label(text=obj.name, icon="OBJECT_DATA")
    from . import models, doors, training
    if doors.is_door(obj):
        doors.draw(layout, obj)
        return
    if training.is_panel(obj) or training.is_mover(obj) or training.is_stand(obj):
        training.draw(layout, obj)
        return
    if obj.get("ps_card_of"):
        layout.label(text=f"Picture of {obj['ps_card_of']} (its original kept, hidden)", icon="IMAGE_RGB_ALPHA")
        layout.operator("psmap.model_cards", icon="LOOP_BACK", depress=True, text="Leaves as pictures: off (originals back)")
        return
    if models.is_model(obj):
        boxes = models.boxes_of(obj)
        layout.label(text=f"Model: seen as it is, lit as players are; {len(boxes)} collision box(es)", icon="MESH_MONKEY")
        if not boxes:
            layout.label(text="No collision: players and bullets go through it", icon="INFO")
        row = layout.row(align=True)
        row.operator("psmap.add_collision_box", icon="MESH_CUBE")
        row.operator("psmap.model_back", icon="LOOP_BACK")
        layout.operator("psmap.make_door", icon="MOD_SIMPLEDEFORM", text="Make door (opens with E)")
        layout.operator("psmap.make_mover", icon="TRIA_UP_BAR", text="Make mover (comes out by a rule)")
        # Lighter: its triangles, as it is and as the game gets it.
        mod = models.simplify_of(obj)
        now = models.triangles_now(obj, context.evaluated_depsgraph_get())
        box = layout.box()
        box.label(text=(f"Triangles: {models.triangles(obj.data):,} → {now:,}" if mod else f"Triangles: {now:,}"),
                  icon="MOD_DECIM")
        row = box.row(align=True)
        if mod is not None:
            row.prop(mod, "ratio", text="Keep", slider=True)
            row.operator("psmap.model_simplify", text="Auto").how = "auto"
            row.operator("psmap.model_simplify", text="", icon="X").how = "off"
        else:
            row.operator("psmap.model_simplify", text="Simplify (Auto: by its size)", icon="MOD_DECIM").how = "auto"
        on = models.cards_on(obj)
        if on or any(models.flat_box(s) for s in models.card_sources(obj)):
            layout.operator("psmap.model_cards", icon="IMAGE_RGB_ALPHA", depress=on,
                            text="Leaves as pictures: on (again: the originals back)" if on
                            else "Leaves as pictures (light: two triangles each)")
        return
    if obj.get("ps_model_box") and obj.parent is not None:
        layout.label(text=f"Collision box of {obj.parent.name}: players and bullets; moves with it", icon="MESH_CUBE")
        layout.label(text="Resize trims it; delete it for no collision there")
    if obj.type == "MESH" and not obj.get("ps_model_box") and obj.get("ps_entity") in (None, "world", "solid", "detail"):
        layout.operator("psmap.make_model", icon="MESH_MONKEY",
                        text="Make model (as it is, a collision box)" if is_brush(obj) else "Make model: not in the game until then")
    if is_brush(obj) and obj.get("ps_entity") == "cutter":
        n = len(cutters.cut_by(obj, context.scene.objects))
        layout.label(text=f"Cutter: cuts {n} brush(es), not exported", icon="MOD_BOOLEAN")
        layout.label(text="G, Resize: the hole follows. Its material: the hole's sides")
        layout.operator("psmap.apply_cut", icon="CHECKMARK", text="Apply cut (for good, deletes the cutter)")
        if obj.ps_maker.kind:
            makers.draw(layout, obj)
        return
    if is_brush(obj):
        others = [o for o in context.selected_objects if o is not obj and is_brush(o)]
        if others:
            layout.operator("psmap.cut_through", icon="MOD_BOOLEAN",
                            text=f"Cut through: {obj.name} cuts {len(others)} other(s)")
        layout.operator("psmap.make_door", icon="MOD_SIMPLEDEFORM", text="Make door (opens with E)")
        layout.operator("psmap.make_mover", icon="TRIA_UP_BAR", text="Make mover (comes out by a rule)")
        cuts = cutters.cuts_of(obj)
        if cuts:
            layout.operator("psmap.apply_cut", icon="CHECKMARK", text=f"Apply cut ({len(cuts)} cutter(s))")
        col = layout.column(align=True)
        row = col.row(align=True)
        kind = "detail" if obj.get("ps_entity") == "detail" else "nocollide" if obj.get("ps_nocollide") else "solid"
        for k, label in (("solid", "Solid"), ("detail", "Detail"), ("nocollide", "No collision")):
            row.operator("psmap.brush_kind", text=label, depress=(kind == k)).kind = k
        mat = obj.active_material
        if mat is not None and not mat.get("ps_tool"):
            col.operator_menu_enum("psmap.material_surface", "surface",
                                   text=f"{mat.name}: {mat.get('ps_surface', 'default')}")
        col.operator_menu_enum("psmap.surface", "surface",
                               text=f"Object override: {obj.get('ps_surface', 'none (the materials say)')}")
        from . import sky
        sky.draw_density(layout, obj, context)
        from . import open_pieces, map_collection, map_objects
        if obj.type == "MESH" and open_pieces(obj):
            row = layout.row(align=True)
            row.operator("psmap.make_solid", icon="MOD_SOLIDIFY", text="Make solid (not closed)")
            row.operator("psmap.problem_edges", icon="EDGESEL", text="Show problem edges")
        root = map_collection(context.scene)
        if root is not None and obj.name not in {o.name for o in map_objects(root)}:
            layout.operator("psmap.into_map", icon="IMPORT", text="Move into the map (outside its collection)")
        if obj.ps_maker.kind:
            makers.draw(layout, obj)
        else:
            plain = [o for o in context.selected_objects if is_brush(o) and not o.ps_maker.kind]
            if len(plain) > 1 or obj.get("ps_parts"):
                # Pieces round a door (a wall with openings edited by hand, or an old wall of three brushes): one wall
                # with openings again.
                layout.operator("psmap.wall_again", icon="MOD_BUILD",
                                text="Wall with openings again" if len(plain) < 2 else f"Join {len(plain)} into a wall with openings")
        return
    kind = obj.get("ps_entity")
    if kind not in ("spawn", "bombsite", "buyzone", "light", "sun", "radarcolor", "ambient"):
        layout.label(text="Nothing to set on it here", icon="INFO")
        return
    col = layout.column(align=True)
    col.label(text=f"{kind}")
    if kind in ("spawn", "buyzone"):
        row = col.row(align=True)
        for team in ("T", "CT"):
            op = row.operator("psmap.set", text=team, depress=obj.get("ps_team") == team)
            op.key, op.value = "team", team
        if kind == "spawn":
            from . import training
            training.draw_spawn(col, obj)
    if kind == "bombsite":
        row = col.row(align=True)
        for site in ("A", "B"):
            op = row.operator("psmap.set", text=site, depress=obj.get("ps_site") == site)
            op.key, op.value = "site", site
    if kind in ("light", "sun", "radarcolor", "ambient"):
        for key in {"light": ("ps_color", "ps_brightness", "ps_range"), "sun": ("ps_color", "ps_brightness"),
                    "radarcolor": ("ps_color",), "ambient": ("ps_color", "ps_brightness", "ps_fade")}[kind]:
            if key in obj:
                col.prop(obj, f'["{key}"]', text=key[3:].capitalize())
    if kind == "sun":
        from . import sun_way, preview_sun
        import math
        way = sun_way(obj)
        down = math.degrees(math.asin(max(-1.0, min(1.0, -way.z))))
        side = math.degrees(math.atan2(way.y, way.x)) % 360
        layout.label(text=f"Light goes {down:.0f}° down, toward {side:.0f}° from +X", icon="LIGHT_SUN")
        layout.label(text="Its arrow is the way (R turns it); where it stands does not matter")
        on = preview_sun(context.scene) is not None
        layout.operator("psmap.preview_sun", icon="LIGHT_SUN", depress=on,
                        text="Sun's shadows: on (again: off)" if on else "Preview sun (its shadows here)")


class MAP_PT_object(Tab, bpy.types.Panel):
    bl_category = "Object"
    bl_label = "Selected"

    def draw(self, context):
        draw_selected(self.layout, context)


class MAP_OT_selected_popup(bpy.types.Operator):
    bl_idname = "psmap.selected_popup"
    bl_label = "Settings of the selected"
    bl_description = "The selected brush's or entity's settings at the mouse (as the Object tab): changed, it is built again"

    def invoke(self, context, event):
        if not is_map_file(context.scene):
            return {"PASS_THROUGH"}
        return context.window_manager.invoke_popup(self, width=340)

    def draw(self, context):
        draw_selected(self.layout, context)

    def execute(self, context):
        return {"FINISHED"}


# ---------- Entities ----------
class MAP_PT_entities(Tab, bpy.types.Panel):
    bl_category = "Entities"
    bl_label = "Add at the 3D cursor"

    def draw(self, context):
        grid = self.layout.grid_flow(columns=2, align=True)
        for k, label, tip in ENTITIES:
            grid.operator("psmap.add_entity", text=label).kind = k
        self.layout.label(text="Ladder, zones: a brush selected becomes it", icon="INFO")


# ---------- View ----------
class MAP_PT_view_groups(Tab, bpy.types.Panel):
    bl_category = "View"
    bl_label = "Show / hide"

    def draw(self, context):
        grid = self.layout.grid_flow(columns=3, align=True)
        for g, label, tip in GROUPS:
            shown = group_shown(context, g)
            grid.operator("psmap.toggle", text=label, depress=shown, icon="HIDE_OFF" if shown else "HIDE_ON").group = g


class MAP_PT_view_overlays(Tab, bpy.types.Panel):
    bl_category = "View"
    bl_label = "In the views"

    def draw(self, context):
        overlay.draw(self.layout, context)
        from . import preview_sun
        on = preview_sun(context.scene) is not None
        self.layout.operator("psmap.preview_sun", icon="LIGHT_SUN", depress=on,
                             text="Sun's shadows: on (again: off)" if on else "Preview sun (its shadows here)")


class MAP_PT_view_timings(Tab, bpy.types.Panel):
    bl_category = "View"
    bl_label = "Timings"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        walk.draw(self.layout, context)


# ---------- Play ----------
class MAP_PT_play(Tab, bpy.types.Panel):
    bl_category = "Play"
    bl_label = "Check and play"

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        row = layout.row(align=True)
        row.prop(scene, "ps_map_collection", text="Map")
        row.operator("psmap.new_map", text="", icon="FILE_NEW")
        row.operator("psmap.flip_panel", text="", icon="ARROW_LEFTRIGHT")
        layout.operator("psmap.check", icon="VIEWZOOM")
        for i, item in enumerate(scene.ps_issues):
            row = layout.row(align=True)
            icon = {"error": "ERROR", "warning": "ERROR", "info": "INFO", "ok": "CHECKMARK"}.get(item.level, "DOT")
            row.label(text=item.text, icon=icon)
            if item.level != "ok":
                row.operator("psmap.go", text="", icon="VIEWZOOM").index = i
                if "triangles drawn" in item.text:
                    row.operator("psmap.select_heavy", text="", icon="RESTRICT_SELECT_OFF")
        layout.prop(scene, "ps_ruleset", text="Mode")
        layout.prop(scene, "ps_cull_unseen", text="Leave out faces nobody sees")
        layout.row(align=True).prop(scene, "ps_texture_size", expand=True)
        layout.label(text="Test light (nothing baked):")
        layout.row(align=True).prop(scene, "ps_test_light", expand=True)
        row = layout.row(align=True)
        row.scale_y = 1.4
        row.enabled = not busy()
        op = row.operator("psmap.export_play", text="Test and play", icon="PLAY")
        op.play, op.test = True, True
        layout.label(text="Baked light (Blender, Cycles):")
        row = layout.row(align=True)
        row.enabled = not busy()
        op = row.operator("psmap.export_play", text="Bake Fast & play", icon="LIGHT_SUN")
        op.play, op.test, op.bake = True, True, "fast"
        op = row.operator("psmap.export_play", text="Bake Final & play", icon="SHADING_RENDERED")
        op.play, op.test, op.bake = True, True, "final"
        if not game_path():
            layout.label(text="No game set (Preferences → Add-ons → Game)" +
                         (": Test goes to Unity" if HAS_UNITY else ": play it on the phone, below"), icon="INFO")
        elif (game_reads() or MAP_FORMAT) < MAP_FORMAT:
            layout.label(text="The game is older than the map tools: update the game", icon="ERROR")
        if busy():
            layout.label(text="Wait: still at work (don't press again)", icon="TIME")
        if scene.ps_status:
            failed = scene.ps_status.startswith("Export failed")
            layout.label(text=scene.ps_status, icon="ERROR" if failed else "TIME" if _export["proc"] is not None else "INFO")
            if failed:
                layout.operator("psmap.open_log", icon="TEXT")


class MAP_PT_play_light(Tab, bpy.types.Panel):
    bl_category = "Play"
    bl_label = "Light and sky"

    def draw(self, context):
        from . import sky
        sky.draw(self.layout, context.scene)


class MAP_PT_play_share(Tab, bpy.types.Panel):
    bl_category = "Play"
    bl_label = "Phone and sharing (.psmap)"

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.enabled = not busy()
        row = col.row(align=True)
        row.scale_y = 1.3
        op = row.operator("psmap.export_play", text="Export .psmap", icon="PACKAGE")
        op.play, op.test, op.share = False, False, True
        op = col.operator("psmap.export_play", text="Bake Final & export .psmap", icon="SHADING_RENDERED")
        op.play, op.test, op.share, op.bake = False, False, True, "final"
        layout.label(text="<map>.psmap beside the .blend: send it to the phone, the game's", icon="INFO")
        layout.label(text="Workshop imports it (Resources → Import map…), then Play")


class MAP_PT_play_more(Tab, bpy.types.Panel):
    bl_category = "Play"
    bl_label = "Unity (the game's project)"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls, context):
        return HAS_UNITY

    def draw(self, context):
        layout = self.layout
        layout.label(text="Baked in the Unity editor:")
        row = layout.row(align=True)
        row.enabled = not busy()
        op = row.operator("psmap.export_play", text="Export and play", icon="RENDER_STILL")
        op.play, op.test = True, False
        op = row.operator("psmap.export_play", text="Compile only")
        op.play, op.test = False, False


class MAP_PT_play_radar(Tab, bpy.types.Panel):
    bl_category = "Play"
    bl_label = "Radar"
    bl_options = {"DEFAULT_CLOSED"}

    def draw_header(self, context):
        self.layout.prop(context.scene, "ps_radar", text="")

    def draw(self, context):
        scene = context.scene
        col = self.layout.column(align=True)
        col.enabled = scene.ps_radar
        col.row(align=True).prop(scene, "ps_radar_resolution", expand=True)
        col.prop(scene, "ps_radar_cover")
        row = col.row(align=True)
        row.prop(scene, "ps_radar_ao", text="Shading")
        sub = row.row(align=True)
        sub.enabled = scene.ps_radar_ao
        sub.prop(scene, "ps_radar_ao_strength", text="Strength")
        row = col.row(align=True)
        row.prop(scene, "ps_radar_shadow", text="Outer shadow")
        row.prop(scene, "ps_radar_tints", text="Zone tints")
        col.label(text="Own pictures (instead of the made ones):")
        for i in range(4):
            col.prop(scene, f"ps_radar_image_{i}", text=f"Layer {i}")
        col.label(text="Made at export (slower: the map is walked from its spawns)", icon="INFO")


class MAP_PT_play_workshop(Tab, bpy.types.Panel):
    bl_category = "Play"
    bl_label = "Workshop card"
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):
        scene = context.scene
        col = self.layout.column(align=True)
        col.prop(scene, "ps_author", text="Author")
        col.prop(scene, "ps_description", text="About")
        col.prop(scene, "ps_version", text="Version")
        row = self.layout.row(align=True)
        row.operator("psmap.preview", icon="RESTRICT_RENDER_OFF")
        row.label(text="has a picture" if has_preview() else "no picture yet", icon="CHECKMARK" if has_preview() else "INFO")


# ---------- Pie menus ----------
class MAP_MT_tools_pie(bpy.types.Menu):
    bl_idname = "MAP_MT_tools_pie"
    bl_label = "Brush tools"

    def draw(self, context):
        pie = self.layout.menu_pie()
        # Left, right, down, up, then up-left, up-right, down-left, down-right.
        col = pie.column(align=True)
        op = col.operator("psmap.opening", text="Door", icon="MOD_BOOLEAN")
        op.width, op.height, op.sill = 64, 112, 0
        op = col.operator("psmap.opening", text="Hole", icon="MOD_BOOLEAN")
        op.width, op.height, op.sill = 64, 64, 0
        col.operator("psmap.cut_through", icon="MOD_BOOLEAN")
        op = pie.operator("psmap.opening", text="Window", icon="MOD_BOOLEAN")
        op.width, op.height, op.sill = 48, 48, 40
        col = pie.column(align=True)
        col.operator("psmap.box", icon="MESH_CUBE")
        col.operator("psmap.cylinder", icon="MESH_CYLINDER")
        col.operator("psmap.clip", icon="SCULPTMODE_HLT")
        pie.operator("psmap.draw_brush", icon="ADD")
        pie.operator("psmap.hollow", icon="MOD_SOLIDIFY")
        pie.operator("psmap.resize", text="Resize", icon="FULLSCREEN_ENTER")
        pie.operator("psmap.stairs", icon="MOD_ARRAY")
        pie.operator("psmap.arch", icon="SPHERECURVE")


class MAP_MT_materials_pie(bpy.types.Menu):
    bl_idname = "MAP_MT_materials_pie"
    bl_label = "Materials"

    def draw(self, context):
        pie = self.layout.menu_pie()
        col = pie.column(align=True)
        col.label(text="Colours")
        for name, _ in DEV:
            col.operator("psmap.material", text=name[4:]).name = name
        col = pie.column(align=True)
        col.label(text="Tools")
        for tool, name, _, tip in TOOLS:
            col.operator("psmap.material", text=name[5:]).name = name
        box = pie.box()
        box.label(text="Surfaces")
        grid = box.grid_flow(columns=3, align=True)
        for surface, name, _ in DEV_SURFACES:
            grid.operator("psmap.material", text=name[4:]).name = name


class MAP_OT_nudge(bpy.types.Operator):
    bl_idname = "psmap.nudge"
    bl_label = "Nudge"
    bl_description = "The selected one grid step that way in the view under the mouse (Hammer's arrow keys)"
    bl_options = {"REGISTER", "UNDO"}
    dx: bpy.props.IntProperty(options={"HIDDEN"})
    dy: bpy.props.IntProperty(options={"HIDDEN"})

    def invoke(self, context, event):
        if not is_map_file(context.scene) or context.region_data is None or not context.selected_objects:
            return {"PASS_THROUGH"}  # another file, another editor: Blender's own keys (frames)
        from mathutils import Vector
        rot = context.region_data.view_rotation
        right, up = rot @ Vector((1, 0, 0)), rot @ Vector((0, 1, 0))
        if context.region_data.view_perspective != "ORTHO":
            # The 3D view: along the floor (up: away from the eye).
            right.z = up.z = 0.0
            if up.length < 1e-6:
                up = rot @ Vector((0, 0, -1))
                up.z = 0.0

        def axis_of(v):
            k = max(range(3), key=lambda i: abs(v[i]))
            out = Vector()
            out[k] = 1.0 if v[k] > 0 else -1.0
            return out
        move = axis_of(right) * self.dx + axis_of(up) * self.dy
        step = context.scene.ps_grid_units * UNIT
        for o in context.selected_objects:
            if o.parent is None or not o.parent.select_get():
                o.location += move * step
        return {"FINISHED"}


class MAP_OT_pie(bpy.types.Operator):
    bl_idname = "psmap.pie"
    bl_label = "Map tools menu"
    bl_description = "The brush tools (Q) or the materials (Shift+Q) round the mouse, in a map file"
    menu: bpy.props.StringProperty()

    def invoke(self, context, event):
        if not is_map_file(context.scene):
            return {"PASS_THROUGH"}  # another file: Blender's own key
        bpy.ops.wm.call_menu_pie(name=self.menu)
        return {"FINISHED"}


CLASSES = [MAP_PT_build_grid, MAP_PT_build_brushes, MAP_PT_build_tools, MAP_PT_build_materials, MAP_PT_object,
           MAP_PT_entities, MAP_PT_view_groups, MAP_PT_view_overlays, MAP_PT_view_timings, MAP_PT_play, MAP_PT_play_light, MAP_PT_play_share, MAP_PT_play_more,
           MAP_PT_play_radar, MAP_PT_play_workshop, MAP_MT_tools_pie, MAP_MT_materials_pie, MAP_OT_pie,
           MAP_OT_selected_popup, MAP_OT_nudge]
_keys = []


def register():
    for c in CLASSES:
        bpy.utils.register_class(c)
    kc = bpy.context.window_manager.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name="Object Mode", space_type="EMPTY")
        for key, shift, menu in (("Q", False, "MAP_MT_tools_pie"), ("Q", True, "MAP_MT_materials_pie")):
            kmi = km.keymap_items.new("psmap.pie", key, "PRESS", shift=shift)
            kmi.properties.menu = menu
            _keys.append((km, kmi))
        _keys.append((km, km.keymap_items.new("psmap.selected_popup", "F", "PRESS")))
        # Ctrl+Z after changing a tool's panel (F9): the settings before, not the whole tool (else Blender's undo).
        _keys.append((km, km.keymap_items.new("psmap.panel_undo", "Z", "PRESS", ctrl=True)))
        for key, dx, dy in (("LEFT_ARROW", -1, 0), ("RIGHT_ARROW", 1, 0), ("UP_ARROW", 0, 1), ("DOWN_ARROW", 0, -1)):
            kmi = km.keymap_items.new("psmap.nudge", key, "PRESS", repeat=True)
            kmi.properties.dx, kmi.properties.dy = dx, dy
            _keys.append((km, kmi))


def unregister():
    for km, kmi in _keys:
        km.keymap_items.remove(kmi)
    _keys.clear()
    for c in reversed(CLASSES):
        bpy.utils.unregister_class(c)
